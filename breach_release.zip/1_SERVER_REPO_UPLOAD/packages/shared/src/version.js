export const BREACH_VERSION = "2.21.0";
export const BUILD_LABEL = "arsenal";
export const PROTOCOL_VERSION = 113;
