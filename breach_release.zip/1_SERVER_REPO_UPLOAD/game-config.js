export const APP_VERSION = '1.37.54';
export const PROTOCOL_VERSION = 66;
export const ROOM_CODE_LENGTH = 4;
export const MAX_PLAYERS = 8;
export const MAX_BOTS = 8;
export const TEAM_COLORS = { blue:'#54a9ff', red:'#ff3b45' };

export const MAP_ORDER = ['highlands','depot','yard','rig'];
export const DEFAULT_MAP_ID = 'highlands';
export const MAPS = Object.freeze({
  highlands:Object.freeze({id:'highlands',name:'HIGHLANDS',short:'HIGHLANDS',description:'Open highland combat with mixed civilian/industrial buildings, wrecks, walls, ladders, and natural cover.'}),
  depot:Object.freeze({id:'depot',name:'FREIGHT DEPOT',short:'DEPOT',description:'Industrial freight yard with varied warehouses, vehicle wrecks, service props, ladders, and close flanking routes.'}),
  yard:Object.freeze({id:'yard',name:'CONTAINER YARD',short:'YARD',description:'Compact container arena with wrecks, service cover, a climbable stack, crossing lanes, and fast respawns.'}),
  rig:Object.freeze({id:'rig',name:'DUST RIG',short:'RIG',description:'Compact desert oil yard with varied utility structures, wrecks, ladders, exposed high ground, and fast four-way rotations.'}),
});
export function normalizeMapId(value){const id=String(value||'').toLowerCase();return MAPS[id]?id:DEFAULT_MAP_ID;}
export function mapSpec(value){return MAPS[normalizeMapId(value)];}

export const WEAPON_ORDER = ['pistol','assault','ump','shotgun','semiShotgun','sniper','grenadeLauncher','rpg'];
export const PRIMARY_WEAPONS = ['assault','ump','shotgun','semiShotgun','sniper','grenadeLauncher','rpg'];
export const WEAPON_SPECS = {
  pistol: { name:'PISTOL', short:'PST', mag:12, damage:35, playerPenetrationRetention:.42, reloadMs:900, cooldownMs:180, bulletSpeed:180, lifetimeMs:3200, adsFov:54, sprintOutMs:115, sprintAdsMs:95, pellets:1, headshotMultiplier:1.50, headshotMinDamage:0, falloffStart:26, falloffEnd:60, minDamageScale:.72, recoilPitch:.0209, recoilYaw:.0066, firstShotRecoilScale:.52, recoilMaxPitch:.0528, recoilRecovery:15, recoilRecoveryDelayMs:50 },
  assault: { name:'ASSAULT RIFLE', short:'AR', mag:30, damage:52, playerPenetrationRetention:.68, reloadMs:1450, cooldownMs:100, bulletSpeed:230, lifetimeMs:3000, adsFov:46, sprintOutMs:180, sprintAdsMs:145, pellets:1, headshotMultiplier:1.50, headshotMinDamage:0, falloffStart:42, falloffEnd:92, minDamageScale:.76, recoilPitch:.01606, recoilYaw:.00748, firstShotRecoilScale:.25, recoilMaxPitch:.209, recoilMaxYaw:.0528, recoilRecovery:10.0, recoilRecoveryDelayMs:60, automatic:true },
  ump: { name:'UMP', short:'UMP', mag:30, damage:42, playerPenetrationRetention:.55, reloadMs:1320, cooldownMs:80, bulletSpeed:210, lifetimeMs:3000, adsFov:49, sprintOutMs:145, sprintAdsMs:115, pellets:1, headshotMultiplier:1.45, headshotMinDamage:0, falloffStart:18, falloffEnd:55, minDamageScale:.56, recoilPitch:.0088, recoilYaw:.00396, firstShotRecoilScale:.22, recoilMaxPitch:.1144, recoilMaxYaw:.0242, recoilRecovery:15.0, recoilRecoveryDelayMs:45, automatic:true },
  shotgun: { name:'PUMP SHOTGUN', short:'SG', mag:6, damage:16, playerPenetrationRetention:.22, centerPelletDamageScale:2.0, reloadMs:620, cooldownMs:800, bulletSpeed:200, lifetimeMs:1700, adsFov:52, sprintOutMs:220, sprintAdsMs:175, pellets:8, headshotMultiplier:1.10, headshotMinDamage:0, falloffStart:10, falloffEnd:26, minDamageScale:.38, recoilPitch:.0385, recoilYaw:.00924, firstShotRecoilScale:.78, recoilMaxPitch:.0572, recoilRecovery:9.5, recoilRecoveryDelayMs:80, shellReload:true },
  semiShotgun: { name:'SEMI-AUTO SHOTGUN', short:'SAS', mag:8, damage:12, playerPenetrationRetention:.18, centerPelletDamageScale:1.0, reloadMs:1550, cooldownMs:330, bulletSpeed:200, lifetimeMs:1750, adsFov:51, sprintOutMs:205, sprintAdsMs:165, pellets:8, headshotMultiplier:1.10, headshotMinDamage:0, falloffStart:9, falloffEnd:24, minDamageScale:.36, recoilPitch:.0297, recoilYaw:.01144, firstShotRecoilScale:.56, recoilMaxPitch:.0704, recoilRecovery:9, recoilRecoveryDelayMs:70 },
  sniper: { name:'SNIPER', short:'SNP', mag:5, damage:110, playerPenetrationRetention:.92, lowerBodyDamageScale:.82, armDamageScale:.82, reloadMs:1650, cooldownMs:1050, bulletSpeed:480, lifetimeMs:2400, adsFov:18, sprintOutMs:285, sprintAdsMs:235, pellets:1, headshotMultiplier:1.50, headshotMinDamage:0, falloffStart:115, falloffEnd:190, minDamageScale:.92, recoilPitch:.0638, recoilYaw:.01056, firstShotRecoilScale:.82, recoilMaxPitch:.0836, recoilRecovery:8.2, recoilRecoveryDelayMs:90 },
  grenadeLauncher: { name:'GRENADE LAUNCHER', short:'GL', mag:1, damage:30, playerPenetrationRetention:0, reloadMs:1650, cooldownMs:1100, bulletSpeed:34, lifetimeMs:3000, adsFov:52, sprintOutMs:245, sprintAdsMs:200, pellets:1, headshotMultiplier:1, headshotMinDamage:0, falloffStart:999, falloffEnd:1000, minDamageScale:1, recoilPitch:.044, recoilYaw:.00836, firstShotRecoilScale:.76, recoilMaxPitch:.066, recoilRecovery:8.4, recoilRecoveryDelayMs:100, projectileGravity:13.5, launchPitchDeg:5.0, explosionRadius:6.8, explosionDamage:140 },
  rpg: { name:'RPG', short:'RPG', mag:1, damage:35, playerPenetrationRetention:0, reloadMs:2200, cooldownMs:1450, bulletSpeed:50, lifetimeMs:4300, adsFov:50, sprintOutMs:310, sprintAdsMs:255, pellets:1, headshotMultiplier:1, headshotMinDamage:0, falloffStart:999, falloffEnd:1000, minDamageScale:1, recoilPitch:.0528, recoilYaw:.00748, firstShotRecoilScale:.82, recoilMaxPitch:.0748, recoilRecovery:7.6, recoilRecoveryDelayMs:110, projectileGravity:0, explosionRadius:8.2, explosionDamage:165 },
};
// Accuracy is centered on the reticle. Movement, stance, airborne state and
// sustained-fire heat widen the cone around that center; they never offset the
// cone sideways from the player's aim direction.
export const WEAPON_ACCURACY = {
  pistol: { hipDeg:1.15, adsDeg:0.09, moveDeg:0.62, adsMoveScale:0.36, airborneDeg:1.55, crouchScale:0.78, slideDeg:.72, fireDeg:0.30, fireMaxDeg:1.05, heatRecoveryMs:170 },
  assault: { hipDeg:1.85, adsDeg:0.06, moveDeg:0.90, adsMoveScale:0.30, airborneDeg:1.85, crouchScale:0.78, slideDeg:1.10, fireDeg:0.20, fireMaxDeg:1.00, heatRecoveryMs:215 },
  ump: { hipDeg:1.45, adsDeg:0.095, moveDeg:0.68, adsMoveScale:0.28, airborneDeg:1.65, crouchScale:0.80, slideDeg:.82, fireDeg:0.24, fireMaxDeg:1.15, heatRecoveryMs:195 },
  shotgun: { hipDeg:4.60, adsDeg:2.70, moveDeg:1.00, adsMoveScale:0.52, airborneDeg:1.60, crouchScale:0.88, slideDeg:.78, fireDeg:0.04, fireMaxDeg:0.15, heatRecoveryMs:230 },
  semiShotgun: { hipDeg:5.00, adsDeg:3.00, moveDeg:1.08, adsMoveScale:0.54, airborneDeg:1.70, crouchScale:0.90, slideDeg:.86, fireDeg:0.18, fireMaxDeg:0.72, heatRecoveryMs:280 },
  sniper: { hipDeg:6.50, adsDeg:0.02, moveDeg:1.70, adsMoveScale:0.25, airborneDeg:3.40, crouchScale:0.75, slideDeg:2.10, fireDeg:0.04, fireMaxDeg:0.12, heatRecoveryMs:320 },
  grenadeLauncher: { hipDeg:1.35, adsDeg:0.22, moveDeg:0.78, adsMoveScale:0.40, airborneDeg:1.65, crouchScale:0.86, slideDeg:1.05, fireDeg:0.04, fireMaxDeg:0.08, heatRecoveryMs:340 },
  rpg: { hipDeg:1.80, adsDeg:0.28, moveDeg:0.95, adsMoveScale:0.42, airborneDeg:2.00, crouchScale:0.88, slideDeg:1.25, fireDeg:0.04, fireMaxDeg:0.08, heatRecoveryMs:380 },
};

function clamp01(value){return Math.max(0,Math.min(1,Number(value)||0));}
export function weaponHeatAfterDelay(weapon,heat,deltaMs){
  const accuracy=WEAPON_ACCURACY[weapon]||WEAPON_ACCURACY.pistol,recovery=Math.max(40,Number(accuracy.heatRecoveryMs)||200),dt=Math.max(0,Number(deltaMs)||0);
  return Math.max(0,(Number(heat)||0)*Math.exp(-dt/recovery));
}
export function weaponHeatAfterShot(weapon,heat){
  const accuracy=WEAPON_ACCURACY[weapon]||WEAPON_ACCURACY.pistol,maxHeat=Math.max(1,(Number(accuracy.fireMaxDeg)||0)/Math.max(.001,Number(accuracy.fireDeg)||.001));
  return Math.min(maxHeat,Math.max(0,Number(heat)||0)+1);
}
export function weaponSpreadRadians(weapon,moveSpeed,runSpeed,adsAmount=0,crouched=false,airborne=false,shotHeat=0,sliding=false){
  const accuracy=WEAPON_ACCURACY[weapon]||WEAPON_ACCURACY.pistol,ads=clamp01(adsAmount),moveRatio=Math.max(0,Math.min(1,(Number(moveSpeed)||0)/Math.max(.1,Number(runSpeed)||.1)));
  // CoD-style iron/scope ADS is sight-authoritative for single-projectile guns:
  // at full ADS the visible sight point is the shot direction. Recoil moves that
  // aim ray; a hidden random cone must not move the bullet away from the post.
  if(ads>=.985&&(weapon==='pistol'||weapon==='assault'||weapon==='ump'||weapon==='sniper'))return 0;
  const base=accuracy.hipDeg+(accuracy.adsDeg-accuracy.hipDeg)*ads,moveScale=1+(accuracy.adsMoveScale-1)*ads;
  let degrees=base+accuracy.moveDeg*moveRatio*moveScale;
  if(airborne)degrees+=accuracy.airborneDeg*(1-.18*ads);
  if(sliding&&!airborne)degrees+=Math.max(0,Number(accuracy.slideDeg)||0)*(1-.28*ads);
  else if(crouched&&!airborne)degrees*=accuracy.crouchScale;
  const firePenalty=Math.min(accuracy.fireMaxDeg,Math.max(0,Number(shotHeat)||0)*accuracy.fireDeg)*(1-.42*ads);
  degrees+=firePenalty;
  return Math.max(0,degrees)*Math.PI/180;
}

export function weaponDamageAtDistance(weapon,baseDamage,distance,headshot=false){
  const spec=WEAPON_SPECS[weapon]||WEAPON_SPECS.pistol,base=Math.max(0,Number(baseDamage)||0),d=Math.max(0,Number(distance)||0);
  const start=Math.max(0,Number(spec.falloffStart)||0),end=Math.max(start+.001,Number(spec.falloffEnd)||start+.001),minScale=Math.max(0,Math.min(1,Number(spec.minDamageScale)||1));
  const t=Math.max(0,Math.min(1,(d-start)/(end-start))),scaled=base*(1-(1-minScale)*t);
  if(!headshot)return scaled;
  return Math.max(Number(spec.headshotMinDamage)||0,scaled*Math.max(1,Number(spec.headshotMultiplier)||1));
}

export function weaponZoneDamageScale(weapon,zone='upper'){
  const spec=WEAPON_SPECS[weapon]||WEAPON_SPECS.pistol;
  if(zone==='lower')return Math.max(0,Math.min(1,Number(spec.lowerBodyDamageScale) || 1));
  if(zone==='arm')return Math.max(0,Math.min(1,Number(spec.armDamageScale) || 1));
  return 1;
}

export const MOVEMENT_FEEL = Object.freeze({
  groundAcceleration:58,
  groundBraking:78,
  airAcceleration:16,
  coyoteTimeMs:105,
  jumpBufferMs:130,
  sprintSpeedMultiplier:1.28,
  sprintMinForward:0.35,
  sprintMinInput:0.55,
  slideDurationMs:650,
  slideStartSpeedMultiplier:1.72,
  slideEndSpeedMultiplier:0.10,
  slideSteer:0.12,
  slideRecoveryMs:200,
  slideServerGraceMs:900,
});

export const WEAPON_SWITCH_MS = 120;

export const CROUCH_HEIGHT = 1.08;
export const CROUCH_SPEED_MULTIPLIER = 0.62;
export const TACTICAL_EQUIPMENT = ['flash','smoke'];
export const LETHAL_EQUIPMENT = ['sticky','frag'];
export const EQUIPMENT_CAPS = { flash:1, smoke:1, sticky:1, frag:1 };
export const EQUIPMENT_SPECS = Object.freeze({
  flash:Object.freeze({name:'FLASHBANG',short:'FLASH',slot:'tactical'}),
  smoke:Object.freeze({name:'SMOKE GRENADE',short:'SMOKE',slot:'tactical'}),
  sticky:Object.freeze({name:'SEMTEX',short:'SEMTEX',slot:'lethal'}),
  frag:Object.freeze({name:'FRAG GRENADE',short:'FRAG',slot:'lethal'}),
});
export function normalizeTactical(value){return TACTICAL_EQUIPMENT.includes(value)?value:'flash';}
export function normalizeLethal(value){return LETHAL_EQUIPMENT.includes(value)?value:'sticky';}
export function equipmentForLoadout(tactical='flash',lethal='sticky'){
  const out=Object.fromEntries(Object.keys(EQUIPMENT_CAPS).map(name=>[name,0]));
  const t=normalizeTactical(tactical),l=normalizeLethal(lethal);out[t]=EQUIPMENT_CAPS[t];out[l]=EQUIPMENT_CAPS[l];return out;
}

export const GAME_MODE_ORDER = ['tdm','ffa','sandbox'];
export const DEFAULT_GAME_MODE = 'tdm';
export const GAME_MODES = Object.freeze({
  tdm:Object.freeze({id:'tdm',name:'TEAM DEATHMATCH',short:'TDM',teamBased:true,scoreType:'team',scoreLimit:30,timeLimitMs:8*60*1000}),
  ffa:Object.freeze({id:'ffa',name:'FREE FOR ALL',short:'FFA',teamBased:false,scoreType:'player',scoreLimit:20,timeLimitMs:8*60*1000}),
  sandbox:Object.freeze({id:'sandbox',name:'SANDBOX',short:'SANDBOX',teamBased:true,scoreType:'none',scoreLimit:0,timeLimitMs:0}),
});
export function normalizeGameMode(value){const id=String(value||'').toLowerCase();return GAME_MODES[id]?id:DEFAULT_GAME_MODE;}
export function gameModeSpec(value){return GAME_MODES[normalizeGameMode(value)];}
export function gameModeIsTeamBased(value){return !!gameModeSpec(value).teamBased;}
export const DEFAULT_MATCH_RULES = { mode:DEFAULT_GAME_MODE, scoreLimit:GAME_MODES.tdm.scoreLimit, timeLimitMs:GAME_MODES.tdm.timeLimitMs, minimapRevealAll:false, minimapDirectional:false };
export const MATCH_WARMUP_MS = 4000;
export const MATCH_END_MS = 7000;

export const DEFAULT_WORLD_SETTINGS = {
  movement: { runSpeed:8.4, walkSpeed:4.6, jumpHeight:1.6, gravity:23 },
  combat: { regenDelayMs:5000, regenPerSecond:50, respawnMs:2800 },
  weapons: Object.fromEntries(WEAPON_ORDER.map((name) => {
    const spec = WEAPON_SPECS[name];
    return [name, { damage:spec.damage, speed:spec.bulletSpeed, reloadMs:spec.reloadMs, cooldownMs:spec.cooldownMs, recoilScale:100 }];
  })),
};

export function normalizeWorldSettings(value) {
  const v=value&&typeof value==='object'?value:{},movement=v.movement&&typeof v.movement==='object'?v.movement:{},combat=v.combat&&typeof v.combat==='object'?v.combat:{},weapons=v.weapons&&typeof v.weapons==='object'?v.weapons:{};
  const number=(value,fallback)=>Number.isFinite(Number(value))?Number(value):fallback;
  const bounded=(value,min,max,fallback)=>Math.max(min,Math.min(max,number(value,fallback)));
  const weapon=(name)=>{const src=weapons[name]&&typeof weapons[name]==='object'?weapons[name]:{},def=DEFAULT_WORLD_SETTINGS.weapons[name];return{damage:bounded(src.damage,1,400,def.damage),speed:bounded(src.speed,10,800,def.speed),reloadMs:Math.round(bounded(src.reloadMs,100,5000,def.reloadMs)),cooldownMs:Math.round(bounded(src.cooldownMs,50,2500,def.cooldownMs)),recoilScale:bounded(src.recoilScale,0,300,def.recoilScale)}};
  const runSpeed=bounded(movement.runSpeed,3,16,DEFAULT_WORLD_SETTINGS.movement.runSpeed);
  return {
    movement:{runSpeed,walkSpeed:Math.min(runSpeed,bounded(movement.walkSpeed,1.5,9,DEFAULT_WORLD_SETTINGS.movement.walkSpeed)),jumpHeight:bounded(movement.jumpHeight,.4,5,DEFAULT_WORLD_SETTINGS.movement.jumpHeight),gravity:bounded(movement.gravity,8,40,DEFAULT_WORLD_SETTINGS.movement.gravity)},
    combat:{regenDelayMs:Math.round(bounded(combat.regenDelayMs,0,15000,DEFAULT_WORLD_SETTINGS.combat.regenDelayMs)),regenPerSecond:bounded(combat.regenPerSecond,0,100,DEFAULT_WORLD_SETTINGS.combat.regenPerSecond),respawnMs:Math.round(bounded(combat.respawnMs,1000,10000,DEFAULT_WORLD_SETTINGS.combat.respawnMs))},
    weapons:Object.fromEntries(WEAPON_ORDER.map(name=>[name,weapon(name)])),
  };
}

export const TACTICAL_THROW_SPEED = 23.5;
export const TACTICAL_THROW_LOFT = 6.4;
export const TACTICAL_GRAVITY = 18;
export const FLASH_RADIUS = 18;
export const STICKY_RADIUS = 7.2;
export const STICKY_MAX_DAMAGE = 145;
export const FRAG_RADIUS = 7.8;
export const FRAG_MAX_DAMAGE = 150;
export const SMOKE_RADIUS = 9.6;
export const SMOKE_DURATION_MS = 14000;
export const GROUND_FOLLOW_DROP = 0.32;
