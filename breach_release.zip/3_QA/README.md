Breach 1.70.0 — walk-around builder

The main builder opens on flat ground. Pick an object, aim at a surface, and press
Place. Green means ready; red means the object needs more room.

Desktop: drag to look, WASD move, E place, R rotate, Q objects, Ctrl/Cmd Z undo.
Build: Space/up rises and C/down lowers. Test: Space jumps and C crouches.
Touch: left stick moves, right area looks, Place builds, arrows rise/lower.
Controller: sticks move/look, A or RT places, X rotates, Y opens Objects, B undoes,
shoulders rise/lower, Menu switches Build/Test. In Test, A jumps and RB crouches.
Use Move/Copy/Erase, then aim and press the main action button. Picking another object
cancels an unfinished move without deleting anything. Overhead allows objects to be dragged.
Save and Publish retain the existing Breach server routes.

Implemented: 17 model thumbnails generated from compiled geometry; surface picking,
grid/face snapping, collision-aware placement, shared commands/normalization/autosave,
automatic team starts and bot routes, Test jumping/crouching, compiled building-overlap
validation, and reusable GPU scene buffers. The 1.69 shared architecture remains intact.

From the extracted release root with Node 24:
  node 3_QA/test.mjs
  node 3_QA/movement.mjs
  node 3_QA/walk-test.mjs
  node 3_QA/model-test.mjs

Passed: existing 2,489 contract/collision assertions and 48 movement assertions;
all 17 tray items pass actual MapDocument export/reopen geometry signatures and deep
publish validation. Controller tests cover placing, floor stacking, rotated rays,
overlap, erase, menu pause, move cancellation, jumping, landing, crouching and standing.
73 JavaScript modules pass syntax/local dependency checks; server worker imports.

LIMITATION: Node controller tests use a minimal DOM adapter, not a rendered browser.
No browser executable was installed; the attempted Chromium download failed. Mobile
layout, WebGL appearance, native input, hosted publish/reload and a full game playthrough
have NOT been verified. The earlier full gameplay release gate remains open. Builder
Test is a collision preview, not multiplayer combat (no shooting, slide or mantle preview).

collision-lab.breachmap.json remains the flat architecture fixture. In the game console:
  breachCollisionDebug('player')
  breachCollisionDebug('projectile')
  breachCollisionDebug('off')
