import assert from 'node:assert/strict';
import {createAuthoredWorldGeometry} from '../1_SERVER_REPO_UPLOAD/authored-world-geometry.js';
import {createAuthoredWorldCollision} from '../1_SERVER_REPO_UPLOAD/authored-world-collision.js';
import {createAuthoredServerCollision} from '../1_SERVER_REPO_UPLOAD/authored-server-collision.js';
import {sweepHorizontalMovement} from '../1_SERVER_REPO_UPLOAD/movement-model.js';
let checks=0;
for(const rot of [0,33,90,147]){
 const g=createAuthoredWorldGeometry({terrain:{preset:'flat'},buildings:[{assetId:'building/rowhouse',x:0,z:0,rot}]}),c=createAuthoredWorldCollision(g),p=createAuthoredServerCollision(g),a=rot*Math.PI/180;
 const point=(x,z)=>({x:x*Math.cos(a)-z*Math.sin(a),z:x*Math.sin(a)+z*Math.cos(a)});
 const move=(x,z,dx,dz,y=0,height=1.7)=>{const start=point(x,z),delta=point(dx,dz);return sweepHorizontalMovement({...start,y,dx:delta.x,dz:delta.z,grounded:y===0,arenaLimit:120,followDrop:.6,supportHeight:(x,z,y)=>g.worldSupportHeight(x,z,y,false),stepUpHeight:g.worldStepUpHeight,blockedAt:(x,z,y,fx,fz,fy)=>c.worldMoveBlockedAt(x,z,y,fx,fz,height,.38,fy)});};
 const doorway=move(0,-8,0,4);const goal=point(0,-4);assert(Math.hypot(doorway.x-goal.x,doorway.z-goal.z)<.01,'walk through doorway');checks++;
 for(const height of [1.7,1.05,.7]){const stop=move(7,-8,0,4,0,height);assert(Math.hypot(stop.x-goal.x,stop.z-goal.z)>2,'wall stops standing crouch slide');checks++}
 // Exterior wall at the second-storey seam must stay solid during a jump.
 const wall=point(7,-5.82);for(const y of [1,2.9,3.05,3.15,4]){assert(c.worldBlockedAt(wall.x,wall.z,y,1.7,.38),'upper wall remains solid');checks++;}
 const front=point(0,-7),inside=point(0,-5);assert.equal(p.segmentFirstObstacleT(front.x,1.3,front.z,inside.x,1.3,inside.z),null,'doorway shot');checks++;
 const windowA=point(4.56,-7),windowB=point(4.56,-5);assert.equal(p.segmentFirstObstacleT(windowA.x,1.4,windowA.z,windowB.x,1.4,windowB.z),null,'window shot');checks++;
 const floor=point(0,0);assert(g.resolveCeilingCollision(0,2,floor.x,floor.z).hit,'jump hits ceiling');checks++;
}
console.log({movementChecks:checks,passed:true});
