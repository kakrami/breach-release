import assert from 'node:assert/strict';
import {createWalkBuilder,WALK_ITEMS,rayBox,boxesOverlap} from '../2_CLIENT_REPO_UPLOAD/walk-builder.js';
import {createAuthoredWorldGeometry} from '../2_CLIENT_REPO_UPLOAD/authored-world-geometry.js';
import {createAuthoredWorldCollision} from '../2_CLIENT_REPO_UPLOAD/authored-world-collision.js';
// Minimal DOM adapter tests the actual placement controller without pretending to render a browser.
class Element{
 constructor(){this.children=[];this.dataset={};this.hidden=false;this.classList={add(){},remove(){},toggle(){}};this.style={};this.nodes=new Map();this.textContent='';}
 set innerHTML(v){this.html=v;for(const m of v.matchAll(/data-walk="([^"]+)"/g)){const n=new Element();n.dataset.walk=m[1];this.nodes.set('[data-walk="'+m[1]+'"]',n);}for(const name of ['walk-tip','walk-picker','walk-menu','walk-hotbar','walk-items'])this.nodes.set('.'+name,new Element());}
 appendChild(n){this.children.push(n);return n;}replaceChildren(...n){this.children=n;}
 querySelector(s){if(s==='.overlay:not(.hide)')return null;if(!this.nodes.has(s))this.nodes.set(s,new Element());return this.nodes.get(s);}
 querySelectorAll(s){return s==='[data-walk]'?[...this.nodes.values()].filter(n=>n.dataset.walk):[];}
 getContext(){return new Proxy({},{get:()=>()=>{}});}toDataURL(){return 'data:image/png;base64,';}click(){this.onclick?.();}setPointerCapture(){}
}
globalThis.document={createElement:()=>new Element()};globalThis.window={addEventListener(){},prompt(){return null}};
const root=new Element();root.getElementById=id=>root.querySelector('#'+id);
const doc={buildings:[],props:[],elevation:[],naturals:[],spawns:[{x:0,z:12,team:'blue'}],arenaLimit:120,get(id){return [...this.buildings,...this.props,...this.elevation,...this.naturals].find(o=>o.id===id)}};
const compile=()=>createAuthoredWorldGeometry({terrain:{preset:'flat'},buildings:doc.buildings,staticBoxes:doc.props,elevationObjects:doc.elevation,naturalObstacles:doc.naturals.map(o=>({...o,type:o.kind}))});
const e={doc,sceneRev:0,play:{keys:new Set(),moveX:0,moveY:0},runtimePhysical(){const geometry=compile();return {geometry,collision:createAuthoredWorldCollision(geometry)}},startPlay(){Object.assign(this.play,{x:0,z:12,y:1.65,yaw:0,pitch:-.22,active:true})},stopPlay(){this.play.active=false},commands:{undo(){},redo(){}}};
const group=o=>o.type==='building'?doc.buildings:o.type==='prop'?doc.props:o.type==='elevation'?doc.elevation:doc.naturals;
let id=0;
const walk=createWalkBuilder({editor:e,root,isActive:()=>true,makeId:()=>`p${++id}`,prepareStarts(){},add:o=>{group(o).push(o);e.sceneRev++},remove:id=>{const o=doc.get(id),list=group(o);list.splice(list.indexOf(o),1);e.sceneRev++},patch:(b,a)=>{Object.assign(b,a);e.sceneRev++}});
walk.enter();walk.choose(WALK_ITEMS.find(o=>o.key==='crate'));walk.update();assert(walk.state.valid);const first={...walk.state.ghost.object};walk.commit();assert.equal(doc.props.length,1);
// Aim down onto the crate to stack a floor using the real ray and compiler.
e.play.x=first.x;e.play.z=first.z+3;e.play.y=4;e.play.pitch=-.7;walk.choose(WALK_ITEMS.find(o=>o.key==='floor'));walk.update();assert(walk.state.target.object);assert.equal(walk.state.target.ny,1);assert(walk.state.valid,walk.state.reason);assert(Math.abs(walk.state.ghost.object.yOffset-1.5)<.01);walk.commit();assert.equal(doc.props.length,2);
// Surface-contact stacking and rotated overlap checks.
assert.equal(boxesOverlap({x:0,z:0,w:4,d:4,minY:0,maxY:1.5},{x:0,z:0,w:4,d:4,minY:1.5,maxY:1.7}),false);
assert.equal(boxesOverlap({x:0,z:0,w:4,d:1,rot:33,minY:0,maxY:3},{x:0,z:0,w:1,d:4,minY:1,maxY:2}),true);
for(const angle of [0,33,90,147]){const a=angle*Math.PI/180,hit=rayBox({x:Math.sin(a)*8,y:1,z:-Math.cos(a)*8},{x:-Math.sin(a),y:0,z:Math.cos(a)},{x:0,z:0,w:4,d:2,minY:0,maxY:3,rot:angle});assert(hit);assert(Math.abs(hit.t-7)<1e-6);}
// Erase uses aimed object, and movement pauses while object tray is open.
walk.action('erase');walk.update();const target=walk.state.target.object.id;walk.commit();assert.equal(doc.get(target),undefined);
walk.action('pick');const before=e.play.x;e.play.moveX=1;walk.motion(.1);assert.equal(e.play.x,before);walk.closePanels();e.play.moveX=1;walk.motion(.1);assert(e.play.x>before);
// Moving an object is non-destructive until placement is committed.
walk.choose(WALK_ITEMS.find(o=>o.key==='crate'));e.play.x=first.x;e.play.z=first.z+5;e.play.y=2;e.play.pitch=-.2;walk.action('move');walk.update();assert(walk.state.target.object);const moving=walk.state.target.object.id;walk.commit();assert(doc.get(moving));assert.equal(walk.state.moveId,moving);walk.choose(WALK_ITEMS[0]);assert(doc.get(moving));assert.equal(walk.state.moveId,null);
console.log('Walk controller: place, stack, rotated ray picking, overlap, erase, pause, move cancellation passed.');

walk.action('test');e.play.x=40;e.play.z=40;e.play.y=1.65;e.play.keys.clear();e.play.moveX=e.play.moveY=0;e.play.keys.add(' ');walk.motion(.016);assert(e.play.y>1.65);e.play.keys.delete(' ');for(let i=0;i<120;i++)walk.motion(.016);assert(Math.abs(e.play.y-1.65)<.001);e.play.keys.add('c');walk.motion(.016);assert.equal(walk.state.eye,1);e.play.keys.clear();walk.motion(.016);assert.equal(walk.state.eye,1.65);console.log('Test mode: jump, landing, crouch and stand passed.');
