import fs from 'node:fs';
import assert from 'node:assert/strict';
const path='2_CLIENT_REPO_UPLOAD/model-test-temp.mjs';let source=fs.readFileSync('2_CLIENT_REPO_UPLOAD/map-builder.js','utf8');source=source.slice(0,source.indexOf('const editor=new Editor();'))+'return {MapDocument,RuntimeCompiler,Validator,templateToDoc,ModelRules,Resolver,AddCommand,DeleteCommand,PatchCommand,CommandStack};\n}';fs.writeFileSync(path,source);
try{
 const {createIntegratedMapBuilder}=await import('../'+path);const model=createIntegratedMapBuilder({host:{shadowRoot:{innerHTML:'',getElementById:()=>null}}});
 const {WALK_ITEMS}=await import('../2_CLIENT_REPO_UPLOAD/walk-builder.js');
 for(const [i,item] of WALK_ITEMS.entries()){
  const d=model.templateToDoc('blank');const o={...item,x:0,z:0,rot:90,yOffset:item.key==='floor'?3.1:0,id:'placed-'+i};d.add(o);model.ModelRules.normalizeDocument(d);model.Resolver.resolve(d);
  const result=model.RuntimeCompiler.parity(d,model.RuntimeCompiler.exportContract(d));if(!result.ok){const round=new model.MapDocument(model.RuntimeCompiler.exportContract(d));console.log(item.key,model.RuntimeCompiler.semanticFingerprint(d),model.RuntimeCompiler.semanticFingerprint(round));}assert(result.ok,item.key+': '+result.issues.join('; '));const blockers=model.Validator.validate(d,true).filter(i=>i.tone==='bad');assert.equal(blockers.length,0,item.key+': '+blockers.map(b=>b.text).join('; '));
 }
 const blank=model.templateToDoc('blank');assert.equal(blank.spawns.length,8);assert.equal(model.Validator.validate(blank).filter(i=>i.tone==='bad').length,0);
 console.log('All 17 walk items pass actual MapDocument export/reopen geometry parity and deep publish validation; blank map starts valid.');
}finally{fs.unlinkSync(path)}
