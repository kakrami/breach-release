import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createAuthoredWorldGeometry as compile} from '../1_SERVER_REPO_UPLOAD/authored-world-geometry.js';
import {createAuthoredWorldGeometry as clientCompile} from '../2_CLIENT_REPO_UPLOAD/authored-world-geometry.js';
import {createAuthoredWorldCollision as collision} from '../1_SERVER_REPO_UPLOAD/authored-world-collision.js';
import {createAuthoredServerCollision as projectile} from '../1_SERVER_REPO_UPLOAD/authored-server-collision.js';
import {createProjectileCollisionGrid} from '../2_CLIENT_REPO_UPLOAD/collision-grid.js';
import {sanitizeUploadedMapDefinition as publish,sanitizeBuilderDraftDefinition as draft} from '../1_SERVER_REPO_UPLOAD/uploaded-map.js';
import {geometrySignature,authoredYaw} from '../1_SERVER_REPO_UPLOAD/geometry-contract.js';
import {BUILDING_ASSETS,PROP_ASSETS,ELEVATION_ASSETS,resolveAsset} from '../1_SERVER_REPO_UPLOAD/object-catalog.js';
import {OFFICIAL_MAP_DEFINITIONS} from '../1_SERVER_REPO_UPLOAD/official-map-definitions.js';
let checks=0;const eq=(a,b,msg)=>{assert.deepEqual(a,b,msg);checks++};
const base={schema:'breach-authored-map',schemaVersion:3,meta:{id:'collision-lab',name:'COLLISION LAB'},theme:'flat',arenaLimit:300,minimapLimit:280,terrain:{preset:'flat'},spawnSets:{blue:[[-270,-270]],red:[[270,270]],ffa:[[-270,-270],[270,270]]}};
const lab={...base,buildings:[],staticBoxes:[],elevationObjects:[],ladders:[]};let index=0;
for(const [archetype,preset] of Object.entries(BUILDING_ASSETS))for(const rot of [0,33,90,147]){
 const scale=rot===147?1.25:1,x=(index%8)*65-235,z=Math.floor(index/8)*72-220;index++;
 lab.buildings.push({id:`b${index}`,archetype,...preset,x,z,rot,w:preset.w*scale,d:preset.d*scale});
}
index=0;for(const [kind,p] of Object.entries(PROP_ASSETS))for(const rot of [0,37]){lab.staticBoxes.push({...p,kind,x:(index%12)*35-215,z:110+Math.floor(index/12)*40,rot});index++}
index=0;for(const [kind,p] of Object.entries(ELEVATION_ASSETS))for(const rot of [0,31,90]){lab.elevationObjects.push({...p,kind,x:index*36-210,z:245,rot});index++}
lab.ladders.push({id:'lab-ladder',x:-243.08,z:-220,nx:-1,nz:0,width:1.2,bottomY:0,topY:6.2});
const saved=draft(lab),published=publish(saved),world=compile(published),sig=geometrySignature(world);
eq(geometrySignature(clientCompile(published)),sig,'client/server compiler parity');
for(const stage of [saved,published,publish(JSON.parse(JSON.stringify(published))),draft(JSON.parse(JSON.stringify(saved)))])eq(geometrySignature(compile(stage)),sig,'save/reopen/export/publication parity');
for(const b of published.buildings)eq(b.assetId,`building/${b.archetype}`,'identity preserved');
for(const [id,suffix] of [['highlands',''],['depot','-depot'],['yard','-yard'],['rig','-rig']]){
 const official=await import(`../1_SERVER_REPO_UPLOAD/world-geometry${suffix}.js`);
 const custom=compile(publish(OFFICIAL_MAP_DEFINITIONS[id]));
 eq(geometrySignature(official),geometrySignature(custom),id+' official/custom parity');
}
// Every wall cell blocks movement and projectiles across its local normal at all tested rotations.
let wallChecks=0;
const wc=collision(world),pc=projectile(world),cc=createProjectileCollisionGrid({staticBoxes:world.STATIC_BOXES,staticColliders:world.STATIC_PROJECTILE_COLLIDERS,pyramids:world.PYRAMIDS,naturalObstacles:world.NATURAL_OBSTACLES,buildingParts:world.BUILDING_PARTS,terrainHeight:world.terrainHeight,naturalGroundBase:world.naturalGroundBase});
for(const part of world.BUILDING_PARTS.filter(p=>p.role==='wall')){
 const y=(part.bottomY+part.topY)/2,a=part.rot*Math.PI/180,n=part.w>part.d?[-Math.sin(a),Math.cos(a)]:[Math.cos(a),Math.sin(a)],r=[part.x-n[0],y,part.z-n[1],part.x+n[0],y,part.z+n[1]];
 assert(pc.segmentFirstObstacleT(...r)!==null,'wall stops shot');eq(pc.segmentFirstObstacleT(...r),cc.firstHitT(...r),'projectile parity');
 assert(wc.worldBlockedAt(part.x,part.z,part.bottomY+.03,Math.min(.3,part.topY-part.bottomY-.04),.1),'wall blocks player');wallChecks++;
}
// No stale collider after delete or move; old world remains a valid immutable snapshot.
const single=publish({...base,staticBoxes:[{kind:'crate',x:0,z:0,w:4,d:4,h:3,rot:33}]});const old=collision(compile(single));
eq(old.worldBlockedAt(0,0,0),true);single.staticBoxes[0].x=20;const moved=collision(compile(single));eq(moved.worldBlockedAt(0,0,0),false);eq(moved.worldBlockedAt(20,0,0),true);single.staticBoxes=[];eq(collision(compile(single)).worldBlockedAt(20,0,0),false);eq(old.worldBlockedAt(0,0,0),true);
// Coordinate basis agrees with Three.js positive-Y rotation semantics.
for(const deg of [15,33,90,147,270]){const a=deg*Math.PI/180,yaw=authoredYaw(deg);assert(Math.abs(-Math.sin(yaw)-Math.sin(a))<1e-12);checks++}
eq(resolveAsset({assetId:'building/warehouse'}).w,28);
assert.throws(()=>publish({...base,buildings:[{assetId:'building/no-such-model'}]}));checks++;
fs.writeFileSync('3_QA/collision-lab.breachmap.json',JSON.stringify(published,null,2));
fs.writeFileSync('3_QA/test-results.json',JSON.stringify({checks,wallChecks,signature:sig,buildings:lab.buildings.length,props:lab.staticBoxes.length,elevation:lab.elevationObjects.length,passed:true},null,2));
console.log({checks,wallChecks,signature:sig,passed:true});
