import { appendTerrainRoad, roadPolygon, subtractRoadPolygon } from './road-path.js?v=2.5.0';
let EditorScene;
import { BUILDING_MATERIALS } from './object-catalog.js?v=2.5.0';
import { authoredYaw, collisionDebugShapes } from './geometry-contract.js?v=2.5.0';
import { createMoonSky } from './mod-environment.js?v=2.5.0';
window.__breachModuleBooted=true;
import * as HighlandsGeometry from './world-geometry.js?v=2.5.0';
import * as DepotGeometry from './world-geometry-depot.js?v=2.5.0';
import * as YardGeometry from './world-geometry-yard.js?v=2.5.0';
import * as RigGeometry from './world-geometry-rig.js?v=2.5.0';
import * as HighlandsWorldCollision from './world-collision.js?v=2.5.0';
import * as DepotWorldCollision from './world-collision-depot.js?v=2.5.0';
import * as YardWorldCollision from './world-collision-yard.js?v=2.5.0';
import * as RigWorldCollision from './world-collision-rig.js?v=2.5.0';
import {
  APP_VERSION, BUILD_ID, PROTOCOL_VERSION, ROOM_CODE_LENGTH, MAX_PLAYERS, MAX_BOTS_PER_TEAM, MAX_MATCH_BOTS, REPLAY_PRE_MS, REPLAY_POST_MS, REPLAY_FINAL_SLOW_PRE_MS, REPLAY_FINAL_SLOW_POST_MS, REPLAY_FINAL_SLOW_RATE, WEAPON_ORDER, PRIMARY_WEAPONS, SECONDARY_WEAPONS, WEAPON_SPECS, ATTACHMENT_SLOTS, ATTACHMENTS, normalizeWeaponAttachments, attachmentOptionsForWeapon, attachmentModsForWeapon, attachmentAccuracyModsForWeapon, attachmentAdsMoveAddForWeapon, resolveWeaponSpec, resolveWeaponAccuracy, attachmentSoundScale, weaponHasAttachment, weaponSpreadRadians, weaponHeatAfterDelay, weaponHeatAfterShot, CROUCH_HEIGHT, CROUCH_SPEED_MULTIPLIER, EQUIPMENT_CAPS, EQUIPMENT_SPECS, TACTICAL_EQUIPMENT, LETHAL_EQUIPMENT, normalizeTactical, normalizeLethal, equipmentForLoadout, LOADOUT_CLASS_COUNT, LOADOUT_CLASS_IDS, normalizeLoadoutClassId, normalizeLoadoutClassName, normalizeLoadoutDefinition, defaultLoadoutClasses, normalizeLoadoutClasses, loadoutClassById,
  DEFAULT_WORLD_SETTINGS, DEFAULT_MATCH_RULES, GAME_MODES, DEFAULT_GAME_MODE, normalizeGameMode, gameModeSpec, normalizeWorldSettings, normalizeGameMod, gameModSpec, GAME_MOD_ORDER, modMovement, modGravity, MOVEMENT_FEEL, WEAPON_SWITCH_MS, EQUIPMENT_THROW_COMMIT_MS, EQUIPMENT_WEAPON_RECOVER_MS, TACTICAL_THROW_SPEED, TACTICAL_THROW_LOFT, TACTICAL_GRAVITY, equipmentCollisionRadius, SMOKE_DURATION_MS, SMOKE_LOS_RADIUS_SCALE, SMOKE_GROW_MS, SMOKE_START_SCALE, GROUND_FOLLOW_DROP,
  DEFAULT_MAP_ID, normalizeMapId, mapSpec, KILLSTREAK_ORDER, KILLSTREAK_SPECS, KILLSTREAK_SELECTION_COUNT, DEFAULT_KILLSTREAK_SELECTION, normalizeKillstreak, normalizeKillstreakSelection
} from './game-config.js?v=2.5.0';
import { RELATIONSHIP, RELATIONSHIP_COLORS, normalizeTeam, otherTeam, teamLabel, teamKey, factionColor, factionUniform, relationshipFor, relationshipColor } from './team-model.js?v=2.5.0';
import { createProjectileCollisionGrid } from './collision-grid.js?v=2.5.0';
import { createAudioEngine } from './audio-engine.js?v=2.5.0';
import { normalizeMatchState as normalizeSharedMatchState } from './match-model.js?v=2.5.0';
import { MATCH_STATUS, matchAllowsLobbyEdits, matchAllowsMovement, matchAllowsCombat, matchPhaseChanged } from './gameplay-phase.js?v=2.5.0';
import { MAX_PLAYER_PHYSICS_STEP_SEC, advanceVerticalMotion, advanceKnockback, sweepHorizontalMovement, createTraversalPlan, traversalPose, tacticalThrowVelocity, LADDER_CLIMB_SPEED, ladderById, ladderFrame, ladderClimbPoint, ladderBottomExitPoint, ladderTopExitPoint, findLadderEntry, ladderClimbStep } from './movement-model.js?v=2.5.0';
import { SHELL_PANEL, createSessionShell, detectInputPlatform } from './app-lifecycle.js?v=2.5.0';
import { GAMEPAD_BUTTON, createGamepadInput } from './gamepad-input.js?v=2.5.0';
import { createControllerRecording } from './controller-recording.js?v=2.5.0';
import { createPointerSessions } from './pointer-sessions.js?v=2.5.0';
import { createSafeStorage } from './browser-storage.js?v=2.5.0';
import { createIntegratedMapBuilder } from './map-builder.js?v=2.5.0';
import { createUiFocusScope } from './ui-focus.js?v=2.5.0';
import { createUiGestures } from './ui-gestures.js?v=2.5.0';
import { CUSTOM_MAP_DEFINITION } from './authored-map-custom.js?v=2.5.0';
import { createAuthoredWorldGeometry, authoredRoadSurfacePolicy, AUTHORED_ROAD_MARKING_POLICY } from './authored-world-geometry.js?v=2.5.0';
import { createAuthoredWorldCollision } from './authored-world-collision.js?v=2.5.0';
import { sanitizeUploadedMapDefinition, customMapSummary, customMapFingerprint, MAX_CUSTOM_MAP_BYTES } from './uploaded-map.js?v=2.5.0';

const preferences=createSafeStorage('localStorage');
const FALLBACK_CUSTOM_MAP_DEFINITION=sanitizeUploadedMapDefinition(CUSTOM_MAP_DEFINITION);
let customMapDefinition=FALLBACK_CUSTOM_MAP_DEFINITION,customMapFingerprintValue=customMapFingerprint(FALLBACK_CUSTOM_MAP_DEFINITION),customMapLoaded=false,customMapSource='fallback';
function compileCustomClientBundle(definition){const safe=sanitizeUploadedMapDefinition(definition),geometry=createAuthoredWorldGeometry(safe),collision=createAuthoredWorldCollision(geometry);return{safe,bundle:Object.freeze({geometry,collision}),summary:customMapSummary(safe),fingerprint:customMapFingerprint(safe)};}
const initialCustom=compileCustomClientBundle(FALLBACK_CUSTOM_MAP_DEFINITION);
let THREE = null;

// A room owns one authoritative map. Built-ins are static; an uploaded map is
// compiled into the same geometry/collision contract before it can be selected.
const {PLAYER_HEIGHT,PLAYER_RADIUS,MAX_STEP_HEIGHT}=HighlandsGeometry;
let ARENA_LIMIT=HighlandsGeometry.ARENA_LIMIT;
const CLIENT_WORLD_BUNDLES={
  highlands:Object.freeze({geometry:HighlandsGeometry,collision:HighlandsWorldCollision}),
  depot:Object.freeze({geometry:DepotGeometry,collision:DepotWorldCollision}),
  yard:Object.freeze({geometry:YardGeometry,collision:YardWorldCollision}),
  rig:Object.freeze({geometry:RigGeometry,collision:RigWorldCollision}),
  'custom-map':initialCustom.bundle,
};
function installCustomMapDefinition(raw,{persist=false,source='local',quiet=false}={}){
  const safe=sanitizeUploadedMapDefinition(raw),fingerprint=customMapFingerprint(safe);let summary;if(customMapLoaded&&fingerprint===customMapFingerprintValue){customMapDefinition=safe;summary=customMapSummary(safe);}else{const geometry=createAuthoredWorldGeometry(safe),collision=createAuthoredWorldCollision(geometry);customMapDefinition=safe;customMapFingerprintValue=fingerprint;CLIENT_WORLD_BUNDLES['custom-map']=Object.freeze({geometry,collision});minimapStaticCache=null;summary=customMapSummary(safe);}
  customMapLoaded=true;customMapSource=source;if(persist){try{preferences.setItem('breachCustomMap',JSON.stringify(safe));}catch{}}updateCustomMapLobbyUi?.();if(!quiet)showToast?.(`CUSTOM MAP LOADED · ${summary.name}`);return summary;
}
function restoreSavedCustomMap(){try{const raw=preferences.getItem('breachCustomMap');if(!raw)return false;installCustomMapDefinition(JSON.parse(raw),{persist:false,source:'saved',quiet:true});return true;}catch{try{preferences.removeItem?.('breachCustomMap');}catch{}return false;}}
function displayMapSpec(value){const id=normalizeMapId(value);if(id==='custom-map'&&customMapLoaded){const base=mapSpec(id),name=String(customMapDefinition?.meta?.name||'CUSTOM MAP').slice(0,64);return{...base,name,short:name.length>18?name.slice(0,17)+'…':name};}return mapSpec(id);}
let currentMapId=DEFAULT_MAP_ID,activeCustomMapFingerprint='';
let worldGeometry=HighlandsGeometry;
let activeWorldCollision=HighlandsWorldCollision;
let ROADS=worldGeometry.ROADS||[],STATIC_BOXES=worldGeometry.STATIC_BOXES,STATIC_PROJECTILE_COLLIDERS=worldGeometry.STATIC_PROJECTILE_COLLIDERS||null,BUILDINGS=worldGeometry.BUILDINGS,PYRAMIDS=worldGeometry.PYRAMIDS,NATURAL_OBSTACLES=worldGeometry.NATURAL_OBSTACLES,LADDERS=worldGeometry.LADDERS||[];
let TERRAIN_SIZE=worldGeometry.TERRAIN_SIZE,TERRAIN_SEGMENTS=worldGeometry.TERRAIN_SEGMENTS,BUILDING_GEOMETRY=worldGeometry.BUILDING_GEOMETRY,BUILDING_PARTS=worldGeometry.BUILDING_PARTS;
let terrainHeight=worldGeometry.terrainHeight,naturalGroundBase=worldGeometry.naturalGroundBase,worldSupportHeight=worldGeometry.worldSupportHeight,worldStepUpHeight=worldGeometry.worldStepUpHeight,resolveCeilingCollision=worldGeometry.resolveCeilingCollision,groundMaterialCode=worldGeometry.groundMaterialCode||(()=>0),authoredEnvironment=worldGeometry.AUTHORED_ENVIRONMENT||null;
function worldBlockedAt(...args){return activeWorldCollision.worldBlockedAt(...args);}
function worldMoveBlockedAt(...args){return activeWorldCollision.worldMoveBlockedAt(...args);}
function worldHeightExpansionBlockedAt(...args){return activeWorldCollision.worldHeightExpansionBlockedAt(...args);}
function findTraversalCandidate(...args){return activeWorldCollision.findTraversalCandidate(...args);}

// Change only this line if Cloudflare gives your Worker a different URL.
const GRENADE_LAUNCH_PITCH=(Number(WEAPON_SPECS.grenadeLauncher?.launchPitchDeg)||0)*Math.PI/180;
const ONLINE_API = 'https://breach-online.kiadesignenterprise.workers.dev';
let mapGalleryTab='official',mapLibraryMine=[],mapLibraryLoading=false,selectedLibraryMap=null;
const OFFICIAL_MAP_GALLERY=Object.freeze([
 {id:'highlands',name:'HIGHLANDS',detail:'Open terrain',source:'official'},
 {id:'depot',name:'FREIGHT DEPOT',detail:'Industrial lanes',source:'official'},
 {id:'yard',name:'CONTAINER YARD',detail:'Dense cover',source:'official'},
 {id:'rig',name:'DUST RIG',detail:'Close quarters',source:'official'}
]);
async function mapLibraryRequest(path,payload={}){const response=await fetch(`${ONLINE_API}${path}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({client:clientId,auth:clientAuth,...payload}),cache:'no-store'});let data={};try{data=await response.json();}catch{}if(!response.ok)throw new Error(data.error||'Map library unavailable.');return data;}
async function refreshMapLibrary({quiet=false}={}){if(mapLibraryLoading)return;mapLibraryLoading=true;try{const data=await mapLibraryRequest('/maps/list');mapLibraryMine=Array.isArray(data.mine)?data.mine:[];if(selectedLibraryMap?.id&&!mapLibraryMine.some(entry=>entry.id===selectedLibraryMap.id)){selectedLibraryMap=null;if((lobbyMapDraft||currentMapId)==='custom-map'&&customMapSource==='library')setLobbyMapDraft(DEFAULT_MAP_ID);}renderMapGallery();}catch(error){if(!quiet)showToast(`MAP LIBRARY · ${String(error?.message||'unavailable').slice(0,70)}`);}finally{mapLibraryLoading=false;}}
function libraryMapLabel(entry){return String(entry?.name||'UNTITLED MAP').toUpperCase().slice(0,40);}
function renderMapGallery(){const host=$('lobbyMapGallery');if(!host)return;const manageable=mapGalleryTab==='mine'&&!!selectedLibraryMap?.id&&isMatchAdmin&&matchAllowsLobbyEdits(matchState);const editBtn=$('lobbyEditMapBtn'),deleteBtn=$('lobbyDeleteMapBtn');if(editBtn)editBtn.disabled=!manageable;if(deleteBtn)deleteBtn.disabled=!manageable;const editable=isMatchAdmin&&matchAllowsLobbyEdits(matchState);host.replaceChildren();const rows=mapGalleryTab==='mine'?mapLibraryMine:OFFICIAL_MAP_GALLERY;if(!rows.length){const empty=document.createElement('div');empty.className='lobby-map-empty';empty.innerHTML='<div>NO SAVED MAPS YET<br><small>Create a map and save it to your Breach library.</small></div>';host.appendChild(empty);return;}for(const entry of rows){const b=document.createElement('button');b.type='button';b.className='lobby-map-choice';b.dataset.mapSource=entry.source||'user';if(entry.source==='official'){b.dataset.lobbyMapChoice=entry.id;b.disabled=!editable;b.classList.toggle('active',(lobbyMapDraft||currentMapId)===entry.id);b.innerHTML=`<strong>${libraryMapLabel(entry)}</strong><small>${entry.detail||'Official map'}</small>`;b.addEventListener('click',()=>setLobbyMapDraft(entry.id));}else{b.dataset.libraryMapId=entry.id;b.disabled=!editable;b.classList.toggle('active',selectedLibraryMap?.id===entry.id&&(lobbyMapDraft||currentMapId)==='custom-map');const rev=Number(entry.publishedRevision)||0;b.innerHTML=`<strong>${libraryMapLabel(entry)}</strong><small>${rev?`Published · Revision ${rev}`:'Draft only'}</small><span class="map-revision">${entry.summary?.buildings||0} buildings · ${entry.summary?.props||0} props</span>`;b.addEventListener('click',()=>void selectLibraryMap(entry));}host.appendChild(b);}}
async function selectLibraryMap(entry){if(!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return;try{const data=await mapLibraryRequest('/maps/get',{mapId:entry.id,revision:Number(entry.publishedRevision)||0});installCustomMapDefinition(data.definition,{persist:true,source:'library',quiet:true});selectedLibraryMap={id:entry.id,name:entry.name,revision:data.revision||0};lobbyMapDraft='custom-map';lobbyMapDirty=lobbyMapDraft!==normalizeMapId(currentMapId)||customMapFingerprintValue!==activeCustomMapFingerprint;renderLobbySetupControls();setLobbyActionState();showToast(`MAP READY · ${libraryMapLabel(entry)}`);}catch(error){showToast(`MAP LOAD FAILED · ${String(error?.message||'unavailable').slice(0,80)}`,{priority:3});}}
let pendingMapDelete=null;
function mapDeletePromptOpen(){return !!mapDeleteConfirm&&!mapDeleteConfirm.classList.contains('hide');}
function openMapDeleteConfirm(){if(!(mapGalleryTab==='mine'&&selectedLibraryMap?.id&&isMatchAdmin&&matchAllowsLobbyEdits(matchState)))return false;const entry=mapLibraryMine.find(item=>item.id===selectedLibraryMap.id);if(!entry)return false;pendingMapDelete=entry;const copy=$('mapDeleteConfirmText');if(copy)copy.textContent=`${libraryMapLabel(entry)} and all saved revisions will be removed from My Maps.`;mapDeleteConfirm.classList.remove('hide');clearControllerUiEditing();clearControllerUiFocus();if(controllerInputActive())requestAnimationFrame(()=>setControllerUiFocus($('mapDeleteCancelBtn')));return true;}
function closeMapDeleteConfirm(){if(!mapDeletePromptOpen())return false;pendingMapDelete=null;mapDeleteConfirm.classList.add('hide');clearControllerUiFocus();return true;}
async function confirmMapDelete(){const entry=pendingMapDelete;if(!entry)return false;const label=libraryMapLabel(entry),button=$('mapDeleteConfirmBtn');if(button)button.disabled=true;try{await mapLibraryRequest('/maps/delete',{mapId:entry.id});mapLibraryMine=mapLibraryMine.filter(item=>item.id!==entry.id);if(selectedLibraryMap?.id===entry.id){selectedLibraryMap=null;if((lobbyMapDraft||currentMapId)==='custom-map'&&customMapSource==='library')setLobbyMapDraft(DEFAULT_MAP_ID);}pendingMapDelete=null;mapDeleteConfirm.classList.add('hide');renderMapGallery();updateCustomMapLobbyUi();setLobbyActionState();showToast(`MAP DELETED · ${label}`);void refreshMapLibrary({quiet:true});return true;}catch(error){showToast(`MAP DELETE FAILED · ${String(error?.message||'unavailable').slice(0,80)}`,{priority:3});return false;}finally{if(button)button.disabled=false;}}
let integratedMapBuilder=null,mapBuilderWarmScheduled=false;
let builderSession=null;
function scheduleMapBuilderWarmup(){if(integratedMapBuilder||mapBuilderWarmScheduled)return;mapBuilderWarmScheduled=true;const warm=()=>{mapBuilderWarmScheduled=false;if(integratedMapBuilder||!shell.inLobby)return;try{ensureIntegratedMapBuilder();}catch(error){console.warn('Map builder warmup failed',error);}};if(typeof requestIdleCallback==='function')requestIdleCallback(warm,{timeout:1200});else setTimeout(warm,220);}

function ensureIntegratedMapBuilder(){
  if(integratedMapBuilder)return integratedMapBuilder;
  integratedMapBuilder=createIntegratedMapBuilder({
    host:$('mapBuilderHost'),
    apiBase:ONLINE_API,
    gameRuntime:builderGameRuntime,
    getIdentity:()=>({client:clientId,auth:clientAuth}),
    onSaved:({mapId,published,map}={})=>{
      if(mapId){
        mapGalleryTab='mine';
        selectedLibraryMap={id:mapId,name:map?.name||selectedLibraryMap?.name||'Saved Map',revision:Number(map?.publishedRevision)||Number(selectedLibraryMap?.revision)||0};
        document.querySelectorAll('[data-map-gallery-tab]').forEach(btn=>btn.classList.toggle('active',btn.dataset.mapGalleryTab==='mine'));
      }
      void refreshMapLibrary({quiet:true});
      if(published)showToast('MAP PUBLISHED');
    },
    onExit:({mapId}={})=>{
      shell.exitBuilder();
      switchLobbySide('map');
      if(mapId)mapGalleryTab='mine';
      document.querySelectorAll('[data-map-gallery-tab]').forEach(btn=>btn.classList.toggle('active',btn.dataset.mapGalleryTab===mapGalleryTab));
      void refreshMapLibrary({quiet:true});
      renderMapGallery();
      setLobbyActionState();
    },
  });
  return integratedMapBuilder;
}
async function openIntegratedMapBuilder(mapId=''){
  if(!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return;
  const errorUI=$('mapBuilderError');if(errorUI){errorUI.hidden=true;errorUI.textContent='';}
  try{if(!await ensureThreeEngine())throw new Error('The 3D engine could not start. Check that WebGL is available in this browser.');const builder=ensureIntegratedMapBuilder();shell.enterBuilder();await builder.open({mapId});}
  catch(error){builderGameRuntime.close();if(shell.inBuilder)shell.exitBuilder();console.error('Map builder startup failed.',error);if(errorUI){errorUI.textContent=`Could not open Map Builder: ${String(error?.message||'Unknown startup error')}`;errorUI.hidden=false;}}
}


const MOBILE_MOVE_ZONE_RATIO = .35;
const CLIENT_FIXED_STEP_SEC = 1/60;
const CLIENT_MAX_FRAME_SEC = .12;
const CLIENT_MAX_SIM_STEPS = 4;
const GROUND_ACCELERATION = MOVEMENT_FEEL.groundAcceleration;
const GROUND_BRAKING = MOVEMENT_FEEL.groundBraking;
const AIR_ACCELERATION = MOVEMENT_FEEL.airAcceleration;
const SPRINT_SPEED_MULTIPLIER = MOVEMENT_FEEL.sprintSpeedMultiplier;
const SPRINT_MIN_FORWARD = MOVEMENT_FEEL.sprintMinForward;
const SPRINT_MIN_INPUT = MOVEMENT_FEEL.sprintMinInput;
const TOUCH_SPRINT_MIN_INPUT = .78;
const TOUCH_SPRINT_MIN_FORWARD = .52;
const SLIDE_DURATION_MS = MOVEMENT_FEEL.slideDurationMs;
const SLIDE_START_SPEED_MULTIPLIER = MOVEMENT_FEEL.slideStartSpeedMultiplier;
const SLIDE_END_SPEED_MULTIPLIER = MOVEMENT_FEEL.slideEndSpeedMultiplier;
const SLIDE_STEER = MOVEMENT_FEEL.slideSteer;
const SLIDE_RECOVERY_MS = MOVEMENT_FEEL.slideRecoveryMs;
const COYOTE_TIME_MS = MOVEMENT_FEEL.coyoteTimeMs;
const JUMP_BUFFER_MS = MOVEMENT_FEEL.jumpBufferMs;
const TOUCH_JOY_BUTTON_PADDING = 12;
const CONTROLLER_LOOK_YAW_RATE = 2.75;
const CONTROLLER_LOOK_PITCH_RATE = 2.25;
const CONTROLLER_TRIGGER_THRESHOLD = .28;
const CONTROLLER_TRIGGER_RELEASE_THRESHOLD = .18;
function freshClientAmmo(){return Object.fromEntries(WEAPON_ORDER.map(name=>[name,weaponCapacity(name)]));}
function freshClientEquipment(tactical='flash',lethal='sticky'){return equipmentForLoadout(tactical,lethal);}
const HUD_ACCENT='#d7ff58', HUD_SURFACE='rgba(9,11,13,.90)', HUD_LINE='rgba(255,255,255,.16)', HUD_MUTED='#8b969f';
const ZOMBIE_BODY_COLOR='#526044';
const IRON_SIGHT_WEAPONS = new Set(['pistol','assault','ump','machineGun','shotgun','semiShotgun','rpg']);
const CHAT_MAX_LENGTH=120,CHAT_VISIBLE_MS=9000,CHAT_MAX_MESSAGES=28;
const ACTIVE_STATE_INTERVAL = 33;
const IDLE_STATE_INTERVAL = 250;
const LOCAL_PREDICTION_HISTORY_MS = 5000;
const LOCAL_PREDICTION_MAX_SAMPLES = 192;
const REMOTE_INTERPOLATION_MS = 85;
const REMOTE_INTERPOLATION_MIN_MS = 70;
const REMOTE_INTERPOLATION_MAX_MS = 220;
const REMOTE_EXTRAPOLATION_MAX_MS = 70;
const REMOTE_HISTORY_MS = 1400;
const REMOTE_HISTORY_MAX_SAMPLES = 64;
// Physical collision/support remains authoritative and discrete. These rates only smooth presentation.
const CROUCH_VIEW_RATE = 13;
const GROUND_VIEW_UP_RATE = 18;
const GROUND_VIEW_DOWN_RATE = 16;
const GROUND_VIEW_MAX_LAG = 0.055;
const AIR_VIEW_RATE = 28;
const VIEW_VERTICAL_SNAP_DISTANCE = 2.75;
const CORRECTION_VIEW_RATE = 13.5;
const CORRECTION_MAX_HORIZONTAL = 0.72;
const CORRECTION_MAX_VERTICAL = 0.55;
const CORRECTION_HARD_SNAP_DISTANCE = 1.35;
const NET_DIAG_URL_ENABLED = new URL(location.href).searchParams.get('netdiag')==='1';
const NET_DIAG_FRAME_STALL_MS = 100;
// Entire sound set is generated locally as 16-bit PCM WAV assets.
// No third-party or runtime-hosted audio is required.
const AUDIO_ASSET_REV='audio-20260831-hit-feedback-no-metal';
const ATTACHMENT_AUDIO_REV='audio-20260829-1';
const KILLSTREAK_AUDIO_REV='audio-20260906-killstreaks-1';
const SOUND_CUES = {
  introMusic:{url:`audio/intro.wav?rev=${AUDIO_ASSET_REV}`,group:'Music',gain:.40,loop:true},
  shotPistol:{url:`audio/shot-pistol.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.78},
  shotAssault:{url:`audio/shot-assault.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.72},
  shotUmp:{url:`audio/shot-ump.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.70},
  shotMachineGun:{url:'audio/shot-machine-gun.wav?rev=audio-20260828-3',group:'Gunfire',gain:.90},
  shotPistolSuppressed:{url:`audio/shot-pistol-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.62},
  shotAssaultSuppressed:{url:`audio/shot-assault-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.58},
  shotUmpSuppressed:{url:`audio/shot-ump-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.62},
  shotMachineGunSuppressed:{url:`audio/shot-machine-gun-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.62},
  shotSniperSuppressed:{url:`audio/shot-sniper-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.64},
  shotShotgunSuppressed:{url:`audio/shot-shotgun-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.72},
  shot1887Suppressed:{url:`audio/shot-1887-suppressed.wav?rev=${ATTACHMENT_AUDIO_REV}`,group:'Gunfire',gain:.74},
  shotShotgun:{url:`audio/shot-shotgun.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.88},
  shot1887:{url:`audio/shot-1887.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.90},
  shotSemiShotgun:{url:`audio/shot-semi-shotgun.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.90},
  shotSniper:{url:`audio/shot-sniper.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.98},
  shotGl:{url:`audio/shot-gl.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.82},
  shotRpg:{url:`audio/shot-rpg.wav?rev=${AUDIO_ASSET_REV}`,group:'Gunfire',gain:.88},
  reloadPistol:{url:`audio/reload-pistol.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.66},
  reloadAssault:{url:`audio/reload-assault.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.64},
  reloadUmp:{url:`audio/reload-ump.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.62},
  reloadMachineGun:{url:'audio/reload-machine-gun.wav?rev=audio-20260828-3',group:'Weapon Handling',gain:.72},
  reloadShotgun:{url:`audio/reload-shotgun.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.68},
  reload1887:{url:`audio/reload-1887.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.70},
  reloadSemiShotgun:{url:`audio/reload-semi-shotgun.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.66},
  shotgunPump:{url:`audio/shotgun-pump.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.78},
  action1887:{url:`audio/action-1887.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.80},
  reloadSniper:{url:`audio/reload-sniper.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.72},
  reloadGl:{url:`audio/reload-gl.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.72},
  reloadRpg:{url:`audio/reload-rpg.wav?rev=${AUDIO_ASSET_REV}`,group:'Weapon Handling',gain:.76},
  hitmarker:{url:`audio/hitmarker.wav?rev=${AUDIO_ASSET_REV}`,group:'Feedback',gain:.58},
  kill:{url:`audio/kill.wav?rev=${AUDIO_ASSET_REV}`,group:'Feedback',gain:.58},
  announcer:{url:`audio/announcer.wav?rev=${AUDIO_ASSET_REV}`,group:'Feedback',gain:.54},
  hurt:{url:`audio/hurt.wav?rev=${AUDIO_ASSET_REV}`,group:'Feedback',gain:.60},
  jump:{url:`audio/jump.wav?rev=${AUDIO_ASSET_REV}`,group:'Movement',gain:.34},
  footstepLeft:{url:`audio/footstep-left.wav?rev=${AUDIO_ASSET_REV}`,group:'Movement',gain:.42},
  footstepRight:{url:`audio/footstep-right.wav?rev=${AUDIO_ASSET_REV}`,group:'Movement',gain:.42},
  land:{url:`audio/land.wav?rev=${AUDIO_ASSET_REV}`,group:'Movement',gain:.66},
  slide:{url:`audio/slide.wav?rev=${AUDIO_ASSET_REV}`,group:'Movement',gain:.58},
  impactWall:{url:`audio/impact-wall.wav?rev=${AUDIO_ASSET_REV}`,group:'Impacts',gain:.62},
  flashThrow:{url:`audio/flash-throw.wav?rev=${AUDIO_ASSET_REV}`,group:'Tactical',gain:.52},
  stickyThrow:{url:`audio/sticky-throw.wav?rev=${AUDIO_ASSET_REV}`,group:'Tactical',gain:.52},
  flashImpact:{url:`audio/flash-impact.wav?rev=${AUDIO_ASSET_REV}`,group:'Tactical',gain:.58},
  stickyImpact:{url:`audio/sticky-impact.wav?rev=${AUDIO_ASSET_REV}`,group:'Tactical',gain:.62},
  semtexBeep:{url:`audio/semtex-beep.wav?rev=${AUDIO_ASSET_REV}`,group:'Tactical',gain:.60},
  flashDetonate:{url:`audio/flash-detonate.wav?rev=${AUDIO_ASSET_REV}`,group:'Explosions',gain:.88},
  grenadeExplosion:{url:`audio/grenade-explosion.wav?rev=${AUDIO_ASSET_REV}`,group:'Explosions',gain:1},
  glExplosion:{url:`audio/gl-explosion.wav?rev=${AUDIO_ASSET_REV}`,group:'Explosions',gain:1},
  rpgExplosion:{url:`audio/rpg-explosion.wav?rev=${AUDIO_ASSET_REV}`,group:'Explosions',gain:1},
  ksUfoInbound:{url:`audio/ks-ufo-inbound.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.74,maxVoices:2},
  ksUfoBeam:{url:`audio/ks-ufo-beam.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.68,maxVoices:3},
  ksLightning:{url:`audio/ks-lightning.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.92,maxVoices:4},
  ksAsteroidIncoming:{url:`audio/ks-asteroid-incoming.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.68,maxVoices:4},
  ksAsteroidImpact:{url:`audio/ks-asteroid-impact.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.96,maxVoices:4},
  ksEarthquakeRumble:{url:`audio/ks-earthquake-rumble.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.76,maxVoices:2},
  ksSolarCharge:{url:`audio/ks-solar-charge.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:.72,maxVoices:1},
  ksSolarBlast:{url:`audio/ks-solar-blast.wav?rev=${KILLSTREAK_AUDIO_REV}`,group:'Killstreaks',gain:1,maxVoices:1},
};

let worldSettings=normalizeWorldSettings(DEFAULT_WORLD_SETTINGS);
let movementSettings=modMovement(worldSettings);
const LONG_SHOT_DISTANCE = 30;

const $ = (id) => document.getElementById(id);

// Breach-owned UI controls. No native browser inputs, selects or range widgets are used.
function controlNumber(el,key,fallback){const n=Number(el?.dataset?.[key]);return Number.isFinite(n)?n:fallback;}
function controlDecimals(step){const raw=String(step??'1');return raw.includes('.')?Math.min(3,raw.split('.')[1].length):0;}
function gameCycleOptions(el){try{return JSON.parse(el?.dataset?.options||'[]');}catch{return[];}}
function renderGameControl(el){
  if(!el)return;
  const type=el.dataset?.gameControl,value=String(el.__gameValue??el.dataset?.value??'');
  if(type==='cycle'){
    const option=gameCycleOptions(el).find(o=>String(o.value)===value)||gameCycleOptions(el)[0];
    const out=el.querySelector('[data-control-value]');if(out)out.textContent=option?.label??value;
  }else if(type==='stepper'){
    const out=el.querySelector('[data-control-value]');if(out){const step=controlNumber(el,'step',1);out.textContent=Number.isFinite(Number(value))?Number(value).toFixed(controlDecimals(step)):value;}
    el.setAttribute('aria-valuenow',value);
  }else if(type==='slider'){
    const min=controlNumber(el,'min',0),max=controlNumber(el,'max',1),n=Math.max(min,Math.min(max,Number(value)||0)),pct=max>min?(n-min)/(max-min)*100:0;
    const fill=el.querySelector('[data-slider-fill]'),knob=el.querySelector('[data-slider-knob]');if(fill)fill.style.width=`${pct}%`;if(knob)knob.style.left=`${pct}%`;
    el.setAttribute('aria-valuenow',String(n));
  }else if(type==='text'){
    const out=el.querySelector('[data-control-value]');if(out){out.textContent=value||el.dataset.placeholder||'';out.classList.toggle('placeholder',!value);}
  }
}
function setGameControlValue(el,value,{emitInput=false,emitChange=false}={}){
  if(!el)return false;const type=el.dataset?.gameControl;
  let next=String(value??'');
  if(type==='cycle'){
    const opts=gameCycleOptions(el);if(opts.length&&!opts.some(o=>String(o.value)===next))next=String(opts[0].value);
  }else if(type==='stepper'||type==='slider'){
    const min=controlNumber(el,'min',-Infinity),max=controlNumber(el,'max',Infinity),step=controlNumber(el,'step',1);let n=Number(next);if(!Number.isFinite(n))n=Number.isFinite(min)?min:0;n=Math.max(min,Math.min(max,n));if(Number.isFinite(step)&&step>0&&Number.isFinite(min))n=min+Math.round((n-min)/step)*step;next=String(Number(n.toFixed(Math.max(0,controlDecimals(step)))));
  }else if(type==='text'){
    next=next.slice(0,Math.max(1,Number(el.dataset.maxlength)||64));
  }
  const previous=String(el.value??el.__gameValue??el.dataset?.value??'');el.value=next;const changed=next!==previous;
  if(emitInput)el.dispatchEvent(new Event('input',{bubbles:true}));if(emitChange&&changed)el.dispatchEvent(new Event('change',{bubbles:true}));return changed;
}
function adjustGameControl(el,dir,{commit=true}={}){
  if(!el||!dir||el.disabled||el.classList?.contains('disabled'))return false;const type=el.dataset?.gameControl;
  if(type==='cycle'){
    const opts=gameCycleOptions(el);if(!opts.length)return false;const cur=Math.max(0,opts.findIndex(o=>String(o.value)===String(el.value))),next=Math.max(0,Math.min(opts.length-1,cur+(dir>0?1:-1)));if(next===cur)return true;setGameControlValue(el,opts[next].value,{emitInput:true,emitChange:commit});return true;
  }
  if(type==='stepper'||type==='slider'){
    const step=controlNumber(el,'step',1);setGameControlValue(el,(Number(el.value)||0)+step*(dir>0?1:-1),{emitInput:true,emitChange:commit});return true;
  }
  return false;
}
function initGameControls(){
  for(const el of document.querySelectorAll('[data-game-control]')){
    const type=el.dataset.gameControl,initial=el.dataset.value??'';
    if(type==='text'){
      let current=initial;Object.defineProperty(el,'value',{configurable:true,get(){return current;},set(v){current=String(v??'').slice(0,Math.max(1,Number(el.dataset.maxlength)||64));el.__gameValue=current;el.dataset.value=current;renderGameControl(el);}});el.value=initial;
    }else{
      let current=initial;Object.defineProperty(el,'value',{configurable:true,get(){return current;},set(v){current=String(v??'');el.__gameValue=current;el.dataset.value=current;renderGameControl(el);}});
      Object.defineProperty(el,'disabled',{configurable:true,get(){return el.classList.contains('disabled');},set(v){el.classList.toggle('disabled',!!v);el.setAttribute('aria-disabled',v?'true':'false');for(const b of el.querySelectorAll('button'))b.disabled=!!v;}});
      for(const key of ['min','max','step'])Object.defineProperty(el,key,{configurable:true,get(){return el.dataset[key]??'';}});
      el.value=initial;
      for(const btn of el.querySelectorAll('[data-control-step]')){
        const dir=Number(btn.dataset.controlStep)||0;
        const clear=()=>{delete el.dataset.pressedStep;btn.classList.remove('pressed');};
        uiGestures.bind(btn,{
          start:state=>{state.initial=String(el.value);state.started=performance.now();state.next=state.started+360;el.dataset.pressedStep=String(dir);btn.classList.add('pressed');adjustGameControl(el,dir,{commit:false});},
          tick:(state,now)=>{if(now<state.next)return;adjustGameControl(el,dir,{commit:false});const held=now-state.started;state.next=now+(held>=2400?42:held>=1200?68:105);},
          finish:state=>{clear();if(String(el.value)!==state.initial)el.dispatchEvent(new Event('change',{bubbles:true}));},
          cancel:state=>{clear();setGameControlValue(el,state.initial,{emitInput:true,emitChange:true});},
        });
        // A pointer hold has already applied its steps. Keyboard/AT activation
        // has no pointer contact and performs one normal committed adjustment.
        btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(e.detail===0)adjustGameControl(el,dir);});
      }
      if(type==='slider'){
        const fromPoint=x=>{const r=(el.querySelector('.game-slider-track')||el).getBoundingClientRect(),min=controlNumber(el,'min',0),max=controlNumber(el,'max',1);setGameControlValue(el,min+(max-min)*Math.max(0,Math.min(1,(x-r.left)/Math.max(1,r.width))),{emitInput:true});};
        uiGestures.bind(el,{
          start:(state,e)=>{state.initial=String(el.value);fromPoint(e.clientX);},
          move:(_,e)=>fromPoint(e.clientX),
          finish:(state,e)=>{fromPoint(e.clientX);if(String(el.value)!==state.initial)el.dispatchEvent(new Event('change',{bubbles:true}));},
          cancel:state=>setGameControlValue(el,state.initial,{emitInput:true,emitChange:true}),
        });
      }
      el.addEventListener('keydown',e=>{if(controllerInputActive()){if(e.key.startsWith('Arrow'))e.preventDefault();return;}if(e.key==='ArrowLeft'||e.key==='ArrowDown'){e.preventDefault();adjustGameControl(el,-1);}else if(e.key==='ArrowRight'||e.key==='ArrowUp'){e.preventDefault();adjustGameControl(el,1);}});

    }
  }
}
function renderLoadoutChoiceGrids(){
  const slotItems={
    primary:PRIMARY_WEAPONS.map(id=>[id,WEAPON_SPECS[id]?.name||id]),
    secondary:SECONDARY_WEAPONS.map(id=>[id,WEAPON_SPECS[id]?.name||id]),
    tactical:TACTICAL_EQUIPMENT.map(id=>[id,EQUIPMENT_SPECS[id]?.name||id]),
    lethal:LETHAL_EQUIPMENT.map(id=>[id,EQUIPMENT_SPECS[id]?.name||id]),
  };
  for(const grid of document.querySelectorAll('[data-loadout-grid]')){
    const [surface,slot]=String(grid.dataset.loadoutGrid||'').split('-');
    const items=slotItems[slot]||[];grid.replaceChildren();
    for(const [id,label] of items){
      const button=document.createElement('button');button.className='loadout-choice';button.type='button';button.setAttribute(`data-${surface}-${slot}-choice`,id);button.dataset.controllerKey=`loadout:${surface}:${slot}:${id}`;
      const text=document.createElement('strong');text.textContent=label;button.append(text);grid.append(button);
    }
  }
}
renderLoadoutChoiceGrids();
const loadoutFocusSlot={lobby:'primary',match:'primary'},loadoutWorkspaceMode={lobby:'classes',match:'classes'},loadoutPreviewDesired=new Map(),loadoutPreviewContexts=new Map(),loadoutAttachmentSlot={'lobby-primary':'','lobby-secondary':'','match-primary':'','match-secondary':''},loadoutAttachmentTrayOpen=new Set(),loadoutAttachmentCompareBase=new Map(),loadoutPreviewAdsKeys=new Set(),loadoutWeaponPickerOpen=new Set(),loadoutHintTimers=new Map();
function flashLoadoutInputHint(surface,duration=1900){const workspace=document.querySelector(`[data-loadout-workspace="${surface}"]`);if(!workspace||loadoutWorkspaceMode[surface]!=='item'||!['primary','secondary'].includes(loadoutFocusSlot[surface]))return;clearTimeout(loadoutHintTimers.get(surface)||0);workspace.classList.add('show-input-hint');loadoutHintTimers.set(surface,setTimeout(()=>{workspace.classList.remove('show-input-hint');loadoutHintTimers.delete(surface);},duration));}
function loadoutSlotWeapon(draft,slot){return slot==='primary'?draft.primaryWeapon:draft.secondaryWeapon;}
function loadoutSlotAttachments(draft,slot){return slot==='primary'?draft.primaryAttachments:draft.secondaryAttachments;}
function loadoutDraftForSurface(surface){return normalizeLoadoutChoice(surface==='lobby'?(lobbyLoadoutDraft||selectedLoadout()):(loadoutDraft||loadoutBaseDraft||pendingLoadout||selectedLoadout()));}
function loadoutMetricClamp(v){return Math.max(0,Math.min(100,Number(v)||0));}
function loadoutAccuracyControlAdjustment(weapon,accuracy){if(!accuracy)return 0;const base=resolveWeaponAccuracy(weapon,{}),fields=[['hipDeg',.26],['adsDeg',.22],['moveDeg',.18],['airborneDeg',.10],['slideDeg',.08],['fireDeg',.08],['fireMaxDeg',.08]];let ratio=0,weight=0;for(const [key,w] of fields){const a=Number(accuracy[key]),b=Number(base[key]);if(!Number.isFinite(a)||!Number.isFinite(b)||b<=0)continue;ratio+=(a/b)*w;weight+=w;}if(!weight)return 0;return Math.max(-18,Math.min(18,(1-ratio/weight)*40));}
function loadoutControlScore(spec,accuracy=null,pelletWeapon=false,weapon='',attachments={}){if(pelletWeapon&&accuracy){return loadoutMetricClamp(100-(Number(accuracy.hipDeg)||0)*9.5-(Number(accuracy.fireDeg)||0)*7);}const initial=Math.max(.001,Number(spec.recoilPitch)||0)+Math.max(0,Number(spec.recoilYaw)||0)*1.35,sustained=Math.max(.001,Number(spec.recoilMaxPitch)||Number(spec.recoilPitch)||0)+Math.max(0,Number(spec.recoilMaxYaw)||Number(spec.recoilYaw)||0)*1.35,initialScore=loadoutMetricClamp(106-initial*2350),sustainedScore=loadoutMetricClamp(106-sustained*400),recoveryScore=loadoutMetricClamp(((Number(spec.recoilRecovery)||8)-6)/12*100);let score=initialScore*.40+sustainedScore*.50+recoveryScore*.10+loadoutAccuracyControlAdjustment(weapon,accuracy);if(weapon==='machineGun'&&weaponHasAttachment(weapon,attachments,'bipod'))score+=(1-Math.max(.45,Math.min(1,Number(ATTACHMENTS.bipod?.conditionalRecoilScale)||.62)))*16;return loadoutMetricClamp(score);}
function loadoutMobilityScore(spec){const adsMove=Math.max(.5,Math.min(1.25,Number(spec.adsMoveSpeedScale)||1)),sprint=Math.max(80,Math.min(350,Number(spec.sprintOutMs)||180));return loadoutMetricClamp(adsMove*72+(1-(sprint-80)/270)*28);}
function loadoutHandlingScore(spec){const ads=Math.max(0,Math.min(420,Number(spec.adsInMs)||0)),reload=Math.max(500,Math.min(4000,Number(spec.reloadMs)||1500));return loadoutMetricClamp((1-ads/420)*68+(1-(reload-500)/3500)*32);}
function loadoutWeaponStats(weapon,attachments,comparisonAttachments={}){
  const spec=resolveWeaponSpec(weapon,attachments),compare=resolveWeaponSpec(weapon,comparisonAttachments),pellets=Math.max(1,Number(spec.pellets)||1),accuracy=resolveWeaponAccuracy(weapon,attachments),compareAccuracy=resolveWeaponAccuracy(weapon,comparisonAttachments),pelletWeapon=pellets>1;
  return[
    {label:'DAMAGE',value:pellets>1?`${Math.round(spec.damage)}×${pellets}`:`${Math.round(spec.damage)}`,score:loadoutMetricClamp((Number(spec.damage)||0)*(pellets>1?2.1:1.65)),baseScore:loadoutMetricClamp((Number(compare.damage)||0)*(pellets>1?2.1:1.65))},
    {label:'RANGE',value:`${Math.round(spec.falloffEnd||0)}M`,score:loadoutMetricClamp((Number(spec.falloffEnd)||0)/2.2),baseScore:loadoutMetricClamp((Number(compare.falloffEnd)||0)/2.2)},
    {label:'CONTROL',value:`${Math.round(loadoutControlScore(spec,accuracy,pelletWeapon,weapon,attachments))}`,score:loadoutControlScore(spec,accuracy,pelletWeapon,weapon,attachments),baseScore:loadoutControlScore(compare,compareAccuracy,pelletWeapon,weapon,comparisonAttachments)},
    {label:'MOBILITY',value:`${Math.round((Number(spec.adsMoveSpeedScale)||1)*100)}%`,score:loadoutMobilityScore(spec),baseScore:loadoutMobilityScore(compare)},
    {label:'HANDLING',value:`${Math.round(loadoutHandlingScore(spec))}`,score:loadoutHandlingScore(spec),baseScore:loadoutHandlingScore(compare)},
    {label:'CAPACITY',value:`${Math.round(spec.mag||0)}`,score:loadoutMetricClamp(Number(spec.mag)||0),baseScore:loadoutMetricClamp(Number(compare.mag)||0)},
  ];
}
function activeLoadoutAttachmentSlot(surface,weaponSlot,weapon){const key=`${surface}-${weaponSlot}`,available=ATTACHMENT_SLOTS.filter(slot=>attachmentOptionsForWeapon(weapon,slot).length),selected=loadoutAttachmentSlot[key];if(!available.includes(selected)){loadoutAttachmentSlot[key]='';loadoutAttachmentTrayOpen.delete(key);loadoutAttachmentCompareBase.delete(key);return'';}return selected;}
function setLoadoutAttachmentComparisonBase(surface,weaponSlot,weapon,slot,attachments){const key=`${surface}-${weaponSlot}`;loadoutAttachmentCompareBase.set(key,{weapon,slot,attachments:normalizeWeaponAttachments(weapon,attachments)});}
function clearLoadoutAttachmentComparisonBase(key){loadoutAttachmentCompareBase.delete(key);}
function loadoutComparisonAttachments(surface,weaponSlot,weapon,attachments){const key=`${surface}-${weaponSlot}`,current=normalizeWeaponAttachments(weapon,attachments);if(!loadoutAttachmentTrayOpen.has(key))return current;const activeSlot=activeLoadoutAttachmentSlot(surface,weaponSlot,weapon),saved=loadoutAttachmentCompareBase.get(key);if(saved&&saved.weapon===weapon&&saved.slot===activeSlot)return normalizeWeaponAttachments(weapon,saved.attachments);return current;}
function renderLoadoutStats(surface,slot,weapon,attachments){
  const host=document.querySelector(`[data-loadout-stats="${surface}-${slot}"]`);if(!host)return;host.replaceChildren();const comparison=loadoutComparisonAttachments(surface,slot,weapon,attachments);
  for(const row of loadoutWeaponStats(weapon,attachments,comparison)){
    const target=loadoutMetricClamp(row.score),baseline=loadoutMetricClamp(row.baseScore),delta=target-baseline,card=document.createElement('div');card.className='loadout-stat';if(delta>1.2)card.classList.add('better');else if(delta<-1.2)card.classList.add('worse');
    const head=document.createElement('div');head.className='loadout-stat-head';const label=document.createElement('span');label.textContent=row.label;const value=document.createElement('strong');value.textContent=row.value;head.append(label,value);
    const changed=Math.abs(delta)>1.2,change=document.createElement('div');change.className='loadout-stat-delta';change.textContent=changed?`${delta>0?'▲':'▼'} ${Math.abs(Math.round(delta))}`:'';change.setAttribute('aria-hidden','true');
    const bar=document.createElement('div');bar.className='loadout-stat-bar';bar.setAttribute('aria-label',changed?`${row.label}: ${Math.round(baseline)} to ${Math.round(target)}`:`${row.label}: ${Math.round(target)}`);
    const solid=document.createElement('i');solid.className='loadout-stat-bar-solid';solid.style.width=`${Math.max(3,Math.min(target,baseline))}%`;bar.append(solid);
    if(changed){const hatch=document.createElement('b');hatch.className=`loadout-stat-bar-hatch ${delta>0?'gain':'loss'}`;hatch.style.left=`${Math.min(target,baseline)}%`;hatch.style.width=`${Math.abs(delta)}%`;bar.append(hatch);}
    if(changed){const baselineMark=document.createElement('em');baselineMark.className='loadout-stat-baseline-mark';baselineMark.style.left=`${baseline}%`;bar.append(baselineMark);}
    card.append(head,change,bar);host.append(card);
  }
}
function modifierTag(label,mult,{lowerBetter=false}={}){const n=Number(mult);if(!Number.isFinite(n)||Math.abs(n-1)<.005)return null;const pct=Math.round(Math.abs(n-1)*100),up=n>1,good=lowerBetter?!up:up;return{text:`${label} ${up?'+':'-'}${pct}%`,good};}
function attachmentEffectTags(item,weapon){if(!item)return[];const tags=[],mods=attachmentModsForWeapon(item,weapon),accuracyMods=attachmentAccuracyModsForWeapon(item,weapon),adsMoveAdd=attachmentAdsMoveAddForWeapon(item,weapon),push=x=>{if(x&&tags.length<8)tags.push(x);};push(modifierTag('DAMAGE',mods.damage));push(modifierTag('VELOCITY',mods.bulletSpeed));push(modifierTag('RANGE',mods.falloffEnd));const recoilVals=[mods.recoilPitch,mods.recoilYaw].map(Number).filter(Number.isFinite);if(recoilVals.length){const avg=recoilVals.reduce((a,b)=>a+b,0)/recoilVals.length;push(modifierTag('RECOIL',avg,{lowerBetter:true}));}push(modifierTag('ADS TIME',mods.adsInMs,{lowerBetter:true}));push(modifierTag('SPRINT-OUT',mods.sprintOutMs,{lowerBetter:true}));push(modifierTag('RELOAD',mods.reloadMs,{lowerBetter:true}));if(adsMoveAdd)push({text:`ADS MOVE ${adsMoveAdd>0?'+':''}${Math.round(adsMoveAdd*100)}%`,good:adsMoveAdd>0});if(item.magAdd?.[weapon]){const add=Number(item.magAdd[weapon])||0,base=Math.max(0,Number(WEAPON_SPECS[weapon]?.mag)||0),next=Math.max(0,base+add);push({text:`MAG ${base}→${next}`,good:add>0});}if(accuracyMods){const fields=[['HIP SPREAD',accuracyMods.hipDeg],['ADS SPREAD',accuracyMods.adsDeg],['MOVE SPREAD',accuracyMods.moveDeg],['AIR SPREAD',accuracyMods.airborneDeg],['SLIDE SPREAD',accuracyMods.slideDeg],['FIRE SPREAD',accuracyMods.fireDeg],['MAX FIRE SPREAD',accuracyMods.fireMaxDeg]].filter(([,value])=>Number.isFinite(Number(value))&&Math.abs(Number(value)-1)>=.005),vals=fields.map(([,value])=>Number(value));if(vals.length){const same=vals.every(value=>Math.abs(value-vals[0])<.005);if(same)push(modifierTag('SPREAD',vals[0],{lowerBetter:true}));else for(const [label,value] of fields)push(modifierTag(label,value,{lowerBetter:true}));}}if(item.soundScale&&item.soundScale<1)push({text:'QUIETER / OFF RADAR',good:true});if(item.conditionalRecoilScale)push({text:`CROUCHED RECOIL -${Math.round((1-item.conditionalRecoilScale)*100)}%`,good:true});if(item.zoomLabel)push({text:`${item.zoomLabel} ZOOM`,good:true});else if(item.adsFov)push({text:`OPTIC ${Math.round(item.adsFov)} FOV`,good:true});if(item.thermalMode)push({text:'THERMAL',good:true});return tags;}
function attachmentDescriptionForWeapon(item,weapon){if(!item)return'';return attachmentEffectTags(item,weapon).map(tag=>tag.text).join(' · ');}
function loadoutOverviewAttachmentText(weapon,attachments){return ATTACHMENT_SLOTS.map(slot=>attachments?.[slot]?ATTACHMENTS[attachments[slot]]?.short||ATTACHMENTS[attachments[slot]]?.name:'').filter(Boolean).join(' · ');}
function renderLoadoutOverview(surface,draft){
  const safe=normalizeLoadoutChoice(draft),classes=surface==='lobby'?normalizeLoadoutClasses(lobbyClassDrafts||loadoutClasses,selectedLoadout()):normalizeLoadoutClasses(matchClassDrafts||loadoutClasses,selectedLoadout()),selected=normalizeLoadoutClassId(loadoutEditClass[surface]||activeClassId),classInfo=loadoutClassById(classes,selected,selectedLoadout()),name=document.querySelector(`[data-loadout-overview-name="${surface}"]`);if(name){const label=document.createElement('span');label.textContent=classInfo.name;const icon=document.createElement('span');icon.className='class-name-edit-icon';icon.setAttribute('aria-hidden','true');icon.textContent='✎';name.replaceChildren(label,icon);}
  for(const slot of ['primary','secondary']){const key=`${surface}-${slot}`,weapon=loadoutSlotWeapon(safe,slot),attachments=loadoutSlotAttachments(safe,slot),spec=resolveWeaponSpec(weapon,attachments),weaponEl=document.querySelector(`[data-loadout-overview-weapon="${key}"]`),modsEl=document.querySelector(`[data-loadout-overview-mods="${key}"]`);if(weaponEl)weaponEl.textContent=spec.name||weapon;if(modsEl){const text=loadoutOverviewAttachmentText(weapon,attachments);modsEl.textContent=text;modsEl.hidden=!text;}}
  const tactical=document.querySelector(`[data-loadout-overview-equipment="${surface}-tactical"]`),lethal=document.querySelector(`[data-loadout-overview-equipment="${surface}-lethal"]`);if(tactical)tactical.textContent=EQUIPMENT_SPECS[safe.tactical]?.name||safe.tactical;if(lethal)lethal.textContent=EQUIPMENT_SPECS[safe.lethal]?.name||safe.lethal;
  const focus=loadoutFocusSlot[surface]||'primary',title=document.querySelector(`[data-loadout-item-title="${surface}"]`),kicker=document.querySelector(`[data-loadout-item-kicker="${surface}"]`),swap=document.querySelector(`[data-loadout-item-swap="${surface}"]`),weaponFocus=focus==='primary'||focus==='secondary';if(title){title.textContent=weaponFocus?(resolveWeaponSpec(loadoutSlotWeapon(safe,focus),loadoutSlotAttachments(safe,focus)).name||loadoutSlotWeapon(safe,focus)):(EQUIPMENT_SPECS[safe[focus]]?.name||safe[focus]);}if(kicker)kicker.textContent=focus==='primary'?'PRIMARY WEAPON':focus==='secondary'?'SECONDARY WEAPON':focus==='tactical'?'TACTICAL':'LETHAL';if(swap){swap.hidden=!weaponFocus;if(weaponFocus){const swapKey=`${surface}-${focus}`;swap.dataset.loadoutWeaponPickerToggle=swapKey;swap.dataset.controllerKey=`weapon-toggle:${swapKey}`;}}
  if(name&&'value' in name)name.value=classInfo.name;
}
function syncLoadoutFocusedView(surface,draft){
  const safe=normalizeLoadoutChoice(draft);for(const slot of ['primary','secondary']){const weapon=loadoutSlotWeapon(safe,slot),attachments=loadoutSlotAttachments(safe,slot),key=`${surface}-${slot}`;renderLoadoutStats(surface,slot,weapon,attachments);loadoutPreviewDesired.set(key,{weapon,attachments:{...attachments},signature:`${weapon}:${JSON.stringify(attachments||{})}`});}
  renderLoadoutOverview(surface,safe);
}
function showLoadoutItemPage(surface,item='primary',{ensurePreview=true}={}){const focus=['primary','secondary','tactical','lethal'].includes(item)?item:'primary';loadoutFocusSlot[surface]=focus;for(const page of document.querySelectorAll(`[data-loadout-weapon-page^="${surface}-"]`)){const active=page.dataset.loadoutWeaponPage===`${surface}-${focus}`;page.hidden=!active;page.inert=!active;page.classList.toggle('active',active);}for(const page of document.querySelectorAll(`[data-loadout-equipment-page^="${surface}-"]`)){const active=page.dataset.loadoutEquipmentPage===`${surface}-${focus}`;page.hidden=!active;page.inert=!active;page.classList.toggle('active',active);}renderLoadoutOverview(surface,loadoutDraftForSurface(surface));if(ensurePreview&&(focus==='primary'||focus==='secondary')){const key=`${surface}-${focus}`;requestAnimationFrame(()=>{if(loadoutPreviewDesired.has(key))void ensureLoadoutPreviewEngine();});}}
function syncLobbyLoadoutFocusMode(mode=loadoutWorkspaceMode.lobby){const lobby=$('lobbyScreen'),loadoutTab=document.querySelector('[data-lobby-side-tab="loadout"]'),focused=!!lobby&&loadoutTab?.classList.contains('active')&&mode!=='classes';lobby?.classList.toggle('loadout-focused',focused);}
function setLoadoutWorkspaceMode(surface,mode='classes',{item=loadoutFocusSlot[surface]||'primary',ensurePreview=true}={}){const next=['classes','class','item'].includes(mode)?mode:'classes';loadoutWorkspaceMode[surface]=next;const workspace=document.querySelector(`[data-loadout-workspace="${surface}"]`),views={classes:document.querySelector(`[data-loadout-classes-view="${surface}"]`),class:document.querySelector(`[data-loadout-class-view="${surface}"]`),item:document.querySelector(`[data-loadout-item-view="${surface}"]`)};if(workspace)workspace.dataset.view=next;for(const [name,view] of Object.entries(views))if(view){const active=name===next;view.hidden=!active;view.inert=!active;view.classList.toggle('active',active);}if(surface==='lobby')syncLobbyLoadoutFocusMode(next);if(next==='item'){showLoadoutItemPage(surface,item,{ensurePreview});requestAnimationFrame(()=>flashLoadoutInputHint(surface));}else{clearTimeout(loadoutHintTimers.get(surface)||0);loadoutHintTimers.delete(surface);workspace?.classList.remove('show-input-hint');for(const key of [...loadoutPreviewAdsKeys])if(key.startsWith(`${surface}-`))setLoadoutAdsPreview(key,false);renderLoadoutOverview(surface,loadoutDraftForSurface(surface));renderLoadoutClassStrip(surface);} }
function setLoadoutAdsPreview(key,active){if(active)loadoutPreviewAdsKeys.add(key);else loadoutPreviewAdsKeys.delete(key);document.querySelector(`[data-loadout-ads-preview="${key}"]`)?.classList.toggle('active',!!active);const ctx=loadoutPreviewContexts.get(key);if(ctx)ctx.adsPreview=!!active;}
function bindLoadoutWorkspaceTabs(){
  for(const nameButton of document.querySelectorAll('[data-loadout-class-name-edit]')){const surface=nameButton.dataset.loadoutClassNameEdit;nameButton.dataset.controllerKey=`class-name:${surface}`;nameButton.dataset.textMode='class';nameButton.dataset.maxlength='18';nameButton.dataset.placeholder='CLASS NAME';nameButton.addEventListener('click',()=>{const classes=loadoutClassesForSurface(surface),item=loadoutClassById(classes,loadoutEditClass[surface],selectedLoadout());nameButton.value=item.name;openGameTextEditor(nameButton);});nameButton.addEventListener('change',()=>renameLoadoutClass(surface,loadoutEditClass[surface],nameButton.value));}
  for(const button of document.querySelectorAll('[data-loadout-edit-item]')){button.dataset.controllerKey=`class-item:${button.dataset.loadoutEditItem}`;button.addEventListener('click',()=>{const [surface,item]=String(button.dataset.loadoutEditItem||'').split('-');loadoutAttachmentTrayOpen.delete(`${surface}-${item}`);clearLoadoutAttachmentComparisonBase(`${surface}-${item}`);loadoutWeaponPickerOpen.delete(`${surface}-${item}`);setLoadoutWorkspaceMode(surface,'item',{item});if(item==='primary'||item==='secondary'){renderAttachmentEditor(surface,item,loadoutDraftForSurface(surface));const weapon=loadoutSlotWeapon(loadoutDraftForSurface(surface),item),first=ATTACHMENT_SLOTS.find(slot=>attachmentOptionsForWeapon(weapon,slot).length);if(first)queueControllerUiFocus(`gunsmith:${surface}-${item}:slot:${first}`);else queueControllerUiFocus(`weapon-toggle:${surface}-${item}`);}else queueControllerUiFocus(`loadout:${surface}:${item}:${loadoutDraftForSurface(surface)[item]}`);});}
  for(const button of document.querySelectorAll('[data-loadout-back-class]')){button.dataset.controllerKey=`back-class:${button.dataset.loadoutBackClass}`;button.addEventListener('click',()=>{const surface=button.dataset.loadoutBackClass,setItem=loadoutFocusSlot[surface]||'primary';setLoadoutWorkspaceMode(surface,'class',{ensurePreview:false});queueControllerUiFocus(`class-item:${surface}-${setItem}`);});}
  for(const button of document.querySelectorAll('[data-loadout-back-classes]')){button.dataset.controllerKey=`back-classes:${button.dataset.loadoutBackClasses}`;button.addEventListener('click',()=>{const surface=button.dataset.loadoutBackClasses;setLoadoutWorkspaceMode(surface,'classes',{ensurePreview:false});queueControllerUiFocus(`class:${surface}:${normalizeLoadoutClassId(loadoutEditClass[surface]||activeClassId)}:main`);});}
  for(const button of document.querySelectorAll('[data-loadout-weapon-picker-toggle]')){const stableKey=button.dataset.loadoutWeaponPickerToggle;button.dataset.controllerKey=`weapon-toggle:${stableKey}`;button.addEventListener('click',()=>{const key=button.dataset.loadoutWeaponPickerToggle,[surface,slot]=key.split('-');if(loadoutWeaponPickerOpen.has(key)){loadoutWeaponPickerOpen.delete(key);renderAttachmentEditor(surface,slot,loadoutDraftForSurface(surface));queueControllerUiFocus(`weapon-toggle:${key}`);}else{loadoutWeaponPickerOpen.add(key);loadoutAttachmentTrayOpen.delete(key);clearLoadoutAttachmentComparisonBase(key);renderAttachmentEditor(surface,slot,loadoutDraftForSurface(surface));queueControllerUiFocus(`loadout:${surface}:${slot}:${loadoutSlotWeapon(loadoutDraftForSurface(surface),slot)}`);}renderLoadoutStats(surface,slot,loadoutSlotWeapon(loadoutDraftForSurface(surface),slot),loadoutSlotAttachments(loadoutDraftForSurface(surface),slot));});}
  for(const button of document.querySelectorAll('[data-loadout-ads-preview]')){
    const key=button.dataset.loadoutAdsPreview;
    uiGestures.bind(button,{start:()=>setLoadoutAdsPreview(key,true),finish:()=>setLoadoutAdsPreview(key,false),cancel:()=>setLoadoutAdsPreview(key,false)});
    button.addEventListener('keydown',e=>{if((e.code==='Space'||e.code==='Enter')&&!e.repeat){e.preventDefault();setLoadoutAdsPreview(key,true);}});
    button.addEventListener('keyup',e=>{if(e.code==='Space'||e.code==='Enter'){e.preventDefault();setLoadoutAdsPreview(key,false);}});
    button.addEventListener('blur',()=>setLoadoutAdsPreview(key,false));
    button.addEventListener('click',e=>{if(e.detail===0)setLoadoutAdsPreview(key,!loadoutPreviewAdsKeys.has(key));});
  }
}
function applyLoadoutAttachmentChoice(surface,weaponSlot,slot,id){const live=loadoutDraftForSurface(surface),key=weaponSlot==='primary'?'primaryAttachments':'secondaryAttachments',next={...loadoutSlotAttachments(live,weaponSlot),[slot]:id};if(surface==='lobby'){setLobbyLoadoutDraft({[key]:next});renderAttachmentEditors('lobby',lobbyLoadoutDraft||loadoutDraftForSurface('lobby'));}else{loadoutDraft=normalizeLoadoutChoice({...live,[key]:next});syncMatchLoadoutEditor();commitMatchLoadoutChange();}}
function renderGunsmithCallouts(surface,weaponSlot,weapon,current,groups){const key=`${surface}-${weaponSlot}`,host=document.querySelector(`[data-gunsmith-callouts="${key}"]`);if(!host)return;host.replaceChildren();const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('gunsmith-callout-lines');svg.setAttribute('aria-hidden','true');host.append(svg);for(const [slot] of groups){const line=document.createElementNS('http://www.w3.org/2000/svg','line');line.dataset.calloutLine=slot;const dot=document.createElementNS('http://www.w3.org/2000/svg','circle');dot.dataset.calloutDot=slot;dot.setAttribute('r','2.8');svg.append(line,dot);const b=document.createElement('button');b.type='button';b.className=`gunsmith-callout gunsmith-callout-${slot}`;b.dataset.calloutSlot=slot;b.dataset.controllerKey=`gunsmith:${key}:slot:${slot}`;const label=document.createElement('span');label.textContent=slot.toUpperCase();const id=current?.[slot]||'',item=id?ATTACHMENTS[id]:null,value=document.createElement('strong');value.textContent=item?.short||item?.name||'NONE';b.append(label,value);b.classList.toggle('active',loadoutAttachmentTrayOpen.has(key)&&loadoutAttachmentSlot[key]===slot);b.classList.toggle('equipped',!!item);b.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();loadoutWeaponPickerOpen.delete(key);if(!loadoutAttachmentTrayOpen.has(key)||loadoutAttachmentSlot[key]!==slot)setLoadoutAttachmentComparisonBase(surface,weaponSlot,weapon,slot,current);loadoutAttachmentSlot[key]=slot;loadoutAttachmentTrayOpen.add(key);renderAttachmentEditor(surface,weaponSlot,loadoutDraftForSurface(surface));renderLoadoutStats(surface,weaponSlot,weapon,loadoutSlotAttachments(loadoutDraftForSurface(surface),weaponSlot));const selected=current?.[slot]||'';queueControllerUiFocus(`attachment:${key}:${slot}:${selected||'none'}`);});host.append(b);} }
function renderAttachmentEditor(surface,weaponSlot,draft){
  const host=document.querySelector(`[data-attachment-editor="${surface}-${weaponSlot}"]`);if(!host)return;const key=`${surface}-${weaponSlot}`,weapon=loadoutSlotWeapon(draft,weaponSlot),current=loadoutSlotAttachments(draft,weaponSlot),groups=ATTACHMENT_SLOTS.map(slot=>[slot,attachmentOptionsForWeapon(weapon,slot)]).filter(([,items])=>items.length),picker=document.querySelector(`[data-gunsmith-weapon-picker="${key}"]`),weaponPicker=loadoutWeaponPickerOpen.has(key),layout=host.closest('.gunsmith-layout');if(layout){layout.classList.toggle('picker-open',weaponPicker);layout.classList.remove('tray-open');}if(picker)picker.hidden=!weaponPicker;host.hidden=weaponPicker;renderGunsmithCallouts(surface,weaponSlot,weapon,current,groups);if(weaponPicker)return;host.replaceChildren();host.classList.toggle('empty',groups.length===0);if(!groups.length){const empty=document.createElement('div');empty.className='gunsmith-inspector-empty';empty.innerHTML='<strong>NO ATTACHMENTS</strong>';host.append(empty);return;}
  const activeSlot=activeLoadoutAttachmentSlot(surface,weaponSlot,weapon),activeItems=activeSlot?(groups.find(([slot])=>slot===activeSlot)?.[1]||[]):[],trayOpen=!!activeSlot&&loadoutAttachmentTrayOpen.has(key);layout?.classList.toggle('tray-open',trayOpen);if(!trayOpen)return;
  const selectedId=current?.[activeSlot]||'',selectedItem=selectedId?ATTACHMENTS[selectedId]:null,head=document.createElement('header');head.className='gunsmith-attachment-head';const title=document.createElement('div'),strong=document.createElement('strong');strong.textContent=activeSlot.toUpperCase();title.append(strong);const close=document.createElement('button');close.type='button';close.className='gunsmith-tray-close';close.textContent='×';close.setAttribute('aria-label','Close attachment options');close.dataset.controllerKey=`attachment:${key}:close`;close.addEventListener('click',()=>{const slot=loadoutAttachmentSlot[key];loadoutAttachmentTrayOpen.delete(key);clearLoadoutAttachmentComparisonBase(key);loadoutAttachmentSlot[key]='';renderAttachmentEditor(surface,weaponSlot,loadoutDraftForSurface(surface));renderLoadoutStats(surface,weaponSlot,weapon,loadoutSlotAttachments(loadoutDraftForSurface(surface),weaponSlot));queueControllerUiFocus(`gunsmith:${key}:slot:${slot}`);});head.append(title,close);
  const options=document.createElement('div');options.className='gunsmith-attachment-options';for(const item of [null,...activeItems]){const id=item?.id||'',b=document.createElement('button');b.type='button';b.className='gunsmith-attachment-option';b.dataset.controllerKey=`attachment:${key}:${activeSlot}:${id||'none'}`;b.classList.toggle('active',(current?.[activeSlot]||'')===id);const name=document.createElement('strong');name.textContent=item?.name||'NONE';const detailText=item?attachmentDescriptionForWeapon(item,weapon):'';b.append(name);if(detailText){const detail=document.createElement('small');detail.textContent=detailText;b.append(detail);}b.addEventListener('click',()=>{applyLoadoutAttachmentChoice(surface,weaponSlot,activeSlot,id);queueControllerUiFocus(`attachment:${key}:${activeSlot}:${id||'none'}`);});options.append(b);}host.append(head,options);
}
function renderAttachmentEditors(surface,draft){syncLoadoutFocusedView(surface,draft);renderAttachmentEditor(surface,'primary',draft);renderAttachmentEditor(surface,'secondary',draft);}
for(const button of document.querySelectorAll('[data-loadout-ads-preview]'))button.dataset.controllerKey=`ads:${button.dataset.loadoutAdsPreview}`;
let adminWeaponSelection='assault';
function currentAdminWeaponSelection(){return WEAPON_ORDER.includes(adminWeaponSelection)?adminWeaponSelection:(WEAPON_ORDER[0]||'assault');}
function hydrateWeaponTuneSelector(){
  const state=$('adminWeaponSelect'),grid=$('adminWeaponGrid');if(!state||!grid)return;
  adminWeaponSelection=WEAPON_ORDER.includes(state.dataset.value)?state.dataset.value:(WEAPON_ORDER[0]||'assault');
  grid.replaceChildren();
  for(const id of WEAPON_ORDER){const button=document.createElement('button');button.type='button';button.className='admin-weapon-choice';button.dataset.adminWeaponChoice=id;button.dataset.controllerKey=`admin-weapon:${id}`;button.setAttribute('role','tab');button.textContent=WEAPON_SPECS[id]?.name||id;button.addEventListener('click',()=>syncAdminWeaponEditor(id));grid.append(button);}
}
hydrateWeaponTuneSelector();
const appRoot=$('appRoot'), gameStage=$('gameStage'), entryScreen=$('entryScreen'), rotateGate=$('rotateGate'), menu=$('menu'), lobbyScreen=$('lobbyScreen'), pause=$('pause'), lobbyQuitConfirm=$('lobbyQuitConfirm'), mapDeleteConfirm=$('mapDeleteConfirm');
const nameInput=$('nameInput'),codeInput=$('codeInput'),menuStatus=$('menuStatus');
const deployTabs=[...document.querySelectorAll('[data-deploy-tab]')],deployViews=[...document.querySelectorAll('[data-deploy-view]')];
const lobbyModeButtons=[...document.querySelectorAll('[data-lobby-mode-choice]')],lobbyPrimaryButtons=[...document.querySelectorAll('[data-lobby-primary-choice]')],lobbySecondaryButtons=[...document.querySelectorAll('[data-lobby-secondary-choice]')],lobbyTacticalButtons=[...document.querySelectorAll('[data-lobby-tactical-choice]')],lobbyLethalButtons=[...document.querySelectorAll('[data-lobby-lethal-choice]')],lobbyMapButtons=[...document.querySelectorAll('[data-lobby-map-choice]')],lobbySideTabs=[...document.querySelectorAll('[data-lobby-side-tab]')],lobbySideViews=[...document.querySelectorAll('[data-lobby-side-view]')];
const matchPrimaryButtons=[...document.querySelectorAll('[data-match-primary-choice]')],matchSecondaryButtons=[...document.querySelectorAll('[data-match-secondary-choice]')],matchTacticalButtons=[...document.querySelectorAll('[data-match-tactical-choice]')],matchLethalButtons=[...document.querySelectorAll('[data-match-lethal-choice]')];
const lobbyRoster=$('lobbyRoster'),lobbyBotDifficulty=$('lobbyBotDifficulty'),lobbyMapPreview=$('lobbyMapPreview'),lobbyMinimapMode=$('lobbyMinimapMode'),lobbyMod=$('lobbyMod'),lobbyScoreLimit=$('lobbyScoreLimit'),lobbyTimeLimit=$('lobbyTimeLimit');
const matchList=$('matchList'),matchCount=$('matchCount'),canvas=$('game'),connectionOverlay=$('connectionOverlay'),connectionText=$('connectionText'),chatComposer=$('chatComposer'),chatInput=$('chatInput'),chatInputText=$('chatInputText'),chatPlaceholder=$('chatPlaceholder'),chatKeyboard=$('chatKeyboard'),chatSendBtn=$('chatSendBtn'),chatShiftBtn=$('chatShiftBtn');
const gameTextEditor=$('gameTextEditor'),gameTextEditorTitle=$('gameTextEditorTitle'),gameTextEditorValue=$('gameTextEditorValue'),gameTextEditorPlaceholder=$('gameTextEditorPlaceholder'),gameTextKeyboard=$('gameTextKeyboard'),gameTextShiftBtn=$('gameTextShiftBtn');
const uiGestures=createUiGestures({root:appRoot,getScope:controllerInputContext});
lobbyMod.dataset.options=JSON.stringify(GAME_MOD_ORDER.map(id=>({value:id,label:gameModSpec(id).name})));
initGameControls();
bindLoadoutWorkspaceTabs();
document.querySelectorAll('[data-app-version]').forEach(el=>{el.textContent=`Version ${APP_VERSION}`;});

const platform=detectInputPlatform();
let isTouch=platform.touchControls;
const clientId=getClientId(),clientAuth=getClientAuth();
const samePlayerId=(a,b)=>String(a??'')===String(b??'');
nameInput.value=preferences.getItem('breachName')||`Player${Math.floor(Math.random()*90+10)}`;
const storedFaction=preferences.getItem('breachFaction')||preferences.getItem('breachTeam');
let preferredTeam=normalizeTeam(storedFaction);
if(!preferences.getItem('breachFaction')&&preferences.getItem('breachTeam')){preferences.setItem('breachFaction',teamKey(preferredTeam));preferences.removeItem('breachTeam');}
const storedPreferredPrimary=preferences.getItem('breachPrimary'),storedPreferredSecondary=preferences.getItem('breachSecondary');
let storedAttachmentPreferences={};try{storedAttachmentPreferences=JSON.parse(preferences.getItem('breachAttachments')||'{}')||{};}catch{}
const normalizedPreferredWeapons=normalizeLoadoutDefinition({primaryWeapon:storedPreferredPrimary,secondaryWeapon:storedPreferredSecondary,primaryAttachments:storedAttachmentPreferences.primary,secondaryAttachments:storedAttachmentPreferences.secondary});
let preferredPrimary=normalizedPreferredWeapons.primaryWeapon,preferredSecondary=normalizedPreferredWeapons.secondaryWeapon;
let preferredPrimaryAttachments=normalizedPreferredWeapons.primaryAttachments,preferredSecondaryAttachments=normalizedPreferredWeapons.secondaryAttachments;
let preferredTactical=normalizeTactical(preferences.getItem('breachTactical'));
let preferredLethal=normalizeLethal(preferences.getItem('breachLethal'));
let storedLoadoutClasses=[];try{storedLoadoutClasses=JSON.parse(preferences.getItem('breachLoadoutClasses')||'[]')||[];}catch{}
let preferredActiveClassId=normalizeLoadoutClassId(preferences.getItem('breachActiveClass'));
let preferredLoadoutClasses=normalizeLoadoutClasses(storedLoadoutClasses,{primaryWeapon:preferredPrimary,secondaryWeapon:preferredSecondary,primaryAttachments:preferredPrimaryAttachments,secondaryAttachments:preferredSecondaryAttachments,tactical:preferredTactical,lethal:preferredLethal});
let storedKillstreakSelection=[];try{storedKillstreakSelection=JSON.parse(preferences.getItem('breachKillstreaks')||'[]')||[];}catch{}
let preferredKillstreakSelection=normalizeKillstreakSelection(storedKillstreakSelection.length?storedKillstreakSelection:DEFAULT_KILLSTREAK_SELECTION);
{const c=loadoutClassById(preferredLoadoutClasses,preferredActiveClassId);preferredPrimary=c.primaryWeapon;preferredSecondary=c.secondaryWeapon;preferredPrimaryAttachments={...c.primaryAttachments};preferredSecondaryAttachments={...c.secondaryAttachments};preferredTactical=c.tactical;preferredLethal=c.lethal;}
let masterMuted=preferences.getItem('breachMuted')==='1';
const requestedRoom=new URL(location.href).searchParams.get('room');
if(requestedRoom)codeInput.value=normalizeCode(requestedRoom);

let scene, camera, renderer, clock, worldRoot, worldHemiLight, worldSunLight, pistolGroup, pistolFlash, pistolMag, akimboLeftGroup, akimboRightGroup, akimboLeftFlash, akimboRightFlash, akimboLeftLever, akimboRightLever, akimboLeftBarrel, akimboRightBarrel, akimboLeftStock, akimboRightStock, assaultGroup, assaultFlash, assaultMag, umpGroup, umpFlash, umpMag, machineGunGroup, machineGunFlash, machineGunBox, machineGunBolt, shotgunGroup, shotgunFlash, shotgunPump, semiShotgunGroup, semiShotgunFlash, semiShotgunMag, sniperGroup, sniperFlash, sniperBolt, grenadeLauncherGroup, grenadeLauncherFlash, rpgGroup, rpgFlash, mantleHands, firstPersonHands, fpLeftHand, fpRightHand, fpLeftForearm, fpRightForearm, fpEquipmentProp, fpRigScratch;
let hudScene, hudCamera, hudMaterial, hudTexture, hudCanvas, hudCtx, hudScale = 1, hudLastDraw = 0, hudLastScopeActive = false;
let socket = null, reconnectTimer = null, reconnectAttempt = 0;
let initialConnectionAttempt=null,initialConnectionSerial=0;
const INITIAL_CONNECTION_TIMEOUT_MS=15000;
function finishInitialConnectionAttempt(){const attempt=initialConnectionAttempt;if(!attempt)return;clearTimeout(attempt.timer);initialConnectionAttempt=null;}
function cancelInitialConnection(reason='Connection canceled.',{silent=false}={}){
  const attempt=initialConnectionAttempt;if(!attempt)return false;initialConnectionAttempt=null;clearTimeout(attempt.timer);attempt.controller.abort();
  if(socket){try{socket.close(1000,'Connection canceled')}catch{}socket=null;}
  clearTimeout(reconnectTimer);currentRoom='';shell.cancelConnection();disableMenu(false);if(!silent)setStatus(reason,'error');return true;
}
function beginInitialConnectionAttempt(text){
  cancelInitialConnection('',{silent:true});const controller=new AbortController(),id=++initialConnectionSerial;
  const attempt={id,controller,timer:0};initialConnectionAttempt=attempt;shell.beginConnection(text);attempt.timer=setTimeout(()=>{if(initialConnectionAttempt?.id===id)cancelInitialConnection('Connection timed out. Try again.');},INITIAL_CONNECTION_TIMEOUT_MS);return attempt;
}
function initialConnectionSignal(attempt){return initialConnectionAttempt?.id===attempt?.id?attempt.controller.signal:null;}
function initialConnectionCurrent(attempt){return !!attempt&&initialConnectionAttempt?.id===attempt.id&&!attempt.controller.signal.aborted;}
let currentRoom = '', myName = '', myTeam = preferredTeam, selfColor = relationshipColor(RELATIONSHIP.SELF), godMode = false, isMatchAdmin = false, matchOwnerId = '', pendingTeam='';
let primaryWeapon=preferredPrimary,secondaryWeapon=preferredSecondary,primaryAttachments={...preferredPrimaryAttachments},secondaryAttachments={...preferredSecondaryAttachments},tacticalEquipment=preferredTactical,lethalEquipment=preferredLethal,loadoutClasses=normalizeLoadoutClasses(preferredLoadoutClasses),activeClassId=preferredActiveClassId,pendingClassId='',pendingLoadout=null,loadoutDraft=null,loadoutBaseDraft=null,matchClassDrafts=null,matchClassBase=null,killstreakSelection=normalizeKillstreakSelection(preferredKillstreakSelection),matchState={status:'waiting',round:1,mode:DEFAULT_GAME_MODE,blueScore:0,redScore:0,scoreLimit:DEFAULT_MATCH_RULES.scoreLimit,timeLimitMs:DEFAULT_MATCH_RULES.timeLimitMs,minimapRevealAll:false,minimapDirectional:false,warmupEndsAt:0,endsAt:0,winner:'',winnerId:'',winnerName:'',reason:'',serverTime:0},matchCustom=false;
let hp = 100, wastedUntil = 0, currentWeapon = preferredPrimary, ammo = freshClientAmmo(), equipment=freshClientEquipment(tacticalEquipment,lethalEquipment), reloadUntil = 0, reloadWeapon = '', reloadRequestPending=false, pendingWeapon='';
let flashUntil=0,flashPeakUntil=0;
let assaultFireMode=preferences.getItem('breachAssaultFireMode')==='semi'?'semi':'auto';
let adsWanted=false,adsBlend=0,baseFov=70,sniperBreathReserve=1,sniperBreathSteadyBlend=0,sniperSwayScopeBlend=0,sniperBreathExhausted=false,sniperBreathActive=false,sniperSwayYaw=0,sniperSwayPitch=0,lastWastedBy='',lastWastedWeapon='',lastWastedHeadshot=false,lastWastedDistance=0,deathViewStartYaw=0,deathViewTargetYaw=NaN,deathViewStartPitch=0;
let crouchWanted=false,crouched=false,crouchBlend=0,viewFeetY=NaN;
let sprintLatched=false,sprinting=false,sliding=false,slideStartedAt=0,slideDirX=0,slideDirZ=0,slideStartSpeed=0,slideRecoveryUntil=0,sprintBlockedUntil=0,sprintActionReadyAt=0,pendingSprintShot='',pendingSprintShotExpiresAt=0,sprintViewBlend=0,slideViewBlend=0;
let correctionViewX=0,correctionViewY=0,correctionViewZ=0;
let myStats={kills:0,deaths:0},scoreboardOpen=false,scoreboardScroll=0,scoreboardDrag=null,scoreboardPanel=null,killConfirmUntil=0,killConfirmName='',killConfirmWeapon='',killConfirmHeadshot=false,killConfirmDistance=0;
let headshotUntil=0,announcerCurrent=null;const announcerQueue=[];
let yaw = 0, pitch = 0, recoilDebtPitch = 0, recoilDebtYaw = 0, recoilPatternPitch = 0, recoilPatternYaw = 0, recoilBurstActive=false, recoilBurstWeapon='', recoilBurstReleaseAt=0, recoilBurstEndedAt=0, weaponKickZ=0, weaponKickVelocity=0, verticalVelocity = 0, moveVelocityX = 0, moveVelocityZ = 0, knockX = 0, knockZ = 0, jumpSeq = 0, lastGroundedAt = 0, jumpBufferedUntil = 0;
let traversal=null,traversalSeq=0,traversalIntentUntil=0,traversalIntentSeq=0,traversalConsumedIntentSeq=0;
let ladderState=null,ladderSeq=0,ladderAttachLockId='',ladderAttachLockUntil=0,ladderAttachNeedsRelease=false;
let onGround = true, lastShotVisualAt = 0, lastLocalShotAt = 0, fireReadyAt = freshClientFireReady(), lastStateSent = 0, lastPing = 0, lastPingLocalAt = 0, serverClockOffset = 0, remoteViewDelayMs=REMOTE_INTERPOLATION_MS, remoteDelayMeanMs=REMOTE_INTERPOLATION_MS, remoteDelayJitterMs=0, remoteDelaySamples=0;
let localShotHeat = Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));
let localShotHeatAt = Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));
let localRecoilStep = Object.fromEntries(WEAPON_ORDER.map(name=>[name,-1]));
let localWeaponShotSequence = Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));
let lastSentState={x:NaN,y:NaN,z:NaN,yaw:NaN,pitch:NaN,ads:false,adsAmount:0,crouched:false,sprinting:false,sliding:false,grounded:true,moveX:0,moveZ:0,ladderId:'',ladderMove:0}, localEquipmentCooldownUntil=0, stateSeq=0, lastCorrectionSeq=0;
const localPredictionHistory=[];
const netDiag={
  startedAt:performance.now(),rttMs:0,rttMeanMs:0,rttJitterMs:0,pingSamples:0,
  lastStateSendAt:0,lastStateGapMs:0,maxStateGapMs:0,stateGapOver120:0,
  serverLastStateGapMs:0,serverMaxStateGapMs:0,serverStateAgeMs:0,
  corrections:0,maxCorrectionM:0,lastCorrectionM:0,lastCorrectionReason:'',correctionReasons:Object.create(null),
  rejects:0,lastReject:'',rejectReasons:Object.create(null),socketCloses:0,reconnects:0,socketErrors:0,messageErrors:0,
  frameStalls:0,maxFrameMs:0,lastFrameMs:0,events:[]
};
function netDiagCount(map,key){const name=String(key||'unknown');map[name]=(map[name]||0)+1;}
function netDiagEvent(type,data={}){netDiag.events.push({at:Math.round(performance.now()-netDiag.startedAt),type,...data});if(netDiag.events.length>24)netDiag.events.shift();diagnosticsRecordEvent(`net:${type}`,data);}
function recordNetFrame(rawDt){const ms=Math.max(0,Number(rawDt)||0)*1000;netDiag.lastFrameMs=ms;netDiag.maxFrameMs=Math.max(netDiag.maxFrameMs,ms);if(ms>=NET_DIAG_FRAME_STALL_MS){netDiag.frameStalls++;if(ms>=180)netDiagEvent('frame',{ms:Math.round(ms)});}}
function recordNetStateSend(now){if(netDiag.lastStateSendAt){const gap=Math.max(0,now-netDiag.lastStateSendAt);netDiag.lastStateGapMs=gap;netDiag.maxStateGapMs=Math.max(netDiag.maxStateGapMs,gap);if(gap>120)netDiag.stateGapOver120++;}netDiag.lastStateSendAt=now;}
function recordNetPong(echoed,received,serverNet){const rtt=Math.max(0,received-echoed);netDiag.rttMs=rtt;if(netDiag.pingSamples===0){netDiag.rttMeanMs=rtt;netDiag.rttJitterMs=0;}else{const prior=netDiag.rttMeanMs;netDiag.rttMeanMs=prior+(rtt-prior)*.18;netDiag.rttJitterMs=netDiag.rttJitterMs+(Math.abs(rtt-prior)-netDiag.rttJitterMs)*.22;}netDiag.pingSamples++;if(serverNet&&typeof serverNet==='object'){netDiag.serverLastStateGapMs=Math.max(0,Number(serverNet.lastStateGapMs)||0);netDiag.serverMaxStateGapMs=Math.max(netDiag.serverMaxStateGapMs,Number(serverNet.maxStateGapMs)||0);netDiag.serverStateAgeMs=Math.max(0,Number(serverNet.stateAgeMs)||0);}}
function recordNetCorrection(m,magnitude){const reason=String(m?.reason||'unspecified');netDiag.corrections++;netDiag.lastCorrectionM=magnitude;netDiag.maxCorrectionM=Math.max(netDiag.maxCorrectionM,magnitude);netDiag.lastCorrectionReason=reason;netDiagCount(netDiag.correctionReasons,reason);if(magnitude>=.35)netDiagEvent('correction',{m:Number(magnitude.toFixed(3)),reason,seq:Math.max(0,Math.floor(Number(m?.seq)||0))});}
function recordNetReject(kind,reason){const label=`${String(kind||'action')}:${String(reason||'rejected')}`;netDiag.rejects++;netDiag.lastReject=label;netDiagCount(netDiag.rejectReasons,label);netDiagEvent('reject',{label});}
function resetNetworkDiagnostics(){const keep=performance.now();Object.assign(netDiag,{startedAt:keep,rttMs:0,rttMeanMs:0,rttJitterMs:0,pingSamples:0,lastStateSendAt:0,lastStateGapMs:0,maxStateGapMs:0,stateGapOver120:0,serverLastStateGapMs:0,serverMaxStateGapMs:0,serverStateAgeMs:0,corrections:0,maxCorrectionM:0,lastCorrectionM:0,lastCorrectionReason:'',rejects:0,lastReject:'',socketCloses:0,reconnects:0,socketErrors:0,messageErrors:0,frameStalls:0,maxFrameMs:0,lastFrameMs:0,events:[]});netDiag.correctionReasons=Object.create(null);netDiag.rejectReasons=Object.create(null);}
function networkDiagnosticsSnapshot(){return JSON.parse(JSON.stringify({...netDiag,uptimeMs:performance.now()-netDiag.startedAt,connected:socket?.readyState===WebSocket.OPEN,room:currentRoom||''}));}
window.breachNetworkDiagnostics=networkDiagnosticsSnapshot;
window.resetBreachNetworkDiagnostics=resetNetworkDiagnostics;
let localMoveAmount=0,moveBobPhase=0,landingKick=0,weaponSwapStartedAt=0,reloadStartedAt=0,deathAnimStartedAt=0,nextFootstepAt=0,footstepSide=0,shotgunPumpStartedAt=0,shotgunPumpSoundPlayed=false;
let audioUnlockPromise=null;
const DEFAULT_PLAYER_SETTINGS=Object.freeze({lookSensitivity:1,adsSensitivity:1,touchSensitivity:1,controllerVerticalSensitivity:1,controllerResponseCurve:'dynamic',controllerAimAssist:'on',controllerMoveDeadzone:.10,controllerLookDeadzone:.07,masterVolume:.85,sfxVolume:.9,musicVolume:.55,graphics:isTouch?'medium':'high',diagnostics:'off'});
function loadPlayerSettings(){
  let saved={};try{saved=JSON.parse(preferences.getItem('breachPlayerSettings')||'{}')||{}}catch{}
  const numeric=(key,min,max)=>{const raw=saved[key];if(raw===null||raw===undefined||raw==='')return DEFAULT_PLAYER_SETTINGS[key];const value=Number(raw);return Number.isFinite(value)?Math.max(min,Math.min(max,value)):DEFAULT_PLAYER_SETTINGS[key];};
  return {lookSensitivity:numeric('lookSensitivity',.5,2),adsSensitivity:numeric('adsSensitivity',.35,1.25),touchSensitivity:numeric('touchSensitivity',.5,2),controllerVerticalSensitivity:numeric('controllerVerticalSensitivity',.5,1.5),controllerResponseCurve:['dynamic','standard','linear'].includes(saved.controllerResponseCurve)?saved.controllerResponseCurve:DEFAULT_PLAYER_SETTINGS.controllerResponseCurve,controllerAimAssist:saved.controllerAimAssist==='off'?'off':'on',controllerMoveDeadzone:numeric('controllerMoveDeadzone',.02,.25),controllerLookDeadzone:numeric('controllerLookDeadzone',.02,.25),masterVolume:numeric('masterVolume',0,1),sfxVolume:numeric('sfxVolume',0,1),musicVolume:numeric('musicVolume',0,1),graphics:['low','medium','high'].includes(saved.graphics)?saved.graphics:DEFAULT_PLAYER_SETTINGS.graphics,diagnostics:saved.diagnostics==='on'?'on':'off'};
}
let playerSettings=loadPlayerSettings();
let playerSettingsDraft=null;
const DIAGNOSTICS_SAMPLE_INTERVAL_MS=33;
const DIAGNOSTICS_MAX_SAMPLES=9000;
const DIAGNOSTICS_MAX_EVENTS=2400;
const DIAGNOSTICS_MAX_INCIDENTS=12;
const DIAGNOSTICS_INCIDENT_HISTORY=150;
const diagnosticsRecorder={startedAt:performance.now(),startedEpoch:Date.now(),lastSampleAt:0,lastFrameAt:0,lastEffectivePitch:NaN,lastBasePitch:NaN,lastCameraY:NaN,lastRecoilDebtPitch:NaN,lastFireHeld:false,lastIncidentAt:0,samples:[],events:[],incidents:[]};
const controllerDiagnostics={rawX:0,rawY:0,inputX:0,inputY:0,inputLength:0,assistStrength:0,assistTarget:'',targetYaw:0,targetPitch:0,velocityYaw:0,velocityPitch:0,deltaYaw:0,deltaPitch:0,dt:0};
function diagnosticsRecordingEnabled(value=playerSettings){return NET_DIAG_URL_ENABLED||value?.diagnostics==='on';}
function diagnosticsRound(value,digits=4){const n=Number(value);return Number.isFinite(n)?Number(n.toFixed(digits)):null;}
const DIAGNOSTICS_VISUAL_HISTORY_MAX=180;
const diagnosticsVisualHistory=[];
function diagnosticsVisualEvent(type,data={}){
  diagnosticsVisualHistory.push({at:new Date().toISOString(),t:diagnosticsRelativeTime(),type:String(type||'visual'),...data});
  if(diagnosticsVisualHistory.length>DIAGNOSTICS_VISUAL_HISTORY_MAX)diagnosticsVisualHistory.splice(0,diagnosticsVisualHistory.length-DIAGNOSTICS_VISUAL_HISTORY_MAX);
}
function diagnosticsColorHex(value){
  try{return value?.isColor?`#${value.getHexString()}`:null;}catch{return null;}
}
function diagnosticsVisualSnapshot(){
  const now=performance.now(),remotePlayers=[];
  for(const r of remotes.values()){
    const baseMaterial=r.thermalBaseMaterials?.body||r.body?.material,renderMaterial=r.body?.material,role=gameplayRelation(r.team,r.bot),expectedFactionBodyColor=remoteFactionColor(r.team,r.zombie),expectedRelationshipColor=relationshipColor(role),expectedMinimapColor=expectedRelationshipColor,expectedNameTagColor=expectedRelationshipColor,hitFlashActive=now<Number(r.hitFlashUntil||0),expectedBodyEmissive=hitFlashActive?'#d8d1c0':'#000000',baseBodyColor=diagnosticsColorHex(baseMaterial?.color),baseBodyEmissive=diagnosticsColorHex(baseMaterial?.emissive),renderBodyColor=diagnosticsColorHex(renderMaterial?.color),renderBodyEmissive=diagnosticsColorHex(renderMaterial?.emissive),actualMinimapColor=minimapDotColor(r),uniformPattern=baseMaterial?.userData?.factionUniform||null,expectedUniformPattern=r.zombie?'zombie':remoteUniformMeta(r.team,false).pattern,nameTagVisible=!!r.tag?.visible,expectedNameTagVisible=r.hp>0&&(role!==RELATIONSHIP.ENEMY||samePlayerId(r.id,aimedRemoteId)),nameTagOpacity=diagnosticsRound(r.tag?.material?.opacity,3),actorDeathMarkers=teammateDeathMarkers.filter(marker=>samePlayerId(marker.actorId,r.id)).map(marker=>({id:marker.id,ageMs:Math.max(0,Math.round(now-marker.createdAt)),remainingMs:Math.max(0,Math.round(marker.expiresAt-now)),x:diagnosticsRound(marker.x,3),y:diagnosticsRound(marker.y,3),z:diagnosticsRound(marker.z,3)})),visualErrors=[];
    if(baseBodyColor!==expectedFactionBodyColor)visualErrors.push('body-faction-color');if(baseBodyEmissive!==expectedBodyEmissive)visualErrors.push('body-emissive');if(uniformPattern!==expectedUniformPattern)visualErrors.push('body-uniform-pattern');if(r.relationship!==role)visualErrors.push('relationship-role');if(r.minimapColor!==expectedMinimapColor||actualMinimapColor!==expectedMinimapColor)visualErrors.push('minimap-color');if(r.tagColor!==expectedNameTagColor)visualErrors.push('name-tag-color');if(nameTagVisible!==expectedNameTagVisible)visualErrors.push('name-tag-visibility');const bodyMismatch=visualErrors.some(x=>x.startsWith('body-')),relationshipMismatch=visualErrors.some(x=>!x.startsWith('body-'));
    remotePlayers.push({id:String(r.id||''),name:String(r.name||''),team:String(r.team||''),teamLabel:teamLabel(r.team),factionColor:factionColor(r.team),role,bot:!!r.bot,zombie:!!r.zombie,hp:Number(r.hp)||0,godMode:!!r.godMode,friendly:modeFriendly(r.team),expectedFactionBodyColor,expectedRelationshipColor,expectedMinimapColor,storedMinimapColor:r.minimapColor||null,actualMinimapColor,expectedNameTagColor,actualNameTagColor:r.tagColor||null,nameTagVisible,expectedNameTagVisible,nameTagOpacity,uniformPattern,expectedUniformPattern,actorDeathMarkers,expectedBodyEmissive,baseBodyColor,baseBodyEmissive,renderBodyColor,renderBodyEmissive,baseEmissiveIntensity:diagnosticsRound(baseMaterial?.emissiveIntensity,3),thermalActive:!!r.thermalActive,hitFlashActive,hitFlashRemainingMs:Math.max(0,Math.round(Number(r.hitFlashUntil||0)-now)),bodyMismatch,relationshipMismatch,visualErrors,visualMismatch:visualErrors.length>0});
  }
  return{presentationPolicy:{self:RELATIONSHIP_COLORS[RELATIONSHIP.SELF],friendlyHuman:RELATIONSHIP_COLORS[RELATIONSHIP.FRIENDLY_HUMAN],friendlyBot:RELATIONSHIP_COLORS[RELATIONSHIP.FRIENDLY_BOT],enemy:RELATIONSHIP_COLORS[RELATIONSHIP.ENEMY]},factions:{alpha:{team:'blue',color:factionColor('blue')},bravo:{team:'red',color:factionColor('red')}},visualMismatchCount:remotePlayers.filter(r=>r.visualMismatch).length,local:{id:String(clientId||''),name:String(myName||''),team:String(myTeam||''),teamLabel:teamLabel(myTeam),factionColor:factionColor(myTeam),role:RELATIONSHIP.SELF,pendingTeam:String(pendingTeam||''),pendingTeamLabel:pendingTeam?teamLabel(pendingTeam):'',godMode:!!godMode,hp:Number(hp)||0,selfColor:String(selfColor||''),expectedMinimapColor:localDisplayColor()},match:{room:String(currentRoom||''),mode:String(matchState?.mode||''),status:String(matchState?.status||''),map:String(currentMapId||''),inMatch:!!shell?.inMatch},replay:{pending:replayPending?{kind:replayPending.kind,killerId:String(replayPending.attacker?.id||''),victimId:String(replayPending.victim?.id||''),killAt:Number(replayPending.killAt)||0}:null,active:replayPlayback?{kind:replayPlayback.kind,killerId:String(replayPlayback.killerId||''),victimId:String(replayPlayback.victim?.id||''),progress:diagnosticsRound(replayProgress(),3),rate:diagnosticsRound(Number(replayPlayback.currentRate)||1,2),killAt:Number(replayPlayback.killAt)||0,clipStartAt:Number(replayPlayback.clipStartAt)||0,clipEndAt:Number(replayPlayback.clipEndAt)||0,slowStartAt:Number(replayPlayback.slowStartAt)||0,slowEndAt:Number(replayPlayback.slowEndAt)||0,frames:replayPlayback.frames?.length||0,events:replayPlayback.events?.length||0}:null,historyFrames:replayHistory.length,historyEvents:replayEvents.length},remotes:remotePlayers,deathMarkers:teammateDeathMarkers.map(marker=>({id:marker.id,actorId:marker.actorId,name:marker.name,team:marker.team,teamLabel:teamLabel(marker.team),bot:marker.bot,role:relationshipFor({viewerTeam:myTeam,actorTeam:marker.team,teamBased:currentModeSpec().teamBased,self:false,bot:marker.bot}),x:diagnosticsRound(marker.x,3),y:diagnosticsRound(marker.y,3),z:diagnosticsRound(marker.z,3),ageMs:Math.max(0,Math.round(now-marker.createdAt)),remainingMs:Math.max(0,Math.round(marker.expiresAt-now))})),recentVisualEvents:diagnosticsVisualHistory.slice()};
}
function diagnosticsRelativeTime(now=performance.now()){return Math.max(0,Math.round(now-diagnosticsRecorder.startedAt));}
function diagnosticsRecordEvent(type,data={}){
  if(!diagnosticsRecordingEnabled())return;
  const event={t:diagnosticsRelativeTime(),type:String(type||'event'),...data};diagnosticsRecorder.events.push(event);if(diagnosticsRecorder.events.length>DIAGNOSTICS_MAX_EVENTS)diagnosticsRecorder.events.splice(0,Math.min(300,diagnosticsRecorder.events.length));
}
function diagnosticsDataCount(){return diagnosticsRecorder.samples.length+diagnosticsRecorder.events.length+diagnosticsRecorder.incidents.length+(controllerRecording?.count||0);}
function resetDiagnosticsRecording({markStart=true}={}){
  controllerRecording?.clear();
  diagnosticsRecorder.startedAt=performance.now();diagnosticsRecorder.startedEpoch=Date.now();diagnosticsRecorder.lastSampleAt=0;diagnosticsRecorder.lastFrameAt=0;diagnosticsRecorder.lastEffectivePitch=NaN;diagnosticsRecorder.lastBasePitch=NaN;diagnosticsRecorder.lastCameraY=NaN;diagnosticsRecorder.lastRecoilDebtPitch=NaN;diagnosticsRecorder.lastFireHeld=false;diagnosticsRecorder.lastIncidentAt=0;diagnosticsRecorder.samples.length=0;diagnosticsRecorder.events.length=0;diagnosticsRecorder.incidents.length=0;resetNetworkDiagnostics();
  if(markStart&&diagnosticsRecordingEnabled())diagnosticsRecordEvent('recording_start',{version:APP_VERSION,protocol:PROTOCOL_VERSION,inputMode:activeInputMode});syncDiagnosticsSettingsUI();hudLastDraw=0;
}
function diagnosticsControllerSnapshot(){return{connected:gamepadFrame.connected,mapping:gamepadFrame.mapping,device:gamepadFrame.id,scope:controllerInputContext(),focused:shell.snapshot().focused,pointerContacts:gameplayPointers.size,rawX:diagnosticsRound(gamepadFrame?.rawLookX??gamepadFrame?.lookX),rawY:diagnosticsRound(gamepadFrame?.rawLookY??gamepadFrame?.lookY),x:diagnosticsRound(controllerDiagnostics.inputX),y:diagnosticsRound(controllerDiagnostics.inputY),len:diagnosticsRound(controllerDiagnostics.inputLength),rt:diagnosticsRound(gamepadFrame?.buttons?.[GAMEPAD_BUTTON.RT]||0,3),lt:diagnosticsRound(gamepadFrame?.buttons?.[GAMEPAD_BUTTON.LT]||0,3),assist:diagnosticsRound(controllerDiagnostics.assistStrength,3),assistTarget:controllerDiagnostics.assistTarget||'',targetPitch:diagnosticsRound(controllerDiagnostics.targetPitch),velocityPitch:diagnosticsRound(controllerDiagnostics.velocityPitch),pitchDelta:diagnosticsRound(controllerDiagnostics.deltaPitch),dt:diagnosticsRound(controllerDiagnostics.dt,5)};}
function diagnosticsFrameState(now,rawFrameDt){
  const effectivePitch=effectiveAimPitch(),effectiveYaw=effectiveAimYaw(),cameraY=Number(camera?.position?.y),fire=fireInputHeld();
  const renderInfo=renderer?.info?.render||{},memoryInfo=renderer?.info?.memory||{},visibleSmokeClouds=[...smokeClouds.values()].reduce((n,c)=>n+(c.root?.visible!==false?1:0),0);
  return{t:diagnosticsRelativeTime(now),dtMs:diagnosticsRound((Number(rawFrameDt)||0)*1000,2),mode:activeInputMode,fire,mouseFire:!!mouseFireDown,touchFire:touchRoleActive('fire'),gamepadFire:!!gamepadFireDown,weapon:currentWeapon,ads:diagnosticsRound(adsBlend,3),yaw:diagnosticsRound(yaw),pitch:diagnosticsRound(pitch),effectiveYaw:diagnosticsRound(effectiveYaw),effectivePitch:diagnosticsRound(effectivePitch),recoilPitch:diagnosticsRound(recoilDebtPitch),recoilPitchTarget:diagnosticsRound(recoilPatternPitch),recoilYaw:diagnosticsRound(recoilDebtYaw),recoilYawTarget:diagnosticsRound(recoilPatternYaw),recoilDebtPitch:diagnosticsRound(recoilDebtPitch),recoilDebtYaw:diagnosticsRound(recoilDebtYaw),recoilPatternPitch:diagnosticsRound(recoilPatternPitch),recoilPatternYaw:diagnosticsRound(recoilPatternYaw),recoilBurst:!!recoilBurstActive,recoilStep:Number(localRecoilStep[currentWeapon]??-1),cameraX:diagnosticsRound(camera?.position?.x,3),cameraY:diagnosticsRound(cameraY,3),cameraZ:diagnosticsRound(camera?.position?.z,3),positionY:diagnosticsRound(position?.y,3),viewFeetY:diagnosticsRound(viewFeetY,3),correctionY:diagnosticsRound(correctionViewY,3),verticalVelocity:diagnosticsRound(verticalVelocity,3),grounded:!!onGround,stateSeq,correctionSeq:lastCorrectionSeq,rttMs:diagnosticsRound(netDiag.rttMs,1),lastCorrectionM:diagnosticsRound(netDiag.lastCorrectionM,3),touchLook:touchRoleActive('look'),renderCalls:Number(renderInfo.calls)||0,renderTriangles:Number(renderInfo.triangles)||0,gpuGeometries:Number(memoryInfo.geometries)||0,gpuTextures:Number(memoryInfo.textures)||0,activeBullets:bullets.size,activeThrowables:throwables.size,activeImpacts:bulletImpactFx.length,activeExplosions:tacticalFx.length,activeSmokeClouds:smokeClouds.size,visibleSmokeClouds,activeRocketPuffs:rocketTrailPuffs.length,activeRemotes:remotes.size,activeAudioVoices:Number(gameAudio?.status?.().activeVoices)||0,controller:diagnosticsControllerSnapshot()};
}
function diagnosticsCaptureIncident(kind,sample,data={}){
  const now=performance.now();if(now-diagnosticsRecorder.lastIncidentAt<250)return;diagnosticsRecorder.lastIncidentAt=now;
  const incident={t:sample.t,kind,details:data,before:diagnosticsRecorder.samples.slice(-DIAGNOSTICS_INCIDENT_HISTORY),at:sample};diagnosticsRecorder.incidents.push(incident);if(diagnosticsRecorder.incidents.length>DIAGNOSTICS_MAX_INCIDENTS)diagnosticsRecorder.incidents.shift();diagnosticsRecordEvent('incident',{kind,...data});
}
function captureGameplayDiagnostics(rawFrameDt,now=performance.now()){
  if(!diagnosticsRecordingEnabled()||!shell.inMatch||!shell.canPlay||!camera||!position){diagnosticsRecorder.lastFrameAt=0;diagnosticsRecorder.lastEffectivePitch=NaN;diagnosticsRecorder.lastBasePitch=NaN;diagnosticsRecorder.lastCameraY=NaN;diagnosticsRecorder.lastRecoilDebtPitch=NaN;diagnosticsRecorder.lastFireHeld=false;return;}
  // Keep the per-render diagnostic path allocation-free. Full nested samples are
  // built only at the recorder's 30 Hz sample cadence or when an incident is
  // actually detected, so diagnostics cannot manufacture the hitch it is meant
  // to measure on mobile.
  const effective=Number(effectiveAimPitch()),base=Number(pitch),cameraY=Number(camera.position.y),recoilPitch=Number(recoilDebtPitch)||0,fire=fireInputHeld();
  if(fire!==diagnosticsRecorder.lastFireHeld)diagnosticsRecordEvent(fire?'fire_hold_start':'fire_hold_end',{weapon:currentWeapon,pitch:diagnosticsRound(base),effectivePitch:diagnosticsRound(effective),rawLookY:diagnosticsRound(gamepadFrame?.rawLookY??gamepadFrame?.lookY),rt:diagnosticsRound(gamepadFrame?.buttons?.[GAMEPAD_BUTTON.RT]||0,3)});
  let incidentKind='',incidentData=null;
  if(fire&&diagnosticsRecorder.lastFireHeld&&Number.isFinite(diagnosticsRecorder.lastEffectivePitch)&&Number.isFinite(effective)){
    const effectiveDelta=effective-diagnosticsRecorder.lastEffectivePitch,baseDelta=base-diagnosticsRecorder.lastBasePitch,cameraYDelta=cameraY-diagnosticsRecorder.lastCameraY;
    if(effectiveDelta<-.055){incidentKind='aim_pitch_down';incidentData={effectiveDelta:diagnosticsRound(effectiveDelta),baseDelta:diagnosticsRound(baseDelta),cameraYDelta:diagnosticsRound(cameraYDelta,3),rawLookY:diagnosticsRound(gamepadFrame?.rawLookY??gamepadFrame?.lookY),processedLookY:diagnosticsRound(controllerDiagnostics.inputY),recoilDelta:diagnosticsRound(recoilPitch-(Number.isFinite(diagnosticsRecorder.lastRecoilDebtPitch)?diagnosticsRecorder.lastRecoilDebtPitch:recoilPitch))};}
    else if(cameraYDelta<-.22){incidentKind='camera_drop';incidentData={effectiveDelta:diagnosticsRound(effectiveDelta),baseDelta:diagnosticsRound(baseDelta),cameraYDelta:diagnosticsRound(cameraYDelta,3),correctionY:diagnosticsRound(correctionViewY,3),lastCorrectionM:diagnosticsRound(netDiag.lastCorrectionM,3)};}
  }
  const shouldSample=now-diagnosticsRecorder.lastSampleAt>=DIAGNOSTICS_SAMPLE_INTERVAL_MS,sample=(shouldSample||incidentKind)?diagnosticsFrameState(now,rawFrameDt):null;
  if(incidentKind&&sample)diagnosticsCaptureIncident(incidentKind,sample,incidentData||{});
  diagnosticsRecorder.lastFrameAt=now;diagnosticsRecorder.lastEffectivePitch=effective;diagnosticsRecorder.lastBasePitch=base;diagnosticsRecorder.lastCameraY=cameraY;diagnosticsRecorder.lastRecoilDebtPitch=recoilPitch;diagnosticsRecorder.lastFireHeld=fire;
  if(shouldSample&&sample){diagnosticsRecorder.lastSampleAt=now;diagnosticsRecorder.samples.push(sample);if(diagnosticsRecorder.samples.length>DIAGNOSTICS_MAX_SAMPLES)diagnosticsRecorder.samples.splice(0,Math.min(600,diagnosticsRecorder.samples.length));}
}
function diagnosticsExportPayload(){
  const settings=normalizePlayerSettingsValue(playerSettings);delete settings.masterVolume;delete settings.sfxVolume;delete settings.musicVolume;
  return{format:'breach-diagnostics-v4',recoilModel:'authoritative-aim-debt-v1',exportedAt:new Date().toISOString(),appVersion:APP_VERSION,protocolVersion:PROTOCOL_VERSION,recording:diagnosticsRecordingEnabled(),recordingStartedAt:diagnosticsRecordingEnabled()?new Date(diagnosticsRecorder.startedEpoch).toISOString():null,diagnosticsWindowStartedAt:new Date(diagnosticsRecorder.startedEpoch).toISOString(),durationMs:Math.max(0,performance.now()-diagnosticsRecorder.startedAt),environment:{userAgent:navigator.userAgent||'',platform:navigator.platform||'',touch:!!isTouch,inputMode:activeInputMode,unsupportedGamepads:gamepadInput.unsupported(),viewport:{w:viewW||0,h:viewH||0},map:currentMapId||'',matchMode:matchState?.mode||''},runtime:diagnosticsVisualSnapshot(),playerSettings:settings,controllerInput:controllerRecording?.exportData()??null,network:networkDiagnosticsSnapshot(),sampleIntervalMs:DIAGNOSTICS_SAMPLE_INTERVAL_MS,samples:diagnosticsRecorder.samples,events:diagnosticsRecorder.events,incidents:diagnosticsRecorder.incidents};
}
function exportDiagnosticsRecording(){
  try{diagnosticsVisualEvent('diagnostics_export',{team:String(myTeam||''),godMode:!!godMode,pendingTeam:String(pendingTeam||''),remoteCount:remotes.size});const json=JSON.stringify(diagnosticsExportPayload());const blob=new Blob([json],{type:'application/json'}),url=URL.createObjectURL(blob),stamp=new Date().toISOString().replace(/[:.]/g,'-'),a=document.createElement('a');a.href=url;a.download=`breach-diagnostics-${APP_VERSION}-${stamp}.json`;a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast('DIAGNOSTICS DOWNLOADED',{duration:900,key:'diagnostics-download'});}catch(error){console.error('Diagnostics export failed',error);showToast('DIAGNOSTICS EXPORT FAILED');}
}
function syncDiagnosticsSettingsUI(){
  const active=diagnosticsRecordingEnabled(),el=$('diagnosticsStatus'),hasData=diagnosticsDataCount()>0,button=$('playerDiagnosticsBtn');
  if(button){button.textContent=active?'STOP RECORDING':'START RECORDING';button.setAttribute('aria-pressed',active?'true':'false');button.classList.toggle('active',active);}
  if(el){const seconds=Math.round(Math.max(0,performance.now()-diagnosticsRecorder.startedAt)/1000);el.textContent=active?`RECORDING · ${seconds}s · ${diagnosticsRecorder.incidents.length} INCIDENT${diagnosticsRecorder.incidents.length===1?'':'S'}`:hasData?(controllerRecording?.count?'RECORDING SAVED':`STOPPED · ${diagnosticsRecorder.incidents.length} INCIDENT${diagnosticsRecorder.incidents.length===1?'':'S'}`):'OFF';}
  if($('diagnosticsExportBtn'))$('diagnosticsExportBtn').disabled=false;if($('diagnosticsClearBtn'))$('diagnosticsClearBtn').disabled=!hasData;
}
function setDiagnosticsRecording(enabled){
  const next=!!enabled,before=diagnosticsRecordingEnabled();
  if(before===next){syncDiagnosticsSettingsUI();return;}
  if(before&&!next)diagnosticsRecordEvent('recording_stop',{samples:diagnosticsRecorder.samples.length,events:diagnosticsRecorder.events.length,incidents:diagnosticsRecorder.incidents.length});
  playerSettings=normalizePlayerSettingsValue({...playerSettings,diagnostics:next?'on':'off'});
  if(playerSettingsDraft)playerSettingsDraft=normalizePlayerSettingsValue({...playerSettingsDraft,diagnostics:next?'on':'off'});
  savePlayerSettings();
  controllerRecording?.setEnabled(diagnosticsRecordingEnabled());
  if(next)resetDiagnosticsRecording();else{syncDiagnosticsSettingsUI();hudLastDraw=0;}
  syncPlayerSettingsUI(playerSettingsDraft||playerSettings);
  setSettingsStatus('');
}
function toggleDiagnosticsRecording(){setDiagnosticsRecording(!diagnosticsRecordingEnabled());}

const gameAudio=createAudioEngine({cues:SOUND_CUES,getVolumes:()=>({master:masterMuted?0:playerSettings.masterVolume,sfx:playerSettings.sfxVolume,music:playerSettings.musicVolume})});
let introMusicHandle=null;

let toastCurrent=null;const toastQueue=[];let hurtUntil = 0, hitUntil = 0;
let blastFeedbackUntil=0,blastFeedbackPower=0,blastFeedbackSeed=0;
let botConfig={blueBots:0,redBots:0,difficulty:'normal'};
const bloodSplats=[];
const damageIndicators=[];
let position = null;
const keys = new Set();
const moveInput = { mx:0, mz:0, len:0 };
const remotes = new Map();
const teammateDeathMarkers=[];
let teammateDeathSkullTexture=null;
const REPLAY_HISTORY_MS=7200,REPLAY_SAMPLE_MS=80,REPLAY_MAX_FRAMES=110,REPLAY_EVENT_HISTORY_MS=7600;
const replayHistory=[],replayEvents=[];
let replayLastCaptureAt=0,replayPending=null,replayPlayback=null,replayLocalActor=null;
const lobbyParticipants = new Map();
let pendingGameSnapshot = null;
let lobbyMatchDraft=null,lobbyMatchDirty=false;
let lobbyMapDraft='',lobbyMapDirty=false;
let lobbyLoadoutDraft=null,lobbyClassDrafts=null,lobbyLoadoutDirty=false,lobbyLoadoutRevision=0,lobbyLoadoutAckRevision=0,lobbyStartingClassId=activeClassId,matchLoadoutRevision=0,matchLoadoutAckRevision=0;
let lobbyKillstreakDraft=null,lobbyKillstreakRevision=0,lobbyKillstreakAckRevision=0,lobbyKillstreakSyncPending=false;
const VERSION_CHECK_INTERVAL_MS=60*1000;
const VERSION_RELOAD_GUARD_KEY='breach:runtime-update-reload';
let versionCheckPromise=null,versionIntervalId=0,pendingClientUpdate=null,pendingClientUpdateNotice='',updateReloading=false;
function normalizeVersionMeta(value,source=''){
  const raw=value&&typeof value==='object'?value:{};
  const version=String(raw.version??raw.game??raw.gameVersion??'').trim(),build=String(raw.build??raw.buildId??'').trim(),n=Number(raw.protocol);
  return{version,build,protocol:Number.isFinite(n)?Math.floor(n):0,source};
}
function versionMetaDiffers(meta){return!!meta&&((meta.version&&meta.version!==APP_VERSION)||(meta.protocol&&meta.protocol!==PROTOCOL_VERSION));}
function updateTargetKey(meta){return`${meta?.version||'unknown'}|${meta?.protocol||0}`;}
function activeMatchForUpdate(){return!!shell.inMatch&&matchState?.status!==MATCH_STATUS.ENDED;}
function clearSuccessfulUpdateGuard(){
  try{sessionStorage.removeItem(VERSION_RELOAD_GUARD_KEY);}catch{}
  const url=new URL(location.href);if(url.searchParams.has('__breach_update')||url.searchParams.has('__breach_reload')){url.searchParams.delete('__breach_update');url.searchParams.delete('__breach_reload');history.replaceState(null,'',url);}
}
function forceClientUpdateReload(meta){
  if(updateReloading)return false;const now=Date.now(),target=updateTargetKey(meta);
  try{
    const old=JSON.parse(sessionStorage.getItem(VERSION_RELOAD_GUARD_KEY)||'null');
    if(old?.target===target){
      if(pendingClientUpdateNotice!=='reload-stalled'){pendingClientUpdateNotice='reload-stalled';showToast('UPDATE PENDING · REOPEN BREACH',{priority:2,key:'client-update-stalled'});}return false;
    }
    sessionStorage.setItem(VERSION_RELOAD_GUARD_KEY,JSON.stringify({target,at:now,runningVersion:APP_VERSION,runningBuild:BUILD_ID}));
  }catch{}
  updateReloading=true;const url=new URL(location.href);url.searchParams.set('__breach_update',meta?.version||'latest');url.searchParams.set('__breach_reload',String(now));location.replace(url.href);return true;
}
function requestClientUpdate(meta,{immediate=false}={}){
  if(!versionMetaDiffers(meta))return false;pendingClientUpdate={...meta,immediate:!!immediate};
  if(activeMatchForUpdate()&&!immediate){const label=updateTargetKey(meta);if(pendingClientUpdateNotice!==label){pendingClientUpdateNotice=label;showToast('UPDATE READY · APPLYING AFTER MATCH',{priority:2,key:'client-update-ready'});}return false;}
  return forceClientUpdateReload(pendingClientUpdate);
}
function maybeApplyPendingClientUpdate(state=null){if(!pendingClientUpdate)return false;const snapshot=state||shell.snapshot();if(pendingClientUpdate.immediate||!snapshot.inMatch||matchState?.status===MATCH_STATUS.ENDED)return forceClientUpdateReload(pendingClientUpdate);return false;}
async function fetchVersionMeta(url,source){const target=new URL(url,location.href);target.searchParams.set('__check',String(Date.now()));const response=await fetch(target,{cache:'no-store'});if(!response.ok)throw new Error(`${source} version check failed`);return normalizeVersionMeta(await response.json(),source);}
async function checkForClientUpdate(reason='timer'){
  if(versionCheckPromise)return versionCheckPromise;
  versionCheckPromise=(async()=>{
    const results=await Promise.allSettled([fetchVersionMeta('./version.json','client'),fetchVersionMeta(`${ONLINE_API}/health`,'server')]);
    const clientMeta=results[0].status==='fulfilled'?results[0].value:null,serverMeta=results[1].status==='fulfilled'?results[1].value:null;
    const clientProtocolChanged=!!clientMeta?.protocol&&clientMeta.protocol!==PROTOCOL_VERSION;
    const serverProtocolChanged=!!serverMeta?.protocol&&serverMeta.protocol!==PROTOCOL_VERSION;
    if(clientProtocolChanged||serverProtocolChanged){
      // Two repos deploy independently. A protocol-breaking client reload waits
      // until version.json and the live server report the same new protocol.
      if(clientMeta?.protocol&&clientMeta.protocol===serverMeta?.protocol&&versionMetaDiffers(clientMeta))requestClientUpdate(clientMeta,{immediate:true});
      else if(pendingClientUpdateNotice!=='deploying'){pendingClientUpdateNotice='deploying';showToast('UPDATE DEPLOYING · RETRYING',{priority:2,key:'client-update-deploying'});}
      return;
    }
    if(clientMeta&&versionMetaDiffers(clientMeta)){requestClientUpdate(clientMeta);return;}
    if(clientMeta){clearSuccessfulUpdateGuard();pendingClientUpdateNotice='';}
  })().catch(error=>console.debug('Breach version check skipped',reason,error)).finally(()=>{versionCheckPromise=null;});
  return versionCheckPromise;
}
function startVersionWatcher(){
  void checkForClientUpdate('startup');
  if(!versionIntervalId)versionIntervalId=setInterval(()=>void checkForClientUpdate('interval'),VERSION_CHECK_INTERVAL_MS);
  addEventListener('focus',()=>void checkForClientUpdate('focus'),{passive:true});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)void checkForClientUpdate('visible');},{passive:true});
}
const loadoutEditClass={lobby:activeClassId,match:activeClassId};
const bullets = new Map();
const throwables = new Map();
const tacticalFx = [];
const killstreakFx = [];
const solarBurnFx = [];
let killstreakStatus={streak:0,available:[],earned:[]},killstreakSelected='',killstreakTargeting=null,killstreakTargetRect=null,killstreakTargetConfirmRect=null,killstreakTargetCancelRect=null,killstreakControlUntil=0,earthquakeControlUntil=0,earthquakeControlSeed=0,earthquakeControlStrength=0,ufoLocalLift=0;
let solarEnvironmentBaseline=null;
const bulletImpactFx = [];
const smokeClouds = new Map();
const rocketTrailPuffs = [];
const liveTransientRoots = new Map();
const replayTransientFx = [];
function pruneLiveTransientRoots(){for(const [root] of liveTransientRoots)if(!root?.parent)liveTransientRoots.delete(root);}
function addLiveTransient(root,kind='fx'){
  if(!root)return root;scene?.add(root);liveTransientRoots.set(root,{kind,restoreVisible:null});if(replayPlayback){const meta=liveTransientRoots.get(root);meta.restoreVisible=!!root.visible;root.visible=false;}if(liveTransientRoots.size>160)pruneLiveTransientRoots();return root;
}
function removeLiveTransient(root){if(!root)return;liveTransientRoots.delete(root);try{root.parent?.remove(root);}catch{try{scene?.remove(root);}catch{}}}
function suppressLiveTransientPresentation(){pruneLiveTransientRoots();for(const [root,meta] of liveTransientRoots){if(meta.restoreVisible===null)meta.restoreVisible=!!root.visible;root.visible=false;}}
function restoreLiveTransientPresentation(){for(const [root,meta] of [...liveTransientRoots]){if(!root?.parent){liveTransientRoots.delete(root);continue;}if(meta.restoreVisible!==null){root.visible=!!meta.restoreVisible;meta.restoreVisible=null;}}}
let sharedSmokeTexture = null, lastSmokeVisibilityAt = 0;
function normalizedKillstreakList(value,{unique=false}={}){const out=[];for(const raw of Array.isArray(value)?value:[]){const id=normalizeKillstreak(raw);if(!id)continue;if(unique&&out.includes(id))continue;out.push(id);if(out.length>=8)break;}return out;}
function readyKillstreakKinds(){return killstreakSelection.filter(kind=>killstreakStatus.available.includes(kind));}
function selectReadyKillstreak(preferred=''){
  const ready=readyKillstreakKinds(),wanted=normalizeKillstreak(preferred);if(wanted&&ready.includes(wanted))killstreakSelected=wanted;else if(!ready.includes(killstreakSelected))killstreakSelected=ready[0]||'';hudLastDraw=0;return killstreakSelected;
}
function killstreakKeyboardKey(kind){const i=killstreakSelection.indexOf(normalizeKillstreak(kind));return i>=0&&i<KILLSTREAK_SELECTION_COUNT?String(i+3):'';}
function applyKillstreakState(value={}){
  if(Array.isArray(value.selection)){killstreakSelection=normalizeKillstreakSelection(value.selection);rememberKillstreakSelection(killstreakSelection);lobbyKillstreakSyncPending=false;if(!lobbyKillstreakDraft||lobbyKillstreakDraft.length===KILLSTREAK_SELECTION_COUNT)lobbyKillstreakDraft=[...killstreakSelection];}
  const selected=new Set(killstreakSelection);killstreakStatus={streak:Math.max(0,Math.floor(Number(value.streak)||0)),available:normalizedKillstreakList(value.available).filter(kind=>selected.has(kind)),earned:normalizedKillstreakList(value.earned,{unique:true}).filter(kind=>selected.has(kind))};selectReadyKillstreak(killstreakSelected);
  for(const kind of normalizedKillstreakList(value.justEarned,{unique:true}).filter(id=>selected.has(id))){const spec=KILLSTREAK_SPECS[kind],key=killstreakKeyboardKey(kind);if(spec)queueAnnouncer(`${spec.name} READY`,controllerInputActive()?'D-PAD ↑ SELECT · → USE':isTouch?'TAP STREAK TO USE':`${spec.kills} KILL STREAK · ${key}`,1900,7);}
  renderLobbyKillstreakSetup();hudLastDraw=0;
}
function resetKillstreakClientState({clearRewards=true}={}){if(clearRewards)killstreakStatus={streak:0,available:[],earned:[]};else killstreakStatus={...killstreakStatus,streak:0,earned:[]};killstreakSelected='';killstreakTargeting=null;killstreakTargetRect=null;killstreakTargetConfirmRect=null;killstreakTargetCancelRect=null;killstreakControlUntil=0;earthquakeControlUntil=0;earthquakeControlSeed=0;earthquakeControlStrength=0;ufoLocalLift=0;hudLastDraw=0;}
function cycleKillstreak(direction=1){const ready=readyKillstreakKinds();if(!ready.length){showToast('NO KILLSTREAK READY');return false;}let index=ready.indexOf(killstreakSelected);if(index<0)index=0;else index=(index+(direction<0?-1:1)+ready.length)%ready.length;killstreakSelected=ready[index];const spec=KILLSTREAK_SPECS[killstreakSelected];showToast(`${spec?.short||killstreakSelected.toUpperCase()} SELECTED`,{duration:900,key:'streak-select'});hudLastDraw=0;return true;}
function killstreakCanUse(kind){const id=normalizeKillstreak(kind);return !!id&&shell.canPlay&&matchAllowsCombat(matchState)&&hp>0&&serverNow()>=killstreakControlUntil&&killstreakStatus.available.includes(id);}
function closeKillstreakTargeting({recapture=false}={}){if(!killstreakTargeting)return;killstreakTargeting=null;killstreakTargetRect=null;killstreakTargetConfirmRect=null;killstreakTargetCancelRect=null;hudLastDraw=0;if(recapture&&activeInputMode===INPUT_MODE.KEYBOARD_MOUSE)void shell.capturePointerFromGesture();}
function openKillstreakTargeting(kind){const id=normalizeKillstreak(kind),spec=KILLSTREAK_SPECS[id];if(!spec?.targeted||!killstreakCanUse(id))return false;keys.clear();resetTouchInput();clearFireInput();cancelEquipmentAction();cancelSprint();scoreboardOpen=false;killstreakSelected=id;killstreakTargeting={kind:id,x:position?.x||0,z:position?.z||0,chosen:false};killstreakTargetRect=null;killstreakTargetConfirmRect=null;killstreakTargetCancelRect=null;if((document.pointerLockElement||document.webkitPointerLockElement)===canvas)(document.exitPointerLock||document.webkitExitPointerLock)?.call(document);hudLastDraw=0;return true;}
function confirmKillstreakTarget({recapture=false}={}){if(!killstreakTargeting||!killstreakCanUse(killstreakTargeting.kind))return false;if(!killstreakTargeting.chosen){showToast('SELECT A TARGET FIRST',{duration:900,key:'streak-target'});return false;}const target={...killstreakTargeting};send({t:'killstreak',kind:target.kind,x:target.x,z:target.z});closeKillstreakTargeting({recapture});return true;}
function requestKillstreak(kind=killstreakSelected){const id=normalizeKillstreak(kind);if(!killstreakCanUse(id)){showToast(id?'KILLSTREAK NOT READY':'NO KILLSTREAK READY');return false;}killstreakSelected=id;if(KILLSTREAK_SPECS[id]?.targeted)return openKillstreakTargeting(id);clearFireInput();cancelEquipmentAction();send({t:'killstreak',kind:id});return true;}
function killstreakTargetFromCanvas(x,y,{choose=true}={}){const r=killstreakTargetRect;if(!r||!pointInRect(x,y,r)||!killstreakTargeting)return false;const limit=minimapWorldLimit();killstreakTargeting.x=THREE.MathUtils.clamp(((x-r.x)/r.w*2-1)*limit,-limit,limit);killstreakTargeting.z=THREE.MathUtils.clamp(((y-r.y)/r.h*2-1)*limit,-limit,limit);if(choose)killstreakTargeting.chosen=true;hudLastDraw=0;return true;}
function updateControllerKillstreakTarget(dt,pressed){if(!killstreakTargeting)return false;const limit=minimapWorldLimit(),speed=Math.max(18,limit*1.2),moving=!killstreakTargeting.chosen&&(Math.abs(gamepadFrame.moveX)>.08||Math.abs(gamepadFrame.moveY)>.08);if(moving){killstreakTargeting.x=THREE.MathUtils.clamp(killstreakTargeting.x+gamepadFrame.moveX*speed*dt,-limit,limit);killstreakTargeting.z=THREE.MathUtils.clamp(killstreakTargeting.z+gamepadFrame.moveY*speed*dt,-limit,limit);}if(pressed[GAMEPAD_BUTTON.A]){if(killstreakTargeting.chosen)confirmKillstreakTarget();else{killstreakTargeting.chosen=true;showToast('TARGET LOCKED · A DEPLOY · B EDIT',{duration:1100,key:'streak-target'});}}else if(pressed[GAMEPAD_BUTTON.B]){if(killstreakTargeting.chosen){killstreakTargeting.chosen=false;showToast('TARGET UNLOCKED',{duration:700,key:'streak-target'});}else closeKillstreakTargeting();}hudLastDraw=0;return true;}
const COMBAT_ACTION=Object.freeze({READY:'ready',EQUIPMENT_AIM:'equipmentAim',EQUIPMENT_THROW:'equipmentThrow',WEAPON_RECOVER:'weaponRecover'});
let combatAction={phase:COMBAT_ACTION.READY,kind:'',startedAt:0,commitAt:0,recoverStartedAt:0,recoverUntil:0,pending:null};
function equipmentAimKind(){return combatAction.phase===COMBAT_ACTION.EQUIPMENT_AIM?combatAction.kind:'';}
function combatWeaponAvailable(now=performance.now()){return combatAction.phase===COMBAT_ACTION.READY||(combatAction.phase===COMBAT_ACTION.WEAPON_RECOVER&&now>=combatAction.recoverUntil);}
function combatActionActive(){return combatAction.phase!==COMBAT_ACTION.READY;}
function equipmentWeaponLower(now=performance.now()){
  if(combatAction.phase===COMBAT_ACTION.READY)return 0;
  if(combatAction.phase===COMBAT_ACTION.EQUIPMENT_AIM)return smoothstep01((now-combatAction.startedAt)/105);
  if(combatAction.phase===COMBAT_ACTION.EQUIPMENT_THROW)return 1;
  if(combatAction.phase===COMBAT_ACTION.WEAPON_RECOVER){const span=Math.max(1,combatAction.recoverUntil-combatAction.recoverStartedAt);return 1-smoothstep01((now-combatAction.recoverStartedAt)/span);}
  return 0;
}
let trajectoryRibbon=null,trajectoryCenters=null,trajectoryVertices=null,trajectoryMarker=null,trajectoryLandingRing=null,trajectoryLandingDot=null,trajectoryScratch=null,trajectoryLastUpdate=0;
let trajectoryLastX=NaN,trajectoryLastY=NaN,trajectoryLastZ=NaN,trajectoryLastYaw=NaN,trajectoryLastPitch=NaN,trajectoryLastHeight=NaN;
const TRAJECTORY_MAX_POINTS=56;
const TRAJECTORY_UPDATE_MS=33;
const TRAJECTORY_RENDER_STEP=.04;
const SIM_HEARTBEAT_MS=33;
const SIM_LEADER_STALE_MS=750;
let lastSimHeartbeat=0;
let trajectoryCollision=createProjectileCollisionGrid({
  staticBoxes:STATIC_BOXES,staticColliders:STATIC_PROJECTILE_COLLIDERS,pyramids:PYRAMIDS,naturalObstacles:NATURAL_OBSTACLES,buildingParts:BUILDING_PARTS,
  terrainHeight,naturalGroundBase,cellSize:8,cellHeight:3
});
const mapObstacles = [];
const joy = { x:0, y:0, centerX:0, centerY:0 };
const look = { x:0, y:0 };
const touchRoles = new Map();
const gameplayPointers=createPointerSessions(canvas,{onCancel:state=>releaseCanvasRole(state.id,false)});
let mouseFireDown=false,akimboLeftCycleStartedAt=0,akimboRightCycleStartedAt=0,akimboCycleSoundPlayed={left:false,right:false},akimboReadyAt={left:0,right:0};
const AKIMBO_1887_CYCLE_MS=920;
const touchVisual = { jumpUntil:0, fireUntil:0, reloadUntil:0, swapUntil:0, modeUntil:0, flashUntil:0, stickyUntil:0 };
let controllerRecording=null;
const gamepadInput=createGamepadInput({buttonThreshold:CONTROLLER_TRIGGER_THRESHOLD,onPoll:sample=>controllerRecording?.sample(sample)});
const INPUT_MODE=Object.freeze({TOUCH:'touch',KEYBOARD_MOUSE:'keyboardMouse',CONTROLLER:'controller'});
let gamepadFrame=gamepadInput.poll();
let activeInputMode=isTouch?INPUT_MODE.TOUCH:INPUT_MODE.KEYBOARD_MOUSE;
let gamepadFireDown=false,controllerOwnsAim=false,lastGamepadKey=gamepadFrame.connected?`${gamepadFrame.index}:${gamepadFrame.id}`:'';
let controllerUiFocus=null,controllerUiEditing=null,controllerUiFocusKey='',controllerFocusScope='',controllerScoreboardHeld=false;
const controllerUiFocusMemory=new Map();
let controllerUiAxisDirection='',controllerUiAxisNextAt=0,controllerUiAxisStartedAt=0,controllerUiAdjusting=null;
appRoot.dataset.inputMode=activeInputMode;

function controllerInputActive(){return activeInputMode===INPUT_MODE.CONTROLLER&&gamepadFrame.connected;}
function touchGameplayControlsVisible(){return isTouch&&activeInputMode===INPUT_MODE.TOUCH&&!chatOpen&&!scoreboardOpen&&(builderSession?builderControlsAvailable():!shell.paused&&!shell.panel);}
function clearControllerGameplayInput(){
  gamepadFireDown=false;endRecoilBurst();resetControllerAimMotion();
  if(controllerOwnsAim){controllerOwnsAim=false;setAim(false);}
  if(combatActionActive())cancelEquipmentAction();
}
function setActiveInputMode(mode,{quiet=false}={}){
  if(!Object.values(INPUT_MODE).includes(mode)||mode===activeInputMode)return false;
  const previous=activeInputMode;
  uiGestures.cancel();
  stopSlide();cancelSprint();endRecoilBurst();
  if(previous===INPUT_MODE.CONTROLLER){clearControllerGameplayInput();clearControllerUiFocus();resetControllerUiAxis();}
  if(mode===INPUT_MODE.CONTROLLER){keys.clear();resetTouchInput();mouseFireDown=false;}
  else if(mode===INPUT_MODE.TOUCH){keys.clear();mouseFireDown=false;}
  else{resetTouchInput();}
  activeInputMode=mode;appRoot.dataset.inputMode=mode;hudLayout=null;
  for(const surface of ['lobby','match'])flashLoadoutInputHint(surface,1600);
  return true;
}

function activateTouchInputMode(){
  if(isTouch)return false;
  isTouch=true;
  appRoot.classList.add('touch');
  appRoot.classList.remove('desktop');
  hudLayout=null;
  if(renderer){applyGraphicsQuality();onResize();}
  return true;
}

const killFeed = [];
const chatMessages=[];
let chatOpen=false,chatDraft='',chatShift=false,chatScroll=0,chatDrag=null,chatPanel=null;
let aimedRemoteId='',aimTagRaycaster=null,nextAimTagCheckAt=0;
let minimapStaticCache=null;
restoreSavedCustomMap();
let hudLayout=null;
let viewW=1,viewH=1,viewDpr=1,graphicsContextAvailable=true;

function rebuildTrajectoryCollision(){
  trajectoryCollision=createProjectileCollisionGrid({staticBoxes:STATIC_BOXES,staticColliders:STATIC_PROJECTILE_COLLIDERS,pyramids:PYRAMIDS,naturalObstacles:NATURAL_OBSTACLES,buildingParts:BUILDING_PARTS,terrainHeight,naturalGroundBase,cellSize:8,cellHeight:3});
}
function applyWorldGeometry(geometry,collision){
  ARENA_LIMIT=geometry.ARENA_LIMIT;
  worldGeometry=geometry;
  activeWorldCollision=collision;
  ROADS=worldGeometry.ROADS||[];STATIC_BOXES=worldGeometry.STATIC_BOXES;STATIC_PROJECTILE_COLLIDERS=worldGeometry.STATIC_PROJECTILE_COLLIDERS||null;BUILDINGS=worldGeometry.BUILDINGS;PYRAMIDS=worldGeometry.PYRAMIDS;NATURAL_OBSTACLES=worldGeometry.NATURAL_OBSTACLES;LADDERS=worldGeometry.LADDERS||[];
  TERRAIN_SIZE=worldGeometry.TERRAIN_SIZE;TERRAIN_SEGMENTS=worldGeometry.TERRAIN_SEGMENTS;BUILDING_GEOMETRY=worldGeometry.BUILDING_GEOMETRY;BUILDING_PARTS=worldGeometry.BUILDING_PARTS;
  terrainHeight=worldGeometry.terrainHeight;naturalGroundBase=worldGeometry.naturalGroundBase;worldSupportHeight=worldGeometry.worldSupportHeight;worldStepUpHeight=worldGeometry.worldStepUpHeight;resolveCeilingCollision=worldGeometry.resolveCeilingCollision;groundMaterialCode=worldGeometry.groundMaterialCode||(()=>0);authoredEnvironment=worldGeometry.AUTHORED_ENVIRONMENT||null;
  rebuildTrajectoryCollision();minimapStaticCache=null;hudLastDraw=0;
}
function setActiveMap(value,{rebuild=true}={}){
  if(builderSession){builderSession.map=normalizeMapId(value);return false;}
  const nextId=normalizeMapId(value),nextCustomFingerprint=nextId==='custom-map'?customMapFingerprintValue:'',changed=nextId!==currentMapId||(nextId==='custom-map'&&nextCustomFingerprint!==activeCustomMapFingerprint);
  currentMapId=nextId;activeCustomMapFingerprint=nextCustomFingerprint;
  const bundle=CLIENT_WORLD_BUNDLES[nextId]||CLIENT_WORLD_BUNDLES[DEFAULT_MAP_ID];
  applyWorldGeometry(bundle.geometry,bundle.collision);
  if(changed&&rebuild&&engineInitialized&&scene)rebuildWorldVisuals();
  return changed;
}

function suspendGameplayInput(){
  keys.clear();
  if(killstreakTargeting)closeKillstreakTargeting();
  gamepadInput.reset();uiGestures.cancel();
  for(const key of [...loadoutPreviewAdsKeys])setLoadoutAdsPreview(key,false);
  stopSlide();cancelSprint();
  resetTouchInput();
  clearControllerGameplayInput();
  clearFireInput();
  cancelEquipmentAction();
  setAim(false);
  mouseFireDown=false;
  scoreboardOpen=false;controllerScoreboardHeld=false;
}

function handleShellState(state){
  if(builderSession&&!state.inBuilder)integratedMapBuilder?.suspend();
  if(chatOpen&&(!state.inMatch||state.paused||state.panel||state.connecting))void dismissChat({restorePointer:false});
  if(state.inMatch&&state.paused)syncPauseContext();
  $('resumeBtn').disabled=!graphicsContextAvailable;
  const fsBtn=$('settingsFullscreenBtn');if(fsBtn){const on=!!state.standalone||!!state.fullscreen;fsBtn.classList.toggle('active',on);fsBtn.setAttribute('aria-checked',String(on));fsBtn.setAttribute('aria-label',state.standalone?'Fullscreen (app mode)':on?'Exit fullscreen':'Enter fullscreen');fsBtn.disabled=state.standalone||(!state.fullscreen&&!state.fullscreenSupported);}const rotateFsBtn=$('rotateFullscreenBtn');if(rotateFsBtn){const on=!!state.fullscreen;rotateFsBtn.textContent=on?'EXIT FULLSCREEN':'ENTER FULLSCREEN';rotateFsBtn.setAttribute('aria-label',on?'Exit fullscreen':'Enter fullscreen');rotateFsBtn.classList.toggle('hide',!!state.standalone||(!on&&!state.fullscreenSupported));rotateFsBtn.disabled=!on&&!state.fullscreenSupported;}const connectionCancel=$('connectionCancelBtn');if(connectionCancel)connectionCancel.classList.toggle('hide',!initialConnectionAttempt||state.inMatch);
  if((state.location==='menu'||state.location==='lobby')&&(!state.touchControls||state.surfaceReady)&&!document.hidden)startIntroMusic();else stopIntroMusic();
  maybeApplyPendingClientUpdate(state);
}

function handleViewportChange(metrics){
  applyViewportSize(metrics);
}

const shell=createSessionShell({
  root:appRoot,
  stage:gameStage,
  canvas,
  platform,
  elements:{
    entry:entryScreen,
    entryButton:$('enterFullscreenBtn'),
    entryStatus:$('entryStatus'),
    menu,
    lobby:lobbyScreen,
    builder:$('mapBuilderScreen'),
    rotate:rotateGate,
    connection:connectionOverlay,
    connectionText,
    pause,
    settings:$('settingsPanel'),
    admin:$('adminPanel'),
    loadout:$('loadoutPanel'),
  },
  onSuspend:suspendGameplayInput,
  onStateChange:handleShellState,
  onViewport:handleViewportChange,
  onPointerLockUnavailable:()=>showToast('Mouse capture unavailable'),
  alternateInputReady:()=>controllerInputActive()||chatOpen||!!killstreakTargeting,
  pointerInputRequired:()=>activeInputMode===INPUT_MODE.KEYBOARD_MOUSE,
  gameplayAvailable:()=>graphicsContextAvailable,
});
({w:viewW,h:viewH,dpr:viewDpr}=shell.viewport);
shell.start();
controllerRecording=createControllerRecording({version:APP_VERSION,build:BUILD_ID,enabled:diagnosticsRecordingEnabled(),readContext:()=>({inputMode:activeInputMode,scope:controllerInputContext(),shellFocused:shell.snapshot().focused,location:shell.location,paused:shell.paused,panel:shell.panel,selectedController:gamepadFrame.index,controllerConnected:gamepadFrame.connected,controllerMapping:gamepadFrame.mapping})});
startVersionWatcher();

syncMusicUI();
syncPlayerSettingsUI();

const ENGINE_MODULE_URL = './vendor/three.module.min.js?v=2.5.0';
let engineReady=false, engineLoadPromise=null, engineInitialized=false;

async function ensureThreeEngine(){
  if(engineReady)return true;
  if(engineLoadPromise)return engineLoadPromise;
  engineLoadPromise=(async()=>{
    try{
      const mod=await import(ENGINE_MODULE_URL);EditorScene||=(await import('./editor-scene.js?v=2.5.0')).EditorScene;
      if(!mod?.WebGLRenderer||!mod?.Scene||!mod?.Vector3)throw new Error('Bundled 3D engine is invalid');
      THREE=mod;
      position=new THREE.Vector3(0,0,0);
      if(!engineInitialized){init3D();engineInitialized=true;onResize();}
      engineReady=true;
      return true;
    }catch(error){
      console.error('Breach could not initialize its bundled 3D engine.',error);
      const webglError=/webgl|context/i.test(String(error?.message||error));
      if(!shell.inMatch)setStatus(webglError?'WEBGL2 UNAVAILABLE':'3D ENGINE UNAVAILABLE','error');
      return false;
    }
  })().finally(()=>{engineLoadPromise=null;});
  return engineLoadPromise;
}

async function prepareGameRuntime(){
  // Keep decoding work out of live gameplay. Only the small movement/current-
  // weapon set is warmed before play; everything else stays lazy on first use.
  const unlockPromise=ensureAudio();
  const engineOk=await ensureThreeEngine();
  if(!engineOk)return false;
  void unlockPromise.then(unlocked=>{if(unlocked)return warmGameplayAudio(currentWeapon);}).catch(()=>{});
  return true;
}

bindUI();
createUiFocusScope({root:appRoot,surfaces:[entryScreen,rotateGate,menu,lobbyScreen,connectionOverlay,pause,$('loadoutPanel'),$('settingsPanel'),$('adminPanel'),lobbyQuitConfirm,mapDeleteConfirm,chatComposer,gameTextEditor],getSurface:controllerUiSurface,onKeyboard:()=>setActiveInputMode(INPUT_MODE.KEYBOARD_MOUSE,{quiet:true})});
let controllerUiFrameLast=performance.now();
function runPreEngineControllerFrame(now){
  if(engineInitialized)return;
  requestAnimationFrame(runPreEngineControllerFrame);
  const dt=Math.min(.10,Math.max(0,(now-controllerUiFrameLast)/1000));controllerUiFrameLast=now;updateGamepadInput(dt);
}
requestAnimationFrame(runPreEngineControllerFrame);
if(shell.location==='menu'&&$('menuShell')?.dataset.deployMode==='live')void refreshMatches();
setInterval(()=>{if(shell.location==='menu'&&$('menuShell')?.dataset.deployMode==='live')void refreshMatches();},7000);
// Full-library audio preloading intentionally disabled; gameplay warms only essential cues.

function getClientId(){
  let id = preferences.getItem('breachClient');
  if (!id) {
    const cryptoApi=globalThis.crypto;
    if(typeof cryptoApi?.randomUUID==='function')id=cryptoApi.randomUUID().replace(/-/g,'').slice(0,24);
    else if(typeof cryptoApi?.getRandomValues==='function'){
      const bytes=new Uint8Array(12);cryptoApi.getRandomValues(bytes);id=[...bytes].map(value=>value.toString(16).padStart(2,'0')).join('');
    }else id=`${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`.replace(/[^a-z0-9]/gi,'').padEnd(24,'0').slice(0,24);
    preferences.setItem('breachClient', id);
  }
  return id;
}
function getClientAuth(){
  let secret=String(preferences.getItem('breachClientAuth')||'').toLowerCase();
  if(!/^[a-f0-9]{64}$/.test(secret)){
    const cryptoApi=globalThis.crypto;
    if(typeof cryptoApi?.getRandomValues==='function'){const bytes=new Uint8Array(32);cryptoApi.getRandomValues(bytes);secret=[...bytes].map(value=>value.toString(16).padStart(2,'0')).join('');}
    else{secret='';while(secret.length<64)secret+=`${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`;secret=secret.replace(/[^a-f0-9]/g,'').padEnd(64,'0').slice(0,64);}
    preferences.setItem('breachClientAuth',secret);
  }
  return secret;
}
function normalizeCode(v){ return String(v||'').toUpperCase().replace(/[^A-HJ-NP-Z2-9]/g,'').slice(0,ROOM_CODE_LENGTH); }
function setStatus(text,tone=''){menuStatus.textContent=text;menuStatus.className=`menu-status ${tone}`;}
function apiToWs(base){ return base.replace(/^https:/,'wss:').replace(/^http:/,'ws:'); }
function safeName(){ return (nameInput.value||'Player').replace(/[<>]/g,'').trim().slice(0,18) || 'Player'; }
function applyWorldSettings(value){
  const previousMod=worldSettings.mod;
  worldSettings=normalizeWorldSettings(value);
  movementSettings=modMovement(worldSettings);
  if(previousMod!==worldSettings.mod)applyWorldEnvironment();
  syncPauseContext();
}
function weaponRules(name){const safe=WEAPON_SPECS[name]?name:'pistol',baseRules=worldSettings.weapons[safe]||DEFAULT_WORLD_SETTINGS.weapons[safe],baseSpec=WEAPON_SPECS[safe],resolved=effectiveWeaponSpec(safe);return{...baseRules,mag:resolved.mag,reloadMs:Number(baseRules.reloadMs)*(resolved.reloadMs/baseSpec.reloadMs),cooldownMs:Number(baseRules.cooldownMs)*(resolved.cooldownMs/baseSpec.cooldownMs),speed:Number(baseRules.speed)*(resolved.bulletSpeed/baseSpec.bulletSpeed),resolvedSpec:resolved};}
function aimSensitivityScale(){if(!adsWanted)return 1;const base=(currentWeapon==='sniper'||thermalOpticMode())?magnifiedScopeSensitivityBase():.62;return base*playerSettings.adsSensitivity;}
function controllerRadialAxes(rawX,rawY,minDeadzone,outerDeadzone=.98){
  const x=THREE.MathUtils.clamp(Number(rawX)||0,-1,1),y=THREE.MathUtils.clamp(Number(rawY)||0,-1,1),len=Math.hypot(x,y);
  const inner=THREE.MathUtils.clamp(Number(minDeadzone)||.07,.01,.45),outer=Math.max(inner+.05,THREE.MathUtils.clamp(Number(outerDeadzone)||.98,.75,1));
  if(len<=inner)return{x:0,y:0,length:0};
  const normalized=THREE.MathUtils.clamp((len-inner)/(outer-inner),0,1),scale=normalized/Math.max(len,1e-6);
  return{x:x*scale,y:y*scale,length:normalized};
}
function controllerResponseMagnitude(value,curve=playerSettings.controllerResponseCurve){
  const t=THREE.MathUtils.clamp(Number(value)||0,0,1);
  if(curve==='linear')return t;
  if(curve==='standard')return Math.pow(t,1.35);
  // Dynamic keeps fine input more alive than the old power curve, stays
  // controlled through the middle, and still reaches full turn rate quickly.
  return t*(.84-.16*t+.32*t*t);
}
function controllerMoveAxes(){
  const rawX=Number.isFinite(gamepadFrame.rawMoveX)?gamepadFrame.rawMoveX:gamepadFrame.moveX,rawY=Number.isFinite(gamepadFrame.rawMoveY)?gamepadFrame.rawMoveY:gamepadFrame.moveY;
  return controllerRadialAxes(rawX,rawY,playerSettings.controllerMoveDeadzone,.98);
}
function controllerLookAxes(){
  const rawX=Number.isFinite(gamepadFrame.rawLookX)?gamepadFrame.rawLookX:gamepadFrame.lookX,rawY=Number.isFinite(gamepadFrame.rawLookY)?gamepadFrame.rawLookY:gamepadFrame.lookY;
  const radial=controllerRadialAxes(rawX,rawY,playerSettings.controllerLookDeadzone,.98);if(!radial.length)return radial;
  const shaped=controllerResponseMagnitude(radial.length),scale=shaped/Math.max(radial.length,1e-6);
  return{x:radial.x*scale,y:radial.y*scale,length:shaped};
}
function controllerAdsSensitivityScale(){
  const blend=smoothstep01(adsBlend);if(blend<=.001)return 1;
  const targetFov=effectiveWeaponSpec(currentWeapon)?.adsFov||baseFov;
  const baseTan=Math.max(.001,Math.tan(baseFov*Math.PI/360)),adsTan=Math.max(.001,Math.tan(targetFov*Math.PI/360));
  const fovRatio=THREE.MathUtils.clamp(adsTan/baseTan,.08,1),scoped=Math.pow(fovRatio,.72)*playerSettings.adsSensitivity;
  return THREE.MathUtils.lerp(1,scoped,blend);
}
function controllerAssistRadiusDeg(){
  const fov=magnifiedScopeFov();if(fov)return fov<=10.5?1.2:fov<=13.5?1.45:1.8;
  return THREE.MathUtils.lerp(4.2,2.8,smoothstep01(adsBlend));
}
function controllerAssistMaxDistance(){return magnifiedScopeFov()?180:THREE.MathUtils.lerp(72,115,smoothstep01(adsBlend));}
function remoteControllerAimPoint(remote,out){
  out.copy(remote.group.position);out.y+=THREE.MathUtils.lerp(1.36,1.03,THREE.MathUtils.clamp(remote.crouchBlend||0,0,1));return out;
}
let controllerAimVelocityX=0,controllerAimVelocityY=0,controllerTurnBoost=0,controllerAssistTargetId='',controllerAssistNextScanAt=0,controllerAssistRaycaster=null,controllerAssistOrigin=null,controllerAssistForward=null,controllerAssistVector=null,controllerAssistPoint=null,controllerAssistProjected=null;
function ensureControllerAimScratch(){
  if(!controllerAssistRaycaster)controllerAssistRaycaster=new THREE.Raycaster();
  controllerAssistOrigin ||= new THREE.Vector3();controllerAssistForward ||= new THREE.Vector3();controllerAssistVector ||= new THREE.Vector3();controllerAssistPoint ||= new THREE.Vector3();controllerAssistProjected ||= new THREE.Vector3();
}
function controllerTargetLineVisible(point,distance){
  if(!worldRoot||!camera)return false;ensureControllerAimScratch();camera.getWorldPosition(controllerAssistOrigin);controllerAssistVector.copy(point).sub(controllerAssistOrigin);const dist=distance||controllerAssistVector.length();if(dist<=.05)return true;
  controllerAssistRaycaster.set(controllerAssistOrigin,controllerAssistVector.normalize());controllerAssistRaycaster.near=.05;controllerAssistRaycaster.far=Math.max(.05,dist-.28);
  if(controllerAssistRaycaster.intersectObject(worldRoot,true)[0])return false;
  // Dense smoke is visual cover, so controller assistance must not track a
  // target the player cannot actually see through it.
  const ox=controllerAssistOrigin.x,oy=controllerAssistOrigin.y,oz=controllerAssistOrigin.z,dx=point.x-ox,dy=point.y-oy,dz=point.z-oz,d2=dx*dx+dy*dy+dz*dz;
  if(d2>.001)for(const cloud of smokeClouds.values()){const cp=cloud?.root?.position;if(!cp)continue;const t=THREE.MathUtils.clamp(((cp.x-ox)*dx+(cp.y-oy)*dy+(cp.z-oz)*dz)/d2,0,1);if(t<=.03||t>=.98)continue;const px=ox+dx*t,py=oy+dy*t,pz=oz+dz*t,grow=THREE.MathUtils.clamp((serverNow()-(Number(cloud.bornAt)||serverNow()))/SMOKE_GROW_MS,0,1),visibleScale=SMOKE_START_SCALE+(1-SMOKE_START_SCALE)*grow,r=Math.max(2.8,(Number(cloud.radius)||9.6)*visibleScale*SMOKE_LOS_RADIUS_SCALE);if((cp.x-px)**2+(cp.y-py)**2+(cp.z-pz)**2<r*r)return false;}
  return true;
}
function controllerTargetMetrics(remote,radiusDeg,maxDistance){
  if(!remote||remote.hp<=0||modeFriendly(remote.team)||!camera)return null;ensureControllerAimScratch();remoteControllerAimPoint(remote,controllerAssistPoint);camera.getWorldPosition(controllerAssistOrigin);controllerAssistVector.copy(controllerAssistPoint).sub(controllerAssistOrigin);const distance=controllerAssistVector.length();if(distance<.35||distance>maxDistance)return null;
  camera.getWorldDirection(controllerAssistForward);const angle=Math.acos(THREE.MathUtils.clamp(controllerAssistForward.dot(controllerAssistVector.normalize()),-1,1))*180/Math.PI;if(angle>radiusDeg)return null;
  return{remote,angle,distance,radiusDeg};
}
function scanControllerAimAssist(now=performance.now()){
  if(playerSettings.controllerAimAssist==='off'||!controllerInputActive()||!shell.canPlay||hp<=0||!camera||!worldRoot){controllerAssistTargetId='';return null;}
  if(now<controllerAssistNextScanAt&&controllerAssistTargetId){const held=[...remotes.values()].find(r=>samePlayerId(r.id,controllerAssistTargetId));if(held&&held.hp>0)return held;}
  controllerAssistNextScanAt=now+30;const enterRadius=controllerAssistRadiusDeg(),exitRadius=enterRadius*1.34,maxDistance=controllerAssistMaxDistance();
  const current=[...remotes.values()].find(r=>samePlayerId(r.id,controllerAssistTargetId));if(current){const metric=controllerTargetMetrics(current,exitRadius,maxDistance*1.08);if(metric){remoteControllerAimPoint(current,controllerAssistPoint);if(controllerTargetLineVisible(controllerAssistPoint,metric.distance))return current;}}
  const candidates=[];for(const remote of remotes.values()){const metric=controllerTargetMetrics(remote,enterRadius,maxDistance);if(metric)candidates.push(metric);}candidates.sort((a,b)=>(a.angle/enterRadius+a.distance/maxDistance*.035)-(b.angle/enterRadius+b.distance/maxDistance*.035));
  for(const metric of candidates.slice(0,3)){remoteControllerAimPoint(metric.remote,controllerAssistPoint);if(controllerTargetLineVisible(controllerAssistPoint,metric.distance)){controllerAssistTargetId=String(metric.remote.id);return metric.remote;}}
  controllerAssistTargetId='';return null;
}
function currentControllerAimAssist(now=performance.now()){
  const remote=scanControllerAimAssist(now);if(!remote)return null;ensureControllerAimScratch();const radius=controllerAssistRadiusDeg()*1.34,maxDistance=controllerAssistMaxDistance()*1.08,metric=controllerTargetMetrics(remote,radius,maxDistance);if(!metric){controllerAssistTargetId='';return null;}
  remoteControllerAimPoint(remote,controllerAssistPoint);controllerAssistProjected.copy(controllerAssistPoint).project(camera);if(controllerAssistProjected.z<-1||controllerAssistProjected.z>1){controllerAssistTargetId='';return null;}
  const normalized=THREE.MathUtils.clamp(metric.angle/Math.max(.01,controllerAssistRadiusDeg()),0,1.34),strength=1-smoothstep01(THREE.MathUtils.clamp((normalized-.08)/.92,0,1));
  return{remote,strength,ndcX:controllerAssistProjected.x,ndcY:controllerAssistProjected.y,angle:metric.angle};
}
function resetControllerAimMotion(){controllerAimVelocityX=controllerAimVelocityY=0;controllerTurnBoost=0;controllerAssistTargetId='';controllerAssistNextScanAt=0;}
function consumeRecoilDebtAxis(debt,delta){
  if(debt>0&&delta<0)return Math.max(0,debt+delta);
  if(debt<0&&delta>0)return Math.min(0,debt+delta);
  return debt;
}
function applyPlayerAimDelta(deltaYaw=0,deltaPitch=0){
  const beforeYaw=yaw,beforePitch=pitch;
  yaw+=Number(deltaYaw)||0;pitch=THREE.MathUtils.clamp(pitch+(Number(deltaPitch)||0),-1.28,1.28);
  const appliedYaw=yaw-beforeYaw,appliedPitch=pitch-beforePitch;
  recoilDebtYaw=consumeRecoilDebtAxis(recoilDebtYaw,appliedYaw);recoilDebtPitch=consumeRecoilDebtAxis(recoilDebtPitch,appliedPitch);
  return{yaw:appliedYaw,pitch:appliedPitch};
}
function applyControllerAim(dt){
  const beforeYaw=yaw,beforePitch=pitch,input=controllerLookAxes(),now=performance.now(),assist=currentControllerAimAssist(now),breakout=1-smoothstep01(THREE.MathUtils.clamp((input.length-.80)/.20,0,1)),assistStrength=(assist?.strength||0)*breakout;
  if(input.length>.86)controllerTurnBoost=Math.min(1,controllerTurnBoost+dt/.22);else controllerTurnBoost=Math.max(0,controllerTurnBoost-dt/.08);
  const ads=smoothstep01(adsBlend),turnMultiplier=1+controllerTurnBoost*.30*(1-ads*.72),adsScale=controllerAdsSensitivityScale();
  const scopeFov=magnifiedScopeFov(),minSlow=scopeFov?(scopeFov<=10.5?.49:scopeFov<=13.5?.51:.53):THREE.MathUtils.lerp(.70,.60,ads),slowdown=assist?THREE.MathUtils.lerp(1,minSlow,assistStrength):1;
  const targetYaw=input.x*CONTROLLER_LOOK_YAW_RATE*playerSettings.lookSensitivity*adsScale*turnMultiplier*slowdown;
  const targetPitch=input.y*CONTROLLER_LOOK_PITCH_RATE*playerSettings.lookSensitivity*playerSettings.controllerVerticalSensitivity*adsScale*turnMultiplier*slowdown;
  const smoothing=1-Math.exp(-dt/.024);controllerAimVelocityX+= (targetYaw-controllerAimVelocityX)*smoothing;controllerAimVelocityY+=(targetPitch-controllerAimVelocityY)*smoothing;
  applyPlayerAimDelta(-controllerAimVelocityX*dt,-controllerAimVelocityY*dt);
  if(assist&&assistStrength>.01){const move=controllerMoveAxes(),strafe=THREE.MathUtils.clamp(move.length/.72,0,1),rotWeight=assistStrength*strafe;if(rotWeight>.001){yaw-=THREE.MathUtils.clamp(assist.ndcX,-.75,.75)*.72*rotWeight*dt;
    // Rotational aim assist may help track horizontally, but it must never
    // counter-steer sustained vertical recoil. Recoil control belongs to the
    // player; rotational assist may track horizontally but must not erase the
    // authoritative pitch recoil the player is actively controlling.
    if(!(automaticRecoilActive(currentWeapon)&&recoilBurstActive&&recoilBurstWeapon===currentWeapon))pitch+=THREE.MathUtils.clamp(assist.ndcY,-.75,.75)*.54*rotWeight*dt;
  }}
  pitch=THREE.MathUtils.clamp(pitch,-1.28,1.28);
  controllerDiagnostics.rawX=Number(gamepadFrame?.rawLookX??gamepadFrame?.lookX)||0;controllerDiagnostics.rawY=Number(gamepadFrame?.rawLookY??gamepadFrame?.lookY)||0;controllerDiagnostics.inputX=input.x;controllerDiagnostics.inputY=input.y;controllerDiagnostics.inputLength=input.length;controllerDiagnostics.assistStrength=assistStrength;controllerDiagnostics.assistTarget=String(assist?.remote?.id||controllerAssistTargetId||'');controllerDiagnostics.targetYaw=targetYaw;controllerDiagnostics.targetPitch=targetPitch;controllerDiagnostics.velocityYaw=controllerAimVelocityX;controllerDiagnostics.velocityPitch=controllerAimVelocityY;controllerDiagnostics.deltaYaw=yaw-beforeYaw;controllerDiagnostics.deltaPitch=pitch-beforePitch;controllerDiagnostics.dt=dt;
}
function currentShotHeat(weapon=currentWeapon,now=performance.now()){
  const last=localShotHeatAt[weapon]||0,heat=weaponHeatAfterDelay(weapon,localShotHeat[weapon]||0,last?now-last:0);
  if(heat<.002)return 0;return heat;
}
function currentSpreadRadians(){
  const movement=movementSettings,ads=Math.max(0,Math.min(1,adsBlend)),speed=THREE.MathUtils.lerp(movement.runSpeed,movement.walkSpeed,smoothstep01(ads))*(crouched?CROUCH_SPEED_MULTIPLIER:1);
  return weaponSpreadRadians(currentWeapon,(localMoveAmount||0)*speed,movement.runSpeed,ads,crouched,!onGround,currentShotHeat(),sliding,attachmentsForWeapon(currentWeapon));
}
function accuracyCrosshairRadius(){const fov=(camera?.fov||baseFov)*Math.PI/180,spread=currentSpreadRadians();return THREE.MathUtils.clamp(Math.tan(spread)*(viewH*.5)/Math.max(.08,Math.tan(fov*.5)),3.5,52);}
// Sniper ADS is one continuous main-camera motion. Centering is front-loaded,
// while eye movement and zoom build underneath it from the same master curve.
// Nothing waits for another phase to finish, so there is no visible midpoint.
const SNIPER_WEAPON_HIDE_BLEND=.94;
const MAGNIFIED_SCOPE_SCREEN_RADIUS=.435;
const SNIPER_SCOPE_AXIS_Y=.14;
const SNIPER_BREATH_READY_BLEND=.965;
const SNIPER_BREATH_HOLD_MS=4200;
const SNIPER_BREATH_RECOVER_MS=3200;
const SNIPER_BREATH_RESTART_RESERVE=.28;
const thermalOpticMaterialStates=new Map();
const thermalOpticLightStates=new Map();
let thermalOpticBackgroundState=null,thermalOpticFogState=null,thermalOpticWorldBlend=0,thermalOpticLastCollectAt=0;
function weaponOpticSpec(weapon=currentWeapon){const id=String(attachmentsForWeapon(weapon)?.optic||'');return id?ATTACHMENTS[id]||null:null;}
function scopeZoomLabelForWeapon(weapon=currentWeapon){return String(weaponOpticSpec(weapon)?.zoomLabel||(weapon==='sniper'?'4X':''));}
function activeScopeZoomLabel(){return scopeZoomLabelForWeapon(currentWeapon)||'SCOPE';}
function sniperZoomLabel(){return scopeZoomLabelForWeapon('sniper');}
function sniperTargetFov(){return Number(effectiveWeaponSpec('sniper')?.adsFov)||18;}
function magnifiedScopeFov(){if(adsBlend<=.2)return 0;if(currentWeapon==='sniper'||thermalOpticMode())return Number(effectiveWeaponSpec(currentWeapon)?.adsFov)||0;return 0;}
function magnifiedScopeSensitivityBase(){const fov=Number(effectiveWeaponSpec(currentWeapon)?.adsFov)||baseFov;return fov<=10.5?.15:fov<=13.5?.20:.28;}
function thermalOpticMode(){return String(weaponOpticSpec(currentWeapon)?.thermalMode||'');}
function thermalOpticScopeAmount(){if(!thermalOpticMode())return 0;if(currentWeapon==='sniper')return sniperMaskAmount();const t=smoothstep01((THREE.MathUtils.clamp(adsBlend,0,1)-.52)/.43);return Math.pow(t,1.45);}
function activeScopeMaskAmount(){return currentWeapon==='sniper'?sniperMaskAmount():thermalOpticScopeAmount();}
function activeScopeReticleAmount(){return currentWeapon==='sniper'?sniperReticleAmount():smoothstep01((thermalOpticScopeAmount()-.48)/.42);}
function thermalOpticAmount(){if(!thermalOpticMode())return 0;if(currentWeapon==='sniper')return smoothstep01((sniperAdsMotion()-.66)/.28);return smoothstep01((thermalOpticScopeAmount()-.42)/.48);}
function thermalOpticWorldAmount(){if(!thermalOpticMode())return 0;if(currentWeapon==='sniper')return smoothstep01((sniperMaskAmount()-.88)/.10);return smoothstep01((thermalOpticScopeAmount()-.82)/.15);}
let thermalOpticColorScratch=null;
function thermalGrayTarget(color,mode,out){out=out||(thermalOpticColorScratch||(thermalOpticColorScratch=new THREE.Color()));const lum=color.r*.2126+color.g*.7152+color.b*.0722,gray=THREE.MathUtils.clamp(lum*(mode==='white'?.38:.44)+(mode==='white'?.022:.028),.018,mode==='white'?.44:.50);return out.setRGB(gray,gray,gray);}
function captureThermalOpticMaterial(mat){if(!mat||mat.userData?.modSky||mat.userData?.thermalOpticSignature||thermalOpticMaterialStates.has(mat)||!mat.color?.isColor)return;const map=mat.map||null,thermalMap=map?.userData?.worldTextureName?getWorldThermalTexture(map.userData.worldTextureName):(map?.userData?.thermalTexture||null);thermalOpticMaterialStates.set(mat,{color:mat.color.clone(),emissive:mat.emissive?.isColor?mat.emissive.clone():null,map,thermalMap});}
function collectThermalOpticSceneState(){if(!scene)return;scene.traverse(obj=>{if(obj.isLight){if(!thermalOpticLightStates.has(obj))thermalOpticLightStates.set(obj,{color:obj.color?.clone?.()||null,groundColor:obj.groundColor?.clone?.()||null});return;}const mats=Array.isArray(obj.material)?obj.material:[obj.material];for(const mat of mats)captureThermalOpticMaterial(mat);});if(!thermalOpticBackgroundState&&scene.background?.isColor)thermalOpticBackgroundState=scene.background.clone();if(!thermalOpticFogState&&scene.fog?.color?.isColor)thermalOpticFogState=scene.fog.color.clone();}
function updateThermalOpticWorld(){
  const mode=thermalOpticMode(),amount=thermalOpticWorldAmount(),now=performance.now();
  if(amount>.001&&(thermalOpticWorldBlend<=.001||now-thermalOpticLastCollectAt>500)){collectThermalOpticSceneState();thermalOpticLastCollectAt=now;}
  if(!thermalOpticMaterialStates.size&&!thermalOpticLightStates.size&&!thermalOpticBackgroundState&&!thermalOpticFogState){thermalOpticWorldBlend=amount;return;}
  for(const [mat,state] of thermalOpticMaterialStates){if(!mat?.color?.isColor)continue;thermalGrayTarget(state.color,mode||'white',thermalOpticColorScratch);mat.color.copy(state.color).lerp(thermalOpticColorScratch,amount);if(state.emissive&&mat.emissive?.isColor){thermalGrayTarget(state.emissive,mode||'white',thermalOpticColorScratch).multiplyScalar(.28);mat.emissive.copy(state.emissive).lerp(thermalOpticColorScratch,amount);}const nextMap=amount>.32&&state.thermalMap?state.thermalMap:state.map;if(mat.map!==nextMap)mat.map=nextMap;}
  for(const [light,state] of thermalOpticLightStates){if(state.color&&light.color?.isColor){thermalGrayTarget(state.color,mode||'white',thermalOpticColorScratch);light.color.copy(state.color).lerp(thermalOpticColorScratch,amount);}if(state.groundColor&&light.groundColor?.isColor){thermalGrayTarget(state.groundColor,mode||'white',thermalOpticColorScratch);light.groundColor.copy(state.groundColor).lerp(thermalOpticColorScratch,amount);}}
  if(thermalOpticBackgroundState&&scene?.background?.isColor){thermalGrayTarget(thermalOpticBackgroundState,mode||'white',thermalOpticColorScratch);scene.background.copy(thermalOpticBackgroundState).lerp(thermalOpticColorScratch,amount);}
  if(thermalOpticFogState&&scene?.fog?.color?.isColor){thermalGrayTarget(thermalOpticFogState,mode||'white',thermalOpticColorScratch);scene.fog.color.copy(thermalOpticFogState).lerp(thermalOpticColorScratch,amount);}
  thermalOpticWorldBlend=amount;
  if(amount<=.001){thermalOpticMaterialStates.clear();thermalOpticLightStates.clear();thermalOpticBackgroundState=null;thermalOpticFogState=null;thermalOpticLastCollectAt=0;}
}
function sniperAdsMotion(){
  if(currentWeapon!=='sniper')return 0;
  const t=THREE.MathUtils.clamp(adsBlend,0,1);
  return t*t*t*(t*(t*6-15)+10);
}
function sniperCenterAmount(){
  const t=sniperAdsMotion();
  return 1-Math.pow(1-t,2.35);
}
function sniperEyeAmount(){
  const t=sniperAdsMotion();
  return Math.pow(t,1.18);
}
function sniperZoomAmount(){
  const t=sniperAdsMotion();
  return Math.pow(t,1.42);
}
function sniperMaskAmount(){
  const t=sniperAdsMotion();
  return Math.pow(t,2.85);
}
function sniperReticleAmount(){
  const t=sniperAdsMotion();
  return smoothstep01((t-.72)/.24);
}
function weaponHiddenForScope(weapon=currentWeapon){if(weapon!==currentWeapon)return false;if(weapon==='sniper')return adsBlend>=SNIPER_WEAPON_HIDE_BLEND;return !!thermalOpticMode()&&thermalOpticScopeAmount()>=.94;}
function sniperWeaponHiddenForScope(){return weaponHiddenForScope('sniper');}
function sniperAdsPose(){return{x:0,y:-SNIPER_SCOPE_AXIS_Y,z:-.235,rx:0,ry:0,rz:0};}
function sniperBreathEligible(){return currentWeapon==='sniper'&&adsWanted&&adsBlend>=SNIPER_BREATH_READY_BLEND&&hp>0&&shell.canPlay&&matchAllowsCombat(matchState)&&!reloadUntil&&!traversal&&!ladderState;}
function sniperBreathInputHeld(){
  if(!sniperBreathEligible())return false;
  if(keys.has('ShiftLeft')||keys.has('ShiftRight'))return true;
  if(controllerInputActive()&&!!gamepadFrame?.held?.[GAMEPAD_BUTTON.LS])return true;
  return touchRoleActive('steady');
}
function resetSniperBreath({full=true}={}){sniperBreathSteadyBlend=0;sniperSwayScopeBlend=0;sniperBreathExhausted=false;sniperBreathActive=false;sniperSwayYaw=0;sniperSwayPitch=0;if(full)sniperBreathReserve=1;}
function updateSniperBreathing(dt,now=performance.now()){
  const frameDt=Math.min(.05,Math.max(0,Number(dt)||0)),inputHeld=sniperBreathInputHeld();
  if(inputHeld&&!sniperBreathExhausted&&sniperBreathReserve>.0001){
    sniperBreathActive=true;sniperBreathReserve=Math.max(0,sniperBreathReserve-frameDt/(SNIPER_BREATH_HOLD_MS/1000));
    if(sniperBreathReserve<=.0001){sniperBreathReserve=0;sniperBreathExhausted=true;sniperBreathActive=false;}
  }else{
    sniperBreathActive=false;sniperBreathReserve=Math.min(1,sniperBreathReserve+frameDt/(SNIPER_BREATH_RECOVER_MS/1000));
    if(!inputHeld&&sniperBreathReserve>=SNIPER_BREATH_RESTART_RESERVE)sniperBreathExhausted=false;
  }
  const target=sniperBreathActive?1:0,follow=1-Math.exp(-(target?18:7)*frameDt);sniperBreathSteadyBlend+=(target-sniperBreathSteadyBlend)*follow;
  const scopeTarget=sniperBreathEligible()?1:0,scopeFollow=1-Math.exp(-(scopeTarget?6:28)*frameDt);sniperSwayScopeBlend+=(scopeTarget-sniperSwayScopeBlend)*scopeFollow;
  if(sniperSwayScopeBlend<=.0001){sniperSwayYaw=0;sniperSwayPitch=0;return;}
  const seconds=now*.001,steadyScale=1-.965*sniperBreathSteadyBlend,moveScale=1+THREE.MathUtils.clamp(localMoveAmount,0,1)*.32;
  // Two slow, offset harmonics avoid a mechanical circle while keeping the
  // motion readable as breathing. The reticle stays fixed; this moves the real
  // camera/shot ray beneath it, so what the player sees is what the rifle fires.
  const yawWave=Math.sin(seconds*1.18+.35)*.00165+Math.sin(seconds*.53+1.90)*.00055;
  const pitchWave=Math.sin(seconds*1.53+.82)*.00220+Math.sin(seconds*.69+2.25)*.00065;
  sniperSwayYaw=yawWave*sniperSwayScopeBlend*steadyScale*moveScale;sniperSwayPitch=pitchWave*sniperSwayScopeBlend*steadyScale*moveScale;
}
function rememberTeam(team){preferredTeam=normalizeTeam(team);preferences.setItem('breachFaction',teamKey(preferredTeam));preferences.removeItem('breachTeam');}
function rememberPrimary(weapon){preferredPrimary=PRIMARY_WEAPONS.includes(weapon)?weapon:'assault';preferences.setItem('breachPrimary',preferredPrimary);}
function rememberSecondary(weapon){preferredSecondary=SECONDARY_WEAPONS.includes(weapon)?weapon:'pistol';preferences.setItem('breachSecondary',preferredSecondary);}
function rememberAttachments(primary=primaryAttachments,secondary=secondaryAttachments,primaryName=primaryWeapon,secondaryName=secondaryWeapon){preferredPrimaryAttachments=normalizeWeaponAttachments(primaryName,primary);preferredSecondaryAttachments=normalizeWeaponAttachments(secondaryName,secondary);preferences.setItem('breachAttachments',JSON.stringify({primary:preferredPrimaryAttachments,secondary:preferredSecondaryAttachments}));}
function attachmentsForWeapon(weapon=currentWeapon,loadout=null){const l=loadout||selectedLoadout();return weapon===l.primaryWeapon?normalizeWeaponAttachments(weapon,l.primaryAttachments):weapon===l.secondaryWeapon?normalizeWeaponAttachments(weapon,l.secondaryAttachments):normalizeWeaponAttachments(weapon,{});}
function effectiveWeaponSpec(weapon=currentWeapon,loadout=null){return resolveWeaponSpec(weapon,attachmentsForWeapon(weapon,loadout));}
function weaponCapacity(weapon=currentWeapon,loadout=null){return Math.max(1,Math.floor(Number(effectiveWeaponSpec(weapon,loadout).mag)||1));}
function rememberEquipment(tactical,lethal){preferredTactical=normalizeTactical(tactical);preferredLethal=normalizeLethal(lethal);preferences.setItem('breachTactical',preferredTactical);preferences.setItem('breachLethal',preferredLethal);}
function rememberLoadoutClasses(classes=loadoutClasses,classId=activeClassId){preferredLoadoutClasses=normalizeLoadoutClasses(classes,selectedLoadout());preferredActiveClassId=normalizeLoadoutClassId(classId);preferences.setItem('breachLoadoutClasses',JSON.stringify(preferredLoadoutClasses));preferences.setItem('breachActiveClass',preferredActiveClassId);}
function rememberKillstreakSelection(selection=killstreakSelection){const next=normalizeKillstreakSelection(selection);preferredKillstreakSelection=[...next];preferences.setItem('breachKillstreaks',JSON.stringify(next));}
function classLoadout(classes,id){const c=loadoutClassById(classes,id,selectedLoadout());return normalizeLoadoutChoice(c);}
function classSetEqual(a,b){return JSON.stringify(normalizeLoadoutClasses(a,selectedLoadout()))===JSON.stringify(normalizeLoadoutClasses(b,selectedLoadout()));}
function writeClassLoadout(classes,id,loadout){const normalized=normalizeLoadoutClasses(classes,selectedLoadout()),idx=normalized.findIndex(c=>c.id===normalizeLoadoutClassId(id));if(idx>=0)normalized[idx]={...normalized[idx],...normalizeLoadoutChoice(loadout)};return normalized;}
function loadoutClassesForSurface(surface){return surface==='lobby'?normalizeLoadoutClasses(lobbyClassDrafts||loadoutClasses,selectedLoadout()):normalizeLoadoutClasses(matchClassDrafts||loadoutClasses,selectedLoadout());}
function currentLobbyStartingClassId(){return normalizeLoadoutClassId(lobbyStartingClassId||activeClassId);}
function markLobbyLoadoutDirty(){lobbyLoadoutDirty=!classSetEqual(lobbyClassDrafts||loadoutClasses,loadoutClasses)||currentLobbyStartingClassId()!==normalizeLoadoutClassId(activeClassId);}
function syncLobbyClassesToServer(){
  if(socket?.readyState!==WebSocket.OPEN)return;
  const classes=normalizeLoadoutClasses(lobbyClassDrafts||loadoutClasses,selectedLoadout()),classId=currentLobbyStartingClassId(),start=classLoadout(classes,classId),rev=++lobbyLoadoutRevision;
  // Keep the established server contract: the message always activates the starting class,
  // while loadoutClasses carries edits for every class, including classes being edited off-screen.
  send({t:'loadout',rev,classId,loadoutClasses:classes,...start});
}
function setLobbyStartingClass(id){
  if(!matchAllowsLobbyEdits(matchState))return;
  if(lobbyLoadoutDraft)lobbyClassDrafts=writeClassLoadout(lobbyClassDrafts||loadoutClasses,loadoutEditClass.lobby,lobbyLoadoutDraft);
  lobbyStartingClassId=normalizeLoadoutClassId(id);markLobbyLoadoutDirty();renderLoadoutClassStrip('lobby');renderLoadoutOverview('lobby',lobbyLoadoutDraft||classLoadout(lobbyClassDrafts,lobbyStartingClassId));setLobbyActionState();syncLobbyClassesToServer();
  
}
function renameLoadoutClass(surface,id,value){
  const classId=normalizeLoadoutClassId(id);
  if(surface==='lobby'){
    if(lobbyLoadoutDraft)lobbyClassDrafts=writeClassLoadout(lobbyClassDrafts||loadoutClasses,loadoutEditClass.lobby,lobbyLoadoutDraft);
    const classes=normalizeLoadoutClasses(lobbyClassDrafts||loadoutClasses,selectedLoadout()),idx=classes.findIndex(c=>c.id===classId);if(idx<0)return;
    classes[idx]={...classes[idx],name:normalizeLoadoutClassName(value,idx)};lobbyClassDrafts=classes;markLobbyLoadoutDirty();renderLoadoutClassStrip('lobby');renderLoadoutOverview('lobby',lobbyLoadoutDraft||classLoadout(classes,loadoutEditClass.lobby));setLobbyActionState();syncLobbyClassesToServer();
  }else{
    if(loadoutDraft)matchClassDrafts=writeClassLoadout(matchClassDrafts||loadoutClasses,loadoutEditClass.match,loadoutDraft);const classes=normalizeLoadoutClasses(matchClassDrafts||loadoutClasses,selectedLoadout()),idx=classes.findIndex(c=>c.id===classId);if(idx<0)return;classes[idx]={...classes[idx],name:normalizeLoadoutClassName(value,idx)};matchClassDrafts=classes;syncMatchLoadoutEditor();commitMatchLoadoutChange();
  }
}
function selectLoadoutClass(surface,id){
  const classId=normalizeLoadoutClassId(id);
  if(surface==='lobby'){setLobbyStartingClass(classId);queueControllerUiFocus(`class:${surface}:${classId}:main`);return;}
  if(loadoutDraft)matchClassDrafts=writeClassLoadout(matchClassDrafts||loadoutClasses,loadoutEditClass.match,loadoutDraft);
  loadoutEditClass.match=classId;loadoutBaseDraft=classLoadout(matchClassBase||loadoutClasses,classId);loadoutDraft=classLoadout(matchClassDrafts||loadoutClasses,classId);syncMatchLoadoutEditor();commitMatchLoadoutChange({selectClass:true});setLoadoutWorkspaceMode('match','classes',{ensurePreview:false});queueControllerUiFocus(`class:${surface}:${classId}:main`);
}
function renderLoadoutClassStrip(surface){
  const host=document.querySelector(`[data-loadout-class-strip="${surface}"]`);if(!host)return;
  const classes=loadoutClassesForSurface(surface),baseline=surface==='lobby'?normalizeLoadoutClasses(loadoutClasses,selectedLoadout()):normalizeLoadoutClasses(matchClassBase||loadoutClasses,selectedLoadout()),selected=normalizeLoadoutClassId(loadoutEditClass[surface]||activeClassId),starting=surface==='lobby'?currentLobbyStartingClassId():normalizeLoadoutClassId(activeClassId);
  host.replaceChildren();
  for(const item of classes){
    const base=loadoutClassById(baseline,item.id,selectedLoadout()),dirty=item.name!==base.name||!loadoutChoiceEqual(item,base),card=document.createElement('div');card.className='loadout-class-card';
    card.classList.toggle('selected',surface!=='lobby'&&item.id===selected);card.classList.toggle('starting',surface==='lobby'&&item.id===starting);card.classList.toggle('equipped',surface!=='lobby'&&item.id===activeClassId);card.classList.toggle('pending',surface!=='lobby'&&item.id===pendingClassId&&!!pendingLoadout);card.classList.toggle('dirty',dirty);card.setAttribute('role','listitem');
    const main=document.createElement('button');main.type='button';main.className='loadout-class-main';main.dataset.loadoutClass=item.id;main.dataset.controllerKey=`class:${surface}:${item.id}:main`;main.setAttribute('aria-pressed',String(surface==='lobby'?item.id===starting:item.id===selected));main.setAttribute('aria-label',surface==='lobby'?`Use ${item.name} as starting class`:`Select ${item.name}`);
    const head=document.createElement('div');head.className='loadout-class-card-head';const name=document.createElement('strong');name.textContent=item.name;const state=document.createElement('span');state.textContent=surface==='lobby'&&item.id===starting?'STARTING':surface!=='lobby'&&item.id===pendingClassId&&pendingLoadout?'NEXT':surface!=='lobby'&&item.id===activeClassId?'ACTIVE':dirty?'EDITED':'';head.append(name,state);
    const weapons=document.createElement('div');weapons.className='loadout-class-weapons';const pmods=attachmentCount(item.primaryAttachments),smods=attachmentCount(item.secondaryAttachments);weapons.innerHTML=`<span><b>PRIMARY</b>${WEAPON_SPECS[item.primaryWeapon]?.name||item.primaryWeapon}${pmods?` · ${pmods} MOD${pmods===1?'':'S'}`:''}</span><span><b>SECONDARY</b>${WEAPON_SPECS[item.secondaryWeapon]?.name||item.secondaryWeapon}${smods?` · ${smods} MOD${smods===1?'':'S'}`:''}</span>`;
    const equipment=document.createElement('small');equipment.textContent=`${EQUIPMENT_SPECS[item.tactical]?.short||item.tactical} · ${EQUIPMENT_SPECS[item.lethal]?.short||item.lethal}`;main.append(head,weapons,equipment);main.addEventListener('click',()=>selectLoadoutClass(surface,item.id));
    const edit=document.createElement('button');edit.type='button';edit.className='loadout-class-edit';edit.dataset.controllerKey=`class:${surface}:${item.id}:edit`;edit.textContent='✎';edit.setAttribute('aria-label',`Edit ${item.name}`);edit.addEventListener('click',e=>{e.stopPropagation();switchLoadoutClass(surface,item.id);});card.append(main,edit);host.append(card);
  }
}
function switchLoadoutClass(surface,id){
  const nextId=normalizeLoadoutClassId(id);
  if(surface==='lobby'){
    if(lobbyLoadoutDraft)lobbyClassDrafts=writeClassLoadout(lobbyClassDrafts||loadoutClasses,loadoutEditClass.lobby,lobbyLoadoutDraft);
    loadoutEditClass.lobby=nextId;lobbyLoadoutDraft=classLoadout(lobbyClassDrafts||loadoutClasses,nextId);markLobbyLoadoutDirty();renderLobbySetupControls();setLobbyActionState();
  }else{
    if(loadoutDraft)matchClassDrafts=writeClassLoadout(matchClassDrafts||loadoutClasses,loadoutEditClass.match,loadoutDraft);loadoutEditClass.match=nextId;loadoutBaseDraft=classLoadout(matchClassBase||loadoutClasses,nextId);loadoutDraft=classLoadout(matchClassDrafts||loadoutClasses,nextId);syncMatchLoadoutEditor();
  }
  setLoadoutWorkspaceMode(surface,'class',{ensurePreview:false});renderLoadoutOverview(surface,loadoutDraftForSurface(surface));queueControllerUiFocus(`class-item:${surface}-primary`);
}
function combatItemName(kind){return EQUIPMENT_SPECS[kind]?.name||WEAPON_SPECS[kind]?.name||String(kind||'').toUpperCase();}
function selectedLoadout(){return{primaryWeapon,secondaryWeapon,primaryAttachments:normalizeWeaponAttachments(primaryWeapon,primaryAttachments),secondaryAttachments:normalizeWeaponAttachments(secondaryWeapon,secondaryAttachments),tactical:tacticalEquipment,lethal:lethalEquipment};}
function applyAttachmentState(value={}){primaryAttachments=normalizeWeaponAttachments(primaryWeapon,value.primaryAttachments??primaryAttachments);secondaryAttachments=normalizeWeaponAttachments(secondaryWeapon,value.secondaryAttachments??secondaryAttachments);}
function attachmentCount(value){return ATTACHMENT_SLOTS.reduce((n,slot)=>n+(value?.[slot]?1:0),0);}function loadoutSummary(loadout=selectedLoadout()){const mods=attachmentCount(loadout.primaryAttachments)+attachmentCount(loadout.secondaryAttachments);return`${WEAPON_SPECS[loadout.primaryWeapon]?.name||'Assault Rifle'} + ${WEAPON_SPECS[loadout.secondaryWeapon]?.name||'Pistol'}${mods?` · ${mods} MOD${mods===1?'':'S'}`:''} · ${combatItemName(loadout.tactical)} · ${combatItemName(loadout.lethal)}`;}


function syncMusicUI(){
  for(const [useId,btnId] of [['musicIconUse','musicBtn']]){const use=$(useId),btn=$(btnId);if(use)use.setAttribute('href',masterMuted?'#i-mute':'#i-sound');if(btn)btn.setAttribute('aria-label',masterMuted?'Unmute audio':'Mute all audio');}
  const setting=$('playerMasterMute');if(setting){setting.classList.toggle('active',masterMuted);setting.setAttribute('aria-checked',String(masterMuted));}
}
function setMasterMuted(next){
  const muted=!!next;if(masterMuted===muted){syncMusicUI();return;}
  masterMuted=muted;preferences.setItem('breachMuted',masterMuted?'1':'0');syncMusicUI();
  if(masterMuted)stopIntroMusic();else{void ensureAudio();if(!shell.inMatch)startIntroMusic();}
}
function toggleMasterMute(){setMasterMuted(!masterMuted);}

function currentGameMode(){return normalizeGameMode(matchState?.mode||DEFAULT_GAME_MODE);}
function currentModeSpec(){return gameModeSpec(currentGameMode());}
function modeFriendly(team){return relationshipFor({viewerTeam:myTeam,actorTeam:team,teamBased:currentModeSpec().teamBased})!==RELATIONSHIP.ENEMY;}
function gameplayRelation(team,bot=false){return relationshipFor({viewerTeam:myTeam,actorTeam:team,teamBased:currentModeSpec().teamBased,self:false,bot:!!bot});}
function localDisplayColor(){return relationshipColor(RELATIONSHIP.SELF);}
const FFA_UNIFORM=Object.freeze({base:'#707674',dark:'#353c3d',light:'#aeb4b0',pattern:'urban'});
function remoteUniformMeta(team,zombie=false){if(zombie)return null;return currentModeSpec().teamBased?factionUniform(team):FFA_UNIFORM;}
function remoteFactionColor(team,zombie=false){return zombie?ZOMBIE_BODY_COLOR:remoteUniformMeta(team,false).base;}
function setLocalTeam(team,{remember=true,source='authoritative',refresh=true}={}){const next=normalizeTeam(team),previous=myTeam;myTeam=next;if(remember)rememberTeam(next);selfColor=localDisplayColor();if(previous!==next)diagnosticsVisualEvent('local_team_changed',{from:previous,to:next,fromLabel:teamLabel(previous),toLabel:teamLabel(next),source:String(source||'authoritative'),godMode:!!godMode,pendingTeam:String(pendingTeam||'')});if(refresh&&previous!==next)syncRelationshipPresentation(`team:${source}`);return previous!==next;}
function syncRelationshipPresentation(source='mode'){selfColor=localDisplayColor();for(const r of remotes.values())syncRemoteRelationshipVisual(r,{source});syncThermalOpticSignatures();hudLastDraw=0;diagnosticsVisualEvent('relationship_visual_refresh',{source:String(source||'mode'),team:String(myTeam||''),teamLabel:teamLabel(myTeam),remoteCount:remotes.size});syncPauseContext();syncLobby();}
function roomSessionActive(){return !!currentRoom&&(shell.inLobby||shell.inMatch||socket?.readyState===WebSocket.OPEN);}
function normalizeLobbyParticipant(player){
  if(!player?.id)return null;const bot=!!player.bot,botWeapon=bot&&WEAPON_ORDER.includes(player.weapon)?player.weapon:'',primaryWeapon=botWeapon||(PRIMARY_WEAPONS.includes(player.primaryWeapon)?player.primaryWeapon:PRIMARY_WEAPONS.includes(player.weapon)?player.weapon:'assault');return {id:String(player.id),name:String(player.name||'Player'),team:normalizeTeam(player.team),bot,godMode:!!player.godMode,admin:!!player.admin,primaryWeapon,secondaryWeapon:SECONDARY_WEAPONS.includes(player.secondaryWeapon)?player.secondaryWeapon:'pistol',tactical:normalizeTactical(player.tactical),lethal:normalizeLethal(player.lethal),kills:Number(player.kills)||0,deaths:Number(player.deaths)||0};
}
function replaceLobbyParticipants(players=[],bots=[]){lobbyParticipants.clear();for(const player of [...players,...bots]){const row=normalizeLobbyParticipant(player);if(row&&row.id!==clientId)lobbyParticipants.set(row.id,row);}}
function upsertLobbyParticipant(player){const row=normalizeLobbyParticipant(player);if(row&&row.id!==clientId)lobbyParticipants.set(row.id,row);}
function removeLobbyParticipant(id){lobbyParticipants.delete(String(id||''));}
function syncLobbyBots(list=[]){for(const [id,row] of lobbyParticipants){if(row.bot)lobbyParticipants.delete(id);}for(const bot of list){const row=normalizeLobbyParticipant(bot);if(row)lobbyParticipants.set(row.id,row);}}
function lobbySnapshot(){
  const selfLoadout=shell.inLobby?classLoadout(lobbyClassDrafts||loadoutClasses,currentLobbyStartingClassId()):selectedLoadout(),rows=[{id:clientId,name:myName||safeName(),team:myTeam,bot:false,godMode,admin:isMatchAdmin,...selfLoadout,kills:myStats.kills||0,deaths:myStats.deaths||0,self:true}];
  for(const row of lobbyParticipants.values())rows.push({...row,self:false});
  return rows;
}
function configuredLobbyBots(mode=currentGameMode()){
  if(!shell.inLobby||!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return null;const draft=lobbyMatchDraft||committedLobbyMatchDraft(),spec=gameModeSpec(mode);if(spec.cooperative)return[];let blue=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(draft.blueBots)||0))),red=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(draft.redBots)||0)));if(!spec.teamBased){const total=Math.max(0,Math.min(MAX_MATCH_BOTS,Math.floor(Number(draft.ffaBots)||0)));blue=Math.ceil(total/2);red=Math.floor(total/2);}
  const rows=[];for(let i=0;i<blue;i++)rows.push({id:`draft-bot-blue-${i+1}`,name:spec.teamBased?`${teamLabel('blue')} Bot ${i+1}`:`Bot ${i+1}`,team:'blue',bot:true,godMode:false,admin:false,primaryWeapon:'assault',secondaryWeapon:'pistol',tactical:'flash',lethal:'frag',kills:0,deaths:0,self:false});for(let i=0;i<red;i++)rows.push({id:`draft-bot-red-${i+1}`,name:spec.teamBased?`${teamLabel('red')} Bot ${i+1}`:`Bot ${blue+i+1}`,team:'red',bot:true,godMode:false,admin:false,primaryWeapon:'assault',secondaryWeapon:'pistol',tactical:'flash',lethal:'frag',kills:0,deaths:0,self:false});return rows;
}
function lobbyRosterSnapshot(mode=currentGameMode()){const rows=lobbySnapshot(),preview=configuredLobbyBots(mode);return preview===null?rows:[...rows.filter(row=>!row.bot),...preview];}
function adjustLobbyBotDraft(team,delta){
  if(!shell.inLobby||!isMatchAdmin||!matchAllowsLobbyEdits(matchState)||!delta)return;
  refreshLobbyDraftOwnership();const draft={...(lobbyMatchDraft||committedLobbyMatchDraft())},spec=gameModeSpec(draft.mode);if(spec.cooperative)return;
  if(spec.teamBased){const normalized=normalizeTeam(team),key=normalized==='red'?'redBots':'blueBots';draft[key]=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(draft[key])||0)+Math.sign(delta)));}
  else draft.ffaBots=Math.max(0,Math.min(MAX_MATCH_BOTS,Math.floor(Number(draft.ffaBots)||0)+Math.sign(delta)));
  lobbyMatchDraft=draft;lobbyMatchDirty=!sameLobbyMatchDraft(lobbyMatchDraft,committedLobbyMatchDraft());renderLobbyRoster(draft.mode);renderLobbySetupControls();setLobbyActionState();
}
function renderLobbyRoster(modeOverride=currentGameMode()){
  if(!lobbyRoster)return;const mode=normalizeGameMode(modeOverride),spec=gameModeSpec(mode),rows=lobbyRosterSnapshot(mode),teamBased=spec.teamBased,editable=!!isMatchAdmin&&matchAllowsLobbyEdits(matchState),draft=lobbyMatchDraft||committedLobbyMatchDraft();
  const humanCount=rows.filter(x=>!x.bot).length,botCount=rows.filter(x=>x.bot).length;$('lobbyPlayerCount').textContent=spec.cooperative?`${humanCount}/${MAX_PLAYERS} PLAYERS`:`${humanCount}/${MAX_PLAYERS} PLAYERS · ${botCount}/${MAX_MATCH_BOTS} BOTS`;
  const hostActions=p=>{if(!isMatchAdmin||p.bot||p.id===matchOwnerId||p.self)return'';return`<div class="lobby-player-actions"><button class="lobby-admin-action ${p.admin?'danger':''}" data-lobby-admin-role="${escapeHtml(p.id)}" type="button">${p.admin?'REMOVE ADMIN':'MAKE ADMIN'}</button></div>`;};
  const playerRow=p=>{const owner=p.id===matchOwnerId,role=p.bot?'BOT':owner?'HOST':p.admin?'ADMIN':'',roleChip=role?` <span class="lobby-role-chip${p.bot?' bot':''}">${role}</span>`:'';return`<div class="lobby-player ${p.self?'self':''}${p.bot?' bot':''}"><span class="lobby-player-color ${teamBased?teamKey(p.team):'ffa'}"></span><div class="lobby-player-copy"><strong>${escapeHtml(p.name)}${p.self?' · YOU':''}${roleChip}</strong><small>${escapeHtml(WEAPON_SPECS[p.primaryWeapon]?.name||'ASSAULT RIFLE')}</small></div>${hostActions(p)}</div>`;};
  const botControl=(team,count)=>{if(!editable||spec.cooperative)return'';const minus=count<=0?' disabled':'',plus=count>=(team==='ffa'?MAX_MATCH_BOTS:MAX_BOTS_PER_TEAM)?' disabled':'';return`<div class="lobby-team-bot-control" aria-label="${team==='ffa'?'Match':teamLabel(team)} bot count"><span>BOTS</span><button data-lobby-bot-step="${team}" data-bot-delta="-1" data-controller-key="lobby-bots:${team}:down" type="button"${minus}>−</button><b>${count}</b><button data-lobby-bot-step="${team}" data-bot-delta="1" data-controller-key="lobby-bots:${team}:up" type="button"${plus}>+</button></div>`;};
  const joinControl=team=>{if(!teamBased||spec.cooperative)return'';const mine=myTeam===team,disabled=mine||socket?.readyState!==WebSocket.OPEN?' disabled':'';return`<button class="lobby-team-join ${mine?'active':''}" data-lobby-team-choice="${team}" data-controller-key="lobby-team:${team}" type="button"${disabled}>${mine?'YOU':'JOIN'}</button>`;};
  if(spec.cooperative){lobbyRoster.className='lobby-roster ffa';const humans=rows.filter(p=>!p.bot);lobbyRoster.innerHTML=`<div class="lobby-team-column"><div class="lobby-team-title"><div class="lobby-team-label"><span>SURVIVORS</span><small>${humans.length} PLAYER${humans.length===1?'':'S'}</small></div></div><div class="lobby-team-players">${humans.map(playerRow).join('')||'<div class="lobby-empty-team">Open slot</div>'}</div></div>`;}
  else if(!teamBased){const sorted=[...rows].sort((a,b)=>Number(b.self)-Number(a.self)||Number(a.bot)-Number(b.bot)||a.name.localeCompare(b.name)),ffaBots=Math.max(0,Math.min(MAX_MATCH_BOTS,Math.floor(Number(draft.ffaBots)||0)));lobbyRoster.className='lobby-roster ffa';lobbyRoster.innerHTML=`<div class="lobby-team-column ffa"><div class="lobby-team-title"><div class="lobby-team-label"><span>FREE FOR ALL</span><small>${humanCount}P · ${botCount}B</small></div><div class="lobby-team-title-actions">${botControl('ffa',ffaBots)}</div></div><div class="lobby-team-players">${sorted.map(playerRow).join('')||'<div class="lobby-empty-team">Open slot</div>'}</div></div>`;}
  else{
    lobbyRoster.className='lobby-roster';const column=team=>{const list=rows.filter(p=>p.team===team).sort((a,b)=>Number(b.self)-Number(a.self)||Number(a.bot)-Number(b.bot)||a.name.localeCompare(b.name)),humans=list.filter(p=>!p.bot).length,bots=list.filter(p=>p.bot).length,configured=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(team==='red'?draft.redBots:draft.blueBots)||0)));return`<div class="lobby-team-column ${teamKey(team)}"><div class="lobby-team-title"><div class="lobby-team-label"><span>${teamLabel(team)}</span><small>${humans}P · ${bots}B</small></div><div class="lobby-team-title-actions">${joinControl(team)}${botControl(team,configured)}</div></div><div class="lobby-team-players">${list.map(playerRow).join('')||'<div class="lobby-empty-team">Open slot</div>'}</div></div>`;};lobbyRoster.innerHTML=column('blue')+column('red');
  }
  for(const btn of lobbyRoster.querySelectorAll('[data-lobby-admin-role]'))btn.addEventListener('click',()=>{const id=btn.dataset.lobbyAdminRole,pl=lobbySnapshot().find(x=>x.id===id);if(pl&&!pl.self)send({t:'adminPlayer',targetId:id,action:'admin',enabled:!pl.admin});});
  for(const btn of lobbyRoster.querySelectorAll('[data-lobby-team-choice]'))btn.addEventListener('click',()=>{if(socket?.readyState===WebSocket.OPEN)send({t:'team',team:btn.dataset.lobbyTeamChoice});});
  for(const btn of lobbyRoster.querySelectorAll('[data-lobby-bot-step]'))btn.addEventListener('click',()=>adjustLobbyBotDraft(btn.dataset.lobbyBotStep,Number(btn.dataset.botDelta)||0));
}
function lobbyBotTotal(value=botConfig){return Math.max(0,Math.min(MAX_MATCH_BOTS,(value.blueBots||0)+(value.redBots||0)));}
function lobbyMinimapModeFromState(state=matchState){return state.minimapDirectional?'directional':(state.minimapRevealAll?'all':'standard');}
function committedLobbyMatchDraft(){const mode=currentGameMode(),spec=gameModeSpec(mode),total=lobbyBotTotal();return{mode,mod:worldSettings.mod,blueBots:Math.max(0,Number(botConfig.blueBots)||0),redBots:Math.max(0,Number(botConfig.redBots)||0),ffaBots:total,difficulty:botConfig.difficulty||'normal',scoreLimit:Number(matchState.scoreLimit||spec.scoreLimit)||spec.scoreLimit,timeLimit:Math.max(2,Math.round((matchState.timeLimitMs||spec.timeLimitMs)/60000)),minimap:lobbyMinimapModeFromState(matchState)};}
function sameLobbyMatchDraft(a,b){if(!a||!b)return false;return a.mode===b.mode&&a.mod===b.mod&&Number(a.blueBots)===Number(b.blueBots)&&Number(a.redBots)===Number(b.redBots)&&Number(a.ffaBots)===Number(b.ffaBots)&&a.difficulty===b.difficulty&&Number(a.scoreLimit)===Number(b.scoreLimit)&&Number(a.timeLimit)===Number(b.timeLimit)&&a.minimap===b.minimap;}
function sameLoadoutChoice(a,b){return loadoutChoiceEqual(a,b);}
function refreshLobbyDraftOwnership(){
  // Session-state ownership stays independent from Create-a-Class rendering.
  const committedMatch=committedLobbyMatchDraft();if(!lobbyMatchDraft||!lobbyMatchDirty)lobbyMatchDraft={...committedMatch};
  const committedMap=normalizeMapId(currentMapId);if(!lobbyMapDraft||!lobbyMapDirty)lobbyMapDraft=committedMap;
  const committedLoadout=normalizeLoadoutChoice(selectedLoadout());
  if(!lobbyClassDrafts){lobbyClassDrafts=normalizeLoadoutClasses(loadoutClasses,committedLoadout);lobbyStartingClassId=normalizeLoadoutClassId(activeClassId);loadoutEditClass.lobby=normalizeLoadoutClassId(activeClassId);lobbyLoadoutDraft=classLoadout(lobbyClassDrafts,loadoutEditClass.lobby);}
  else if(!lobbyLoadoutDirty){lobbyClassDrafts=normalizeLoadoutClasses(loadoutClasses,committedLoadout);lobbyStartingClassId=normalizeLoadoutClassId(activeClassId);loadoutEditClass.lobby=normalizeLoadoutClassId(loadoutEditClass.lobby||activeClassId);lobbyLoadoutDraft=classLoadout(lobbyClassDrafts,loadoutEditClass.lobby);}
  if(!lobbyKillstreakDraft)lobbyKillstreakDraft=[...killstreakSelection];
}
function stableKillstreakDraft(value=lobbyKillstreakDraft??killstreakSelection){
  const out=Array(KILLSTREAK_SELECTION_COUNT).fill(''),seen=new Set(),source=Array.isArray(value)?value:[];
  for(let i=0;i<KILLSTREAK_SELECTION_COUNT;i++){const id=normalizeKillstreak(source[i]);if(!id||seen.has(id))continue;out[i]=id;seen.add(id);}return out;
}
function renderLobbyKillstreakSetup(){
  const choices=$('lobbyKillstreakChoices'),equipped=$('lobbyKillstreakEquipped'),count=$('lobbyKillstreakCount');if(!choices||!equipped||!count)return;
  const draft=stableKillstreakDraft(),selected=new Set(draft.filter(Boolean)),equippedCount=selected.size;count.textContent=`${equippedCount} / ${KILLSTREAK_SELECTION_COUNT} EQUIPPED`;count.classList.toggle('incomplete',equippedCount!==KILLSTREAK_SELECTION_COUNT);
  equipped.replaceChildren();for(let i=0;i<KILLSTREAK_SELECTION_COUNT;i++){const kind=draft[i],slot=document.createElement('div');slot.className=`killstreak-equipped-slot${kind?'':' empty'}`;slot.dataset.slot=String(i+1);if(kind){const spec=KILLSTREAK_SPECS[kind];slot.innerHTML=`<span class="kill-count">${spec.kills}</span><div><strong>${escapeHtml(spec.name)}</strong><small>SLOT ${i+1} · KILL STREAK</small></div>`;}else slot.innerHTML=`<span class="kill-count">—</span><div><strong>OPEN SLOT</strong><small>SLOT ${i+1}</small></div>`;equipped.append(slot);}
  choices.replaceChildren();for(const kind of KILLSTREAK_ORDER){const spec=KILLSTREAK_SPECS[kind],active=selected.has(kind),button=document.createElement('button');button.type='button';button.className=`killstreak-choice${active?' selected':''}`;button.dataset.killstreakChoice=kind;button.dataset.controllerKey=`killstreak-choice:${kind}`;button.setAttribute('aria-pressed',String(active));button.classList.toggle('syncing',lobbyKillstreakSyncPending);button.setAttribute('aria-disabled',String(lobbyKillstreakSyncPending));button.innerHTML=`<span class="killstreak-choice-top"><span class="killstreak-choice-kills">${spec.kills}</span><span class="killstreak-choice-state">${active?'EQUIPPED':'SELECT'}</span></span><strong>${escapeHtml(spec.name)}</strong><p>${escapeHtml(spec.description||'')}</p>`;button.addEventListener('click',()=>toggleLobbyKillstreakChoice(kind));choices.append(button);}
}
function toggleLobbyKillstreakChoice(kind){
  if(!shell.inLobby||!matchAllowsLobbyEdits(matchState)){showToast('KILLSTREAKS LOCKED DURING MATCH');return false;}if(lobbyKillstreakSyncPending){showToast('SAVING KILLSTREAKS',{key:'killstreak-saving'});return false;}const id=normalizeKillstreak(kind);if(!id)return false;const draft=stableKillstreakDraft(),selectedIndex=draft.indexOf(id);
  if(selectedIndex>=0){draft[selectedIndex]='';lobbyKillstreakDraft=draft;renderLobbyKillstreakSetup();return true;}
  const openIndex=draft.findIndex(item=>!item);if(openIndex<0){showToast(`${KILLSTREAK_SELECTION_COUNT} KILLSTREAKS EQUIPPED · REMOVE ONE FIRST`,{key:'killstreak-limit'});return false;}
  draft[openIndex]=id;lobbyKillstreakDraft=draft;renderLobbyKillstreakSetup();if(draft.every(Boolean))commitLobbyKillstreakSelection();return true;
}
function commitLobbyKillstreakSelection(){
  const next=normalizeKillstreakSelection(lobbyKillstreakDraft,{fill:false});if(next.length!==KILLSTREAK_SELECTION_COUNT||!matchAllowsLobbyEdits(matchState))return false;killstreakSelection=normalizeKillstreakSelection(next);rememberKillstreakSelection(killstreakSelection);lobbyKillstreakDraft=[...killstreakSelection];lobbyKillstreakSyncPending=true;const rev=++lobbyKillstreakRevision;send({t:'killstreakLoadout',rev,selection:killstreakSelection});renderLobbyKillstreakSetup();setLobbyActionState();hudLastDraw=0;return true;
}
function applyKillstreakLoadoutAck(message={}){
  const rev=Math.max(0,Math.floor(Number(message.rev)||0));if(rev&&rev<lobbyKillstreakRevision)return;if(rev&&rev<lobbyKillstreakAckRevision)return;lobbyKillstreakAckRevision=Math.max(lobbyKillstreakAckRevision,rev);lobbyKillstreakSyncPending=false;if(Array.isArray(message.selection)){killstreakSelection=normalizeKillstreakSelection(message.selection);rememberKillstreakSelection(killstreakSelection);}lobbyKillstreakDraft=[...killstreakSelection];renderLobbyKillstreakSetup();setLobbyActionState();hudLastDraw=0;if(message.accepted===false)showToast(message.reason==='locked'?'KILLSTREAKS LOCKED DURING MATCH':'KILLSTREAK SELECTION REJECTED');
}
let lobbyHostControlsDocked=false;
function restoreAdminTuningNode(nodeId,anchorId){const node=$(nodeId),anchor=$(anchorId);if(node&&anchor&&node.previousElementSibling!==anchor)anchor.after(node);}
function syncLobbyHostControlPlacement(){
  const dock=!!shell.inLobby&&!!isMatchAdmin,gameplay=$('adminGameplay'),weapons=$('adminAdvanced');
  $('lobbyCheatsTab')?.classList.toggle('hide',!dock);
  if(dock){
    if(!lobbyHostControlsDocked){$('lobbyGameplayHostMount')?.append(gameplay);$('lobbyWeaponsHostMount')?.append(weapons);gameplay?.classList.remove('hide');weapons?.classList.remove('hide');populateAdminGameplay(worldSettings);populateAdminWeapons(worldSettings);syncAdminWeaponEditor(currentAdminWeaponSelection());lobbyHostControlsDocked=true;}
    $('adminBotsCard')?.classList.add('hide');
  }else if(lobbyHostControlsDocked){
    restoreAdminTuningNode('adminGameplay','adminGameplayHome');restoreAdminTuningNode('adminAdvanced','adminAdvancedHome');lobbyHostControlsDocked=false;
    const liveBots=$('adminBotsCard');liveBots?.classList.toggle('hide',!shell.inMatch||!!currentModeSpec().cooperative);
    if(shell.panel===SHELL_PANEL.ADMIN)switchAdminTab(activeAdminTab);
  }
  if(!dock&&document.querySelector('[data-lobby-side-tab="cheats"]')?.classList.contains('active'))switchLobbySide('players');
}
function lobbyDisplayMode(){return isMatchAdmin?(lobbyMatchDraft?.mode||currentGameMode()):currentGameMode();}
function setLobbyActionState(){
  if(!shell.inLobby)return;const status=$('lobbyStatus');if(status)status.textContent=(lobbyLoadoutDirty||lobbyKillstreakSyncPending)?'SYNCING':'';
}
function collectLobbyStartSetup(){
  refreshLobbyDraftOwnership();
  const draft={...(lobbyMatchDraft||committedLobbyMatchDraft())},spec=gameModeSpec(draft.mode);let blue=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(draft.blueBots)||0))),red=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(draft.redBots)||0)));
  if(!spec.teamBased){const total=Math.max(0,Math.min(MAX_MATCH_BOTS,Math.floor(Number(draft.ffaBots)||0)));blue=Math.ceil(total/2);red=Math.floor(total/2);}
  if(spec.cooperative){blue=0;red=0;}
  if(blue+red>MAX_MATCH_BOTS)return null;
  const gameplay=collectAdminGameplayPatch(),weapons=collectAdminWeaponsPatch(),scoreLimit=Math.max(5,Math.min(100,Math.round(Number(draft.scoreLimit)||spec.scoreLimit))),timeLimit=Math.max(2,Math.min(30,Math.round(Number(draft.timeLimit)||Math.max(2,spec.timeLimitMs/60000))));
  return{
    mode:normalizeGameMode(draft.mode),mapId:normalizeMapId(lobbyMapDraft||currentMapId),customMapDefinition:normalizeMapId(lobbyMapDraft||currentMapId)==='custom-map'?customMapDefinition:undefined,
    rules:{scoreLimit,timeLimitMs:spec.scoreType==='none'||spec.cooperative?0:timeLimit*60000},
    bots:{blueBots:blue,redBots:red,difficulty:String(draft.difficulty||'normal')},
    minimap:{revealAll:draft.minimap!=='standard',directional:draft.minimap==='directional'},
    settings:normalizeWorldSettings({...worldSettings,mod:draft.mod,movement:gameplay.movement,combat:gameplay.combat,weapons:weapons.weapons}),
    loadout:classLoadout(lobbyClassDrafts||loadoutClasses,currentLobbyStartingClassId()),loadoutClasses:normalizeLoadoutClasses(lobbyClassDrafts||loadoutClasses,selectedLoadout()),classId:currentLobbyStartingClassId(),killstreakSelection:normalizeKillstreakSelection(killstreakSelection)
  };
}
function renderLobbySetupControls(){
  if(!shell.inLobby)return;refreshLobbyDraftOwnership();const host=!!isMatchAdmin,draft=lobbyMatchDraft||committedLobbyMatchDraft(),draftSpec=gameModeSpec(draft.mode),draftLoadout=lobbyLoadoutDraft||normalizeLoadoutChoice(selectedLoadout());renderLoadoutClassStrip('lobby');renderAttachmentEditors('lobby',draftLoadout);renderLobbyKillstreakSetup();
  for(const btn of lobbyPrimaryButtons)btn.classList.toggle('active',btn.dataset.lobbyPrimaryChoice===draftLoadout.primaryWeapon);
  for(const btn of lobbySecondaryButtons)btn.classList.toggle('active',btn.dataset.lobbySecondaryChoice===draftLoadout.secondaryWeapon);
  for(const btn of lobbyTacticalButtons)btn.classList.toggle('active',btn.dataset.lobbyTacticalChoice===draftLoadout.tactical);
  for(const btn of lobbyLethalButtons)btn.classList.toggle('active',btn.dataset.lobbyLethalChoice===draftLoadout.lethal);
  for(const btn of lobbyModeButtons)btn.classList.toggle('active',btn.dataset.lobbyModeChoice===draft.mode);
  const mapChoice=host?(lobbyMapDraft||currentMapId):currentMapId;for(const btn of lobbyMapButtons){btn.classList.toggle('active',btn.dataset.lobbyMapChoice===mapChoice);btn.disabled=!host||!matchAllowsLobbyEdits(matchState);}const customLoad=$('lobbyLoadCustomMapBtn');if(customLoad)customLoad.disabled=!host||!matchAllowsLobbyEdits(matchState);renderMapGallery();updateCustomMapLobbyUi();renderLobbyMapPreview(mapChoice);
  const coop=!!draftSpec.cooperative;$('lobbyBotDifficultyWrap')?.classList.toggle('hide',!host||coop);$('lobbyZombieInfo')?.classList.toggle('hide',!coop);
  if(host){
    lobbyBotDifficulty.value=draft.difficulty;lobbyBotDifficulty.disabled=!matchAllowsLobbyEdits(matchState);lobbyMinimapMode.value=draft.minimap;lobbyMod.value=draft.mod;lobbyMod.disabled=!matchAllowsLobbyEdits(matchState);
    const sandbox=draftSpec.scoreType==='none'||coop;lobbyScoreLimit.value=sandbox?'':String(draft.scoreLimit);lobbyTimeLimit.value=sandbox?'':String(draft.timeLimit);lobbyScoreLimit.disabled=sandbox;lobbyTimeLimit.disabled=sandbox;$('lobbyScoreWrap')?.classList.toggle('disabled-setting',sandbox);$('lobbyTimeWrap')?.classList.toggle('disabled-setting',sandbox);$('lobbyScoreWrap')?.classList.toggle('hide',coop);$('lobbyTimeWrap')?.classList.toggle('hide',coop);
  }
}
function renderLobbyShell(){
  if(!shell.inLobby)return;refreshLobbyDraftOwnership();syncLobbyHostControlPlacement();const host=!!isMatchAdmin,displayMode=lobbyDisplayMode(),displaySpec=gameModeSpec(displayMode),committedMode=currentGameMode(),committedSpec=gameModeSpec(committedMode),total=lobbyBotTotal();
  $('lobbyRoomCode').textContent=currentRoom||'----';$('lobbyModeBadge').textContent=displaySpec.name+(gameModSpec(host?lobbyMatchDraft?.mod:worldSettings.mod).id==='normal'?'':' · '+gameModSpec(host?lobbyMatchDraft?.mod:worldSettings.mod).name.toUpperCase());
  $('lobbyHostSetup').classList.toggle('hide',!host);$('lobbyGuestSetup').classList.toggle('hide',host);$('lobbyCheatsTab')?.classList.toggle('hide',!host);
  if(host)scheduleMapBuilderWarmup();
  const godToggle=$('lobbyGodModeToggle');if(godToggle){godToggle.classList.toggle('active',!!godMode);godToggle.setAttribute('aria-checked',String(!!godMode));godToggle.disabled=!host||socket?.readyState!==WebSocket.OPEN;}
  const startBtn=$('lobbyStartBtn');startBtn.classList.toggle('hide',!host);startBtn.disabled=!matchAllowsLobbyEdits(matchState);
  
  const committedRule=committedSpec.cooperative?'Survive escalating waves':committedSpec.scoreType==='none'?'No score / time limit':`First ${matchState.scoreLimit||committedSpec.scoreLimit} · ${Math.max(2,Math.round((matchState.timeLimitMs||committedSpec.timeLimitMs)/60000))} min`,committedMinimap=`Minimap: ${lobbyMinimapModeFromState()==='directional'?'Directional':(lobbyMinimapModeFromState()==='all'?'Always On':'Standard')}`,committedMap=displayMapSpec(currentMapId).name;
  $('lobbyGuestMode').textContent=`${committedSpec.name} · ${committedMap} · ${gameModSpec(worldSettings.mod).name}`;$('lobbyGuestBots').textContent=committedSpec.cooperative?'Melee zombies · Return next wave':`${total} bot${total===1?'':'s'} · ${(botConfig.difficulty||'normal').replace(/^./,c=>c.toUpperCase())}`;$('lobbyGuestRules').textContent=`${committedRule} · ${committedMinimap}${matchCustom?' · Custom rules':''}`;
}
function syncLobby({setup=true,roster=true}={}){if(!shell.inLobby)return;renderLobbyShell();if(setup){try{renderLobbySetupControls();}catch(error){console.error('Loadout/setup UI render failed without interrupting lobby session state.',error);}}setLobbyActionState();if(roster)renderLobbyRoster(lobbyDisplayMode());}
function showLobby(){finishInitialConnectionAttempt();const leave=$('leaveBtn');if(leave){leave.disabled=false;const label=leave.querySelector('span');if(label)label.textContent='Leave Match';}shell.enterLobby();refreshLobbyDraftOwnership();syncLobby();const url=new URL(location.href);url.searchParams.set('room',currentRoom);history.replaceState(null,'',url);}
function updateLobbyMatchDraftFromControls(){
  if(!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return;if(!lobbyMatchDraft)lobbyMatchDraft=committedLobbyMatchDraft();const spec=gameModeSpec(lobbyMatchDraft.mode),blue=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(lobbyMatchDraft.blueBots)||0))),red=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(lobbyMatchDraft.redBots)||0))),ffaBots=Math.max(0,Math.min(MAX_MATCH_BOTS,Math.floor(Number(lobbyMatchDraft.ffaBots)||0)));
  lobbyMatchDraft={...lobbyMatchDraft,mod:normalizeGameMod(lobbyMod.value),blueBots:blue,redBots:red,ffaBots,difficulty:lobbyBotDifficulty.value,scoreLimit:spec.scoreType==='none'?lobbyMatchDraft.scoreLimit:Math.max(5,Math.min(100,Math.round(Number(lobbyScoreLimit.value)||spec.scoreLimit))),timeLimit:spec.scoreType==='none'?lobbyMatchDraft.timeLimit:Math.max(2,Math.min(30,Math.round(Number(lobbyTimeLimit.value)||spec.timeLimitMs/60000))),minimap:['standard','all','directional'].includes(lobbyMinimapMode.value)?lobbyMinimapMode.value:'standard'};
  lobbyMatchDirty=!sameLobbyMatchDraft(lobbyMatchDraft,committedLobbyMatchDraft());renderLobbyShell();renderLobbySetupControls();renderLobbyRoster(lobbyDisplayMode());setLobbyActionState();
}
function setLobbyModeDraft(mode){if(!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return;if(!lobbyMatchDraft)lobbyMatchDraft=committedLobbyMatchDraft();lobbyMatchDraft={...lobbyMatchDraft,mode:normalizeGameMode(mode)};lobbyMatchDirty=!sameLobbyMatchDraft(lobbyMatchDraft,committedLobbyMatchDraft());syncLobby();}
function updateCustomMapLobbyUi(){
  const load=$('lobbyLoadCustomMapBtn'),status=$('lobbyCustomMapStatus');if(load)load.textContent='IMPORT FILE';if(status){if(selectedLibraryMap)status.textContent=`${selectedLibraryMap.name} · server map · revision ${selectedLibraryMap.revision||'draft'}`;else if(customMapLoaded&&customMapSource==='upload'){const q=customMapSummary(customMapDefinition);status.textContent=`Imported file · ${q.name} · ${q.buildings} buildings · ${q.props} props`;}else status.textContent='Saved maps sync automatically · file import is optional';}}
function requestCustomMapFile(){if(!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return;const input=$('lobbyCustomMapFile');if(input){input.value='';input.click();}}
async function loadCustomMapFile(file){
  if(!file)return false;const status=$('lobbyCustomMapStatus');try{if(file.size>MAX_CUSTOM_MAP_BYTES*1.35)throw new Error(`File is too large (${Math.ceil(file.size/1024)} KB).`);if(status)status.textContent='Validating map…';const parsed=JSON.parse(await file.text()),summary=installCustomMapDefinition(parsed,{persist:true,source:'upload',quiet:true});lobbyMapDraft='custom-map';lobbyMapDirty=lobbyMapDraft!==normalizeMapId(currentMapId)||customMapFingerprintValue!==activeCustomMapFingerprint;renderLobbySetupControls();setLobbyActionState();updateCustomMapLobbyUi();showToast(`CUSTOM MAP READY · ${summary.name}`);return true;}catch(error){if(status)status.textContent=String(error?.message||'Could not load map.');showToast(`MAP LOAD FAILED · ${String(error?.message||'invalid file').slice(0,80)}`,{priority:3,key:'custom-map-load'});return false;}
}
function setLobbyMapDraft(mapId){if(!isMatchAdmin||!matchAllowsLobbyEdits(matchState))return;const next=normalizeMapId(mapId);if(next==='custom-map'&&!customMapLoaded){requestCustomMapFile();return;}lobbyMapDraft=next;lobbyMapDirty=lobbyMapDraft!==normalizeMapId(currentMapId)||(next==='custom-map'&&customMapFingerprintValue!==activeCustomMapFingerprint);renderLobbySetupControls();setLobbyActionState();}
function setLobbyLoadoutDraft(next={}){
  if(!lobbyClassDrafts)lobbyClassDrafts=normalizeLoadoutClasses(loadoutClasses,selectedLoadout());if(!lobbyLoadoutDraft)lobbyLoadoutDraft=classLoadout(lobbyClassDrafts,loadoutEditClass.lobby||activeClassId);
  lobbyLoadoutDraft=normalizeLoadoutChoice({...lobbyLoadoutDraft,...next});lobbyClassDrafts=writeClassLoadout(lobbyClassDrafts,loadoutEditClass.lobby,lobbyLoadoutDraft);markLobbyLoadoutDirty();renderLobbySetupControls();setLobbyActionState();syncLobbyClassesToServer();
}

function syncPauseContext(){
  if(shell.inMatch)syncLobbyHostControlPlacement();const spec=currentModeSpec(),badge=$('pauseTeamBadge');if(badge){badge.textContent=spec.cooperative?'SURVIVOR':spec.teamBased?teamLabel(myTeam):spec.short;const color=spec.teamBased?factionColor(myTeam):HUD_ACCENT;badge.style.color=color;badge.style.borderColor=`${color}88`;badge.style.background=`${color}22`;}
  if($('pauseRoom'))$('pauseRoom').textContent=`${displayMapSpec(currentMapId).short} · ${spec.short}${worldSettings.mod==='normal'?'':' · '+gameModSpec(worldSettings.mod).name.toUpperCase()}`;
  if($('pauseLoadout'))$('pauseLoadout').textContent=loadoutClassById(loadoutClasses,pendingClassId||activeClassId).name;
  const adminBtn=$('adminBtn');if(adminBtn)adminBtn.classList.toggle('hide',!isMatchAdmin);
  const leave=$('leaveBtn');if(leave){leave.disabled=false;const label=leave.querySelector('span');if(label)label.textContent='Leave Match';}
  const teamBtn=$('teamSwitchBtn');if(teamBtn)teamBtn.classList.toggle('hide',!spec.teamBased||!!spec.cooperative);const teamText=$('teamSwitchText');if(teamText)teamText.textContent=pendingTeam?`SWITCHING TO ${teamLabel(pendingTeam)} ON RESPAWN`:'SWITCH TEAM';
}

function switchLobbySide(name='players'){
  let next=['players','match','map','loadout','killstreaks','cheats'].includes(name)?name:'players',current=document.querySelector('[data-lobby-side-tab].active')?.dataset.lobbySideTab||'';
  if(current==='killstreaks'&&next!=='killstreaks'&&normalizeKillstreakSelection(lobbyKillstreakDraft,{fill:false}).length!==KILLSTREAK_SELECTION_COUNT){lobbyKillstreakDraft=[...killstreakSelection];renderLobbyKillstreakSetup();}
  if(next!=='loadout')$('lobbyScreen')?.classList.remove('loadout-focused');
  if(next==='cheats'&&!isMatchAdmin)next='players';
  for(const tab of lobbySideTabs){const active=tab.dataset.lobbySideTab===next;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));}
  for(const view of lobbySideViews){const active=view.dataset.lobbySideView===next;view.classList.toggle('active',active);view.hidden=!active;view.inert=!active;}
  if(next==='map'){requestAnimationFrame(renderLobbyMapPreview);scheduleMapBuilderWarmup();}if(next==='loadout'){setLoadoutWorkspaceMode('lobby','classes',{ensurePreview:false});renderAttachmentEditors('lobby',lobbyLoadoutDraft||normalizeLoadoutChoice(selectedLoadout()));}if(next==='killstreaks'){lobbyKillstreakDraft=[...killstreakSelection];renderLobbyKillstreakSetup();}
}
function switchSubTabs(tabSelector,pageSelector,tabAttr,pageAttr,name){
  const tabs=[...document.querySelectorAll(tabSelector)],pages=[...document.querySelectorAll(pageSelector)];if(!tabs.length||!pages.length)return;
  const next=tabs.some(t=>t.getAttribute(tabAttr)===name)?name:tabs[0].getAttribute(tabAttr);
  for(const tab of tabs){const active=tab.getAttribute(tabAttr)===next;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));tab.tabIndex=active?0:-1;}
  for(const page of pages){const active=page.getAttribute(pageAttr)===next;page.classList.toggle('active',active);page.hidden=!active;page.inert=!active;}
}
function bindSubTabs(tabSelector,pageSelector,tabAttr,pageAttr,initial){
  const tabs=[...document.querySelectorAll(tabSelector)];for(const tab of tabs){tab.addEventListener('click',()=>switchSubTabs(tabSelector,pageSelector,tabAttr,pageAttr,tab.getAttribute(tabAttr)));tab.addEventListener('keydown',e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;const available=tabs.filter(item=>!item.hidden&&!item.classList.contains('hide'));if(!available.length)return;e.preventDefault();const cur=Math.max(0,available.indexOf(tab)),next=e.key==='Home'?0:e.key==='End'?available.length-1:(cur+(e.key==='ArrowRight'?1:-1)+available.length)%available.length;available[next].focus();switchSubTabs(tabSelector,pageSelector,tabAttr,pageAttr,available[next].getAttribute(tabAttr));});}
  switchSubTabs(tabSelector,pageSelector,tabAttr,pageAttr,initial);
}
function normalizeLoadoutChoice(value,fallback=selectedLoadout()){return normalizeLoadoutDefinition(value,fallback);}
function loadoutChoiceEqual(a,b){const x=normalizeLoadoutChoice(a),y=normalizeLoadoutChoice(b);return x.primaryWeapon===y.primaryWeapon&&x.secondaryWeapon===y.secondaryWeapon&&JSON.stringify(x.primaryAttachments)===JSON.stringify(y.primaryAttachments)&&JSON.stringify(x.secondaryAttachments)===JSON.stringify(y.secondaryAttachments)&&x.tactical===y.tactical&&x.lethal===y.lethal;}
function syncMatchLoadoutEditor(){
  const draft=normalizeLoadoutChoice(loadoutDraft||loadoutBaseDraft||pendingLoadout||selectedLoadout());loadoutDraft=draft;renderAttachmentEditors('match',draft);
  for(const btn of matchPrimaryButtons)btn.classList.toggle('active',btn.dataset.matchPrimaryChoice===draft.primaryWeapon);
  for(const btn of matchSecondaryButtons)btn.classList.toggle('active',btn.dataset.matchSecondaryChoice===draft.secondaryWeapon);
  for(const btn of matchTacticalButtons)btn.classList.toggle('active',btn.dataset.matchTacticalChoice===draft.tactical);
  for(const btn of matchLethalButtons)btn.classList.toggle('active',btn.dataset.matchLethalChoice===draft.lethal);
  if(matchClassDrafts)matchClassDrafts=writeClassLoadout(matchClassDrafts,loadoutEditClass.match,draft);renderLoadoutClassStrip('match');const status=$('loadoutStatus');if(status)status.textContent=godMode?'EQUIPS NOW':'NEXT SPAWN';
}
function openMatchLoadout(){if(!shell.inMatch||matchState.status===MATCH_STATUS.ENDED)return;matchClassBase=normalizeLoadoutClasses(loadoutClasses,selectedLoadout());matchClassDrafts=normalizeLoadoutClasses(matchClassBase,selectedLoadout());loadoutEditClass.match=normalizeLoadoutClassId(pendingClassId||activeClassId);loadoutBaseDraft=classLoadout(matchClassBase,loadoutEditClass.match);loadoutDraft=classLoadout(matchClassDrafts,loadoutEditClass.match);syncMatchLoadoutEditor();shell.openPanel(SHELL_PANEL.LOADOUT);setLoadoutWorkspaceMode('match','classes',{ensurePreview:false});}
function closeMatchLoadout(){setLoadoutWorkspaceMode('match','classes',{ensurePreview:false});loadoutDraft=null;loadoutBaseDraft=null;matchClassDrafts=null;matchClassBase=null;shell.closePanel(SHELL_PANEL.LOADOUT);}
function commitMatchLoadoutChange({selectClass=false}={}){
  if(socket?.readyState!==WebSocket.OPEN||!matchClassDrafts||!loadoutDraft)return false;
  matchClassDrafts=writeClassLoadout(matchClassDrafts,loadoutEditClass.match,loadoutDraft);
  const editedClassId=normalizeLoadoutClassId(loadoutEditClass.match),classId=selectClass?editedClassId:normalizeLoadoutClassId(pendingClassId||activeClassId),classes=normalizeLoadoutClasses(matchClassDrafts,selectedLoadout()),next=classLoadout(classes,classId),classesOnly=!selectClass&&editedClassId!==classId,rev=++matchLoadoutRevision;
  loadoutClasses=classes;matchClassBase=normalizeLoadoutClasses(classes,selectedLoadout());loadoutBaseDraft=classLoadout(matchClassBase,editedClassId);rememberLoadoutClasses(loadoutClasses,classId);
  if(!classesOnly&&!godMode){pendingClassId=classId;pendingLoadout=next;}
  send(classesOnly?{t:'loadout',rev,classId,loadoutClasses:classes,classesOnly:true}:{t:'loadout',rev,classId,loadoutClasses:classes,...next});syncPauseContext();renderLoadoutClassStrip('match');
  
  return true;
}
function setMatchLoadoutDraft(next={}){loadoutDraft=normalizeLoadoutChoice({...loadoutDraftForSurface('match'),...next});syncMatchLoadoutEditor();commitMatchLoadoutChange();}

function weaponSoundCueIds(weapon=currentWeapon){return weapon==='akimbo1887'?['shot1887','shot1887Suppressed','reload1887','action1887']:weapon==='assault'?['shotAssault','shotAssaultSuppressed','reloadAssault']:weapon==='ump'?['shotUmp','shotUmpSuppressed','reloadUmp']:weapon==='machineGun'?['shotMachineGun','shotMachineGunSuppressed','reloadMachineGun']:weapon==='shotgun'?['shotShotgun','shotShotgunSuppressed','reloadShotgun','shotgunPump']:weapon==='semiShotgun'?['shotSemiShotgun','reloadSemiShotgun']:weapon==='sniper'?['shotSniper','shotSniperSuppressed','reloadSniper']:weapon==='grenadeLauncher'?['shotGl','reloadGl','glExplosion']:weapon==='rpg'?['shotRpg','reloadRpg','rpgExplosion']:['shotPistol','shotPistolSuppressed','reloadPistol'];}
function warmWeaponAudio(weapon=currentWeapon){for(const id of weaponSoundCueIds(weapon))gameAudio.load(id);}
const CORE_GAMEPLAY_AUDIO_IDS=Object.freeze(['footstepLeft','footstepRight','jump','land','slide','impactWall','hurt','hitmarker','kill','announcer','flashDetonate','grenadeExplosion','glExplosion','rpgExplosion','flashThrow','stickyThrow','flashImpact','stickyImpact','semtexBeep','ksUfoInbound','ksUfoBeam','ksLightning','ksAsteroidIncoming','ksAsteroidImpact','ksEarthquakeRumble','ksSolarCharge','ksSolarBlast']);
const ALL_WEAPON_AUDIO_IDS=Object.freeze([...new Set(WEAPON_ORDER.flatMap(weapon=>weaponSoundCueIds(weapon)))]);
function ensureAudio(){audioUnlockPromise=gameAudio.unlock();return audioUnlockPromise;}
async function warmGameplayAudio(weapon=currentWeapon){
  if(masterMuted)return false;
  const unlocked=await (audioUnlockPromise||ensureAudio());if(!unlocked)return false;
  const ids=[...new Set([...CORE_GAMEPLAY_AUDIO_IDS,...weaponSoundCueIds(weapon)])];
  const results=await Promise.all(ids.map(id=>gameAudio.load(id)));
  // Do not hold match entry for every weapon. Once the critical/local set is
  // ready, decode the remaining weapon library opportunistically so the first
  // nearby remote shot/reload is unlikely to arrive cold.
  for(const id of ALL_WEAPON_AUDIO_IDS)if(!ids.includes(id))void gameAudio.load(id);
  return results.every(Boolean);
}
function playSoundCue(cueId,volume=1,override={}){return gameAudio.play(cueId,volume,override);}
function spatialAudioParams(x,y,z,maxDistance=60){
  if(!position)return{volume:.08,pan:0,distanceRatio:1,lowpassHz:3200};
  const dx=Number(x||0)-position.x,dy=Number(y||0)-(position.y+1),dz=Number(z||0)-position.z,d=Math.hypot(dx,dy,dz),range=Math.max(1,maxDistance),distanceRatio=THREE.MathUtils.clamp(d/range,0,1);
  const volume=Math.pow(Math.max(0,1-distanceRatio),1.7);
  if(d<.001)return{volume,pan:0,distanceRatio:0,lowpassHz:20000};
  const rightX=-Math.cos(yaw),rightZ=Math.sin(yaw),pan=THREE.MathUtils.clamp((dx*rightX+dz*rightZ)/d,-.92,.92),lowpassHz=THREE.MathUtils.lerp(19000,2600,Math.pow(distanceRatio,1.08));
  return{volume,pan,distanceRatio,lowpassHz};
}
function playSpatialCue(cueId,x,y,z,maxDistance=60,volume=1,override={}){const p=spatialAudioParams(x,y,z,maxDistance);if(p.volume<=.004)return null;return playSoundCue(cueId,p.volume*volume,{...override,pan:p.pan,lowpassHz:override.lowpassHz??p.lowpassHz});}
function savePlayerSettings(){preferences.setItem('breachPlayerSettings',JSON.stringify(playerSettings));}
function targetPixelRatio(){
  const quality=playerSettings.graphics,maxRatio=quality==='low'?1:quality==='medium'?(isTouch?1.25:1.5):(isTouch?1.5:2);
  return Math.min(devicePixelRatio||1,maxRatio);
}
function applyGraphicsQuality(){
  if(!renderer)return;
  const ratio=targetPixelRatio();
  if(Math.abs(renderer.getPixelRatio()-ratio)>.001)renderer.setPixelRatio(ratio);
  renderer.shadowMap.enabled=playerSettings.graphics==='high'&&!isTouch;
  if(hudCanvas)resizeHudOverlay();
}
function normalizePlayerSettingsValue(value={}){
  const clamp=(raw,min,max,fallback)=>{const n=Number(raw);return Number.isFinite(n)?Math.max(min,Math.min(max,n)):fallback;};
  return{
    lookSensitivity:clamp(value.lookSensitivity,.5,2,DEFAULT_PLAYER_SETTINGS.lookSensitivity),
    adsSensitivity:clamp(value.adsSensitivity,.35,1.25,DEFAULT_PLAYER_SETTINGS.adsSensitivity),
    touchSensitivity:clamp(value.touchSensitivity,.5,2,DEFAULT_PLAYER_SETTINGS.touchSensitivity),
    controllerVerticalSensitivity:clamp(value.controllerVerticalSensitivity,.5,1.5,DEFAULT_PLAYER_SETTINGS.controllerVerticalSensitivity),
    controllerResponseCurve:['dynamic','standard','linear'].includes(value.controllerResponseCurve)?value.controllerResponseCurve:DEFAULT_PLAYER_SETTINGS.controllerResponseCurve,
    controllerAimAssist:value.controllerAimAssist==='off'?'off':'on',
    controllerMoveDeadzone:clamp(value.controllerMoveDeadzone,.02,.25,DEFAULT_PLAYER_SETTINGS.controllerMoveDeadzone),
    controllerLookDeadzone:clamp(value.controllerLookDeadzone,.02,.25,DEFAULT_PLAYER_SETTINGS.controllerLookDeadzone),
    masterVolume:clamp(value.masterVolume,0,1,DEFAULT_PLAYER_SETTINGS.masterVolume),
    sfxVolume:clamp(value.sfxVolume,0,1,DEFAULT_PLAYER_SETTINGS.sfxVolume),
    musicVolume:clamp(value.musicVolume,0,1,DEFAULT_PLAYER_SETTINGS.musicVolume),
    graphics:['low','medium','high'].includes(value.graphics)?value.graphics:DEFAULT_PLAYER_SETTINGS.graphics,
    diagnostics:value.diagnostics==='on'?'on':'off'
  };
}
function setSettingsStatus(text,tone=''){const el=$('settingsStatus');if(!el)return;el.textContent=text;el.className=`admin-status ${tone}`.trim();}
function playerSettingsEqual(a,b){const x=normalizePlayerSettingsValue(a),y=normalizePlayerSettingsValue(b);return Object.keys(x).every(k=>x[k]===y[k]);}
function syncPlayerSettingsUI(value=playerSettings){
  const source=normalizePlayerSettingsValue(value),values=[['playerLookSensitivity','lookSensitivity'],['playerAdsSensitivity','adsSensitivity'],['playerTouchSensitivity','touchSensitivity'],['playerControllerVerticalSensitivity','controllerVerticalSensitivity'],['playerControllerMoveDeadzone','controllerMoveDeadzone'],['playerControllerLookDeadzone','controllerLookDeadzone'],['playerMasterVolume','masterVolume'],['playerSfxVolume','sfxVolume'],['playerMusicVolume','musicVolume']];
  for(const [id,key] of values){const el=$(id),out=$(`${id}Value`);if(el)el.value=source[key];if(out)out.textContent=key.includes('Volume')?`${Math.round(source[key]*100)}%`:key.includes('Deadzone')?`${Math.round(source[key]*100)}%`:`${Number(source[key]).toFixed(2)}×`;}
  if($('playerGraphics'))$('playerGraphics').value=source.graphics;if($('playerControllerResponseCurve'))$('playerControllerResponseCurve').value=source.controllerResponseCurve;const aimAssist=$('playerControllerAimAssist');if(aimAssist){const on=source.controllerAimAssist!=='off';aimAssist.classList.toggle('active',on);aimAssist.setAttribute('aria-checked',String(on));}syncMusicUI();syncDiagnosticsSettingsUI();
}
function applyPlayerSettings(next,{status=''}={}){const previous=playerSettings;playerSettings=normalizePlayerSettingsValue(next);playerSettingsDraft=null;savePlayerSettings();applyGraphicsQuality();hudLastDraw=0;syncPlayerSettingsUI(playerSettings);setSettingsStatus(status,status?'ok':'');return previous;}
function stagePlayerSettingFromUI(id,key){const el=$(id);if(!el)return;applyPlayerSettings({...playerSettings,[key]:Number(el.value)});}
function stagePlayerChoice(key,value){applyPlayerSettings({...playerSettings,[key]:value});}
function refreshIntroMusicVolume(){if(!shell.inMatch&&introMusicHandle){stopIntroMusic();if(!masterMuted)startIntroMusic();}}
function openPlayerSettings(){if(shell.inMatch&&matchState.status===MATCH_STATUS.ENDED)return;playerSettingsDraft=null;syncPlayerSettingsUI(playerSettings);setSettingsStatus('');switchSubTabs('[data-settings-tab]','[data-settings-page]','data-settings-tab','data-settings-page','controls');shell.openPanel(SHELL_PANEL.SETTINGS);}
let developerVersionTapCount=0,developerVersionTapTimer=0;
function openDeveloperSettings(){const tab=$('settingsDeveloperTab');if(!tab)return;tab.classList.remove('hide');openPlayerSettings();switchSubTabs('[data-settings-tab]','[data-settings-page]','data-settings-tab','data-settings-page','developer');}
function registerDeveloperVersionTap(){developerVersionTapCount++;clearTimeout(developerVersionTapTimer);developerVersionTapTimer=setTimeout(()=>{developerVersionTapCount=0;},1800);if(developerVersionTapCount>=5){developerVersionTapCount=0;clearTimeout(developerVersionTapTimer);openDeveloperSettings();}}
function closePlayerSettings(){playerSettingsDraft=null;shell.closePanel(SHELL_PANEL.SETTINGS);}
function cancelPlayerSettings(){closePlayerSettings();}
function resetPlayerSettings(){const diagnostics=playerSettings.diagnostics;setMasterMuted(false);applyPlayerSettings({...DEFAULT_PLAYER_SETTINGS,diagnostics},{status:''});refreshIntroMusicVolume();}



function sightMarkMaterial(color=0xf4f1df){return new THREE.MeshBasicMaterial({color,transparent:true,opacity:.96,depthWrite:false,side:THREE.DoubleSide,toneMapped:false});}
function addPistolIronSights(group,material,{rearZ=.08,frontZ=-.31,sightY=.140,rearMountY=.112,frontMountY=.112,eyeZ=-.46}={}){
  // CoD-style pistol sight picture: a shallow square rear notch and a narrow
  // front blade with high-contrast three-dot references. Keep the center open.
  const parts=[],markMat=sightMarkMaterial(),rearBaseH=.010,rearBase=new THREE.Mesh(new THREE.BoxGeometry(.058,rearBaseH,.020),material);rearBase.position.set(0,rearMountY+rearBaseH/2,rearZ);parts.push(rearBase);
  const earW=.011,earH=Math.max(.014,sightY-rearMountY-.006),gap=.016,rearL=new THREE.Mesh(new THREE.BoxGeometry(earW,earH,.018),material),rearR=rearL.clone();rearL.position.set(-(gap+earW/2),rearMountY+rearBaseH+earH/2,rearZ);rearR.position.set(gap+earW/2,rearMountY+rearBaseH+earH/2,rearZ);parts.push(rearL,rearR);
  const frontBaseH=.008,frontBase=new THREE.Mesh(new THREE.BoxGeometry(.024,frontBaseH,.018),material);frontBase.position.set(0,frontMountY+frontBaseH/2,frontZ);const postBottom=frontMountY+frontBaseH,postH=Math.max(.008,sightY-postBottom),frontPost=new THREE.Mesh(new THREE.BoxGeometry(.0062,postH,.014),material);frontPost.position.set(0,postBottom+postH/2,frontZ);parts.push(frontBase,frontPost);
  const rearDotL=new THREE.Mesh(new THREE.CircleGeometry(.0034,12),markMat),rearDotR=rearDotL.clone(),frontDot=new THREE.Mesh(new THREE.CircleGeometry(.0036,12),markMat);rearDotL.position.set(-.020,sightY-.008,rearZ+.010);rearDotR.position.set(.020,sightY-.008,rearZ+.010);frontDot.position.set(0,sightY-.006,frontZ+.008);parts.push(rearDotL,rearDotR,frontDot);
  group.add(...parts);group.userData.ironSightParts=parts;group.userData.adsSightRear={x:0,y:sightY,z:rearZ};group.userData.adsSightTip={x:0,y:sightY,z:frontZ};group.userData.adsSightY=sightY;group.userData.adsPose={x:0,y:-sightY,z:eyeZ-rearZ,rx:0,ry:0,rz:0};return sightY;
}
function addApertureIronSights(group,material,{rearZ=.04,frontZ=-.66,sightY=.165,rearMountY=.132,frontMountY=.132,eyeZ=-.40,rearRadius=.021,rearTube=.0036,postWidth=.0065,frontEarGap=.020}={}){
  // Rifle/SMG sight picture: thin rear aperture + protected front post. This
  // keeps the center much less obstructed than the old generic square notch.
  const parts=[],rearRing=new THREE.Mesh(new THREE.TorusGeometry(rearRadius,rearTube,7,24),material);rearRing.position.set(0,sightY,rearZ);parts.push(rearRing);
  const rearStemTop=sightY-rearRadius-rearTube*.35,rearStemH=Math.max(.008,rearStemTop-rearMountY),rearStem=new THREE.Mesh(new THREE.BoxGeometry(.012,rearStemH,.018),material);rearStem.position.set(0,rearMountY+rearStemH/2,rearZ);const rearFoot=new THREE.Mesh(new THREE.BoxGeometry(.046,.008,.024),material);rearFoot.position.set(0,rearMountY+.004,rearZ);parts.push(rearStem,rearFoot);
  const frontBaseH=.008,frontBase=new THREE.Mesh(new THREE.BoxGeometry(.040,frontBaseH,.018),material);frontBase.position.set(0,frontMountY+frontBaseH/2,frontZ);const postBottom=frontMountY+frontBaseH,postH=Math.max(.008,sightY-postBottom),frontPost=new THREE.Mesh(new THREE.BoxGeometry(postWidth,postH,.014),material);frontPost.position.set(0,postBottom+postH/2,frontZ);parts.push(frontBase,frontPost);
  const earW=.0065,earTop=sightY+.010,earH=Math.max(.010,earTop-postBottom),frontL=new THREE.Mesh(new THREE.BoxGeometry(earW,earH,.014),material),frontR=frontL.clone();frontL.position.set(-(frontEarGap+earW/2),postBottom+earH/2,frontZ);frontR.position.set(frontEarGap+earW/2,postBottom+earH/2,frontZ);parts.push(frontL,frontR);
  group.add(...parts);group.userData.ironSightParts=parts;group.userData.adsSightRear={x:0,y:sightY,z:rearZ};group.userData.adsSightTip={x:0,y:sightY,z:frontZ};group.userData.adsSightY=sightY;group.userData.adsPose={x:0,y:-sightY,z:eyeZ-rearZ,rx:0,ry:0,rz:0};return sightY;
}
function addShotgunBeadSight(group,material,{rearZ=.02,frontZ=-1.04,sightY=.116,rearMountY=.090,frontMountY=.060,eyeZ=-.42}={}){
  // Pump shotgun: low receiver rib and a bright, simple front bead. The eye is
  // not boxed in by a fake rear notch.
  const parts=[],rib=new THREE.Mesh(new THREE.BoxGeometry(.030,.006,.055),material);rib.position.set(0,rearMountY+.003,rearZ-.010);parts.push(rib);
  const beadStemH=Math.max(.006,sightY-frontMountY-.006),beadStem=new THREE.Mesh(new THREE.BoxGeometry(.010,beadStemH,.014),material);beadStem.position.set(0,frontMountY+beadStemH/2,frontZ);const bead=new THREE.Mesh(new THREE.SphereGeometry(.0055,10,7),sightMarkMaterial(0xfff0b8));bead.position.set(0,sightY,frontZ);parts.push(beadStem,bead);
  group.add(...parts);group.userData.ironSightParts=parts;group.userData.adsSightRear={x:0,y:sightY,z:rearZ};group.userData.adsSightTip={x:0,y:sightY,z:frontZ};group.userData.adsSightY=sightY;group.userData.adsPose={x:0,y:-sightY,z:eyeZ-rearZ,rx:0,ry:0,rz:0};return sightY;
}
function addShotgunGhostRingSight(group,material,opts={}){
  return addApertureIronSights(group,material,{rearRadius:.017,rearTube:.0032,postWidth:.006,frontEarGap:.017,...opts});
}
function weaponUsesIronSights(weapon=currentWeapon){return IRON_SIGHT_WEAPONS.has(weapon);}
function attachmentVisualMaterial(color=0x171c20,metalness=.34,roughness=.44){return new THREE.MeshStandardMaterial({color,metalness,roughness});}
function bakedWeaponInsetMaterial(){return bakedWeaponInsetMaterial.material||(bakedWeaponInsetMaterial.material=attachmentVisualMaterial(0x101519,.36,.52));}
function addBakedBoxPanels(mesh,{side=true,top=false,panelScale=.62}={}){
  const p=mesh?.geometry?.parameters,w=Number(p?.width),h=Number(p?.height),d=Number(p?.depth);if(!(w>0&&h>0&&d>0))return mesh;
  const mat=bakedWeaponInsetMaterial(),t=Math.max(.0016,Math.min(w,h,d)*.028),ph=h*Math.max(.28,Math.min(.82,panelScale)),pd=d*.62;
  if(side){for(const x of [-1,1]){const panel=new THREE.Mesh(new THREE.BoxGeometry(t,ph,pd),mat);panel.position.set(x*(w*.5+t*.42),h*.015,0);mesh.add(panel);}}
  if(top){const panel=new THREE.Mesh(new THREE.BoxGeometry(w*.64,t,d*.56),mat);panel.position.set(0,h*.5+t*.42,0);mesh.add(panel);}
  return mesh;
}
function addBakedGripRibs(mesh,{count=4}={}){
  const p=mesh?.geometry?.parameters,w=Number(p?.width),h=Number(p?.height),d=Number(p?.depth);if(!(w>0&&h>0&&d>0))return mesh;const mat=bakedWeaponInsetMaterial(),n=Math.max(2,Math.min(7,Math.round(count))),t=Math.max(.0015,h*.025);
  for(let i=0;i<n;i++){const rib=new THREE.Mesh(new THREE.BoxGeometry(w*1.025,t,d*1.025),mat);rib.position.y=THREE.MathUtils.lerp(-h*.34,h*.30,n===1?.5:i/(n-1));mesh.add(rib);}return mesh;
}
function addBakedMagazineRibs(mesh,{count=3}={}){
  const p=mesh?.geometry?.parameters,w=Number(p?.width),h=Number(p?.height),d=Number(p?.depth);if(!(w>0&&h>0&&d>0))return mesh;const mat=bakedWeaponInsetMaterial(),n=Math.max(2,Math.min(6,Math.round(count))),t=Math.max(.0016,h*.022);
  for(let i=0;i<n;i++){const rib=new THREE.Mesh(new THREE.BoxGeometry(w*1.03,t,d*1.03),mat);rib.position.y=THREE.MathUtils.lerp(-h*.34,h*.34,n===1?.5:i/(n-1));mesh.add(rib);}return mesh;
}
function addBakedRailRibs(mesh,{count=7}={}){
  const p=mesh?.geometry?.parameters,w=Number(p?.width),h=Number(p?.height),d=Number(p?.depth);if(!(w>0&&h>0&&d>0))return mesh;const mat=bakedWeaponInsetMaterial(),n=Math.max(3,Math.min(12,Math.round(count))),ridgeD=Math.max(.002,d/(n*4.2));
  for(let i=0;i<n;i++){const ridge=new THREE.Mesh(new THREE.BoxGeometry(w*1.08,Math.max(.002,h*.28),ridgeD),mat);ridge.position.set(0,h*.5+Math.max(.001,h*.12),THREE.MathUtils.lerp(-d*.42,d*.42,n===1?.5:i/(n-1)));mesh.add(ridge);}return mesh;
}
function addBakedTubeBands(mesh,{count=2}={}){
  const p=mesh?.geometry?.parameters,r=Math.max(Number(p?.radiusTop)||0,Number(p?.radiusBottom)||0),len=Number(p?.height);if(!(r>0&&len>0))return mesh;const mat=bakedWeaponInsetMaterial(),n=Math.max(1,Math.min(5,Math.round(count))),tube=Math.max(.0015,r*.08);
  for(let i=0;i<n;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(r*1.035,tube,5,14),mat);ring.rotation.x=Math.PI/2;ring.position.y=THREE.MathUtils.lerp(-len*.30,len*.30,n===1?.5:i/(n-1));mesh.add(ring);}return mesh;
}
function addBakedStockPad(mesh){
  const p=mesh?.geometry?.parameters,w=Number(p?.width),h=Number(p?.height),d=Number(p?.depth);if(!(w>0&&h>0&&d>0))return mesh;const t=Math.max(.002,d*.035),pad=new THREE.Mesh(new THREE.BoxGeometry(w*1.025,h*.90,t),bakedWeaponInsetMaterial());pad.position.z=d*.5+t*.45;mesh.add(pad);return mesh;
}
function bakeWeaponGeometry({receivers=[],handguards=[],grips=[],magazines=[],rails=[],stocks=[],tubes=[],detail=1}={}){
  const high=Number(detail)>=.8;
  for(const mesh of receivers.filter(Boolean))addBakedBoxPanels(mesh,{side:true,top:false});
  for(const mesh of handguards.filter(Boolean)){addBakedBoxPanels(mesh,{side:true,top:false,panelScale:.48});if(high)addBakedGripRibs(mesh,{count:3});}
  for(const mesh of grips.filter(Boolean))addBakedGripRibs(mesh,{count:high?5:3});
  for(const mesh of magazines.filter(Boolean))addBakedMagazineRibs(mesh,{count:high?3:2});
  for(const mesh of rails.filter(Boolean))addBakedRailRibs(mesh,{count:high?7:4});
  for(const mesh of stocks.filter(Boolean))addBakedStockPad(mesh);
  for(const mesh of tubes.filter(Boolean))addBakedTubeBands(mesh,{count:high?2:1});
}
function registerAttachmentVisual(group,id,object){if(!group||!object)return object;if(!group.userData.attachmentVisuals)group.userData.attachmentVisuals={};group.userData.attachmentVisuals[id]=object;object.visible=false;group.add(object);return object;}
function makeMuzzleAttachment({radius=.030,length=.22,color=0x171c20,muzzle={x:0,y:0,z:-1},overlap=.018,ported=false}={}){
  // Devices are built around the authoritative bore position. Added detail is
  // concentric, so cosmetic upgrades cannot move the shot/muzzle origin.
  const g=new THREE.Group(),mx=Number(muzzle?.x)||0,my=Number(muzzle?.y)||0,mz=Number(muzzle?.z)||0,seat=Math.max(0,Math.min(length*.35,Number(overlap)||0)),centerZ=mz-length*.5+seat,frontZ=mz-length+seat;
  const mat=attachmentVisualMaterial(color,.48,.34),dark=attachmentVisualMaterial(0x0d1114,.38,.48),body=new THREE.Mesh(new THREE.CylinderGeometry(radius*.96,radius,length,18),mat);body.rotation.x=Math.PI/2;body.position.set(mx,my,centerZ);g.add(body);
  const collarLen=Math.min(.040,length*.22),collar=new THREE.Mesh(new THREE.CylinderGeometry(radius*.84,radius*.84,collarLen,16),dark);collar.rotation.x=Math.PI/2;collar.position.set(mx,my,mz+seat*.35);g.add(collar);
  const frontRing=new THREE.Mesh(new THREE.TorusGeometry(radius*.91,Math.max(.0018,radius*.075),6,18),dark);frontRing.position.set(mx,my,frontZ+.002);g.add(frontRing);
  if(ported){for(const x of [-1,1])for(const dz of [-.18,.08]){const port=new THREE.Mesh(new THREE.BoxGeometry(Math.max(.006,radius*.30),Math.max(.010,radius*.54),Math.max(.014,length*.17)),dark);port.position.set(mx+x*radius*.78,my+radius*.05,centerZ+length*dz);g.add(port);}}
  else{for(const dz of [-.22,.10]){const band=new THREE.Mesh(new THREE.TorusGeometry(radius*.985,Math.max(.0015,radius*.055),5,16),dark);band.position.set(mx,my,centerZ+length*dz);g.add(band);}}
  g.userData.muzzleTip=new THREE.Vector3(mx,my,frontZ);g.userData.muzzleSeat=new THREE.Vector3(mx,my,mz);return g;
}
function opticReticleMaterials(){return{glow:new THREE.MeshBasicMaterial({color:0xff312c,transparent:true,opacity:.20,depthTest:false,depthWrite:false,toneMapped:false,side:THREE.DoubleSide}),core:new THREE.MeshBasicMaterial({color:0xff5149,transparent:true,opacity:.99,depthTest:false,depthWrite:false,toneMapped:false,side:THREE.DoubleSide})};}
function makeChevronReticle(material,{size=.0065,z=0}={}){
  const s=Math.max(.002,Number(size)||.0065),shape=new THREE.Shape();shape.moveTo(-s,-s*.42);shape.lineTo(0,s*.38);shape.lineTo(s,-s*.42);shape.lineTo(s*.64,-s*.42);shape.lineTo(0,s*.04);shape.lineTo(-s*.64,-s*.42);shape.closePath();const mesh=new THREE.Mesh(new THREE.ShapeGeometry(shape),material);mesh.position.z=z;return mesh;
}
function makeRedDotAttachment({sightY=.15,z=-.18,mountY=.12,eyeZ=-.38}={}){
  const g=new THREE.Group(),mat=attachmentVisualMaterial(0x14191d,.34,.44),dark=attachmentVisualMaterial(0x0e1215,.28,.58),lens=new THREE.MeshStandardMaterial({color:0x9ab8c1,roughness:.06,metalness:.05,transparent:true,opacity:.13,emissive:0x142d34,emissiveIntensity:.07,depthWrite:false,side:THREE.DoubleSide}),ret=opticReticleMaterials();
  const base=new THREE.Mesh(new THREE.BoxGeometry(.060,.014,.072),mat);base.position.set(0,mountY+.007,z+.003);const riserH=Math.max(.008,sightY-mountY-.028),riserL=new THREE.Mesh(new THREE.BoxGeometry(.009,riserH,.024),mat),riserR=riserL.clone();riserL.position.set(-.017,mountY+riserH*.5+.002,z-.002);riserR.position.set(.017,mountY+riserH*.5+.002,z-.002);
  const frameW=.006,windowW=.050,windowH=.039,left=new THREE.Mesh(new THREE.BoxGeometry(frameW,windowH+.006,.016),mat),right=left.clone(),top=new THREE.Mesh(new THREE.BoxGeometry(windowW+.006,frameW,.016),mat),chin=new THREE.Mesh(new THREE.BoxGeometry(windowW*.74,.006,.016),mat);left.position.set(-windowW*.5,sightY,z-.014);right.position.set(windowW*.5,sightY,z-.014);top.position.set(0,sightY+windowH*.5,z-.014);chin.position.set(0,sightY-windowH*.49,z-.014);
  const glass=new THREE.Mesh(new THREE.BoxGeometry(windowW-.004,windowH-.004,.003),lens);glass.position.set(0,sightY,z-.015);const dotGlow=new THREE.Mesh(new THREE.CircleGeometry(.0048,18),ret.glow),dotCore=new THREE.Mesh(new THREE.CircleGeometry(.0022,18),ret.core);dotGlow.position.set(0,sightY,z-.017);dotCore.position.set(0,sightY,z-.0167);dotGlow.renderOrder=8;dotCore.renderOrder=9;
  const dial=new THREE.Mesh(new THREE.CylinderGeometry(.008,.008,.010,10),dark);dial.rotation.z=Math.PI/2;dial.position.set(.034,sightY+.006,z-.006);const frontLip=new THREE.Mesh(new THREE.BoxGeometry(.057,.007,.008),dark);frontLip.position.set(0,mountY+.017,z-.034);
  g.add(base,riserL,riserR,left,right,top,chin,glass,dial,frontLip,dotGlow,dotCore);g.userData.aimPoint=dotCore;g.userData.adsPose={x:0,y:-sightY,z:Number(eyeZ)-Number(z-.015),rx:0,ry:0,rz:0};return g;
}
function makeHoloAttachment({sightY=.15,z=-.17,mountY=.12,eyeZ=-.38}={}){
  const g=new THREE.Group(),mat=attachmentVisualMaterial(0x171c20,.30,.47),dark=attachmentVisualMaterial(0x0d1114,.24,.62),lens=new THREE.MeshStandardMaterial({color:0xa5bec4,roughness:.06,metalness:.05,transparent:true,opacity:.10,emissive:0x13292e,emissiveIntensity:.05,depthWrite:false,side:THREE.DoubleSide}),ret=opticReticleMaterials();
  const base=new THREE.Mesh(new THREE.BoxGeometry(.098,.020,.102),mat);base.position.set(0,mountY+.010,z+.005);const frameW=.008,windowW=.086,windowH=.066,left=new THREE.Mesh(new THREE.BoxGeometry(frameW,windowH+.010,.020),mat),right=left.clone(),top=new THREE.Mesh(new THREE.BoxGeometry(windowW+.010,frameW,.020),mat),chin=new THREE.Mesh(new THREE.BoxGeometry(windowW*.80,.008,.020),mat);left.position.set(-windowW*.5,sightY,z-.020);right.position.set(windowW*.5,sightY,z-.020);top.position.set(0,sightY+windowH*.5,z-.020);chin.position.set(0,sightY-windowH*.48,z-.020);
  const guardL=new THREE.Mesh(new THREE.BoxGeometry(.010,.044,.074),mat),guardR=guardL.clone();guardL.position.set(-.050,mountY+.038,z+.006);guardR.position.set(.050,mountY+.038,z+.006);guardL.rotation.z=-.09;guardR.rotation.z=.09;
  const glass=new THREE.Mesh(new THREE.BoxGeometry(windowW-.005,windowH-.005,.003),lens);glass.position.set(0,sightY,z-.022);const ringGlow=new THREE.Mesh(new THREE.RingGeometry(.0090,.0118,32),ret.glow),ring=new THREE.Mesh(new THREE.RingGeometry(.0086,.0102,32),ret.core),dot=new THREE.Mesh(new THREE.CircleGeometry(.0021,18),ret.core);for(const obj of [ringGlow,ring,dot])obj.position.set(0,sightY,z-.024);ringGlow.renderOrder=8;ring.renderOrder=9;dot.renderOrder=10;
  const buttonA=new THREE.Mesh(new THREE.CylinderGeometry(.005,.005,.005,8),dark),buttonB=buttonA.clone();buttonA.rotation.z=buttonB.rotation.z=Math.PI/2;buttonA.position.set(.054,mountY+.026,z+.024);buttonB.position.set(.054,mountY+.026,z+.008);const rearShelf=new THREE.Mesh(new THREE.BoxGeometry(.072,.010,.026),dark);rearShelf.position.set(0,mountY+.024,z+.047);
  g.add(base,guardL,guardR,left,right,top,chin,glass,buttonA,buttonB,rearShelf,ringGlow,ring,dot);g.userData.aimPoint=dot;g.userData.adsPose={x:0,y:-sightY,z:Number(eyeZ)-Number(z-.022),rx:0,ry:0,rz:0};return g;
}
function makeCombatOptic({sightY=.15,z=-.17,mountY=.12,eyeZ=-.38,length=.19,scopeRadius=.037}={}){
  const g=new THREE.Group(),mat=attachmentVisualMaterial(0x171b1e,.30,.48),dark=attachmentVisualMaterial(0x0c1012,.32,.50),innerMat=new THREE.MeshStandardMaterial({color:0x07090b,roughness:.98,metalness:.01,side:THREE.BackSide}),lensMat=new THREE.MeshStandardMaterial({color:0xb9cdd2,roughness:.05,metalness:.04,transparent:true,opacity:.09,emissive:0x102126,emissiveIntensity:.035,depthWrite:false,side:THREE.DoubleSide}),ret=opticReticleMaterials(),radius=Math.max(.026,Number(scopeRadius)||.037);
  const railBase=new THREE.Mesh(new THREE.BoxGeometry(.070,.014,length*.68),mat);railBase.position.set(0,mountY+.007,z+.010);const footH=Math.max(.014,sightY-radius-(mountY+.014)),footA=new THREE.Mesh(new THREE.BoxGeometry(.046,footH,.032),mat),footB=footA.clone();footA.position.set(0,mountY+.014+footH*.5,z-length*.24);footB.position.set(0,mountY+.014+footH*.5,z+length*.24);
  const body=new THREE.Mesh(new THREE.CylinderGeometry(radius*.92,radius,length,20,1,true),mat);body.rotation.x=Math.PI/2;body.position.set(0,sightY,z);const inner=new THREE.Mesh(new THREE.CylinderGeometry(radius*.72,radius*.76,length*.91,20,1,true),innerMat);inner.rotation.x=Math.PI/2;inner.position.copy(body.position);
  const objectiveRing=new THREE.Mesh(new THREE.TorusGeometry(radius*.94,.0048,8,24),mat),eyeRing=new THREE.Mesh(new THREE.TorusGeometry(radius*.82,.0045,8,24),mat),focusRing=new THREE.Mesh(new THREE.TorusGeometry(radius*.93,.0036,7,22),dark);objectiveRing.position.set(0,sightY,z-length*.50);eyeRing.position.set(0,sightY,z+length*.50);focusRing.position.set(0,sightY,z+length*.26);const front=new THREE.Mesh(new THREE.CircleGeometry(radius*.78,24),lensMat),rear=new THREE.Mesh(new THREE.CircleGeometry(radius*.68,24),lensMat);front.position.set(0,sightY,z-length*.485);rear.position.set(0,sightY,z+length*.485);
  const topRail=new THREE.Mesh(new THREE.BoxGeometry(.030,.010,length*.33),mat);topRail.position.set(0,sightY+radius*.92,z-.018);addBakedRailRibs(topRail,{count:4});const turret=new THREE.Mesh(new THREE.CylinderGeometry(.010,.010,.016,10),dark);turret.position.set(0,sightY+radius+.010,z);const sideDial=new THREE.Mesh(new THREE.CylinderGeometry(.009,.009,.013,10),dark);sideDial.rotation.z=Math.PI/2;sideDial.position.set(radius+.007,sightY,z+.008);
  const reticle=new THREE.Group(),chevron=makeChevronReticle(ret.core,{size:.0080}),centerDot=new THREE.Mesh(new THREE.CircleGeometry(.00135,14),ret.core);reticle.add(chevron,centerDot);for(let i=1;i<=4;i++){const tick=new THREE.Mesh(new THREE.BoxGeometry(.0060-i*.0007,.0008,.0001),ret.core);tick.position.set(0,-.008-i*.0054,0);reticle.add(tick);}reticle.position.set(0,sightY,z+length*.492);reticle.traverse(o=>{if(o.isMesh)o.renderOrder=10;});
  g.add(railBase,footA,footB,body,inner,objectiveRing,eyeRing,focusRing,front,rear,topRail,turret,sideDial,reticle);g.userData.aimPoint=centerDot;g.userData.adsPose={x:0,y:-sightY,z:Number(eyeZ)-Number(z+length*.485),rx:0,ry:0,rz:0};return g;
}
function makeThermalOpticAttachment({sightY=.17,z=-.12,mountY=.12,eyeZ=-.40,length=.20,radius=.040,long=false}={}){
  const g=makeCombatOptic({sightY,z,mountY,eyeZ,length,scopeRadius:radius}),mat=attachmentVisualMaterial(0x252d31,.18,.60),dark=attachmentVisualMaterial(0x101518,.20,.68),sensorMat=attachmentVisualMaterial(0x647d82,.08,.28);
  const module=new THREE.Mesh(new THREE.BoxGeometry(radius*.72,radius*.62,length*.30),mat),battery=new THREE.Mesh(new THREE.BoxGeometry(radius*.36,radius*.34,length*.22),dark),sensor=new THREE.Mesh(new THREE.CircleGeometry(radius*.15,14),sensorMat),wire=new THREE.Mesh(new THREE.CylinderGeometry(radius*.035,radius*.035,length*.22,8),dark);
  module.position.set(-radius*1.22,sightY-radius*.08,z+length*.05);battery.position.set(-radius*1.22,sightY-radius*.55,z+length*.06);sensor.rotation.y=Math.PI/2;sensor.position.set(-radius*1.59,sightY-radius*.06,z+length*.01);wire.rotation.x=Math.PI/2;wire.position.set(-radius*.92,sightY-radius*.40,z+length*.10);g.add(module,battery,sensor,wire);
  if(long){const rearPack=new THREE.Mesh(new THREE.BoxGeometry(radius*.58,radius*.44,length*.18),mat),cap=new THREE.Mesh(new THREE.BoxGeometry(radius*.42,radius*.28,length*.12),dark);rearPack.position.set(radius*1.06,sightY-radius*.12,z+length*.24);cap.position.set(radius*1.05,sightY-radius*.47,z+length*.24);g.add(rearPack,cap);}
  return g;
}
function makeSniperScopeMarker({z=-.16,y=.14,radius=.052,kind='precision'}={}){
  const thermal=String(kind).startsWith('thermal'),long=String(kind).includes('long'),g=new THREE.Group(),mat=attachmentVisualMaterial(thermal?0x2d3437:0x394147,.28,.48),dark=attachmentVisualMaterial(0x151a1d,.24,.58);
  const turret=new THREE.Mesh(new THREE.CylinderGeometry(.017,.017,.032,12),mat),turretCap=new THREE.Mesh(new THREE.CylinderGeometry(.019,.019,.006,12),dark),index=new THREE.Mesh(new THREE.BoxGeometry(.010,.020,.026),mat);turret.rotation.z=turretCap.rotation.z=Math.PI/2;turret.position.set(radius+.014,y,z);turretCap.position.set(radius+.031,y,z);index.position.set(radius+.014,y+.024,z);g.add(turret,turretCap,index);
  const focus=new THREE.Mesh(new THREE.TorusGeometry(radius*.96,Math.max(.0025,radius*.07),6,20),dark);focus.position.set(0,y,z+.068);g.add(focus);
  if(long){const cap=new THREE.Mesh(new THREE.CylinderGeometry(radius*.80,radius*.75,.052,18),mat),lip=new THREE.Mesh(new THREE.TorusGeometry(radius*.78,Math.max(.0025,radius*.065),6,20),dark);cap.rotation.x=Math.PI/2;cap.position.set(0,y,z-.073);lip.position.set(0,y,z-.100);g.add(cap,lip);}
  if(thermal){const module=new THREE.Mesh(new THREE.BoxGeometry(radius*.68,radius*.58,.066),attachmentVisualMaterial(0x202629,.16,.64)),battery=new THREE.Mesh(new THREE.BoxGeometry(radius*.34,radius*.30,.040),dark),sensor=new THREE.Mesh(new THREE.CircleGeometry(radius*.14,12),attachmentVisualMaterial(0x5a7378,.08,.30));module.position.set(-radius*.88,y-radius*.12,z+.005);battery.position.set(-radius*.90,y-radius*.43,z+.006);sensor.rotation.y=Math.PI/2;sensor.position.set(-radius*1.23,y-radius*.10,z-.010);g.add(module,battery,sensor);}
  return g;
}
function makeVerticalGrip({z=-.45,y=-.12}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x1a1f22,.14,.72),dark=attachmentVisualMaterial(0x0f1417,.18,.62),stem=new THREE.Mesh(new THREE.BoxGeometry(.055,.155,.065),mat),mount=new THREE.Mesh(new THREE.BoxGeometry(.074,.022,.094),mat),cap=new THREE.Mesh(new THREE.BoxGeometry(.060,.016,.070),dark);mount.position.set(0,y+.075,z);stem.position.set(0,y,z);stem.rotation.x=-.08;cap.position.set(0,y-.080,z);addBakedGripRibs(stem,{count:4});g.add(mount,stem,cap);return g;}
function makeAngledGrip({z=-.45,y=-.105}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x20262a,.16,.68),dark=attachmentVisualMaterial(0x111619,.18,.60),mount=new THREE.Mesh(new THREE.BoxGeometry(.086,.020,.118),mat),wedge=new THREE.Mesh(new THREE.BoxGeometry(.072,.075,.108),mat),heel=new THREE.Mesh(new THREE.BoxGeometry(.074,.018,.070),dark);mount.position.set(0,y+.055,z);wedge.position.set(0,y+.005,z-.018);wedge.rotation.x=-.48;heel.position.set(0,y-.030,z+.030);heel.rotation.x=-.48;addBakedGripRibs(wedge,{count:3});g.add(mount,wedge,heel);return g;}
function makeBipodAttachment({z=-.60,y=-.13,scale=1}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x171c1f,.20,.56),dark=attachmentVisualMaterial(0x0d1215,.24,.58),mount=new THREE.Mesh(new THREE.BoxGeometry(.060*scale,.028*scale,.060*scale),mat),hinge=new THREE.Mesh(new THREE.CylinderGeometry(.015*scale,.015*scale,.075*scale,10),dark),left=new THREE.Mesh(new THREE.CylinderGeometry(.008*scale,.008*scale,.20*scale,8),mat),right=left.clone(),footL=new THREE.Mesh(new THREE.BoxGeometry(.036*scale,.012*scale,.026*scale),dark),footR=footL.clone();mount.position.set(0,y+.10*scale,z);hinge.rotation.z=Math.PI/2;hinge.position.set(0,y+.072*scale,z);left.position.set(-.050*scale,y,z);right.position.set(.050*scale,y,z);left.rotation.z=.19;right.rotation.z=-.19;left.rotation.x=right.rotation.x=.12;footL.position.set(-.068*scale,y-.097*scale,z+.010*scale);footR.position.set(.068*scale,y-.097*scale,z+.010*scale);g.add(mount,hinge,left,right,footL,footR);return g;}
function makeLaserAttachment({x=.035,z=-.40,y=-.09,scale=1}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x191e21,.22,.54),dark=attachmentVisualMaterial(0x0e1316,.26,.52),green=0x39ff70,lensMat=new THREE.MeshBasicMaterial({color:green,transparent:true,opacity:1,depthWrite:false,toneMapped:false}),beamMat=new THREE.MeshBasicMaterial({color:green,transparent:true,opacity:.34,depthTest:true,depthWrite:false,toneMapped:false,blending:THREE.AdditiveBlending}),coreMat=new THREE.MeshBasicMaterial({color:0xb9ffd0,transparent:true,opacity:.78,depthTest:true,depthWrite:false,toneMapped:false,blending:THREE.AdditiveBlending}),body=new THREE.Mesh(new THREE.BoxGeometry(.055*scale,.042*scale,.105*scale),mat),mount=new THREE.Mesh(new THREE.BoxGeometry(.068*scale,.018*scale,.070*scale),dark),bezel=new THREE.Mesh(new THREE.CylinderGeometry(.014*scale,.014*scale,.016*scale,12),dark),lens=new THREE.Mesh(new THREE.CircleGeometry(.010*scale,14),lensMat),beam=new THREE.Mesh(new THREE.CylinderGeometry(.0024*scale,.0024*scale,1,6,1,true),beamMat),core=new THREE.Mesh(new THREE.CylinderGeometry(.0009*scale,.0009*scale,1,5,1,true),coreMat),emitter=new THREE.Vector3(x,y,z-.061*scale);body.position.set(x,y,z);mount.position.set(x,y+.029*scale,z+.012*scale);bezel.rotation.x=Math.PI/2;bezel.position.copy(emitter).add(new THREE.Vector3(0,0,.008*scale));lens.position.copy(emitter);beam.rotation.x=core.rotation.x=Math.PI/2;beam.renderOrder=core.renderOrder=35;beam.userData.previewSkip=true;core.userData.previewSkip=true;g.userData.laserBeam={beam,core,emitter,maxLength:24,length:24,nextRaycastAt:0};g.add(body,mount,bezel,lens,beam,core);setLaserBeamLength(g,24);return g;}
function setLaserBeamLength(visual,length){const data=visual?.userData?.laserBeam;if(!data)return;const len=Math.max(.04,Math.min(data.maxLength||24,Number(length)||0)),emitter=data.emitter;data.length=len;for(const mesh of [data.beam,data.core]){mesh.scale.y=len;mesh.position.set(emitter.x,emitter.y,emitter.z-len*.5);}}
let laserRaycaster=null,laserWorldOrigin=null,laserWorldDirection=null,laserWorldQuaternion=null;
function updateLaserAttachmentBeam(visual,now=performance.now(),raycastInterval=0){const data=visual?.userData?.laserBeam;if(!data||!visual.visible||!worldRoot)return;if(now>=data.nextRaycastAt){laserRaycaster=laserRaycaster||new THREE.Raycaster();laserWorldOrigin=laserWorldOrigin||new THREE.Vector3();laserWorldDirection=laserWorldDirection||new THREE.Vector3();laserWorldQuaternion=laserWorldQuaternion||new THREE.Quaternion();visual.localToWorld(laserWorldOrigin.copy(data.emitter));visual.getWorldQuaternion(laserWorldQuaternion);laserWorldDirection.set(0,0,-1).applyQuaternion(laserWorldQuaternion).normalize();laserRaycaster.set(laserWorldOrigin,laserWorldDirection);laserRaycaster.near=.02;laserRaycaster.far=data.maxLength;const hit=laserRaycaster.intersectObject(worldRoot,true)[0],distance=hit?Math.max(.04,hit.distance-.012):data.maxLength;setLaserBeamLength(visual,distance);data.nextRaycastAt=now+Math.max(0,raycastInterval);}}
function updateGameplayLaserBeams(now=performance.now()){const local=[];for(const group of [pistolGroup,akimboLeftGroup,akimboRightGroup,assaultGroup,umpGroup,machineGunGroup,shotgunGroup,semiShotgunGroup,sniperGroup,rpgGroup]){const laser=group?.userData?.attachmentVisuals?.laser;if(laser?.visible&&group.visible)local.push(laser);}for(const laser of local)updateLaserAttachmentBeam(laser,now,0);for(const r of remotes.values()){if(!r||r.hp<=0)continue;if(r.weapon==='akimbo1887'){for(const gun of [r.akimboLeft,r.akimboRight]){const laser=gun?.userData?.attachmentVisuals?.laser;if(laser?.visible&&gun.visible)updateLaserAttachmentBeam(laser,now,42);}}else{const gun=r[r.weapon],laser=gun?.userData?.attachmentVisuals?.laser;if(laser?.visible&&gun?.visible)updateLaserAttachmentBeam(laser,now,42);}}}

function makeStockAttachment({z=.40,y=-.02,width=.15}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x4c555b,.12,.70),dark=attachmentVisualMaterial(0x202629,.10,.80),plate=new THREE.Mesh(new THREE.BoxGeometry(width,.12,.055),mat),brace=new THREE.Mesh(new THREE.BoxGeometry(width*.55,.045,.11),mat),pad=new THREE.Mesh(new THREE.BoxGeometry(width*1.04,.105,.018),dark);plate.position.set(0,y,z+.055);brace.position.set(0,y+.025,z);pad.position.set(0,y-.004,z+.088);g.add(brace,plate,pad);return g;}
function makeFullStockAttachment({z=.42,y=-.02,width=.16}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x424b50,.14,.66),dark=attachmentVisualMaterial(0x22272a,.10,.82),body=new THREE.Mesh(new THREE.BoxGeometry(width,.15,.18),mat),cheek=new THREE.Mesh(new THREE.BoxGeometry(width*.70,.040,.115),mat),pad=new THREE.Mesh(new THREE.BoxGeometry(width*1.04,.16,.045),dark);body.position.set(0,y,z);body.rotation.x=-.08;cheek.position.set(0,y+.082,z-.010);cheek.rotation.x=-.08;pad.position.set(0,y-.008,z+.105);pad.rotation.x=-.08;addBakedBoxPanels(body,{side:true,top:false,panelScale:.42});g.add(body,cheek,pad);return g;}
function makeCompactStockAttachment({z=.24,y=.01,width=.10}={}){const g=new THREE.Group(),mat=attachmentVisualMaterial(0x343b40,.18,.58),dark=attachmentVisualMaterial(0x171c20,.12,.78),braceL=new THREE.Mesh(new THREE.BoxGeometry(width*.16,.036,.12),mat),braceR=braceL.clone(),pad=new THREE.Mesh(new THREE.BoxGeometry(width,.095,.035),dark);braceL.position.set(-width*.25,y+.015,z);braceR.position.set(width*.25,y+.015,z);pad.position.set(0,y,z+.075);g.add(braceL,braceR,pad);return g;}
function makeMagMarker({z=-.12,y=-.21,width=.11}={}){const g=new THREE.Group(),mat=new THREE.MeshStandardMaterial({color:0x808e96,roughness:.62,metalness:.22}),dark=bakedWeaponInsetMaterial(),band=new THREE.Mesh(new THREE.BoxGeometry(width+.012,.026,.14),mat),tab=new THREE.Mesh(new THREE.BoxGeometry(width*.40,.018,.055),dark);band.position.set(0,y,z);tab.position.set(width*.28,y+.020,z+.030);g.add(band,tab);return g;}
function makeFastMagBand({width=.11,depth=.13,y=.18}={}){const mat=new THREE.MeshStandardMaterial({color:0x87969f,roughness:.58,metalness:.24}),g=new THREE.Group(),bandA=new THREE.Mesh(new THREE.BoxGeometry(width,.026,depth),mat),bandB=new THREE.Mesh(new THREE.BoxGeometry(width*.34,.035,depth*.46),bakedWeaponInsetMaterial());bandA.position.set(0,y,0);bandB.position.set(width*.28,y+.018,0);g.add(bandA,bandB);g.visible=false;return g;}
function setupWeaponAttachmentVisuals(group,weapon,opts={}){
  if(!group)return;const flash=opts.flash||null,muzzle=opts.muzzle?{x:Number(opts.muzzle.x)||0,y:Number(opts.muzzle.y)||0,z:Number(opts.muzzle.z)||0}:flash?{x:flash.position.x,y:flash.position.y,z:flash.position.z}:null;
  group.userData.attachmentWeapon=weapon;group.userData.attachmentFlash=flash;group.userData.attachmentBaseFlash=flash?flash.position.clone():null;group.userData.attachmentMuzzle=muzzle;group.userData.attachmentMagazine=opts.mag||null;if(opts.mag)group.userData.attachmentMagazineBaseScale=opts.mag.scale.clone();
  if(opts.barrelMesh){const mesh=opts.barrelMesh,length=Math.max(.001,Number(mesh.geometry?.parameters?.height)||.1),baseScale=mesh.scale.clone(),basePosition=mesh.position.clone(),worldLength=length*baseScale.y,rearZ=basePosition.z+worldLength*.5;group.userData.attachmentBarrel={mesh,baseScale,basePosition,baseLength:worldLength,rearZ,baseFrontZ:rearZ-worldLength};}
  group.userData.attachmentStockBaseParts=(opts.stockBaseParts||[]).filter(Boolean);group.userData.attachmentBipodBaseParts=(opts.bipodBaseParts||[]).filter(Boolean);
  if(opts.redDot)registerAttachmentVisual(group,'redDot',makeRedDotAttachment(opts.redDot));if(opts.holoSight)registerAttachmentVisual(group,'holoSight',makeHoloAttachment(opts.holoSight));if(opts.combatOptic)registerAttachmentVisual(group,'combatOptic',makeCombatOptic(opts.combatOptic));for(const id of ['precisionScope6x','longRangeScope8x'])if(opts[id])registerAttachmentVisual(group,id,makeSniperScopeMarker(opts[id]));for(const id of ['thermalScope4x','thermalScope6x'])if(opts[id])registerAttachmentVisual(group,id,weapon==='sniper'?makeSniperScopeMarker(opts[id]):makeThermalOpticAttachment(opts[id]));
  if(opts.suppressor&&muzzle)registerAttachmentVisual(group,'suppressor',makeMuzzleAttachment({...opts.suppressor,muzzle,ported:false}));if(opts.compensator&&muzzle)registerAttachmentVisual(group,'compensator',makeMuzzleAttachment({...opts.compensator,muzzle,ported:true}));if(opts.shotgunChoke&&muzzle)registerAttachmentVisual(group,'shotgunChoke',makeMuzzleAttachment({...opts.shotgunChoke,muzzle,ported:false}));
  if(opts.verticalGrip)registerAttachmentVisual(group,'verticalGrip',makeVerticalGrip(opts.verticalGrip));if(opts.angledGrip)registerAttachmentVisual(group,'angledGrip',makeAngledGrip(opts.angledGrip));if(opts.bipod&&!group.userData.attachmentBipodBaseParts.length)registerAttachmentVisual(group,'bipod',makeBipodAttachment(opts.bipod));if(opts.laser)registerAttachmentVisual(group,'laser',makeLaserAttachment(opts.laser));
  if(opts.lightweightStock)registerAttachmentVisual(group,'lightweightStock',makeStockAttachment(opts.lightweightStock));if(opts.fullStock)registerAttachmentVisual(group,'fullStock',makeFullStockAttachment(opts.fullStock));if(opts.compactStock)registerAttachmentVisual(group,'compactStock',makeCompactStockAttachment(opts.compactStock));
  if(opts.fastMag){if(opts.mag){const band=makeFastMagBand(opts.fastMag);group.userData.attachmentVisuals=group.userData.attachmentVisuals||{};group.userData.attachmentVisuals.fastMag=band;opts.mag.add(band);}else registerAttachmentVisual(group,'fastMag',makeMagMarker(opts.fastMag));}if(opts.extendedMag&&!opts.mag)registerAttachmentVisual(group,'extendedMag',makeMagMarker(opts.extendedMag));
}
function syncWeaponAttachmentVisuals(group,weapon,attachments){
  if(!group)return;const normalized=normalizeWeaponAttachments(weapon,attachments),visuals=group.userData.attachmentVisuals||{};for(const [id,obj] of Object.entries(visuals))obj.visible=weaponHasAttachment(weapon,normalized,id);
  const opticId=String(normalized.optic||'');for(const part of group.userData.ironSightParts||[])part.visible=!opticId;
  const mag=group.userData.attachmentMagazine,baseScale=group.userData.attachmentMagazineBaseScale;if(mag&&baseScale){mag.scale.copy(baseScale);if(weaponHasAttachment(weapon,normalized,'extendedMag'))mag.scale.y*=weapon==='machineGun'?1.14:1.20;}const fast=visuals.fastMag;if(fast)fast.visible=weaponHasAttachment(weapon,normalized,'fastMag');
  for(const part of group.userData.attachmentStockBaseParts||[])part.visible=!weaponHasAttachment(weapon,normalized,'compactStock');for(const part of group.userData.attachmentBipodBaseParts||[])part.visible=weaponHasAttachment(weapon,normalized,'bipod');
  let muzzleDeltaZ=0;const barrel=group.userData.attachmentBarrel;if(barrel?.mesh){let lengthScale=1,thickness=1;if(weaponHasAttachment(weapon,normalized,'heavyBarrel')){lengthScale=1.16;thickness=1.16;}else if(weaponHasAttachment(weapon,normalized,'shortBarrel')){lengthScale=.76;thickness=.94;}else if(weaponHasAttachment(weapon,normalized,'shotgunLongBarrel')){lengthScale=1.20;thickness=1.06;}barrel.mesh.scale.copy(barrel.baseScale);barrel.mesh.scale.y*=lengthScale;barrel.mesh.scale.x*=thickness;barrel.mesh.scale.z*=thickness;barrel.mesh.position.copy(barrel.basePosition);const newLength=barrel.baseLength*lengthScale,newFront=barrel.rearZ-newLength;barrel.mesh.position.z=barrel.rearZ-newLength*.5;muzzleDeltaZ=newFront-barrel.baseFrontZ;}
  for(const id of ['suppressor','compensator','shotgunChoke'])if(visuals[id])visuals[id].position.z=muzzleDeltaZ;
  const flash=group.userData.attachmentFlash,baseFlash=group.userData.attachmentBaseFlash;if(flash&&baseFlash){flash.position.copy(baseFlash);flash.position.z+=muzzleDeltaZ;const activeMuzzleId=weaponHasAttachment(weapon,normalized,'suppressor')?'suppressor':weaponHasAttachment(weapon,normalized,'compensator')?'compensator':weaponHasAttachment(weapon,normalized,'shotgunChoke')?'shotgunChoke':'';const visual=activeMuzzleId?visuals[activeMuzzleId]:null,tip=visual?.userData?.muzzleTip;if(tip){flash.position.copy(tip);flash.position.add(visual.position);}}
}
function syncLocalAttachmentVisuals(){
  const loadout=selectedLoadout();for(const weapon of WEAPON_ORDER){const attachments=attachmentsForWeapon(weapon,loadout);if(weapon==='akimbo1887'){for(const group of [akimboLeftGroup,akimboRightGroup])if(group)syncWeaponAttachmentVisuals(group,weapon,attachments);continue;}const group=activeFirstPersonWeaponGroup(weapon);if(group)syncWeaponAttachmentVisuals(group,weapon,attachments);}
}
function addViewAnchor(root,key,parent,position,rotation=[0,0,0]){
  const anchor=new THREE.Object3D(),host=parent||root;anchor.position.set(position[0],position[1],position[2]);anchor.rotation.set(rotation[0]||0,rotation[1]||0,rotation[2]||0);host.add(anchor);root.userData[key]=anchor;return anchor;
}
function registerWeaponHandAnchors(root,{right,left,reloadLeft,reloadRight}={}){
  if(right)addViewAnchor(root,'fpRightGrip',right.parent||root,right.position,right.rotation);
  if(left)addViewAnchor(root,'fpLeftGrip',left.parent||root,left.position,left.rotation);
  if(reloadLeft)addViewAnchor(root,'fpReloadLeft',reloadLeft.parent||root,reloadLeft.position,reloadLeft.rotation);
  if(reloadRight)addViewAnchor(root,'fpReloadRight',reloadRight.parent||root,reloadRight.position,reloadRight.rotation);
}
function activeFirstPersonWeaponGroup(weapon=currentWeapon){
  return weapon==='pistol'?pistolGroup:weapon==='akimbo1887'?null:weapon==='assault'?assaultGroup:weapon==='ump'?umpGroup:weapon==='machineGun'?machineGunGroup:weapon==='shotgun'?shotgunGroup:weapon==='semiShotgun'?semiShotgunGroup:weapon==='sniper'?sniperGroup:weapon==='grenadeLauncher'?grenadeLauncherGroup:weapon==='rpg'?rpgGroup:null;
}
function cloneLoadoutPreviewNode(source){
  // Preview only the geometry that is actually active. Hidden attachment meshes
  // must not affect weapon framing or the preview bounding box.
  if(!source||source.visible===false||source.userData?.previewSkip)return null;let clone;if(source.isMesh){clone=new THREE.Mesh(source.geometry,source.material);clone.castShadow=false;clone.receiveShadow=false;}else clone=new THREE.Group();clone.position.copy(source.position);clone.quaternion.copy(source.quaternion);clone.scale.copy(source.scale);clone.visible=true;clone.renderOrder=source.renderOrder||0;for(const child of source.children||[]){const copy=cloneLoadoutPreviewNode(child);if(copy)clone.add(copy);}return clone;
}
function loadoutPreviewSightPoint(source,weapon,attachments){
  if(!source)return null;const normalized=normalizeWeaponAttachments(weapon,attachments),opticId=String(normalized.optic||''),optic=opticId?source.userData?.attachmentVisuals?.[opticId]:null,aim=optic?.userData?.aimPoint;if(aim?.getWorldPosition){source.updateWorldMatrix(true,true);aim.updateWorldMatrix(true,false);const p=new THREE.Vector3();aim.getWorldPosition(p);return source.worldToLocal(p);}const rear=source.userData?.adsSightRear;if(rear)return new THREE.Vector3(Number(rear.x)||0,Number(rear.y)||0,Number(rear.z)||0);if(weapon==='sniper')return new THREE.Vector3(0,.14,.05);return null;
}
function loadoutPreviewNodePoint(source,node){if(!source||!node?.getWorldPosition)return null;source.updateWorldMatrix(true,true);node.updateWorldMatrix(true,false);const p=new THREE.Vector3();node.getWorldPosition(p);return source.worldToLocal(p);}
function loadoutPreviewCalloutPoints(source,weapon,attachments){
  if(!source)return{};const normalized=normalizeWeaponAttachments(weapon,attachments),visuals=source.userData?.attachmentVisuals||{},points={},opticId=String(normalized.optic||''),optic=opticId?visuals[opticId]:null,opticAim=optic?.userData?.aimPoint;
  points.optic=loadoutPreviewNodePoint(source,opticAim||optic)||(()=>{const rear=source.userData?.adsSightRear;return rear?new THREE.Vector3(Number(rear.x)||0,Number(rear.y)||0,Number(rear.z)||0):null;})();
  points.muzzle=loadoutPreviewNodePoint(source,source.userData?.attachmentFlash)||(()=>{const m=source.userData?.attachmentMuzzle;return m?new THREE.Vector3(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0):null;})();
  points.barrel=loadoutPreviewNodePoint(source,source.userData?.attachmentBarrel?.mesh);
  points.magazine=loadoutPreviewNodePoint(source,source.userData?.attachmentMagazine);
  const underId=String(normalized.underbarrel||''),under=underId?visuals[underId]:null;points.underbarrel=loadoutPreviewNodePoint(source,under)||loadoutPreviewNodePoint(source,source.userData?.fpLeftGrip);
  const stockId=String(normalized.stock||''),stock=stockId?visuals[stockId]:null,stockBase=(source.userData?.attachmentStockBaseParts||[])[0];points.stock=loadoutPreviewNodePoint(source,stock)||loadoutPreviewNodePoint(source,stockBase)||loadoutPreviewNodePoint(source,source.userData?.fpRightGrip);
  return Object.fromEntries(Object.entries(points).filter(([,v])=>v));
}
function buildLoadoutPreviewModel(weapon,attachments){
  const root=new THREE.Group(),referenceRoot=new THREE.Group(),sources=weapon==='akimbo1887'?[akimboLeftGroup,akimboRightGroup]:[activeFirstPersonWeaponGroup(weapon)].filter(Boolean);if(!sources.length)return root;let sightPoint=null,calloutPoints={};
  const appendVisibleSource=(target,source)=>{const copy=new THREE.Group();for(const child of source?.children||[]){const node=cloneLoadoutPreviewNode(child);if(node)copy.add(node);}target.add(copy);};
  const poseAkimbo=target=>{if(weapon==='akimbo1887'&&target.children.length>=2){target.children[0].position.x=-.19;target.children[0].rotation.y=.08;target.children[1].position.x=.19;target.children[1].rotation.y=-.08;}};
  const changed=[];for(const source of sources){if(source?.userData?.attachmentWeapon){syncWeaponAttachmentVisuals(source,weapon,attachments);changed.push(source);}if(sources.length===1){if(!sightPoint)sightPoint=loadoutPreviewSightPoint(source,weapon,attachments);calloutPoints=loadoutPreviewCalloutPoints(source,weapon,attachments);}appendVisibleSource(root,source);}
  // Frame every configuration from the weapon's base silhouette. Extended mags,
  // long/heavy barrels and other dimensional attachments no longer make the
  // weapon jump in size or recenter when the player compares options.
  for(const source of changed)syncWeaponAttachmentVisuals(source,weapon,{});for(const source of sources)appendVisibleSource(referenceRoot,source);poseAkimbo(root);poseAkimbo(referenceRoot);
  // Restore the live viewmodel immediately; draft attachments belong only to the preview until saved.
  if(changed.length)syncLocalAttachmentVisuals();
  const frameRoot=referenceRoot.children.length?referenceRoot:root,box=new THREE.Box3().setFromObject(frameRoot),size=box.getSize(new THREE.Vector3()),center=box.getCenter(new THREE.Vector3()),maxDim=Math.max(.01,size.x,size.y,size.z),scale=2.16/maxDim;root.position.sub(center);const wrapper=new THREE.Group();wrapper.add(root);wrapper.scale.setScalar(scale);if(sightPoint)wrapper.userData.adsPoint=sightPoint.sub(center).multiplyScalar(scale);wrapper.userData.calloutPoints={};for(const [slot,point] of Object.entries(calloutPoints))wrapper.userData.calloutPoints[slot]=point.clone().sub(center).multiplyScalar(scale);return wrapper;
}
function adjustLoadoutPreviewAngle(ctx,horizontalDelta){
  if(!ctx)return false;const delta=Number(horizontalDelta)||0;if(!delta)return false;ctx.angle+=delta*.012;ctx.interacted=true;return true;
}
function createLoadoutPreviewContext(key,canvas){
  const previewScene=new THREE.Scene(),previewCamera=new THREE.PerspectiveCamera(28,1,.05,20),previewRenderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'low-power'});previewRenderer.setPixelRatio(1);previewRenderer.outputColorSpace=THREE.SRGBColorSpace;previewRenderer.toneMapping=THREE.ACESFilmicToneMapping;previewRenderer.toneMappingExposure=1.08;previewRenderer.setClearColor(0x000000,0);previewCamera.position.set(0,.18,4.6);previewCamera.lookAt(0,0,0);previewScene.add(new THREE.HemisphereLight(0xeaf6ff,0x29322d,2.5));const keyLight=new THREE.DirectionalLight(0xffffff,2.3);keyLight.position.set(-3,4,4);previewScene.add(keyLight);const rim=new THREE.DirectionalLight(0x9bc7da,1.1);rim.position.set(4,1,-3);previewScene.add(rim);const pivot=new THREE.Group();previewScene.add(pivot);const ctx={key,canvas,scene:previewScene,camera:previewCamera,renderer:previewRenderer,pivot,signature:'',angle:.16,dragging:false,lastX:0,interacted:false,lastRenderedAt:0,adsPreview:loadoutPreviewAdsKeys.has(key)};
  uiGestures.bind(canvas,{
    start:()=>{ctx.dragging=true;ctx.interacted=true;},
    move:state=>adjustLoadoutPreviewAngle(ctx,state.dx),
    finish:()=>{ctx.dragging=false;},cancel:()=>{ctx.dragging=false;},
  });return ctx;
}
async function ensureLoadoutPreviewEngine(){if(engineReady)return true;return ensureThreeEngine();}
function updateLoadoutCalloutLines(key,ctx,model,w,h){const host=document.querySelector(`[data-gunsmith-callouts="${key}"]`);if(!host||!model)return;host.classList.toggle('ads-hidden',!!ctx.adsPreview);if(ctx.adsPreview)return;const svg=host.querySelector('.gunsmith-callout-lines');if(!svg)return;svg.setAttribute('viewBox',`0 0 ${w} ${h}`);ctx.pivot.updateMatrixWorld(true);ctx.camera.updateMatrixWorld(true);const canvasRect=ctx.canvas.getBoundingClientRect(),points=model.userData?.calloutPoints||{};for(const button of host.querySelectorAll('[data-callout-slot]')){const slot=button.dataset.calloutSlot,point=points[slot],line=svg.querySelector(`[data-callout-line="${slot}"]`),dot=svg.querySelector(`[data-callout-dot="${slot}"]`);if(!point||!line){if(line)line.style.display='none';if(dot)dot.style.display='none';continue;}const projected=point.clone();ctx.pivot.localToWorld(projected);projected.project(ctx.camera);const x=(projected.x*.5+.5)*w,y=(-projected.y*.5+.5)*h,br=button.getBoundingClientRect(),bx=br.left-canvasRect.left+br.width*.5,by=br.top-canvasRect.top+br.height*.5,visible=projected.z>=-1&&projected.z<=1&&x>=-w*.15&&x<=w*1.15&&y>=-h*.2&&y<=h*1.2;line.style.display=visible?'':'none';line.setAttribute('x1',String(x));line.setAttribute('y1',String(y));line.setAttribute('x2',String(bx));line.setAttribute('y2',String(by));if(dot){dot.style.display=visible?'':'none';dot.setAttribute('cx',String(x));dot.setAttribute('cy',String(y));}}
}
function updateLoadoutPreviewFrame(now,dt){
  if(!engineReady||!THREE)return;for(const [key,desired] of loadoutPreviewDesired){const canvas=document.querySelector(`[data-loadout-preview="${key}"]`);if(!canvas||!canvas.getClientRects().length||canvas.closest('[hidden]'))continue;let ctx=loadoutPreviewContexts.get(key);if(!ctx){ctx=createLoadoutPreviewContext(key,canvas);loadoutPreviewContexts.set(key,ctx);}if(ctx.signature!==desired.signature){while(ctx.pivot.children.length)ctx.pivot.remove(ctx.pivot.children[0]);const model=buildLoadoutPreviewModel(desired.weapon,desired.attachments);ctx.pivot.add(model);ctx.signature=desired.signature;}
    const w=Math.max(2,Math.round(canvas.clientWidth||2)),h=Math.max(2,Math.round(canvas.clientHeight||2));if(canvas.width!==w||canvas.height!==h)ctx.renderer.setSize(w,h,false);ctx.camera.aspect=w/h;ctx.adsPreview=loadoutPreviewAdsKeys.has(key);const model=ctx.pivot.children[0],adsPoint=model?.userData?.adsPoint;if(ctx.adsPreview){ctx.camera.fov=23;ctx.camera.position.set(0,0,3.75);ctx.pivot.rotation.set(0,0,0);ctx.pivot.position.set(-(adsPoint?.x||0),-(adsPoint?.y||0),0);}else{ctx.camera.fov=28;ctx.camera.position.set(0,.18,4.6);ctx.pivot.position.set(0,0,0);if(!ctx.dragging&&!ctx.interacted)ctx.angle+=Math.max(0,Number(dt)||0)*.10;ctx.pivot.rotation.set(-.10,Math.PI/2+ctx.angle,.02);}ctx.camera.updateProjectionMatrix();ctx.renderer.render(ctx.scene,ctx.camera);updateLoadoutCalloutLines(key,ctx,model,w,h);ctx.lastRenderedAt=now;}
}
function createFirstPersonHand(side,gloveMat){
  const root=new THREE.Group(),palm=new THREE.Mesh(new THREE.BoxGeometry(.074,.050,.096),gloveMat),knuckles=new THREE.Mesh(new THREE.BoxGeometry(.078,.032,.052),gloveMat),thumb=new THREE.Mesh(new THREE.CapsuleGeometry(.012,.035,3,6),gloveMat);
  palm.position.set(0,0,0);knuckles.position.set(0,.005,-.055);thumb.rotation.z=side*.72;thumb.rotation.x=-.34;thumb.position.set(side*.045,-.010,-.002);root.add(palm,knuckles,thumb);root.userData.side=side;return root;
}
function initFirstPersonHandRig(){
  firstPersonHands=new THREE.Group();
  const gloveMat=new THREE.MeshStandardMaterial({color:0x171b1f,roughness:.94,metalness:.02}),sleeveMat=new THREE.MeshStandardMaterial({color:0x35414a,roughness:.96,metalness:.01});
  fpLeftHand=createFirstPersonHand(-1,gloveMat);fpRightHand=createFirstPersonHand(1,gloveMat);
  fpLeftForearm=new THREE.Mesh(new THREE.CylinderGeometry(.040,.052,1,8),sleeveMat);fpRightForearm=fpLeftForearm.clone();
  fpEquipmentProp=new THREE.Mesh(new THREE.SphereGeometry(.048,9,7),new THREE.MeshStandardMaterial({color:0x4d5659,roughness:.68,metalness:.18}));fpEquipmentProp.position.set(-.004,.035,-.060);fpEquipmentProp.visible=false;fpLeftHand.add(fpEquipmentProp);
  firstPersonHands.add(fpLeftForearm,fpRightForearm,fpLeftHand,fpRightHand);camera.add(firstPersonHands);
  fpRigScratch={p0:new THREE.Vector3(),p1:new THREE.Vector3(),p2:new THREE.Vector3(),p3:new THREE.Vector3(),dir:new THREE.Vector3(),q0:new THREE.Quaternion(),q1:new THREE.Quaternion(),q2:new THREE.Quaternion(),camQ:new THREE.Quaternion(),camInvQ:new THREE.Quaternion(),camInvMatrix:new THREE.Matrix4(),unitY:new THREE.Vector3(0,1,0)};
}
function anchorPoseInCamera(anchor,outPos,outQuat){
  if(!anchor||!camera||!fpRigScratch)return false;anchor.updateWorldMatrix(true,false);outPos.setFromMatrixPosition(anchor.matrixWorld).applyMatrix4(fpRigScratch.camInvMatrix);anchor.getWorldQuaternion(outQuat);outQuat.premultiply(fpRigScratch.camInvQ);return true;
}
function reloadHandWeight(p,start=.10,end=.82,edge=.14){
  if(p<=start||p>=end)return 0;const enter=smoothstep01((p-start)/Math.max(.001,edge)),exit=1-smoothstep01((p-(end-edge))/Math.max(.001,edge));return Math.max(0,Math.min(1,enter*exit));
}
function updateForearmMesh(mesh,side,wrist){
  if(!mesh||!wrist||!fpRigScratch)return;const elbow=fpRigScratch.p3.set(side*.33,-.43,-.20),dir=fpRigScratch.dir.copy(wrist).sub(elbow),length=Math.max(.08,dir.length());dir.normalize();mesh.position.copy(elbow).add(wrist).multiplyScalar(.5);mesh.scale.set(1,length,1);mesh.quaternion.setFromUnitVectors(fpRigScratch.unitY,dir);
}
function equipmentHandTarget(now,outPos,outQuat){
  let t=0,posA=[-.17,-.17,-.54],posB=[-.205,-.185,-.68],rotA=[-.50,.18,-.28],rotB=[-.82,.14,-.34];
  if(combatAction.phase===COMBAT_ACTION.EQUIPMENT_AIM)t=smoothstep01((now-combatAction.startedAt)/120);
  else if(combatAction.phase===COMBAT_ACTION.EQUIPMENT_THROW){const start=combatAction.commitAt-EQUIPMENT_THROW_COMMIT_MS;t=smoothstep01((now-start)/Math.max(1,EQUIPMENT_THROW_COMMIT_MS));}
  else t=0;
  outPos.set(THREE.MathUtils.lerp(posA[0],posB[0],t),THREE.MathUtils.lerp(posA[1],posB[1],t),THREE.MathUtils.lerp(posA[2],posB[2],t));
  fpRigScratch.q2.setFromEuler(new THREE.Euler(THREE.MathUtils.lerp(rotA[0],rotB[0],t),THREE.MathUtils.lerp(rotA[1],rotB[1],t),THREE.MathUtils.lerp(rotA[2],rotB[2],t),'XYZ'));outQuat.copy(fpRigScratch.q2);
}
function updateFirstPersonHandRig(now,reloading,reloadP,traversalViewActive){
  if(!firstPersonHands||!fpRigScratch)return;
  const scopedHidden=sniperWeaponHiddenForScope(),alive=!!shell.inMatch&&hp>0&&!traversalViewActive&&!scopedHidden;firstPersonHands.visible=alive;if(!alive){if(fpEquipmentProp)fpEquipmentProp.visible=false;return;}
  let leftAnchor=null,rightAnchor=null,reloadLeft=null,reloadRight=null;
  if(currentWeapon==='akimbo1887'){leftAnchor=akimboLeftGroup?.userData.fpLeftGrip||null;rightAnchor=akimboRightGroup?.userData.fpRightGrip||null;reloadLeft=akimboLeftGroup?.userData.fpReloadLeft||null;reloadRight=akimboRightGroup?.userData.fpReloadRight||null;}
  else{const group=activeFirstPersonWeaponGroup(currentWeapon);leftAnchor=group?.userData.fpLeftGrip||null;rightAnchor=group?.userData.fpRightGrip||null;reloadLeft=group?.userData.fpReloadLeft||null;reloadRight=group?.userData.fpReloadRight||null;}
  if(!leftAnchor||!rightAnchor){firstPersonHands.visible=false;return;}
  camera.updateMatrixWorld(true);camera.getWorldQuaternion(fpRigScratch.camQ);fpRigScratch.camInvQ.copy(fpRigScratch.camQ).invert();fpRigScratch.camInvMatrix.copy(camera.matrixWorld).invert();
  const lp=fpRigScratch.p0,lq=fpRigScratch.q0,rp=fpRigScratch.p1,rq=fpRigScratch.q1,targetP=fpRigScratch.p2,targetQ=fpRigScratch.q2;
  anchorPoseInCamera(leftAnchor,lp,lq);anchorPoseInCamera(rightAnchor,rp,rq);
  if(reloading&&reloadLeft){let w=currentWeapon==='shotgun'?reloadHandWeight(reloadP,.06,.92,.16):currentWeapon==='machineGun'?reloadHandWeight(reloadP,.10,.84,.18):reloadHandWeight(reloadP,.12,.80,.14);if(w>0&&anchorPoseInCamera(reloadLeft,targetP,targetQ)){lp.lerp(targetP,w);lq.slerp(targetQ,w);}}
  if(reloading&&reloadRight){const w=currentWeapon==='sniper'?reloadHandWeight(reloadP,.24,.64,.10):reloadHandWeight(reloadP,.20,.68,.12);if(w>0&&anchorPoseInCamera(reloadRight,targetP,targetQ)){rp.lerp(targetP,w);rq.slerp(targetQ,w);}}
  const equipmentWeight=equipmentWeaponLower(now);if(equipmentWeight>0){equipmentHandTarget(now,targetP,targetQ);lp.lerp(targetP,equipmentWeight);lq.slerp(targetQ,equipmentWeight);}
  fpLeftHand.position.copy(lp);fpLeftHand.quaternion.copy(lq);fpRightHand.position.copy(rp);fpRightHand.quaternion.copy(rq);updateForearmMesh(fpLeftForearm,-1,lp);updateForearmMesh(fpRightForearm,1,rp);
  if(fpEquipmentProp){const show=combatAction.phase===COMBAT_ACTION.EQUIPMENT_AIM||combatAction.phase===COMBAT_ACTION.EQUIPMENT_THROW;fpEquipmentProp.visible=show;const kind=combatAction.kind||'';fpEquipmentProp.material.color.set(kind==='frag'?0x4e5745:kind==='sticky'?0x70757a:kind==='smoke'?0x59636b:0x72787b);const baseScale=kind==='flash'?.64:kind==='sticky'?.68:kind==='smoke'?.84:.80;fpEquipmentProp.scale.set(baseScale,baseScale*(kind==='flash'?1.28:kind==='sticky'?1.10:1),baseScale);}
}

function init3D(){
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x9acde6);
  scene.fog = new THREE.Fog(0x9acde6, 95, 285);
  const initialView=getViewSize(); viewW=initialView.w; viewH=initialView.h;
  camera = new THREE.PerspectiveCamera(70, viewW/viewH, 0.05, 360);
  camera.rotation.order = 'YXZ';
  renderer = new THREE.WebGLRenderer({ canvas, antialias:true, powerPreference:'high-performance' });
  renderer.setPixelRatio(1);
  renderer.setSize(viewW, viewH, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = false;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  applyGraphicsQuality();
  clock = new THREE.Clock();
  initHudOverlay();

  worldHemiLight = new THREE.HemisphereLight(0xdaf4ff, 0x52604c, 2.2); scene.add(worldHemiLight);
  worldSunLight = new THREE.DirectionalLight(0xffffff, 2.15); worldSunLight.position.set(26,38,18);worldSunLight.castShadow=!isTouch;if(!isTouch){worldSunLight.shadow.mapSize.set(1536,1536);worldSunLight.shadow.camera.left=-125;worldSunLight.shadow.camera.right=125;worldSunLight.shadow.camera.top=125;worldSunLight.shadow.camera.bottom=-125;worldSunLight.shadow.camera.near=5;worldSunLight.shadow.camera.far=110;worldSunLight.shadow.bias=-.00035;} scene.add(worldSunLight);

  buildWorldVisuals();


  pistolGroup = new THREE.Group();
  const pistolMetal = new THREE.MeshStandardMaterial({color:0x20262c,roughness:.38,metalness:.48});
  const pistolPoly = new THREE.MeshStandardMaterial({color:0x32383d,roughness:.72,metalness:.12});
  const gripMat = new THREE.MeshStandardMaterial({color:0x47413a,roughness:.9,metalness:.04});
  const glockSlide = new THREE.Mesh(new THREE.BoxGeometry(.17,.11,.46),pistolMetal);glockSlide.position.set(0,.055,-.11);
  const glockFront = new THREE.Mesh(new THREE.BoxGeometry(.145,.095,.10),pistolMetal);glockFront.position.set(0,.047,-.39);
  const glockFrame = new THREE.Mesh(new THREE.BoxGeometry(.16,.10,.30),pistolPoly);glockFrame.position.set(0,-.005,-.05);
  const glockDust = new THREE.Mesh(new THREE.BoxGeometry(.14,.07,.15),pistolPoly);glockDust.position.set(0,-.045,-.23);
  const glockBarrel = new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,.18,10),pistolMetal);glockBarrel.rotation.x=Math.PI/2;glockBarrel.position.set(0,.047,-.39);
  const triggerGuard = new THREE.Mesh(new THREE.TorusGeometry(.045,.010,5,18,Math.PI),pistolPoly);triggerGuard.rotation.y=Math.PI/2;triggerGuard.rotation.z=Math.PI;triggerGuard.position.set(0,-.085,-.03);
  const glockGrip = new THREE.Mesh(new THREE.BoxGeometry(.135,.30,.15),gripMat);glockGrip.position.set(0,-.185,.05);glockGrip.rotation.x=-.32;
  const glockBackstrap = new THREE.Mesh(new THREE.BoxGeometry(.05,.16,.11),pistolPoly);glockBackstrap.position.set(0,-.125,.13);glockBackstrap.rotation.x=-.32;
  pistolMag=new THREE.Mesh(new THREE.BoxGeometry(.090,.20,.11),pistolMetal);pistolMag.position.set(0,-.245,.045);pistolMag.rotation.x=-.32;
  pistolFlash = new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),new THREE.MeshBasicMaterial({color:0xffd27a,transparent:true,opacity:0}));pistolFlash.position.set(0,.047,-.51);
  bakeWeaponGeometry({receivers:[glockSlide,glockFrame],handguards:[glockDust],grips:[glockGrip],magazines:[pistolMag],tubes:[glockBarrel]});
  pistolGroup.add(glockSlide,glockFront,glockFrame,glockDust,glockBarrel,triggerGuard,glockGrip,glockBackstrap,pistolMag,pistolFlash);pistolGroup.userData.cyclePart=glockSlide;pistolGroup.userData.cycleBaseZ=-.11;pistolGroup.userData.cycleTravel=.075;addPistolIronSights(pistolGroup,pistolMetal,{rearZ:.08,frontZ:-.31,sightY:.140,rearMountY:.112,frontMountY:.112,eyeZ:-.46});registerWeaponHandAnchors(pistolGroup,{right:{position:[.035,-.16,.055],rotation:[-.30,-.04,.04]},left:{position:[-.045,-.105,-.015],rotation:[-.34,.10,.20]},reloadLeft:{parent:pistolMag,position:[-.035,-.02,.01],rotation:[-.18,.08,.18]}});pistolGroup.position.set(.33,-.25,-.67);pistolGroup.rotation.set(-.08,-.08,0);

  const buildAkimbo1887=(side)=>{
    const g=new THREE.Group(),metal=new THREE.MeshStandardMaterial({color:0x24282b,roughness:.40,metalness:.46}),wood=new THREE.MeshStandardMaterial({color:0x684933,roughness:.84}),leverMat=new THREE.MeshStandardMaterial({color:0x34383b,roughness:.36,metalness:.44});
    const receiver=new THREE.Mesh(new THREE.BoxGeometry(.15,.14,.36),metal);receiver.position.set(0,.02,-.16);
    const tang=new THREE.Mesh(new THREE.BoxGeometry(.06,.05,.16),metal);tang.position.set(0,.06,.05);
    const barrel=new THREE.Mesh(new THREE.CylinderGeometry(.022,.022,1.02,10),metal);barrel.rotation.x=Math.PI/2;barrel.position.set(0,.04,-.70);
    const tube=new THREE.Mesh(new THREE.CylinderGeometry(.018,.018,.88,9),metal);tube.rotation.x=Math.PI/2;tube.position.set(0,-.012,-.66);
    const forearm=new THREE.Mesh(new THREE.BoxGeometry(.12,.095,.32),wood);forearm.position.set(0,-.005,-.43);forearm.rotation.x=-.03;
    const grip=new THREE.Mesh(new THREE.BoxGeometry(.12,.22,.12),wood);grip.position.set(0,-.13,.05);grip.rotation.x=-.34;
    const stock=new THREE.Mesh(new THREE.BoxGeometry(.11,.14,.38),wood);stock.position.set(0,-.005,.22);stock.rotation.x=-.12;
    const butt=new THREE.Mesh(new THREE.BoxGeometry(.12,.16,.08),wood);butt.position.set(0,-.03,.42);butt.rotation.x=-.12;
    const lever=new THREE.Mesh(new THREE.TorusGeometry(.072,.011,6,22),leverMat);lever.rotation.x=Math.PI/2;lever.scale.set(1,.68,1);lever.position.set(0,-.11,.00);
    const hammer=new THREE.Mesh(new THREE.BoxGeometry(.040,.045,.07),metal);hammer.position.set(0,.08,.07);hammer.rotation.x=-.30;
    const flash=new THREE.Mesh(new THREE.SphereGeometry(.082,8,6),new THREE.MeshBasicMaterial({color:0xffcf79,transparent:true,opacity:0}));flash.position.set(0,.04,-1.24);
    bakeWeaponGeometry({receivers:[receiver,tang],handguards:[forearm],grips:[grip],stocks:[stock],tubes:[barrel,tube]});
    g.add(receiver,tang,barrel,tube,forearm,grip,stock,butt,lever,hammer,flash);g.userData.akimboSide=side;return{group:g,flash,lever,barrel,stock};
  };
  ({group:akimboLeftGroup,flash:akimboLeftFlash,lever:akimboLeftLever,barrel:akimboLeftBarrel,stock:akimboLeftStock}=buildAkimbo1887('left'));({group:akimboRightGroup,flash:akimboRightFlash,lever:akimboRightLever,barrel:akimboRightBarrel,stock:akimboRightStock}=buildAkimbo1887('right'));
  registerWeaponHandAnchors(akimboLeftGroup,{left:{position:[0,-.12,.055],rotation:[-.32,.05,-.06]},reloadLeft:{position:[0,-.16,.075],rotation:[-.20,.02,-.08]}});registerWeaponHandAnchors(akimboRightGroup,{right:{position:[0,-.12,.055],rotation:[-.32,-.05,.06]},reloadRight:{position:[0,-.16,.075],rotation:[-.20,-.02,.08]}});akimboLeftGroup.position.set(-.40,-.32,-.72);akimboLeftGroup.rotation.set(-.08,.18,-.035);akimboLeftGroup.visible=false;
  akimboRightGroup.position.set(.40,-.32,-.72);akimboRightGroup.rotation.set(-.08,-.18,.035);akimboRightGroup.visible=false;

  assaultGroup = new THREE.Group();
  const arMat = new THREE.MeshStandardMaterial({color:0x23292f,roughness:.40,metalness:.42});
  const arAccent = new THREE.MeshStandardMaterial({color:0x61574a,roughness:.74,metalness:.08});
  const scarUpper = new THREE.Mesh(new THREE.BoxGeometry(.18,.11,.40),arMat);scarUpper.position.set(0,.05,-.24);
  const scarLower = new THREE.Mesh(new THREE.BoxGeometry(.17,.10,.30),arMat);scarLower.position.set(0,-.03,-.10);
  const scarRail = new THREE.Mesh(new THREE.BoxGeometry(.09,.03,.72),new THREE.MeshStandardMaterial({color:0x4a5158,roughness:.55,metalness:.30}));scarRail.position.set(0,.115,-.34);
  const scarHandguard = new THREE.Mesh(new THREE.BoxGeometry(.16,.11,.36),new THREE.MeshStandardMaterial({color:0x7a6e5a,roughness:.82,metalness:.05}));scarHandguard.position.set(0,.015,-.56);
  const arBarrel = new THREE.Mesh(new THREE.CylinderGeometry(.021,.021,.54,10),arMat);arBarrel.rotation.x=Math.PI/2;arBarrel.position.set(0,.02,-.92);
  const scarStockStem = new THREE.Mesh(new THREE.BoxGeometry(.045,.055,.22),arMat);scarStockStem.position.set(0,-.01,.22);scarStockStem.rotation.x=-.10;
  const scarStock = new THREE.Mesh(new THREE.BoxGeometry(.15,.14,.18),arAccent);scarStock.position.set(0,-.01,.40);scarStock.rotation.x=-.10;
  const scarGrip = new THREE.Mesh(new THREE.BoxGeometry(.11,.23,.12),arMat);scarGrip.position.set(0,-.17,.01);scarGrip.rotation.x=-.26;
  const scarBolt=new THREE.Mesh(new THREE.BoxGeometry(.018,.035,.12),new THREE.MeshStandardMaterial({color:0x11161a,roughness:.28,metalness:.62}));scarBolt.position.set(.095,.055,-.21);addBakedGripRibs(scarBolt,{count:3});
  assaultMag = new THREE.Mesh(new THREE.BoxGeometry(.11,.29,.16),new THREE.MeshStandardMaterial({color:0x676f75,roughness:.62,metalness:.18}));assaultMag.position.set(0,-.19,-.15);assaultMag.rotation.x=.16;
  assaultFlash = new THREE.Mesh(new THREE.SphereGeometry(.074,8,6),new THREE.MeshBasicMaterial({color:0xffd98d,transparent:true,opacity:0}));assaultFlash.position.set(0,.02,-1.20);
  bakeWeaponGeometry({receivers:[scarUpper,scarLower],handguards:[scarHandguard],grips:[scarGrip],magazines:[assaultMag],rails:[scarRail],stocks:[scarStock],tubes:[arBarrel]});
  assaultGroup.add(scarUpper,scarLower,scarRail,scarHandguard,arBarrel,scarStockStem,scarStock,scarGrip,scarBolt,assaultMag,assaultFlash);assaultGroup.userData.cyclePart=scarBolt;assaultGroup.userData.cycleBaseZ=-.21;assaultGroup.userData.cycleTravel=.055;addApertureIronSights(assaultGroup,scarRail.material,{rearZ:.05,frontZ:-.66,sightY:.165,rearMountY:.132,frontMountY:.132,rearRadius:.021,postWidth:.0065,frontEarGap:.019,eyeZ:-.40});registerWeaponHandAnchors(assaultGroup,{right:{position:[.025,-.145,.025],rotation:[-.28,-.03,.05]},left:{position:[-.025,-.045,-.51],rotation:[-.18,.05,.02]},reloadLeft:{parent:assaultMag,position:[-.04,.02,.015],rotation:[-.12,.06,.16]}});assaultGroup.position.set(.30,-.27,-.52);assaultGroup.rotation.set(-.06,-.055,0);assaultGroup.visible=false;

  umpGroup = new THREE.Group();
  const umpMat=new THREE.MeshStandardMaterial({color:0x1f252a,roughness:.42,metalness:.34}),umpAccent=new THREE.MeshStandardMaterial({color:0x3f464b,roughness:.68,metalness:.12}),polyBlack=new THREE.MeshStandardMaterial({color:0x22272c,roughness:.84,metalness:.04});
  const umpReceiver=new THREE.Mesh(new THREE.BoxGeometry(.18,.18,.38),umpMat);umpReceiver.position.set(0,.04,-.12);
  const umpLower=new THREE.Mesh(new THREE.BoxGeometry(.17,.12,.24),polyBlack);umpLower.position.set(0,-.03,-.02);
  const umpHandguard=new THREE.Mesh(new THREE.BoxGeometry(.15,.11,.22),polyBlack);umpHandguard.position.set(0,.00,-.42);
  const umpTop=new THREE.Mesh(new THREE.BoxGeometry(.08,.025,.50),umpAccent);umpTop.position.set(0,.112,-.22);
  const umpBarrel=new THREE.Mesh(new THREE.CylinderGeometry(.020,.020,.24,9),umpMat);umpBarrel.rotation.x=Math.PI/2;umpBarrel.position.set(0,.02,-.63);
  const umpGrip=new THREE.Mesh(new THREE.BoxGeometry(.11,.22,.12),polyBlack);umpGrip.position.set(0,-.17,.03);umpGrip.rotation.x=-.28;
  const umpStockRodL=new THREE.Mesh(new THREE.BoxGeometry(.02,.02,.23),umpAccent);umpStockRodL.position.set(-.035,.045,.12);
  const umpStockRodR=umpStockRodL.clone();umpStockRodR.position.x=.035;
  const umpButt=new THREE.Mesh(new THREE.BoxGeometry(.12,.11,.06),umpAccent);umpButt.position.set(0,.03,.26);
  const umpBolt=new THREE.Mesh(new THREE.BoxGeometry(.016,.032,.10),new THREE.MeshStandardMaterial({color:0x12171b,roughness:.30,metalness:.58}));umpBolt.position.set(.095,.045,-.13);addBakedGripRibs(umpBolt,{count:3});
  umpMag=new THREE.Mesh(new THREE.BoxGeometry(.10,.31,.12),polyBlack);umpMag.position.set(0,-.20,-.12);umpMag.rotation.x=.08;
  umpFlash=new THREE.Mesh(new THREE.SphereGeometry(.072,8,6),new THREE.MeshBasicMaterial({color:0xffd994,transparent:true,opacity:0}));umpFlash.position.set(0,.02,-.77);
  bakeWeaponGeometry({receivers:[umpReceiver,umpLower],handguards:[umpHandguard],grips:[umpGrip],magazines:[umpMag],rails:[umpTop],stocks:[umpButt],tubes:[umpBarrel]});
  umpGroup.add(umpReceiver,umpLower,umpHandguard,umpTop,umpBarrel,umpGrip,umpStockRodL,umpStockRodR,umpButt,umpBolt,umpMag,umpFlash);umpGroup.userData.cyclePart=umpBolt;umpGroup.userData.cycleBaseZ=-.13;umpGroup.userData.cycleTravel=.050;addApertureIronSights(umpGroup,umpAccent,{rearZ:.00,frontZ:-.46,sightY:.155,rearMountY:.126,frontMountY:.126,rearRadius:.020,postWidth:.0063,frontEarGap:.018,eyeZ:-.46});registerWeaponHandAnchors(umpGroup,{right:{position:[.022,-.145,.035],rotation:[-.30,-.03,.05]},left:{position:[-.025,-.045,-.38],rotation:[-.18,.05,.02]},reloadLeft:{parent:umpMag,position:[-.035,.02,.01],rotation:[-.12,.06,.15]}});umpGroup.position.set(.30,-.27,-.54);umpGroup.rotation.set(-.06,-.05,0);umpGroup.visible=false;

  machineGunGroup = new THREE.Group();
  const mgMat=new THREE.MeshStandardMaterial({color:0x252b2e,roughness:.44,metalness:.42}),mgAccent=new THREE.MeshStandardMaterial({color:0x596053,roughness:.76,metalness:.08}),mgDark=new THREE.MeshStandardMaterial({color:0x161b1e,roughness:.52,metalness:.34});
  const mgReceiver=new THREE.Mesh(new THREE.BoxGeometry(.22,.16,.54),mgMat);mgReceiver.position.set(0,.03,-.18);
  const mgTopCover=new THREE.Mesh(new THREE.BoxGeometry(.18,.035,.42),mgDark);mgTopCover.position.set(0,.128,-.20);
  const mgFeedTray=new THREE.Mesh(new THREE.BoxGeometry(.12,.024,.18),mgDark);mgFeedTray.position.set(0,.142,-.17);
  const mgHandguard=new THREE.Mesh(new THREE.BoxGeometry(.18,.12,.42),mgAccent);mgHandguard.position.set(0,.00,-.62);
  const mgBarrel=new THREE.Mesh(new THREE.CylinderGeometry(.023,.023,.72,10),mgMat);mgBarrel.rotation.x=Math.PI/2;mgBarrel.position.set(0,.025,-1.00);
  const mgGasTube=new THREE.Mesh(new THREE.CylinderGeometry(.014,.014,.48,9),mgDark);mgGasTube.rotation.x=Math.PI/2;mgGasTube.position.set(0,.058,-.82);
  const mgStock=new THREE.Mesh(new THREE.BoxGeometry(.18,.19,.38),mgAccent);mgStock.position.set(0,-.02,.34);mgStock.rotation.x=-.08;
  const mgGrip=new THREE.Mesh(new THREE.BoxGeometry(.11,.25,.13),mgDark);mgGrip.position.set(0,-.17,.02);mgGrip.rotation.x=-.25;
  machineGunBox=new THREE.Mesh(new THREE.BoxGeometry(.20,.28,.22),mgAccent);machineGunBox.position.set(-.045,-.19,-.18);machineGunBox.rotation.z=.03;
  machineGunBolt=new THREE.Mesh(new THREE.BoxGeometry(.020,.040,.14),new THREE.MeshStandardMaterial({color:0x0f1417,roughness:.26,metalness:.66}));machineGunBolt.position.set(.122,.052,-.18);addBakedGripRibs(machineGunBolt,{count:3});
  const mgBipodMount=new THREE.Mesh(new THREE.BoxGeometry(.050,.024,.050),mgDark);mgBipodMount.position.set(0,-.020,-.71);
  const mgBipodL=new THREE.Mesh(new THREE.CylinderGeometry(.008,.008,.20,7),mgDark);mgBipodL.position.set(-.050,-.095,-.71);mgBipodL.rotation.z=.18;mgBipodL.rotation.x=.12;
  const mgBipodR=mgBipodL.clone();mgBipodR.position.x=.050;mgBipodR.rotation.z=-.18;
  machineGunFlash=new THREE.Mesh(new THREE.SphereGeometry(.080,8,6),new THREE.MeshBasicMaterial({color:0xffd98d,transparent:true,opacity:0}));machineGunFlash.position.set(0,.025,-1.38);
  bakeWeaponGeometry({receivers:[mgReceiver,mgTopCover],handguards:[mgHandguard],grips:[mgGrip],magazines:[machineGunBox],rails:[mgFeedTray],stocks:[mgStock],tubes:[mgBarrel,mgGasTube]});
  machineGunGroup.add(mgReceiver,mgTopCover,mgFeedTray,mgHandguard,mgBarrel,mgGasTube,mgStock,mgGrip,machineGunBox,machineGunBolt,mgBipodMount,mgBipodL,mgBipodR,machineGunFlash);machineGunGroup.userData.cyclePart=machineGunBolt;machineGunGroup.userData.cycleBaseZ=-.18;machineGunGroup.userData.cycleTravel=.060;addApertureIronSights(machineGunGroup,mgDark,{rearZ:.02,frontZ:-.80,sightY:.171,rearMountY:.136,frontMountY:.106,rearRadius:.022,postWidth:.007,frontEarGap:.021,eyeZ:-.42});registerWeaponHandAnchors(machineGunGroup,{right:{position:[.028,-.155,.025],rotation:[-.28,-.03,.05]},left:{position:[-.035,-.055,-.58],rotation:[-.16,.04,.02]},reloadLeft:{parent:machineGunBox,position:[-.055,.015,.015],rotation:[-.08,.08,.20]}});machineGunGroup.position.set(.30,-.29,-.55);machineGunGroup.rotation.set(-.06,-.05,0);machineGunGroup.visible=false;

  shotgunGroup = new THREE.Group();
  const sgMat=new THREE.MeshStandardMaterial({color:0x2b3135,roughness:.48,metalness:.30});
  const sgWood=new THREE.MeshStandardMaterial({color:0x5a4636,roughness:.82});
  const sgReceiver=new THREE.Mesh(new THREE.BoxGeometry(.17,.14,.36),sgMat);sgReceiver.position.set(0,.02,-.14);
  const sgBarrel=new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,1.00,10),sgMat);sgBarrel.rotation.x=Math.PI/2;sgBarrel.position.set(0,.035,-.72);
  const sgTube=new THREE.Mesh(new THREE.CylinderGeometry(.018,.018,.80,9),sgMat);sgTube.rotation.x=Math.PI/2;sgTube.position.set(0,-.02,-.64);
  const sgStock=new THREE.Mesh(new THREE.BoxGeometry(.12,.16,.42),sgWood);sgStock.position.set(0,-.01,.22);sgStock.rotation.x=-.12;
  const sgGrip=new THREE.Mesh(new THREE.BoxGeometry(.12,.21,.12),sgWood);sgGrip.position.set(0,-.13,.05);sgGrip.rotation.x=-.28;
  shotgunPump=new THREE.Mesh(new THREE.BoxGeometry(.12,.10,.28),sgWood);shotgunPump.position.set(0,-.02,-.42);
  shotgunFlash=new THREE.Mesh(new THREE.SphereGeometry(.09,8,6),new THREE.MeshBasicMaterial({color:0xffd181,transparent:true,opacity:0}));shotgunFlash.position.set(0,.035,-1.24);
  bakeWeaponGeometry({receivers:[sgReceiver],handguards:[shotgunPump],grips:[sgGrip],stocks:[sgStock],tubes:[sgBarrel,sgTube]});
  shotgunGroup.add(sgReceiver,sgBarrel,sgTube,sgStock,sgGrip,shotgunPump,shotgunFlash);addShotgunBeadSight(shotgunGroup,sgMat,{rearZ:.02,frontZ:-1.04,sightY:.116,rearMountY:.090,frontMountY:.060,eyeZ:-.42});registerWeaponHandAnchors(shotgunGroup,{right:{position:[.025,-.125,.055],rotation:[-.26,-.03,.04]},left:{parent:shotgunPump,position:[-.025,-.015,.00],rotation:[-.12,.04,.02]},reloadLeft:{position:[-.035,-.115,-.12],rotation:[-.58,.08,.15]}});shotgunGroup.position.set(.30,-.28,-.50);shotgunGroup.rotation.set(-.06,-.05,0);shotgunGroup.visible=false;

  semiShotgunGroup = new THREE.Group();
  const sasMat=new THREE.MeshStandardMaterial({color:0x252d31,roughness:.43,metalness:.30}),sasAccent=new THREE.MeshStandardMaterial({color:0x454f45,roughness:.78,metalness:.08});
  const sasReceiver=new THREE.Mesh(new THREE.BoxGeometry(.18,.14,.42),sasMat);sasReceiver.position.set(0,.03,-.14);
  const sasHandguard=new THREE.Mesh(new THREE.BoxGeometry(.13,.10,.28),sasAccent);sasHandguard.position.set(0,-.005,-.42);
  const sasBarrel=new THREE.Mesh(new THREE.CylinderGeometry(.024,.024,.82,10),sasMat);sasBarrel.rotation.x=Math.PI/2;sasBarrel.position.set(0,.03,-.72);
  const sasTube=new THREE.Mesh(new THREE.CylinderGeometry(.017,.017,.52,9),sasMat);sasTube.rotation.x=Math.PI/2;sasTube.position.set(0,-.015,-.56);
  const sasStock=new THREE.Mesh(new THREE.BoxGeometry(.13,.16,.34),sasAccent);sasStock.position.set(0,-.01,.20);sasStock.rotation.x=-.12;
  const sasGrip=new THREE.Mesh(new THREE.BoxGeometry(.11,.22,.12),sasMat);sasGrip.position.set(0,-.15,.00);sasGrip.rotation.x=-.25;
  const sasBolt=new THREE.Mesh(new THREE.BoxGeometry(.018,.040,.13),new THREE.MeshStandardMaterial({color:0x12171a,roughness:.28,metalness:.62}));sasBolt.position.set(.095,.045,-.16);addBakedGripRibs(sasBolt,{count:3});
  semiShotgunMag=new THREE.Mesh(new THREE.BoxGeometry(.12,.18,.12),sasMat);semiShotgunMag.position.set(0,-.14,-.10);
  semiShotgunFlash=new THREE.Mesh(new THREE.SphereGeometry(.088,8,6),new THREE.MeshBasicMaterial({color:0xffd181,transparent:true,opacity:0}));semiShotgunFlash.position.set(0,.03,-1.13);
  bakeWeaponGeometry({receivers:[sasReceiver],handguards:[sasHandguard],grips:[sasGrip],magazines:[semiShotgunMag],stocks:[sasStock],tubes:[sasBarrel,sasTube]});
  semiShotgunGroup.add(sasReceiver,sasHandguard,sasBarrel,sasTube,sasStock,sasGrip,sasBolt,semiShotgunMag,semiShotgunFlash);semiShotgunGroup.userData.cyclePart=sasBolt;semiShotgunGroup.userData.cycleBaseZ=-.16;semiShotgunGroup.userData.cycleTravel=.070;addShotgunGhostRingSight(semiShotgunGroup,sasMat,{rearZ:.04,frontZ:-.94,sightY:.118,rearMountY:.090,frontMountY:.060,rearRadius:.017,postWidth:.006,frontEarGap:.017,eyeZ:-.40});registerWeaponHandAnchors(semiShotgunGroup,{right:{position:[.025,-.135,.015],rotation:[-.27,-.03,.04]},left:{position:[-.025,-.040,-.40],rotation:[-.14,.04,.02]},reloadLeft:{parent:semiShotgunMag,position:[-.035,.015,.01],rotation:[-.10,.07,.15]}});semiShotgunGroup.position.set(.30,-.28,-.50);semiShotgunGroup.rotation.set(-.06,-.05,0);semiShotgunGroup.visible=false;

  sniperGroup = new THREE.Group();
  const rifleMat = new THREE.MeshStandardMaterial({color:0x2f3438,roughness:.42,metalness:.40});
  const stockMat = new THREE.MeshStandardMaterial({color:0x5a5e4a,roughness:.84,metalness:.06});
  const lensMat = new THREE.MeshStandardMaterial({color:0xcfe6ef,roughness:.06,metalness:.08,transparent:true,opacity:.18,emissive:0x10252e,emissiveIntensity:.08,depthWrite:false,side:THREE.DoubleSide});
  const rearLensMat = new THREE.MeshStandardMaterial({color:0x17242b,roughness:.18,metalness:.12,transparent:true,opacity:.58,emissive:0x081218,emissiveIntensity:.10,depthWrite:true,side:THREE.DoubleSide});
  const dragReceiver = new THREE.Mesh(new THREE.BoxGeometry(.16,.12,.46),rifleMat);dragReceiver.position.set(0,.04,-.18);
  const dragHandguard = new THREE.Mesh(new THREE.BoxGeometry(.13,.10,.36),stockMat);dragHandguard.position.set(0,-.005,-.52);
  const rifleBarrel = new THREE.Mesh(new THREE.CylinderGeometry(.020,.020,.84,10),rifleMat);rifleBarrel.rotation.x=Math.PI/2;rifleBarrel.position.set(0,.025,-.82);
  const stock = new THREE.Mesh(new THREE.BoxGeometry(.13,.17,.42),stockMat);stock.position.set(0,-.01,.23);stock.rotation.x=-.12;
  const stockComb = new THREE.Mesh(new THREE.BoxGeometry(.11,.06,.22),stockMat);stockComb.position.set(0,.06,.20);stockComb.rotation.x=-.12;
  const sniperMag=new THREE.Mesh(new THREE.BoxGeometry(.095,.16,.12),rifleMat);sniperMag.position.set(0,-.075,-.16);sniperMag.rotation.x=.10;
  const scope = new THREE.Mesh(new THREE.CylinderGeometry(.048,.048,.42,18,1,true),rifleMat);scope.rotation.x=Math.PI/2;scope.position.set(0,.14,-.16);
  const scopeInner=new THREE.Mesh(new THREE.CylinderGeometry(.039,.039,.39,18,1,true),new THREE.MeshStandardMaterial({color:0x090c10,roughness:.96,metalness:.02,side:THREE.BackSide}));scopeInner.rotation.x=Math.PI/2;scopeInner.position.copy(scope.position);
  const scopeFrontRing=new THREE.Mesh(new THREE.TorusGeometry(.043,.0055,8,20),rifleMat);scopeFrontRing.position.set(0,.14,-.37);
  const scopeRearRing=new THREE.Mesh(new THREE.TorusGeometry(.043,.0055,8,20),rifleMat);scopeRearRing.position.set(0,.14,.05);
  const scopeFrontLens = new THREE.Mesh(new THREE.CircleGeometry(.0405,24),lensMat);scopeFrontLens.position.set(0,.14,-.366);
  const scopeRearLens = new THREE.Mesh(new THREE.CircleGeometry(.0405,28),rearLensMat);scopeRearLens.position.set(0,.14,.046);
  // Low rail feet stay entirely below the optical bore. The old .055-high
  // blocks rose into the line of sight and were the rectangular obstruction
  // visible through both the rear and front of the scope.
  const scopeMountRear=new THREE.Mesh(new THREE.BoxGeometry(.065,.014,.032),rifleMat);scopeMountRear.position.set(0,.085,-.02);
  const scopeMountFront=new THREE.Mesh(new THREE.BoxGeometry(.065,.014,.032),rifleMat);scopeMountFront.position.set(0,.085,-.27);
  const scopeShade=new THREE.Mesh(new THREE.CylinderGeometry(.051,.051,.035,18,1,true),rifleMat);scopeShade.rotation.x=Math.PI/2;scopeShade.position.set(0,.14,-.39);
  sniperBolt=new THREE.Mesh(new THREE.BoxGeometry(.050,.050,.16),rifleMat);sniperBolt.position.set(.10,.065,-.06);addBakedGripRibs(sniperBolt,{count:3});
  sniperFlash = new THREE.Mesh(new THREE.SphereGeometry(.085,8,6),new THREE.MeshBasicMaterial({color:0xffe6a6,transparent:true,opacity:0}));sniperFlash.position.set(0,.025,-1.24);
  bakeWeaponGeometry({receivers:[dragReceiver],handguards:[dragHandguard],magazines:[sniperMag],stocks:[stock],tubes:[rifleBarrel,scope]});
  sniperGroup.add(dragReceiver,dragHandguard,rifleBarrel,stock,stockComb,sniperMag,scopeMountRear,scopeMountFront,scope,scopeInner,scopeShade,scopeFrontRing,scopeRearRing,scopeFrontLens,scopeRearLens,sniperBolt,sniperFlash);sniperGroup.userData.cyclePart=sniperBolt;sniperGroup.userData.cycleBaseZ=-.06;sniperGroup.userData.cycleTravel=.085;registerWeaponHandAnchors(sniperGroup,{right:{position:[.030,-.120,.035],rotation:[-.25,-.03,.05]},left:{position:[-.030,-.045,-.45],rotation:[-.14,.04,.02]},reloadLeft:{position:[-.035,-.125,-.08],rotation:[-.16,.08,.14]},reloadRight:{parent:sniperBolt,position:[.025,.015,.00],rotation:[-.44,-.12,.25]}});sniperGroup.position.set(.28,-.28,-.48);sniperGroup.rotation.set(-.055,-.05,0);sniperGroup.visible=false;

  grenadeLauncherGroup=new THREE.Group();
  const glMat=new THREE.MeshStandardMaterial({color:0x273126,roughness:.58,metalness:.26}),glTube=new THREE.Mesh(new THREE.CylinderGeometry(.075,.075,.73,12),glMat);glTube.rotation.x=Math.PI/2;glTube.position.set(0,.01,-.40);
  const glGrip=new THREE.Mesh(new THREE.BoxGeometry(.15,.28,.18),gripMat);glGrip.position.set(0,-.20,-.10);glGrip.rotation.x=-.12;
  grenadeLauncherFlash=new THREE.Mesh(new THREE.SphereGeometry(.105,8,6),new THREE.MeshBasicMaterial({color:0xffc66f,transparent:true,opacity:0}));grenadeLauncherFlash.position.set(0,.01,-.80);
  bakeWeaponGeometry({grips:[glGrip],tubes:[glTube]});
  grenadeLauncherGroup.add(glTube,glGrip,grenadeLauncherFlash);registerWeaponHandAnchors(grenadeLauncherGroup,{right:{position:[.025,-.145,-.08],rotation:[-.25,-.03,.05]},left:{position:[-.030,-.035,-.45],rotation:[-.14,.04,.02]},reloadLeft:{position:[-.035,-.10,-.31],rotation:[-.48,.10,.16]}});grenadeLauncherGroup.position.set(.30,-.28,-.48);grenadeLauncherGroup.rotation.set(-.06+GRENADE_LAUNCH_PITCH,-.05,0);grenadeLauncherGroup.visible=false;

  rpgGroup=new THREE.Group();
  const rpgMat=new THREE.MeshStandardMaterial({color:0x4a5443,roughness:.64,metalness:.18}),rpgTube=new THREE.Mesh(new THREE.CylinderGeometry(.068,.068,.95,12),rpgMat);rpgTube.rotation.x=Math.PI/2;rpgTube.position.set(0,.02,-.30);
  const rpgCone=new THREE.Mesh(new THREE.ConeGeometry(.09,.20,10),new THREE.MeshStandardMaterial({color:0x30372f,roughness:.7}));rpgCone.rotation.x=-Math.PI/2;rpgCone.position.set(0,.02,-.88);
  rpgFlash=new THREE.Mesh(new THREE.SphereGeometry(.12,8,6),new THREE.MeshBasicMaterial({color:0xffc05e,transparent:true,opacity:0}));rpgFlash.position.set(0,.02,-1.00);
  bakeWeaponGeometry({tubes:[rpgTube]});
  rpgGroup.add(rpgTube,rpgCone,rpgFlash);addApertureIronSights(rpgGroup,rpgMat,{rearZ:.07,frontZ:-.70,sightY:.145,rearMountY:.092,frontMountY:.092,eyeZ:-.42,rearRadius:.018,rearTube:.0032,postWidth:.006,frontEarGap:.016});registerWeaponHandAnchors(rpgGroup,{right:{position:[.030,-.080,-.04],rotation:[-.18,-.04,.04]},left:{position:[-.030,-.020,-.52],rotation:[-.10,.04,.02]},reloadLeft:{position:[-.040,-.08,-.34],rotation:[-.34,.08,.14]}});rpgGroup.position.set(.34,-.16,-.46);rpgGroup.rotation.set(-.025,-.07,.015);rpgGroup.visible=false;
  setupWeaponAttachmentVisuals(akimboLeftGroup,'akimbo1887',{flash:akimboLeftFlash,barrelMesh:akimboLeftBarrel,stockBaseParts:[akimboLeftStock],suppressor:{radius:.028,length:.20,overlap:.018},laser:{x:.050,z:-.46,y:-.060},lightweightStock:{z:.31,y:-.01,width:.115},fastMag:{z:-.10,y:-.17,width:.09}});
  setupWeaponAttachmentVisuals(akimboRightGroup,'akimbo1887',{flash:akimboRightFlash,barrelMesh:akimboRightBarrel,stockBaseParts:[akimboRightStock],suppressor:{radius:.028,length:.20,overlap:.018},laser:{x:.050,z:-.46,y:-.060},lightweightStock:{z:.31,y:-.01,width:.115},fastMag:{z:-.10,y:-.17,width:.09}});
  setupWeaponAttachmentVisuals(pistolGroup,'pistol',{flash:pistolFlash,mag:pistolMag,redDot:{sightY:.140,z:-.10,mountY:.110,eyeZ:-.46},suppressor:{radius:.030,length:.20,overlap:.020},compensator:{radius:.030,length:.09,overlap:.014},laser:{x:.045,z:-.25,y:-.065,scale:.78},fastMag:{width:.095,depth:.115,y:.07}});
  setupWeaponAttachmentVisuals(assaultGroup,'assault',{flash:assaultFlash,mag:assaultMag,barrelMesh:arBarrel,stockBaseParts:[scarStockStem,scarStock],redDot:{sightY:.165,z:-.16,mountY:.130,eyeZ:-.39},holoSight:{sightY:.180,z:-.15,mountY:.130,eyeZ:-.39},combatOptic:{sightY:.192,z:-.11,mountY:.130,eyeZ:-.40,length:.20},thermalScope4x:{sightY:.192,z:-.11,mountY:.130,eyeZ:-.40,length:.20,radius:.039},thermalScope6x:{sightY:.198,z:-.10,mountY:.130,eyeZ:-.40,length:.22,radius:.041,long:true},suppressor:{radius:.032,length:.27,overlap:.022},compensator:{radius:.030,length:.11,overlap:.016},verticalGrip:{z:-.55,y:-.105},angledGrip:{z:-.54,y:-.105},laser:{x:.065,z:-.55,y:-.105},lightweightStock:{z:.43,y:-.01,width:.145},fullStock:{z:.41,y:-.01,width:.155},compactStock:{z:.12,y:.01,width:.105},fastMag:{width:.115,depth:.165,y:.08}});
  setupWeaponAttachmentVisuals(umpGroup,'ump',{flash:umpFlash,mag:umpMag,barrelMesh:umpBarrel,stockBaseParts:[umpStockRodL,umpStockRodR,umpButt],redDot:{sightY:.155,z:-.15,mountY:.124,eyeZ:-.40},holoSight:{sightY:.171,z:-.14,mountY:.124,eyeZ:-.40},thermalScope4x:{sightY:.174,z:-.11,mountY:.124,eyeZ:-.40,length:.19,radius:.038},thermalScope6x:{sightY:.180,z:-.10,mountY:.124,eyeZ:-.40,length:.21,radius:.040,long:true},suppressor:{radius:.032,length:.22,overlap:.020},compensator:{radius:.030,length:.09,overlap:.015},verticalGrip:{z:-.40,y:-.105},angledGrip:{z:-.39,y:-.105},laser:{x:.060,z:-.39,y:-.100},lightweightStock:{z:.27,y:.03,width:.125},fullStock:{z:.27,y:.015,width:.135},compactStock:{z:.12,y:.035,width:.095},fastMag:{width:.105,depth:.125,y:.09}});
  setupWeaponAttachmentVisuals(machineGunGroup,'machineGun',{flash:machineGunFlash,mag:machineGunBox,barrelMesh:mgBarrel,stockBaseParts:[mgStock],bipodBaseParts:[mgBipodMount,mgBipodL,mgBipodR],redDot:{sightY:.171,z:-.20,mountY:.150,eyeZ:-.405},holoSight:{sightY:.190,z:-.19,mountY:.150,eyeZ:-.405},combatOptic:{sightY:.202,z:-.14,mountY:.150,eyeZ:-.415,length:.21},thermalScope4x:{sightY:.202,z:-.14,mountY:.150,eyeZ:-.415,length:.21,radius:.040},thermalScope6x:{sightY:.208,z:-.13,mountY:.150,eyeZ:-.415,length:.23,radius:.042,long:true},suppressor:{radius:.035,length:.30,overlap:.025},compensator:{radius:.033,length:.12,overlap:.018},verticalGrip:{z:-.61,y:-.12},angledGrip:{z:-.60,y:-.12},laser:{x:.070,z:-.60,y:-.115},lightweightStock:{z:.46,y:-.02,width:.175},fullStock:{z:.45,y:-.025,width:.185},fastMag:{width:.19,depth:.22,y:.08}});
  setupWeaponAttachmentVisuals(shotgunGroup,'shotgun',{flash:shotgunFlash,barrelMesh:sgBarrel,redDot:{sightY:.116,z:-.12,mountY:.090,eyeZ:-.42},thermalScope4x:{sightY:.128,z:-.10,mountY:.090,eyeZ:-.42,length:.18,radius:.035},thermalScope6x:{sightY:.134,z:-.09,mountY:.090,eyeZ:-.42,length:.20,radius:.037,long:true},suppressor:{radius:.029,length:.22,overlap:.018},shotgunChoke:{radius:.029,length:.10,overlap:.018},laser:{x:.055,z:-.48,y:-.055}});
  setupWeaponAttachmentVisuals(semiShotgunGroup,'semiShotgun',{flash:semiShotgunFlash,mag:semiShotgunMag,barrelMesh:sasBarrel,redDot:{sightY:.118,z:-.14,mountY:.095,eyeZ:-.39},holoSight:{sightY:.142,z:-.13,mountY:.095,eyeZ:-.39},combatOptic:{sightY:.151,z:-.08,mountY:.095,eyeZ:-.40,length:.19},shotgunChoke:{radius:.028,length:.10,overlap:.018},laser:{x:.055,z:-.43,y:-.075},fastMag:{width:.125,depth:.125,y:.05}});
  setupWeaponAttachmentVisuals(sniperGroup,'sniper',{flash:sniperFlash,mag:sniperMag,barrelMesh:rifleBarrel,precisionScope6x:{z:-.16,y:.14,radius:.052,kind:'precision'},longRangeScope8x:{z:-.16,y:.14,radius:.052,kind:'long'},thermalScope4x:{z:-.16,y:.14,radius:.052,kind:'thermal'},thermalScope6x:{z:-.16,y:.14,radius:.052,kind:'thermal-long'},laser:{x:.050,z:-.50,y:-.070},suppressor:{radius:.032,length:.30,overlap:.022},fastMag:{width:.10,depth:.125,y:.04}});
  setupWeaponAttachmentVisuals(rpgGroup,'rpg',{flash:rpgFlash,thermalScope4x:{sightY:.180,z:-.12,mountY:.092,eyeZ:-.42,length:.19,radius:.039},thermalScope6x:{sightY:.188,z:-.11,mountY:.092,eyeZ:-.42,length:.21,radius:.041,long:true},laser:{x:.065,z:-.38,y:-.060,scale:1.05}});
  syncLocalAttachmentVisuals();
  camera.add(pistolGroup,akimboLeftGroup,akimboRightGroup,assaultGroup,umpGroup,machineGunGroup,shotgunGroup,semiShotgunGroup,sniperGroup,grenadeLauncherGroup,rpgGroup);initFirstPersonHandRig();
  // First-person traversal view model. Keep this geometry entirely in camera
  // space and well in front of the near plane. The old capsule arms extended
  // back toward the eye and could fill the screen during mantle/vault motion,
  // creating the appearance that the camera had entered the player's body.
  mantleHands=new THREE.Group();
  const mantleGloveMat=new THREE.MeshStandardMaterial({color:0x171c20,roughness:.92,depthTest:false,depthWrite:false});
  const mantleSleeveMat=new THREE.MeshStandardMaterial({color:0x344047,roughness:.96,depthTest:false,depthWrite:false});
  for(const side of [-1,1]){
    const limb=new THREE.Group();
    const forearm=new THREE.Mesh(new THREE.CylinderGeometry(.038,.050,.30,8),mantleSleeveMat);
    forearm.rotation.x=Math.PI/2;forearm.position.set(0,-.035,.10);forearm.renderOrder=1000;
    const hand=new THREE.Mesh(new THREE.SphereGeometry(.050,10,7),mantleGloveMat);
    hand.scale.set(1.12,.66,1.24);hand.position.set(0,.025,-.105);hand.renderOrder=1001;
    limb.position.set(side*.27,-.34,-.82);limb.rotation.z=side*.06;limb.userData.side=side;limb.userData.forearm=forearm;limb.userData.hand=hand;
    limb.add(forearm,hand);mantleHands.add(limb);
  }
  mantleHands.visible=false;mantleHands.renderOrder=1000;camera.add(mantleHands);scene.add(camera);

  animate();
}



const WORLD_TEXTURE_DEFS=Object.freeze({
  concrete:Object.freeze({file:'concrete.png',repeat:[2.4,2.4]}),
  plaster:Object.freeze({file:'plaster.png',repeat:[2.8,2.8]}),
  brick:Object.freeze({file:'brick.png',repeat:[2.0,2.0]}),
  stone:Object.freeze({file:'stone.png',repeat:[2.2,2.2]}),
  paintedMetal:Object.freeze({file:'painted_metal.png',repeat:[3.0,3.0]}),
  corrugatedMetal:Object.freeze({file:'corrugated_metal.png',repeat:[4.0,2.0]}),
  rustedMetal:Object.freeze({file:'rusted_metal.png',repeat:[3.0,3.0]}),
  charredMetal:Object.freeze({file:'charred_metal.png',repeat:[3.0,3.0]}),
  wood:Object.freeze({file:'wood.png',repeat:[2.0,3.0]}),
  sandbag:Object.freeze({file:'sandbag_fabric.png',repeat:[4.0,4.0]}),
  bark:Object.freeze({file:'bark.png',repeat:[2.0,3.0]}),
  foliage:Object.freeze({file:'foliage.png',repeat:[3.0,3.0]}),
  rock:Object.freeze({file:'rock.png',repeat:[2.0,2.0]}),
  glass:Object.freeze({file:'glass_grime.png',repeat:[2.0,2.0]}),
});
const WORLD_TEXTURE_ASSET_REV='textures-20260826-1';
const worldTextureCache=new Map(),worldThermalTextureCache=new Map();
let worldTextureLoader=null;
function configureWorldTexture(tex,def){tex.colorSpace=THREE.SRGBColorSpace;tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(def.repeat[0],def.repeat[1]);tex.minFilter=THREE.LinearMipmapLinearFilter;tex.magFilter=THREE.LinearFilter;tex.anisotropy=Math.min(isTouch?1:8,renderer?.capabilities?.getMaxAnisotropy?.()||1);tex.userData.preserveWorldTexture=true;return tex;}
function getWorldTexture(name){
  if(!THREE||!name)return null;
  if(worldTextureCache.has(name))return worldTextureCache.get(name);
  const def=WORLD_TEXTURE_DEFS[name];if(!def)return null;
  worldTextureLoader ||= new THREE.TextureLoader();
  const tex=configureWorldTexture(worldTextureLoader.load(`textures/${def.file}?rev=${WORLD_TEXTURE_ASSET_REV}`,()=>{editorThumbnailCache.clear();builderSession?.editor.syncUI();}),def);
  tex.userData.worldTextureName=name;worldTextureCache.set(name,tex);return tex;
}
function getWorldThermalTexture(name){
  if(!THREE||!name)return null;if(worldThermalTextureCache.has(name))return worldThermalTextureCache.get(name);const def=WORLD_TEXTURE_DEFS[name];if(!def)return null;worldTextureLoader ||= new THREE.TextureLoader();const tex=configureWorldTexture(worldTextureLoader.load(`textures/thermal/${def.file}?rev=${WORLD_TEXTURE_ASSET_REV}`),def);tex.userData.worldThermalTexture=true;worldThermalTextureCache.set(name,tex);return tex;
}
function worldMat(color,texture,roughness=.9,metalness=0,extra={}){
  return new THREE.MeshStandardMaterial({color,map:getWorldTexture(texture),roughness,metalness,...extra});
}
function buildingWallTexture(style){
  return ({plaster:'plaster',brick:'brick',stone:'stone',office:'concrete',industrial:'corrugatedMetal',warehouse:'corrugatedMetal',tower:'stone',utility:'plaster'})[style]||'concrete';
}

let modSkyRoot=null;
function applyWorldEnvironment(){
  if(!scene||!THREE)return;
  restoreSolarEnvironment();
  if(modSkyRoot){scene.remove(modSkyRoot);disposeObject3D(modSkyRoot);modSkyRoot=null;}
  const moon=gameModSpec(worldSettings.mod).environment==='moon',depot=currentMapId==='depot',yard=currentMapId==='yard',rig=currentMapId==='rig',custom=currentMapId==='custom-map'&&authoredEnvironment&&Object.keys(authoredEnvironment).length;
  let sky=moon?0x02040b:rig?0xb9a27f:yard?0x7e878d:depot?0x89979d:0x9acde6,fogNear=rig?72:yard?58:depot?90:95,fogFar=rig?205:yard?145:depot?260:285,hemiIntensity=moon?1.65:2.2,sunIntensity=moon?2.4:2.15,hemiColor=moon?0xb4caff:0xdaf4ff,groundColor=moon?0x444b65:0x52604c,sunColor=moon?0xd3e2ff:0xffffff;
  if(custom&&!moon){const e=authoredEnvironment,night=Number(e.sunElevation)<0,storm=e.weather==='storm',overcast=e.weather==='overcast'||Number(e.cloudAmount)>.7;if(night)sky=0x0b1427;else if(storm)sky=0x3d464c;else if(overcast)sky=0x76848a;else if(Number(e.sunElevation)<20)sky=0xca9167;else sky=0x7eb0cc;const fog=Math.max(0,Math.min(.85,Number(e.fogAmount)||0));fogFar=Math.max(70,285-fog*235);fogNear=Math.max(18,fogFar*(.28+fog*.10));hemiIntensity=Math.max(.35,Math.min(2.7,(Number(e.ambient)||.72)*3));sunIntensity=night?.55:Math.max(.65,2.25*(.55+Math.max(0,Number(e.sunElevation)||0)/120));hemiColor=night?0x889bc2:overcast?0xd5e1e4:0xdaf4ff;groundColor=night?0x283044:0x52604c;sunColor=night?0xc9d8eb:Number(e.sunElevation)<20?0xffbe73:0xffedbe;if(worldSunLight){const az=(Number(e.sunAzimuth)||0)*Math.PI/180,el=(Number(e.sunElevation)||0)*Math.PI/180,r=55;worldSunLight.position.set(Math.cos(el)*Math.cos(az)*r,Math.sin(el)*r,Math.cos(el)*Math.sin(az)*r);}}
  scene.background=new THREE.Color(sky);scene.fog=moon?null:new THREE.Fog(sky,fogNear,fogFar);
  if(worldHemiLight){worldHemiLight.color.set(hemiColor);worldHemiLight.groundColor.set(groundColor);worldHemiLight.intensity=hemiIntensity;thermalOpticLightStates.delete(worldHemiLight);}
  if(worldSunLight){worldSunLight.color.set(sunColor);worldSunLight.intensity=sunIntensity;thermalOpticLightStates.delete(worldSunLight);}
  thermalOpticBackgroundState=null;thermalOpticFogState=null;if(moon){modSkyRoot=createMoonSky(THREE);scene.add(modSkyRoot);}
}
function buildWorldVisuals(){
  if(!scene||!THREE)return;
  mapObstacles.length=0;
  worldRoot=new THREE.Group();worldRoot.name=`world:${currentMapId}`;scene.add(worldRoot);
  const depot=currentMapId==='depot',yard=currentMapId==='yard',rig=currentMapId==='rig';
  applyWorldEnvironment();
  addTerrain();
  addRoadsBatch();
  const wallMat=worldMat(rig?0x6d5d49:(yard?0x454c50:(depot?0x626a6e:0xd8d4cc)),yard?'paintedMetal':(rig?'stone':'concrete'),.9,yard?.08:0);addBoundaryWallsBatch(wallMat);
  const blockMat=worldMat(rig?0x756a59:(yard?0x6f777a:(depot?0x697983:0xb8c0c5)),'concrete',.88,0);
  const pyramidMat=worldMat(rig?0x9b8058:(depot?0x88775f:0xc8a86b),'stone',.94,0);addStaticBoxesBatch(blockMat);addPyramidsBatch(pyramidMat);
  const trunkMat=worldMat(0x60452f,'bark',1,0),leafMat=worldMat(depot?0x405b3f:0x315f37,'foliage',1,0),bushMat=worldMat(depot?0x53664b:0x3f7441,'foliage',1,0),rockMat=worldMat(rig?0x8b7459:(depot?0x777b78:0x6b706f),'rock',.98,0);
  addNaturalObstaclesBatch(trunkMat,leafMat,bushMat,rockMat);addBuildingsBatch();addLaddersBatch();
  const markerMat=worldMat(depot?0x303a40:0x49606f,'paintedMetal',.78,.15);if(!yard&&!rig)addMarkersBatch(markerMat);
  minimapStaticCache=null;
}
function rebuildWorldVisuals(){
  if(worldRoot){try{scene.remove(worldRoot);}catch{}disposeObject3D(worldRoot);worldRoot=null;}
  buildWorldVisuals();
  if(collisionOverlayMode!=='off')window.breachCollisionDebug(collisionOverlayMode);
  for(const r of remotes.values()){try{scene.remove(r.group);}catch{}disposeObject3D(r.group);}remotes.clear();
  clearBullets();clearBulletImpactFx();clearThrowables();clearSmokeClouds();clearTacticalFx();clearRocketTrailPuffs();hideTrajectory();
}

function addTerrain(){
  const size=TERRAIN_SIZE,segments=TERRAIN_SEGMENTS,geo=new THREE.PlaneGeometry(size,size,segments,segments),pos=geo.attributes.position,colors=[];
  const depot=currentMapId==='depot',yard=currentMapId==='yard',rig=currentMapId==='rig',customMaterials=currentMapId==='custom-map'&&worldGeometry.AUTHORED_MATERIAL_SURFACE,wet=Math.max(0,Math.min(1,Number(authoredEnvironment?.wetness)||0)),low=new THREE.Color(rig?0x8f7957:(yard?0x686c6d:(depot?0x62655f:0x587552))),mid=new THREE.Color(rig?0xa58d66:(yard?0x747878:(depot?0x777972:0x78915f))),high=new THREE.Color(rig?0xb59a70:(yard?0x7d8080:(depot?0x756d60:0x807a65))),peak=new THREE.Color(rig?0xc0a77c:(yard?0x858888:(depot?0x8b8375:0x9a9586))),materialPalette=[0x6c7b62,0x557947,0x80664a,0xb79b6b,0x777a76,0x858b8c,0x5f4c3d,0x696a65,0xd9e1e2];
  for(let i=0;i<pos.count;i++){
    const x=pos.getX(i),z=-pos.getY(i),h=terrainHeight(x,z);pos.setZ(i,h);let color;
    if(customMaterials){const code=Math.max(0,Math.min(8,Math.round(groundMaterialCode(x,z)||0)));if(code){color=new THREE.Color(materialPalette[code]);const noise=.94+((Math.sin(x*1.73+z*2.91)+Math.cos(x*.57-z*1.31))*.025);color.multiplyScalar(noise*(1-wet*.18));}else{color=new THREE.Color();if(h<1.5)color.lerpColors(low,mid,THREE.MathUtils.clamp((h+2.4)/3.9,0,1));else if(h<7)color.lerpColors(mid,high,(h-1.5)/5.5);else color.lerpColors(high,peak,THREE.MathUtils.clamp((h-7)/6.8,0,1));}}else{color=new THREE.Color();if(h<1.5)color.lerpColors(low,mid,THREE.MathUtils.clamp((h+2.4)/3.9,0,1));else if(h<7)color.lerpColors(mid,high,(h-1.5)/5.5);else color.lerpColors(high,peak,THREE.MathUtils.clamp((h-7)/6.8,0,1));}
    colors.push(color.r,color.g,color.b);
  }
  geo.setAttribute('color',new THREE.Float32BufferAttribute(colors,3));geo.computeVertexNormals();const terrainTexture=makeTerrainTexture(),mat=new THREE.MeshStandardMaterial({vertexColors:true,map:terrainTexture,roughness:1,metalness:0}),ground=new THREE.Mesh(geo,mat);ground.rotation.x=-Math.PI/2;ground.receiveShadow=!isTouch;worldRoot.add(ground);
}
function makeTerrainTexture(){
  const size=256,c=document.createElement('canvas');c.width=c.height=size;const x=c.getContext('2d');
  const image=x.createImageData(size,size),depot=currentMapId==='depot',yard=currentMapId==='yard',rig=currentMapId==='rig',customMaterials=currentMapId==='custom-map'&&worldGeometry.AUTHORED_MATERIAL_SURFACE;let seed=rig?0x9f5e2b:(yard?0x413c37:(depot?0x6d4f23:0x51f15e));
  const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  for(let py=0;py<size;py++)for(let px=0;px<size;px++){
    const i=(py*size+px)*4,n=rand(),wave=Math.sin(px*.19+Math.sin(py*.07))*5+Math.cos(py*.15)*4;
    if(customMaterials){const v=Math.max(202,Math.min(246,226+(n-.5)*20+wave*.18));image.data[i]=image.data[i+1]=image.data[i+2]=v;image.data[i+3]=255;}
    else if(rig){const v=Math.max(142,Math.min(205,176+(n-.5)*34+wave*.42));image.data[i]=v;image.data[i+1]=Math.round(v*.86);image.data[i+2]=Math.round(v*.64);image.data[i+3]=255;}
    else if(yard){const v=Math.max(118,Math.min(174,145+(n-.5)*24+wave*.35));image.data[i]=v;image.data[i+1]=v+2;image.data[i+2]=v+3;image.data[i+3]=255;}
    else{const v=Math.max(depot?128:168,Math.min(depot?202:238,(depot?168:211)+(n-.5)*(depot?36:30)+wave));image.data[i]=Math.round(v*(depot?.94:.96));image.data[i+1]=Math.round(v*(depot?.93:1));image.data[i+2]=Math.round(v*(depot?.89:.88));image.data[i+3]=255;}
  }
  x.putImageData(image,0,0);
  if(rig){x.globalAlpha=.18;x.strokeStyle='#8a7251';x.lineWidth=1;for(let i=0;i<28;i++){const y=(i*29+13)%size;x.beginPath();x.moveTo(0,y);x.bezierCurveTo(80,y+3,170,y-4,size,y+2);x.stroke();}x.globalAlpha=.20;x.fillStyle='#715d43';for(let i=0;i<520;i++){const px=rand()*size,py=rand()*size,r=.3+rand()*1.0;x.fillRect(px,py,r,r);}}
  else if(yard){x.globalAlpha=.22;x.strokeStyle='#575d60';x.lineWidth=1;for(let i=0;i<18;i++){const y=(i*31+9)%size;x.beginPath();x.moveTo(0,y);x.lineTo(size,y+((i%3)-1)*2);x.stroke();}x.globalAlpha=.18;x.fillStyle='#4e5355';for(let i=0;i<420;i++){const px=rand()*size,py=rand()*size,r=.35+rand()*1.2;x.fillRect(px,py,r,r);}}
  else{x.globalAlpha=depot?.28:.22;x.strokeStyle=depot?'#575d5b':'#758064';x.lineWidth=1;for(let i=0;i<34;i++){const y=(i*37)%size;x.beginPath();x.moveTo(0,y);x.bezierCurveTo(70,y+10,150,y-12,size,y+4);x.stroke();}x.globalAlpha=.16;x.fillStyle=depot?'#777064':'#5d674d';for(let i=0;i<520;i++){const px=rand()*size,py=rand()*size,r=.4+rand()*1.5;x.beginPath();x.arc(px,py,r,0,Math.PI*2);x.fill();}}
  const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.wrapS=tex.wrapT=THREE.RepeatWrapping;tex.repeat.set(yard?34:(rig?30:28),yard?34:(rig?30:28));tex.anisotropy=Math.min(8,renderer.capabilities.getMaxAnisotropy?.()||1);tex.userData.preserveWorldTexture=true;
  const tc=document.createElement('canvas');tc.width=tc.height=size;const tx=tc.getContext('2d');tx.drawImage(c,0,0);const td=tx.getImageData(0,0,size,size);for(let i=0;i<td.data.length;i+=4){const g=Math.round(td.data[i]*.2126+td.data[i+1]*.7152+td.data[i+2]*.0722);td.data[i]=td.data[i+1]=td.data[i+2]=g;}tx.putImageData(td,0,0);const thermalTex=new THREE.CanvasTexture(tc);thermalTex.colorSpace=THREE.SRGBColorSpace;thermalTex.wrapS=thermalTex.wrapT=THREE.RepeatWrapping;thermalTex.repeat.copy(tex.repeat);thermalTex.anisotropy=tex.anisotropy;thermalTex.userData.preserveWorldTexture=true;thermalTex.userData.worldThermalTexture=true;tex.userData.thermalTexture=thermalTex;return tex;
}
function addStaticInstancedMesh(geometry,material,transforms,{castShadow=true,receiveShadow=true}={}){
  if(!transforms.length)return null;
  const mesh=new THREE.InstancedMesh(geometry,material,transforms.length),dummy=new THREE.Object3D();
  for(let i=0;i<transforms.length;i++){
    const t=transforms[i];dummy.position.set(t.x||0,t.y||0,t.z||0);dummy.rotation.set(t.rx||0,t.ry||0,t.rz||0);dummy.scale.set(t.sx??1,t.sy??1,t.sz??1);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);
  }
  mesh.instanceMatrix.setUsage(THREE.StaticDrawUsage);mesh.instanceMatrix.needsUpdate=true;mesh.castShadow=castShadow&&!isTouch;mesh.receiveShadow=receiveShadow&&!isTouch;mesh.computeBoundingBox?.();mesh.computeBoundingSphere?.();worldRoot.add(mesh);return mesh;
}
function appendRoadSurface(data,road,{width=road.d,offset=.018,patches=null}={}){
 const terrain={TERRAIN_SIZE,TERRAIN_SEGMENTS,terrainHeight};
 if(patches){const angle=(road.rot||0)*Math.PI/180;for(const q of patches){const x=q.x||0,z=q.z||0,r={...road,x:road.x+x*Math.cos(angle)-z*Math.sin(angle),z:road.z+x*Math.sin(angle)+z*Math.cos(angle),w:q.w,d:q.d};let polygons=[roadPolygon(r)];if(road.kind!=='crosswalk')for(const other of ROADS){if(other===road||road.sourceRoad!=null&&other.sourceRoad===road.sourceRoad)continue;if(Math.hypot(other.x-r.x,other.z-r.z)>(Math.hypot(other.w,other.d)+Math.hypot(r.w,r.d))/2)continue;polygons=polygons.flatMap(p=>subtractRoadPolygon(p,roadPolygon(other)));if(!polygons.length)break;}for(const polygon of polygons)appendTerrainRoad(data,polygon,terrain,offset);}return;}
 appendTerrainRoad(data,roadPolygon(road,width),terrain,offset);
 // Cap authored paths at both ends, and bridge every bend on the same terrain surface.
 if(road.pathIndex!=null){
   const a=(road.rot||0)*Math.PI/180,dx=Math.cos(a)*road.w/2,dz=Math.sin(a)*road.w/2;
   const final=!ROADS.some(other=>other.sourceRoad===road.sourceRoad&&other.pathIndex>road.pathIndex);
   const centers=[{x:road.x-dx,z:road.z-dz},...(final?[{x:road.x+dx,z:road.z+dz}]:[])];
   for(const center of centers){const poly=Array.from({length:20},(_,i)=>({x:center.x+Math.cos(i*Math.PI/10)*width/2,z:center.z+Math.sin(i*Math.PI/10)*width/2}));appendTerrainRoad(data,poly,terrain,offset);}
 }
}
function roadGeometryFromData(data){const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3));geo.setAttribute('uv',new THREE.Float32BufferAttribute(data.uvs,2));geo.setIndex(data.indices);geo.computeVertexNormals();return geo;}
function addRoadsBatch(){
  if(!ROADS.length)return;
  const colors={street:0x2e3336,alley:0x3c4244,service:0x353a3d,dirt:0x806b4e,sidewalk:0x777d80,crosswalk:0x44494c},groups=new Map(),markGroups=new Map(),dataFor=(map,key)=>{if(!map.has(key))map.set(key,{positions:[],uvs:[],indices:[]});return map.get(key);};
  for(const road of ROADS){
    const kind=colors[road.kind]!=null?road.kind:'street',surface=authoredRoadSurfacePolicy(kind);appendRoadSurface(dataFor(groups,kind),road,{offset:surface.surfaceOffset});
    const patches=[];let markKey='white';
    if(kind==='street'||kind==='service'){markKey=kind==='street'?'yellow':'white';const dash=2.1,gap=2.0,total=dash+gap;for(let start=-(road.distance||0)%total;start<road.w;start+=total){const lo=Math.max(0,start),hi=Math.min(road.w,start+dash);if(hi>lo)patches.push({x:-road.w/2+(lo+hi)/2,z:0,w:hi-lo,d:.13});}}
    else if(kind==='crosswalk'){const stripeCount=Math.max(3,Math.floor(road.d/.65)),stripeD=road.d/stripeCount*.52;for(let i=0;i<stripeCount;i++)patches.push({x:0,z:-road.d/2+(i+.5)*road.d/stripeCount,w:Math.min(road.w,4.5),d:stripeD});}
    if(patches.length)appendRoadSurface(dataFor(markGroups,markKey),road,{offset:AUTHORED_ROAD_MARKING_POLICY.surfaceOffset,patches});
  }
  const orderedGroups=[...groups.entries()].sort((a,b)=>authoredRoadSurfacePolicy(a[0]).priority-authoredRoadSurfacePolicy(b[0]).priority);
  for(const [kind,data] of orderedGroups){const surface=authoredRoadSurfacePolicy(kind),mat=worldMat(colors[kind],'concrete',kind==='dirt'?1:.98,0).clone();mat.depthTest=true;mat.depthWrite=false;mat.depthFunc=THREE.LessDepth;mat.polygonOffset=true;mat.polygonOffsetFactor=surface.polygonOffsetFactor;mat.polygonOffsetUnits=surface.polygonOffsetUnits;const mesh=new THREE.Mesh(roadGeometryFromData(data),mat);mesh.receiveShadow=!isTouch;mesh.castShadow=false;mesh.renderOrder=surface.renderOrder;worldRoot.add(mesh);}
  for(const [key,data] of markGroups){const mat=worldMat(key==='yellow'?0xd0ad49:0xd8dcda,'paintedMetal',.92,0).clone();mat.depthTest=true;mat.depthWrite=false;mat.depthFunc=THREE.LessDepth;mat.polygonOffset=true;mat.polygonOffsetFactor=AUTHORED_ROAD_MARKING_POLICY.polygonOffsetFactor;mat.polygonOffsetUnits=AUTHORED_ROAD_MARKING_POLICY.polygonOffsetUnits;const mesh=new THREE.Mesh(roadGeometryFromData(data),mat);mesh.receiveShadow=false;mesh.castShadow=false;mesh.renderOrder=AUTHORED_ROAD_MARKING_POLICY.renderOrder;worldRoot.add(mesh);}
}

function addBoundaryWallsBatch(mat){
  const pieces=16,span=ARENA_LIMIT*2,piece=span/pieces,edge=ARENA_LIMIT+1,transforms=[];
  for(let i=0;i<pieces;i++){
    const p=-ARENA_LIMIT+piece*(i+.5);
    transforms.push({x:p,y:terrainHeight(p,-edge)+2.5,z:-edge,sx:piece+.35,sy:5,sz:2});
    transforms.push({x:p,y:terrainHeight(p,edge)+2.5,z:edge,sx:piece+.35,sy:5,sz:2});
    transforms.push({x:-edge,y:terrainHeight(-edge,p)+2.5,z:p,sx:2,sy:5,sz:piece+.35});
    transforms.push({x:edge,y:terrainHeight(edge,p)+2.5,z:p,sx:2,sy:5,sz:piece+.35});
  }
  addStaticInstancedMesh(new THREE.BoxGeometry(1,1,1),mat,transforms);
}
function addLaddersBatch(){
  if(!LADDERS.length)return;const metal=worldMat(0x8d8170,'rustedMetal',.82,.35);
  for(const ladder of LADDERS){const frame=ladderFrame(ladder);if(!frame)continue;const g=new THREE.Group(),height=Math.max(.8,ladder.topY-ladder.bottomY),cx=ladder.x+frame.nx*.05,cz=ladder.z+frame.nz*.05;g.position.set(cx,ladder.bottomY,cz);worldRoot.add(g);const horizontal=Math.abs(frame.tx)>.5;
    const railOffset=ladder.width*.43;for(const side of [-1,1]){const rail=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,height,8),metal);rail.position.set(frame.tx*railOffset*side,height/2,frame.tz*railOffset*side);g.add(rail);}
    const rungCount=Math.max(4,Math.floor(height/.34));for(let i=0;i<=rungCount;i++){const rung=new THREE.Mesh(new THREE.CylinderGeometry(.032,.032,ladder.width*.90,8),metal);rung.position.y=.18+(height-.36)*(i/rungCount);rung.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(frame.tx,0,frame.tz));g.add(rung);}
  }
}
function authoredPropRole(role){
    const r=String(role||'');
    if(r.includes('Wheel'))return 'wheel';
    if(r.startsWith('burntCar')||r.startsWith('burntBus'))return r.includes('Cabin')||r.includes('Upper')?'vehicleUpper':'vehicleBody';
    if(r.startsWith('fuelTank'))return 'fuelTank';
    if(r.startsWith('dumpster'))return 'dumpster';
    if(r.startsWith('checkpoint'))return 'checkpoint';
    if(r==='sandbag')return 'sandbag';
    if(r==='brokenWall')return 'brokenWall';
    if(r==='crate')return 'crate';
    if(r==='pipe')return 'pipe';
    if(r==='tank')return 'tank';
    if(r==='shed')return 'shed';
    if(r==='barrier'||r==='boundary')return 'concrete';
    if(r==='containerBlue')return 'containerBlue';
    if(r==='containerRed')return 'containerRed';
    if(r==='containerGreen')return 'containerGreen';
    if(r==='containerTan')return 'containerTan';
    return 'default';
  }
function authoredPropMaterials(){return {
    wheel:new THREE.MeshStandardMaterial({color:0x111213,roughness:1}),
    vehicleBody:worldMat(0x252728,'charredMetal',.94,.12),vehicleUpper:worldMat(0x5f4030,'rustedMetal',.97,.04),
    fuelTank:worldMat(0x485056,'paintedMetal',.84,.18),dumpster:worldMat(0x303438,'charredMetal',.92,.12),checkpoint:worldMat(0x76523a,'rustedMetal',.96,.05),
    sandbag:worldMat(0x8b7753,'sandbag',1,0),brokenWall:worldMat(0x8e8a80,'concrete',.98,0),crate:worldMat(0x755437,'wood',.96,0),pipe:worldMat(0x6d665d,'rustedMetal',.76,.18),
    tank:worldMat(0x82755f,'rustedMetal',.80,.12),shed:worldMat(0x765744,'corrugatedMetal',.88,.08),concrete:worldMat(0x9a8b70,'concrete',.96,0),
    containerBlue:worldMat(0x385f78,'corrugatedMetal',.82,.06),containerRed:worldMat(0x8a473f,'corrugatedMetal',.84,.06),containerGreen:worldMat(0x4f6d58,'corrugatedMetal',.86,.06),containerTan:worldMat(0x847457,'corrugatedMetal',.88,.05),
    default:worldMat(0x6f706d,'concrete',.95,0),
  };}
function addCanonicalAuthoredStaticProps(){
  const parts=worldGeometry?.STATIC_PARTS;if(!Array.isArray(parts)||!parts.length)return false;
  const unitBox=new THREE.BoxGeometry(1,1,1),unitRound=new THREE.CylinderGeometry(1,1,1,14),boxGroups=new Map(),roundGroups=new Map();
  const roleKey=authoredPropRole,materials=authoredPropMaterials();
  const push=(map,key,t)=>{if(!map.has(key))map.set(key,[]);map.get(key).push(t);};
  for(const part of parts){
    const key=roleKey(part.role),bottom=Number(part.minY??part.bottomY),top=Number(part.maxY??part.topY),h=top-bottom;if(!(h>0))continue;
    if(part.type==='round')push(roundGroups,key,{x:part.x,y:(bottom+top)/2,z:part.z,sx:part.r,sy:h,sz:part.r});
    else push(boxGroups,key,{x:part.x,y:(bottom+top)/2,z:part.z,sx:part.w,sy:h,sz:part.d,ry:authoredYaw(part.rot)});
  }
  for(const [key,transforms] of boxGroups)addStaticInstancedMesh(unitBox,materials[key]||materials.default,transforms);
  for(const [key,transforms] of roundGroups)addStaticInstancedMesh(unitRound,materials[key]||materials.default,transforms);
  return true;
}
function addStaticBoxesBatch(mat){
  addCanonicalAuthoredStaticProps();
  for(const o of STATIC_BOXES)mapObstacles.push({type:'box',x:o.x,z:o.z,w:o.w,d:o.d,rot:o.rot||0});
}
function addPyramidsBatch(mat){
  const transforms=[];
  for(const p of PYRAMIDS){const radius=p.base/Math.sqrt(2),ground=terrainHeight(p.x,p.z);transforms.push({x:p.x,y:ground+p.h/2-.05,z:p.z,ry:Math.PI/4,sx:radius,sy:p.h,sz:radius});mapObstacles.push({type:'pyramid',x:p.x,z:p.z,base:p.base});}
  addStaticInstancedMesh(new THREE.ConeGeometry(1,1,4,1),mat,transforms);
}
function naturalVisualBatches(objects,baseHeight){
  const trunks=[],crowns=[],bushes=[],rocks=[];
  const bushOffsets=[[0,0,1],[-.55,0,.72],[.55,.08,.68],[0,.48,.63]];
  for(const o of objects){
    const base=baseHeight(o);
    if(o.type==='tree'){
      trunks.push({x:o.x,y:base+o.h*.32,z:o.z,sx:o.r,sy:o.h*.64,sz:o.r});
      crowns.push({x:o.x,y:base+o.h*.62,z:o.z,sx:o.r*3.0,sy:o.h*.48,sz:o.r*3.0});
      crowns.push({x:o.x,y:base+o.h*.83,z:o.z,sx:o.r*2.35,sy:o.h*.40,sz:o.r*2.35});
    }else if(o.type==='bush'){
      for(const [ox,oz,scale] of bushOffsets){const r=o.r*scale*.72;bushes.push({x:o.x+ox*o.r*.45,y:base+o.h*.42,z:o.z+oz*o.r*.45,sx:r,sy:r*.62,sz:r});}
    }else rocks.push({x:o.x,y:base+o.h/2,z:o.z,ry:.4,sx:o.r,sy:o.h,sz:o.r});
  }
return [trunks,crowns,bushes,rocks];
}
function naturalVisualGeometries(){return [new THREE.CylinderGeometry(.72,1,1,8),new THREE.ConeGeometry(1,1,9),new THREE.SphereGeometry(1,8,6),new THREE.CylinderGeometry(.62,1,1,7,2,false)];}
function addNaturalObstaclesBatch(trunkMat,leafMat,bushMat,rockMat){
const batches=naturalVisualBatches(NATURAL_OBSTACLES,o=>naturalGroundBase(o.type,o.x,o.z,o.r)),geometries=naturalVisualGeometries(),materials=[trunkMat,leafMat,bushMat,rockMat];
for(const o of NATURAL_OBSTACLES)mapObstacles.push({type:o.type,x:o.x,z:o.z,r:o.r,h:o.h});
for(let i=0;i<4;i++)addStaticInstancedMesh(geometries[i],materials[i],batches[i],i>=2?{castShadow:false,receiveShadow:false}:{});
}
function addBuildingsBatch(){
  const unitBox=new THREE.BoxGeometry(1,1,1);
  for(let index=0;index<BUILDINGS.length;index++){
    const b=BUILDINGS[index],geometry=BUILDING_GEOMETRY[index];
    const buildingStyle=BUILDING_MATERIALS[b.style]||BUILDING_MATERIALS.industrial;
    const materials={
      wall:worldMat(buildingStyle?buildingStyle[0]:(currentMapId==='rig'?(b.tall?0x6f6250:0x89735b):(currentMapId==='depot'?(b.tall?0x7d8589:0x919698):(b.tall?0x929aa0:0xa8adb0))),buildingWallTexture(b.style),.92,b.style==='industrial'||b.style==='warehouse'?.05:0),
      trim:worldMat(buildingStyle?buildingStyle[1]:(currentMapId==='rig'?(b.tall?0x3b3229:0x514336):(currentMapId==='depot'?(b.tall?0x30383d:0x41494e):(b.tall?0x39444d:0x4f5961))),'paintedMetal',.78,.10),
      floor:worldMat(buildingStyle?buildingStyle[2]:(currentMapId==='rig'?0x5b5145:(currentMapId==='depot'?0x5d6264:0x6d7478)),'concrete',.97,0),
    };
    const groups={wall:[],trim:[],floor:[]};
    for(const part of geometry.parts){
      const h=part.topY-part.bottomY,key=part.role==='wall'?'wall':(part.role==='trim'||part.role==='rail'||part.role==='roof'||part.role==='stairSide'?'trim':'floor');
      groups[key].push({x:part.x,y:(part.bottomY+part.topY)/2,z:part.z,sx:part.w,sy:h,sz:part.d,ry:authoredYaw(part.rot)});
    }
    for(const key of ['wall','trim','floor'])addStaticInstancedMesh(unitBox,materials[key],groups[key]);
    mapObstacles.push({type:'box',x:b.x,z:b.z,w:b.w,d:b.d,rot:b.rot||0});
  }
  const elevationRoles=new Set(['platform','overpass','overpassSupport','rampStep','stairStep']),elevationTransforms=[];for(const part of (worldGeometry.ELEVATION_GEOMETRY||[]).flatMap(g=>g.parts))if(elevationRoles.has(part.role))elevationTransforms.push({x:part.x,y:(part.bottomY+part.topY)/2,z:part.z,sx:part.w,sy:part.topY-part.bottomY,sz:part.d,ry:authoredYaw(part.rot)});if(elevationTransforms.length)addStaticInstancedMesh(unitBox,worldMat(0x68757c,'concrete',.92,.03),elevationTransforms);
}
function addMarkersBatch(mat){
  const transforms=[];for(const [x,z] of [[-102,-102],[102,-102],[-102,102],[102,102],[0,-108],[108,0],[0,108],[-108,0]])transforms.push({x,y:terrainHeight(x,z)+2.6,z});
  addStaticInstancedMesh(new THREE.CylinderGeometry(.28,.4,5.2,10),mat,transforms,{castShadow:false,receiveShadow:false});
}


function bindUI(){

  const menuShell=$('menuShell');
  const setDeployMode=(mode)=>{
    const next=['create','join','live'].includes(mode)?mode:'create';
    menuShell.dataset.deployMode=next;
    for(const tab of deployTabs){const active=tab.dataset.deployTab===next;tab.classList.toggle('active',active);tab.setAttribute('aria-selected',String(active));}
    for(const view of deployViews){
      const active=view.dataset.deployView===next;
      view.hidden=!active;
      view.inert=!active;
      view.setAttribute('aria-hidden',String(!active));
    }
    const focused=document.activeElement;
    if(focused instanceof HTMLElement&&focused.matches('input,textarea,select')&&focused.closest('[data-deploy-view]')?.dataset.deployView!==next)focused.blur();
    if(next==='live')void refreshMatches();
  };
  for(const tab of deployTabs)tab.addEventListener('click',()=>setDeployMode(tab.dataset.deployTab));
  setDeployMode(requestedRoom?'join':'create');
  bindSubTabs('[data-settings-tab]','[data-settings-page]','data-settings-tab','data-settings-page','controls');
  bindSubTabs('[data-lobby-cheat-tab]','[data-lobby-cheat-page]','data-lobby-cheat-tab','data-lobby-cheat-page','gameplay');

  $('createBtn').addEventListener('click',createMatch);
  $('refreshBtn').addEventListener('click',refreshMatches);
  $('enterFullscreenBtn').addEventListener('click',()=>{ensureAudio();void shell.enterFullscreenFromGesture();});
  $('musicBtn').addEventListener('click',()=>{ensureAudio();toggleMasterMute();});
  $('settingsBtn').addEventListener('click',openPlayerSettings);
  $('lobbySettingsBtn').addEventListener('click',openPlayerSettings);
  $('pauseSettingsBtn').addEventListener('click',openPlayerSettings);
  $('pauseLoadoutBtn').addEventListener('click',openMatchLoadout);
  $('loadoutCloseBtn').addEventListener('click',closeMatchLoadout);
  for(const btn of matchPrimaryButtons)btn.addEventListener('click',()=>setMatchLoadoutDraft({primaryWeapon:btn.dataset.matchPrimaryChoice}));
  for(const btn of matchSecondaryButtons)btn.addEventListener('click',()=>setMatchLoadoutDraft({secondaryWeapon:btn.dataset.matchSecondaryChoice}));
  for(const btn of matchTacticalButtons)btn.addEventListener('click',()=>setMatchLoadoutDraft({tactical:btn.dataset.matchTacticalChoice}));
  for(const btn of matchLethalButtons)btn.addEventListener('click',()=>setMatchLoadoutDraft({lethal:btn.dataset.matchLethalChoice}));
  $('settingsCloseBtn').addEventListener('click',closePlayerSettings);
  $('settingsFullscreenBtn').addEventListener('click',async()=>{ensureAudio();if(shell.fullscreen)await shell.exitFullscreenFromGesture();else await shell.enterFullscreenFromGesture();});
  for(const version of document.querySelectorAll('[data-app-version]'))version.addEventListener('click',registerDeveloperVersionTap);
  $('rotateFullscreenBtn')?.addEventListener('click',async()=>{ensureAudio();if(shell.fullscreen)await shell.exitFullscreenFromGesture();else await shell.enterFullscreenFromGesture();});
  $('connectionCancelBtn')?.addEventListener('click',()=>cancelInitialConnection('Connection canceled.'));
  $('settingsResetBtn').addEventListener('click',resetPlayerSettings);
  $('playerMasterMute')?.addEventListener('click',()=>{setMasterMuted(!masterMuted);setSettingsStatus('');});
  for(const [id,key] of [['playerLookSensitivity','lookSensitivity'],['playerAdsSensitivity','adsSensitivity'],['playerTouchSensitivity','touchSensitivity'],['playerControllerVerticalSensitivity','controllerVerticalSensitivity'],['playerControllerMoveDeadzone','controllerMoveDeadzone'],['playerControllerLookDeadzone','controllerLookDeadzone'],['playerMasterVolume','masterVolume'],['playerSfxVolume','sfxVolume'],['playerMusicVolume','musicVolume']])$(id)?.addEventListener('input',()=>stagePlayerSettingFromUI(id,key));
  for(const id of ['playerMasterVolume','playerMusicVolume'])$(id)?.addEventListener('change',refreshIntroMusicVolume);
  $('playerGraphics').addEventListener('change',()=>stagePlayerChoice('graphics',$('playerGraphics').value));
  $('playerControllerResponseCurve')?.addEventListener('change',()=>stagePlayerChoice('controllerResponseCurve',$('playerControllerResponseCurve').value));
  $('playerControllerAimAssist')?.addEventListener('click',()=>stagePlayerChoice('controllerAimAssist',playerSettings.controllerAimAssist==='off'?'on':'off'));
  $('playerDiagnosticsBtn')?.addEventListener('click',toggleDiagnosticsRecording);
  $('diagnosticsExportBtn')?.addEventListener('click',exportDiagnosticsRecording);
  $('diagnosticsClearBtn')?.addEventListener('click',()=>{resetDiagnosticsRecording({markStart:diagnosticsRecordingEnabled()});});
  chatSendBtn.addEventListener('click',submitChat);
  chatKeyboard.addEventListener('click',e=>{const btn=e.target.closest?.('[data-chat-char],[data-chat-action]');if(!btn||!chatOpen)return;e.preventDefault();handleChatKeyboardButton(btn);});
  $('joinBtn').addEventListener('click', () => joinMatch(normalizeCode(codeInput.value)));
  nameInput.addEventListener('click',()=>openGameTextEditor(nameInput));
  codeInput.addEventListener('click',()=>openGameTextEditor(codeInput));
  for(const btn of gameTextKeyboard?.querySelectorAll('[data-editor-char],[data-editor-action]')||[])btn.addEventListener('click',()=>handleGameTextEditorButton(btn));
  $('resumeBtn').addEventListener('click', resumeFromGesture);
  $('copyBtn').addEventListener('click', copyInvite);
  $('pauseDiagnosticsBtn')?.addEventListener('click',exportDiagnosticsRecording);
  $('teamSwitchBtn').addEventListener('click',()=>requestTeamChange(godMode?otherTeam(myTeam):(pendingTeam?myTeam:otherTeam(myTeam))));
  $('adminBtn').addEventListener('click',()=>openAdminPanel('gameplay'));
  $('adminCancelBtn').addEventListener('click',closeAdminPanel);
  $('adminBotDifficulty')?.addEventListener('change',syncAdminBotDraftSummary);
  const adminTabs=[...document.querySelectorAll('[data-admin-tab]')];
  for(const tab of adminTabs){
    tab.addEventListener('click',()=>switchAdminTab(tab.dataset.adminTab));
    tab.addEventListener('keydown',e=>{
      if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
      const tabs=availableAdminTabs();if(!tabs.includes(tab)||!tabs.length)return;
      e.preventDefault();
      const current=tabs.indexOf(tab),next=e.key==='Home'?0:e.key==='End'?tabs.length-1:(current+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length;
      tabs[next].focus();switchAdminTab(tabs[next].dataset.adminTab);
    });
  }
  $('leaveBtn').addEventListener('click',()=>{if(isMatchAdmin)returnToLobby();else leaveMatch();});
  $('lobbyLeaveBtn').addEventListener('click',openLobbyQuitConfirm);$('lobbyQuitStayBtn')?.addEventListener('click',closeLobbyQuitConfirm);$('lobbyQuitLeaveBtn')?.addEventListener('click',confirmLobbyQuit);
  $('lobbyCopyBtn').addEventListener('click',copyInvite);
  for(const tab of lobbySideTabs)tab.addEventListener('click',()=>switchLobbySide(tab.dataset.lobbySideTab));
  $('lobbyGodModeToggle')?.addEventListener('click',()=>{if(isMatchAdmin&&socket?.readyState===WebSocket.OPEN)send({t:'god',enabled:!godMode});});
  switchLobbySide('players');
  for(const btn of lobbyPrimaryButtons)btn.addEventListener('click',()=>setLobbyLoadoutDraft({primaryWeapon:btn.dataset.lobbyPrimaryChoice}));
  for(const btn of lobbySecondaryButtons)btn.addEventListener('click',()=>setLobbyLoadoutDraft({secondaryWeapon:btn.dataset.lobbySecondaryChoice}));
  for(const btn of lobbyTacticalButtons)btn.addEventListener('click',()=>setLobbyLoadoutDraft({tactical:btn.dataset.lobbyTacticalChoice}));
  for(const btn of lobbyLethalButtons)btn.addEventListener('click',()=>setLobbyLoadoutDraft({lethal:btn.dataset.lobbyLethalChoice}));
  for(const btn of lobbyModeButtons)btn.addEventListener('click',()=>setLobbyModeDraft(btn.dataset.lobbyModeChoice));
  for(const el of [lobbyBotDifficulty,lobbyScoreLimit,lobbyTimeLimit,lobbyMinimapMode,lobbyMod])el.addEventListener('input',updateLobbyMatchDraftFromControls);
  for(const root of [$('adminGameplay'),$('adminAdvanced'),$('adminPlayers')]){root?.addEventListener('input',()=>{if(shell.inLobby)setLobbyActionState();});root?.addEventListener('change',()=>{if(shell.inLobby)setLobbyActionState();else if(shell.inMatch&&isMatchAdmin)saveAdminSettings(root.id==='adminAdvanced'?'advanced':root.id==='adminPlayers'?'players':'gameplay');});}
  for(const btn of lobbyMapButtons)btn.addEventListener('click',()=>setLobbyMapDraft(btn.dataset.lobbyMapChoice));
  $('lobbyLoadCustomMapBtn')?.addEventListener('click',requestCustomMapFile);$('lobbyCustomMapFile')?.addEventListener('change',event=>{const file=event.target.files?.[0];if(file)void loadCustomMapFile(file);});$('lobbyCreateMapBtn')?.addEventListener('click',()=>openIntegratedMapBuilder());$('lobbyEditMapBtn')?.addEventListener('click',()=>{if(selectedLibraryMap?.id)openIntegratedMapBuilder(selectedLibraryMap.id)});$('lobbyDeleteMapBtn')?.addEventListener('click',openMapDeleteConfirm);$('mapDeleteCancelBtn')?.addEventListener('click',closeMapDeleteConfirm);$('mapDeleteConfirmBtn')?.addEventListener('click',()=>void confirmMapDelete());document.querySelectorAll('[data-map-gallery-tab]').forEach(btn=>btn.addEventListener('click',()=>{mapGalleryTab=btn.dataset.mapGalleryTab==='mine'?'mine':'official';document.querySelectorAll('[data-map-gallery-tab]').forEach(x=>x.classList.toggle('active',x===btn));if(mapGalleryTab==='mine')void refreshMapLibrary({quiet:true});renderMapGallery();}));void refreshMapLibrary({quiet:true});updateCustomMapLobbyUi();scheduleMapBuilderWarmup();
  $('lobbyStartBtn').addEventListener('click',async()=>{
    if(!isMatchAdmin||socket?.readyState!==WebSocket.OPEN||!matchAllowsLobbyEdits(matchState))return;
    const setup=collectLobbyStartSetup();if(!setup){$('lobbyStatus').textContent=`Maximum ${MAX_MATCH_BOTS} bots per match.`;return;}
    const button=$('lobbyStartBtn');button.disabled=true;$('lobbyStatus').textContent='Preparing match…';
    // Validate first. Fullscreen/input capture happens only for a setup that can actually start.
    if(!(await shell.prepareInputFromGesture())){button.disabled=false;$('lobbyStatus').textContent='Fullscreen / game input is required to start.';return;}
    if(!(await prepareGameRuntime())){button.disabled=false;$('lobbyStatus').textContent='Game runtime could not be prepared.';return;}
    loadoutClasses=normalizeLoadoutClasses(setup.loadoutClasses,selectedLoadout());rememberLoadoutClasses(loadoutClasses,setup.classId);send({t:'startMatch',setup});$('lobbyStatus').textContent='Starting match…';
  });

  canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();graphicsContextAvailable=false;shell.pause('graphics');showToast('GRAPHICS INTERRUPTED · WAIT FOR RECOVERY');});
  canvas.addEventListener('webglcontextrestored',()=>{graphicsContextAvailable=true;shell.render('graphics-restored');onResize();hudLastDraw=0;showToast('GRAPHICS RESTORED · RESUME WHEN READY');});
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  canvas.addEventListener('pointerdown', onCanvasPointerDown, {passive:false});
  canvas.addEventListener('pointermove', onCanvasPointerMove, {passive:false});
  canvas.addEventListener('pointerup', onCanvasPointerEnd, {passive:false});
  canvas.addEventListener('pointercancel', onCanvasPointerEnd, {passive:false});
  canvas.addEventListener('lostpointercapture', onCanvasPointerEnd);
  const suppressNativeUI=e=>{if(!isEditableTarget(e.target)){e.preventDefault();const sel=window.getSelection?.();if(sel)sel.removeAllRanges();}};
  document.addEventListener('contextmenu',suppressNativeUI,{capture:true});
  document.addEventListener('gesturestart',suppressNativeUI,{passive:false,capture:true});
  document.addEventListener('gesturechange',suppressNativeUI,{passive:false,capture:true});
  document.addEventListener('gestureend',suppressNativeUI,{passive:false,capture:true});

  document.addEventListener('mousemove', e => {
    if(chatOpen||scoreboardOpen||killstreakTargeting||!playerMovementActive()||hp<=0||!playerPointerLocked()) return;
    if(Math.abs(e.movementX)+Math.abs(e.movementY)>.01)setActiveInputMode(INPUT_MODE.KEYBOARD_MOUSE,{quiet:true});
    const beforePitch=pitch,sens=aimSensitivityScale()*playerSettings.lookSensitivity;applyPlayerAimDelta(-e.movementX*.0023*sens,-e.movementY*.0020*sens);if(diagnosticsRecordingEnabled()&&fireInputHeld()&&Math.abs(pitch-beforePitch)>.02)diagnosticsRecordEvent('mouse_look',{dx:diagnosticsRound(e.movementX,2),dy:diagnosticsRound(e.movementY,2),pitchDelta:diagnosticsRound(pitch-beforePitch)});
  });
  document.addEventListener('pointerdown',e=>{
    if(!e.isTrusted)return;
    if(e.pointerType==='touch'||e.pointerType==='pen'){activateTouchInputMode();setActiveInputMode(INPUT_MODE.TOUCH,{quiet:true});}
    else if(e.pointerType==='mouse')setActiveInputMode(INPUT_MODE.KEYBOARD_MOUSE,{quiet:true});
  },{capture:true,passive:true});
  document.addEventListener('keydown', e => {
    if(gameTextEditorTarget){handlePhysicalGameTextKey(e);return;}
    if(chatOpen){handlePhysicalChatKey(e);return;}
    if(mapDeletePromptOpen()&&e.code==='Escape'&&!e.repeat){e.preventDefault();closeMapDeleteConfirm();return;}
    if(lobbyQuitPromptOpen()&&e.code==='Escape'&&!e.repeat){e.preventDefault();closeLobbyQuitConfirm();return;}
    if(replayPlayback){if(replayPlayback.kind==='killcam'&&!e.repeat&&['Escape','Space','Enter'].includes(e.code)){e.preventDefault();skipReplayPlayback();}else if(['Escape','Space','Enter'].includes(e.code))e.preventDefault();return;}
    if(isEditableTarget(e.target)) return;
    if(killstreakTargeting){
      if(e.code==='Escape'&&!e.repeat){e.preventDefault();closeKillstreakTargeting();return;}
      if(e.code==='Enter'&&!e.repeat){e.preventDefault();confirmKillstreakTarget();return;}
      const step=e.shiftKey?5:2;if(!e.repeat||['ArrowUp','ArrowDown','ArrowLeft','ArrowRight','KeyW','KeyA','KeyS','KeyD'].includes(e.code)){const limit=minimapWorldLimit();if(e.code==='ArrowUp'||e.code==='KeyW')killstreakTargeting.z=Math.max(-limit,killstreakTargeting.z-step);else if(e.code==='ArrowDown'||e.code==='KeyS')killstreakTargeting.z=Math.min(limit,killstreakTargeting.z+step);else if(e.code==='ArrowLeft'||e.code==='KeyA')killstreakTargeting.x=Math.max(-limit,killstreakTargeting.x-step);else if(e.code==='ArrowRight'||e.code==='KeyD')killstreakTargeting.x=Math.min(limit,killstreakTargeting.x+step);else return;killstreakTargeting.chosen=true;e.preventDefault();hudLastDraw=0;return;}
    }
    if(e.isTrusted)setActiveInputMode(INPUT_MODE.KEYBOARD_MOUSE,{quiet:true});
    if(e.code==='Enter'&&!e.repeat&&shell.inMatch&&!shell.paused&&!shell.panel){e.preventDefault();openChat();return;}
    if(e.code==='Escape'&&!e.repeat&&shell.panel){
      e.preventDefault();
      if(shell.panel===SHELL_PANEL.SETTINGS){closePlayerSettings();return;}
      if(shell.panel===SHELL_PANEL.ADMIN){closeAdminPanel();return;}
      if(shell.panel===SHELL_PANEL.LOADOUT){if(loadoutWorkspaceMode.match==='item'){setLoadoutWorkspaceMode('match','class',{ensurePreview:false});return;}if(loadoutWorkspaceMode.match==='class'){setLoadoutWorkspaceMode('match','classes',{ensurePreview:false});return;}closeMatchLoadout();return;}
    }
    if(e.code==='Escape'&&!e.repeat&&shell.inLobby&&loadoutWorkspaceMode.lobby!=='classes'&&document.querySelector('[data-lobby-side-tab="loadout"]')?.classList.contains('active')){e.preventDefault();setLoadoutWorkspaceMode('lobby',loadoutWorkspaceMode.lobby==='item'?'class':'classes',{ensurePreview:false});return;}
    if(e.code==='Escape'&&!e.repeat&&shell.inLobby){e.preventDefault();openLobbyQuitConfirm();return;}
    if(shell.inBuilder){
      if(e.ctrlKey||e.metaKey||e.altKey)return;
      if(!playerMovementActive()||isEditableTarget(canvas.getRootNode().activeElement)||canvas.getRootNode().activeElement?.closest?.('.builder-access'))return;
      if(['KeyW','KeyA','KeyS','KeyD','ShiftLeft','ShiftRight','Space','KeyC'].includes(e.code)){e.preventDefault();keys.add(e.code);if(builderSession.editor.state.phase==='test'){if(!e.repeat&&e.code==='Space')tryJump();if(!e.repeat&&e.code==='KeyC')toggleCrouch();}}
      return;
    }
    if(!shell.inMatch)return;
    if((e.code==='KeyM'||e.code==='Escape')&&!e.repeat){
      e.preventDefault();
      if(scoreboardOpen){scoreboardOpen=false;return;}
      if(!shell.paused)openPause();
      return;
    }
    if(!shell.canPlay)return;
    if(scoreboardOpen){if(e.code==='Tab')e.preventDefault();return;}
    if(matchAllowsMovement(matchState)&&hp<=0&&e.code==='KeyL'&&!e.repeat){e.preventDefault();openMatchLoadout();return;}
    if(['KeyW','KeyA','KeyS','KeyD','ShiftLeft','ShiftRight','Space','KeyC','KeyR','KeyQ','KeyB','KeyF','KeyG','Digit1','Digit2','Digit3','Digit4','Digit5','Tab'].includes(e.code)) e.preventDefault();
    if(e.repeat&&!keys.has(e.code))return;
    keys.add(e.code);
    if(e.code==='Space' && !e.repeat) tryJump();
    if(e.code==='KeyC' && !e.repeat) toggleCrouch();
    if(e.code==='KeyR' && !e.repeat) doReload();
    if(e.code==='Digit1' && !e.repeat) switchWeapon(primaryWeapon);
    if(e.code==='Digit2' && !e.repeat) switchWeapon(secondaryWeapon);
    if(e.code==='Digit3' && !e.repeat) requestKillstreak(killstreakSelection[0]);
    if(e.code==='Digit4' && !e.repeat) requestKillstreak(killstreakSelection[1]);
    if(e.code==='Digit5' && !e.repeat) requestKillstreak(killstreakSelection[2]);
    if(e.code==='KeyF' && !e.repeat) beginEquipmentAim(tacticalEquipment);
    if(e.code==='KeyG' && !e.repeat) beginEquipmentAim(lethalEquipment);
    if(e.code==='KeyQ' && !e.repeat) switchWeapon(currentWeapon===secondaryWeapon?primaryWeapon:secondaryWeapon);
    if(e.code==='KeyB' && !e.repeat) toggleFireMode();
    if(e.code==='Tab'&&!e.repeat){scoreboardOpen=true;scoreboardScroll=0;resetTouchInput();clearFireInput();cancelEquipmentAction();}
  });
  document.addEventListener('keyup', e => {
    const owned=keys.delete(e.code);
    if(chatOpen){e.preventDefault();return;}
    if(isEditableTarget(e.target)||!owned)return;
    if(e.code==='Tab')scoreboardOpen=false;
    if(e.code==='KeyF'&&equipmentAimKind()===tacticalEquipment){releaseEquipmentAim();}
    if(e.code==='KeyG'&&equipmentAimKind()===lethalEquipment){releaseEquipmentAim();}
  });
  document.addEventListener('mousedown',onMouseButtonDown);
  document.addEventListener('mouseup',e=>{if(e.button===0){mouseFireDown=false;endRecoilBurstIfReleased();}});
  document.addEventListener('selectstart',e=>{if(!isEditableTarget(e.target))e.preventDefault();});
  document.addEventListener('dragstart',e=>e.preventDefault());
  canvas.addEventListener('wheel',onScoreboardWheel,{passive:false});
}

let gameTextEditorTarget=null,gameTextEditorDraft='',gameTextEditorShift=true;
function gameTextMode(){return gameTextEditorTarget?.dataset?.textMode||'callsign';}
function normalizeGameTextDraft(value){
  let text=String(value??'').replace(/[<>\u0000-\u001f\u007f]/g,'');
  if(gameTextMode()==='code')text=text.toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,ROOM_CODE_LENGTH);
  else text=text.replace(/\s+/g,' ').slice(0,Math.max(1,Number(gameTextEditorTarget?.dataset?.maxlength)||18));
  return text;
}
function renderKeyboardLetterCase(root,dataKey,caps){
  for(const key of root?.querySelectorAll?.(`[data-${dataKey}-char]`)||[]){const raw=String(key.dataset?.[`${dataKey}Char`]||'');if(/^[a-z]$/i.test(raw))key.textContent=caps?raw.toUpperCase():raw.toLowerCase();}
}
function renderGameTextEditor(){
  if(!gameTextEditorTarget)return;const codeMode=gameTextMode()==='code',caps=codeMode||gameTextEditorShift;gameTextEditorValue.textContent=gameTextEditorDraft;gameTextEditorPlaceholder.textContent=gameTextEditorDraft?'':(gameTextEditorTarget.dataset.placeholder||'');gameTextShiftBtn?.classList.toggle('active',caps);if(gameTextShiftBtn){gameTextShiftBtn.textContent=caps?'CAPS ON':'CAPS';gameTextShiftBtn.disabled=codeMode;}
  gameTextKeyboard?.classList.toggle('code-mode',codeMode);renderKeyboardLetterCase(gameTextKeyboard,'editor',caps);
}
function openGameTextEditor(target){
  if(!target||target.disabled)return false;gameTextEditorTarget=target;gameTextEditorDraft=String(target.value||'');gameTextEditorShift=gameTextMode()==='code';
  const mode=gameTextMode();gameTextEditorTitle.textContent=mode==='code'?'ROOM CODE':mode==='class'?'CLASS NAME':'CALLSIGN';
  gameTextEditor.classList.remove('hide');renderGameTextEditor();clearControllerUiFocus();return true;
}
function closeGameTextEditor(commit){
  if(!gameTextEditorTarget)return;const target=gameTextEditorTarget;if(commit){target.value=normalizeGameTextDraft(gameTextEditorDraft);target.dispatchEvent(new Event('change',{bubbles:true}));}
  gameTextEditorTarget=null;gameTextEditorDraft='';gameTextEditor.classList.add('hide');clearControllerUiFocus();
  if(controllerInputActive())requestAnimationFrame(()=>setControllerUiFocus(target));
}
function cancelGameTextEditor(){closeGameTextEditor(false);}
function commitGameTextEditor(){closeGameTextEditor(true);}
function appendGameTextChar(char){
  if(!gameTextEditorTarget)return;let out=String(char||'');if(gameTextMode()==='code'){out=out.toUpperCase();if(!/^[A-Z0-9]$/.test(out))return;}else if(/^[a-z]$/i.test(out)){out=gameTextEditorShift?out.toUpperCase():out.toLowerCase();}
  const max=gameTextMode()==='code'?ROOM_CODE_LENGTH:Math.max(1,Number(gameTextEditorTarget.dataset.maxlength)||18);if(gameTextEditorDraft.length>=max)return;gameTextEditorDraft=normalizeGameTextDraft(gameTextEditorDraft+out);renderGameTextEditor();
}
function backspaceGameText(){if(!gameTextEditorTarget||!gameTextEditorDraft)return;gameTextEditorDraft=Array.from(gameTextEditorDraft).slice(0,-1).join('');renderGameTextEditor();}
function handleGameTextEditorButton(btn){
  if(!gameTextEditorTarget)return;const char=btn.dataset.editorChar,action=btn.dataset.editorAction;if(char!=null){appendGameTextChar(char);return;}if(action==='shift'){gameTextEditorShift=!gameTextEditorShift;renderGameTextEditor();return;}if(action==='backspace'){backspaceGameText();return;}if(action==='space'){if(gameTextMode()!=='code')appendGameTextChar(' ');return;}if(action==='cancel'){cancelGameTextEditor();return;}if(action==='done')commitGameTextEditor();
}
function handlePhysicalGameTextKey(e){
  if(!gameTextEditorTarget)return false;e.preventDefault();e.stopPropagation();if(e.key==='Escape'){cancelGameTextEditor();return true;}if(e.key==='Enter'){commitGameTextEditor();return true;}if(e.key==='Backspace'){backspaceGameText();return true;}if(e.key===' '){if(gameTextMode()!=='code')appendGameTextChar(' ');return true;}
  if(!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key?.length===1){if(gameTextMode()==='code')appendGameTextChar(e.key);else{const max=Math.max(1,Number(gameTextEditorTarget.dataset.maxlength)||18);if(gameTextEditorDraft.length<max){gameTextEditorDraft=normalizeGameTextDraft(gameTextEditorDraft+e.key);renderGameTextEditor();}}}return true;
}

function cleanChatText(value){return String(value??'').replace(/[\u0000-\u001f\u007f]/g,' ').replace(/\s+/g,' ').trim().slice(0,CHAT_MAX_LENGTH);}
function receiveChatMessage(m){
  const text=cleanChatText(m?.text),name=String(m?.name||'Player').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,18)||'Player';if(!text)return;
  chatMessages.push({id:String(m?.id||''),name,team:String(m?.team||'blue')==='red'?'red':'blue',text,until:performance.now()+CHAT_VISIBLE_MS});
  if(chatOpen&&chatScroll>0)chatScroll++;
  while(chatMessages.length>CHAT_MAX_MESSAGES)chatMessages.shift();hudLastDraw=0;
}
function renderChatDraft(){
  const text=chatDraft.slice(0,CHAT_MAX_LENGTH);chatInputText.textContent=text;chatInput.classList.toggle('has-text',!!text);chatShiftBtn?.classList.toggle('active',chatShift);if(chatShiftBtn)chatShiftBtn.textContent=chatShift?'CAPS ON':'CAPS';renderKeyboardLetterCase(chatKeyboard,'chat',chatShift);
}
function setChatDraft(value){chatDraft=String(value??'').replace(/[\u0000-\u001f\u007f]/g,' ').slice(0,CHAT_MAX_LENGTH);renderChatDraft();}
function appendChatCharacter(char){
  if(!chatOpen||chatDraft.length>=CHAT_MAX_LENGTH)return;let out=String(char||'');if(!out)return;
  if(/^[a-z]$/i.test(out)){out=chatShift?out.toUpperCase():out.toLowerCase();}
  setChatDraft(chatDraft+out);
}
function backspaceChat(){if(!chatDraft)return;const chars=Array.from(chatDraft);chars.pop();setChatDraft(chars.join(''));}
function handleChatKeyboardButton(btn){
  const char=btn.dataset.chatChar,action=btn.dataset.chatAction;if(char!=null){appendChatCharacter(char);return;}
  if(action==='shift'){chatShift=!chatShift;renderChatDraft();return;}
  if(action==='backspace'){backspaceChat();return;}
  if(action==='space'){appendChatCharacter(' ');return;}
  if(action==='send'){submitChat();return;}
  if(action==='cancel')void dismissChat();
}
function handlePhysicalChatKey(e){
  if(!chatOpen)return false;e.preventDefault();e.stopPropagation();
  if(e.key==='Escape'){void dismissChat();return true;}
  if(e.key==='Enter'){submitChat();return true;}
  if(e.key==='Backspace'){backspaceChat();return true;}
  if(e.key===' '){if(chatDraft.length<CHAT_MAX_LENGTH)setChatDraft(chatDraft+' ');return true;}
  if(!e.ctrlKey&&!e.metaKey&&!e.altKey&&e.key?.length===1&&chatDraft.length<CHAT_MAX_LENGTH)setChatDraft(chatDraft+e.key);
  return true;
}
function openChat(){
  if(chatOpen||!shell.inMatch||shell.paused||shell.panel||shell.connecting||hp<=0||!matchAllowsMovement(matchState))return false;
  chatOpen=true;chatScroll=0;chatDrag=null;chatPanel=null;scoreboardOpen=false;chatShift=false;setChatDraft('');suspendGameplayInput();chatComposer.classList.remove('hide');
  if((document.pointerLockElement||document.webkitPointerLockElement)===canvas)(document.exitPointerLock||document.webkitExitPointerLock)?.call(document);
  hudLayout=null;hudLastDraw=0;return true;
}
async function dismissChat({restorePointer=true}={}){
  if(!chatOpen){chatComposer.classList.add('hide');return false;}
  chatComposer.classList.add('hide');chatShift=false;setChatDraft('');keys.clear();resetTouchInput();clearFireInput();cancelEquipmentAction();
  const recapture=restorePointer&&activeInputMode===INPUT_MODE.KEYBOARD_MOUSE&&shell.inMatch&&!shell.paused&&!shell.panel&&!controllerInputActive();let captured=true;
  if(recapture)captured=await shell.capturePointerFromGesture();
  chatOpen=false;chatScroll=0;chatDrag=null;chatPanel=null;hudLayout=null;hudLastDraw=0;if(recapture&&!captured)showToast('CLICK GAME TO CAPTURE MOUSE');return true;
}
function submitChat(){
  if(!chatOpen)return;const text=cleanChatText(chatDraft);setChatDraft('');
  if(text){if(socket?.readyState===WebSocket.OPEN)send({t:'chat',text});else showToast('CHAT OFFLINE');}
  void dismissChat();
}

function clipHudText(c,text,maxWidth){let out=String(text||'');if(c.measureText(out).width<=maxWidth)return out;const ell='…';while(out.length>1&&c.measureText(out+ell).width>maxWidth)out=out.slice(0,-1);return out+ell;}
function drawChatFeed(c,L,w,h,now){
  const r=L.chatFeed,rowH=isTouch?17:19,maxRows=Math.max(0,Math.floor(r.h/rowH));if(maxRows<1){chatPanel=null;return;}
  const source=chatMessages.filter(item=>chatOpen||item.until>now),rowLimit=Math.min(maxRows,chatOpen?12:(isTouch?3:5));if(!source.length){chatPanel={...r,maxScroll:0,rowH};return;}
  const maxScroll=chatOpen?Math.max(0,source.length-rowLimit):0;chatScroll=Math.max(0,Math.min(maxScroll,Math.round(chatScroll)));const end=Math.max(0,source.length-chatScroll),start=Math.max(0,end-rowLimit),visible=source.slice(start,end);
  chatPanel={...r,maxScroll,rowH};const x=r.x,y=r.y,boxW=r.w;c.save();c.beginPath();c.rect(x,y,r.w,r.h);c.clip();c.shadowColor='rgba(0,0,0,.88)';c.shadowBlur=3;c.shadowOffsetY=1;let cy=y+rowH/2;
  for(const item of visible){const mine=samePlayerId(item.id,clientId),teamColor=currentModeSpec().teamBased?factionColor(item.team):'#dfe8ee';c.textAlign='left';c.font=`900 ${isTouch?10:11}px system-ui`;c.fillStyle=mine?HUD_ACCENT:teamColor;const label=`${item.name}: `;c.fillText(label,x+2,cy);const lw=c.measureText(label).width;c.font=`800 ${isTouch?10:11}px system-ui`;c.fillStyle='rgba(244,248,250,.90)';c.fillText(clipHudText(c,item.text,boxW-lw-8),x+2+lw,cy);cy+=rowH;}
  c.shadowColor='transparent';if(chatOpen&&maxScroll>0){const trackH=Math.max(24,Math.min(r.h,visible.length*rowH)),thumbH=Math.max(16,trackH*(rowLimit/source.length)),thumbY=y+(trackH-thumbH)*(1-chatScroll/maxScroll);c.fillStyle='rgba(255,255,255,.22)';c.fillRect(x+r.w-2,thumbY,2,thumbH);}c.restore();
}
function drawChatButton(c,r){
  if(!r)return;const active=chatOpen;roundRect(c,r.x,r.y,r.w,r.h,7,active?'rgba(215,255,88,.18)':HUD_SURFACE,active?'rgba(215,255,88,.55)':HUD_LINE);c.save();c.textAlign='center';c.fillStyle=active?HUD_ACCENT:'#dbe4ea';c.font='1000 10px system-ui';c.fillText('CHAT',r.x+r.w/2,r.y+r.h/2);c.restore();
}

function isEditableTarget(target){return !!target?.isContentEditable||!!target?.closest?.('input,textarea,select');}

function getViewSize(){const v=shell.viewport;return {w:v.w,h:v.h};}
async function resumeFromGesture(){
  ensureAudio();
  if(!shell.inMatch)return;
  if(!(await shell.resumeFromGesture()))return;
  resetTouchInput();
  clock?.getDelta();
}

function onCanvasPointerDown(e){
  if(replayPlayback){if(replayPlayback.kind==='killcam'){e.preventDefault();skipReplayPlayback();}return;}
  if(!playerMovementActive())return;
  const directTouch=e.pointerType==='touch'||e.pointerType==='pen';
  if(directTouch){activateTouchInputMode();setActiveInputMode(INPUT_MODE.TOUCH,{quiet:true});}else setActiveInputMode(INPUT_MODE.KEYBOARD_MOUSE,{quiet:true});
  const p=canvasPoint(e);
  const gesture=gameplayPointers.begin(e,{capture:directTouch||!!killstreakTargeting||chatOpen||scoreboardOpen});if(!gesture)return;
  if(builderSession){
    if(!directTouch){if(!playerPointerLocked()){const request=canvas.requestPointerLock?.();request?.catch?.(()=>{});}else if(e.button===0)builderSession.editor.primary();return;}
    e.preventDefault();const layout=hudLayout||computeHudLayout();
    if(builderSession.editor.state.phase==='test'&&pointInCircle(p.x,p.y,layout.jump)){touchRoles.set(e.pointerId,'jump');touchVisual.jumpUntil=performance.now()+150;tryJump();return;}
    if(builderSession.editor.state.phase==='test'&&pointInCircle(p.x,p.y,layout.crouch)){touchRoles.set(e.pointerId,'crouch');toggleCrouch();return;}
    if(!touchRoleActive('joy')&&joystickSpawnAllowed(p,layout)){joy.centerX=p.x;joy.centerY=p.y;touchRoles.set(e.pointerId,'joy');updateJoy(p.x,p.y,{x:p.x,y:p.y,r:layout.joy.r});return;}
    if(p.x>viewW*MOBILE_MOVE_ZONE_RATIO&&!touchRoleActive('look')){touchRoles.set(e.pointerId,'look');look.x=p.x;look.y=p.y;}return;
  }
  if(killstreakTargeting){e.preventDefault();const recapture=!directTouch&&e.pointerType==='mouse';if(pointInRect(p.x,p.y,killstreakTargetConfirmRect)){armCanvasAction(e,killstreakTargetConfirmRect,()=>confirmKillstreakTarget({recapture}));return;}if(pointInRect(p.x,p.y,killstreakTargetCancelRect)){armCanvasAction(e,killstreakTargetCancelRect,()=>closeKillstreakTargeting({recapture}));return;}armCanvasAction(e,killstreakTargetRect,point=>killstreakTargetFromCanvas(point.x,point.y,{choose:true}));return;}
  if(chatOpen){
    const layout=hudLayout||computeHudLayout();
    if(pointInRect(p.x,p.y,layout.chat)){e.preventDefault();armCanvasAction(e,layout.chat,()=>void dismissChat({restorePointer:false}));return;}
    if(chatPanel?.maxScroll>0&&pointInRect(p.x,p.y,layout.chatFeed)){e.preventDefault();chatDrag={startY:p.y,startScroll:chatScroll,rowH:chatPanel.rowH};touchRoles.set(e.pointerId,'chat-scroll');}
    return;
  }
  if(scoreboardOpen){
      const panel=scoreboardPanel;
      if(panel?.close&&pointInRect(p.x,p.y,panel.close)){armCanvasAction(e,panel.close,()=>{scoreboardOpen=false;scoreboardDrag=null;});return;}
      if(panel&&pointInRect(p.x,p.y,panel)&&!touchRoleActive('scoreboard-scroll')){scoreboardDrag={startY:p.y,startScroll:scoreboardScroll};touchRoles.set(e.pointerId,'scoreboard-scroll');return;}
      return;
    }
  ensureAudio();
  if(!directTouch&&(document.pointerLockElement||document.webkitPointerLockElement)!==canvas){void shell.capturePointerFromGesture();return;}
  if(directTouch){
    e.preventDefault();
    const layout=hudLayout||computeHudLayout();
    const activeRound=matchAllowsMovement(matchState),liveHud=activeRound&&hp>0;
    // Any canvas control that changes surfaces is armed on press and
    // committed on pointerup. This keeps one physical gesture on one UI
    // surface and prevents the release/click from falling through into a
    // control that did not exist when the press began.
    if(liveHud&&pointInRect(p.x,p.y,layout.chat)){armCanvasAction(e,layout.chat,openChat);return;}
    if(activeRound&&hp<=0&&layout.deathLoadout&&pointInRect(p.x,p.y,layout.deathLoadout)){armCanvasAction(e,layout.deathLoadout,openMatchLoadout);return;}
    if(pointInRect(p.x,p.y,layout.team)){armCanvasAction(e,layout.team,toggleScoreboard);return;}
    if(matchState.status!==MATCH_STATUS.ENDED&&pointInRect(p.x,p.y,layout.menu)){
      armCanvasAction(e,layout.menu,openPause);return;
    }
    if(!liveHud)return;
    const streakSlot=combatOverviewVisible()?layout.streak.slots.findIndex(slot=>pointInRect(p.x,p.y,slot)):-1;
    if(streakSlot>=0){const kind=normalizeKillstreakSelection(killstreakSelection)[streakSlot];armCanvasAction(e,layout.streak.slots[streakSlot],()=>requestKillstreak(kind));return;}
    if(currentWeapon!=='akimbo1887'&&pointInCircle(p.x,p.y,layout.aim)){touchRoles.set(e.pointerId,'aimtoggle');toggleAim();return;}
    if(currentWeapon==='sniper'&&adsWanted&&adsBlend>=SNIPER_BREATH_READY_BLEND&&pointInCircle(p.x,p.y,layout.steady)){if(!sniperBreathExhausted)touchRoles.set(e.pointerId,'steady');return;}
    if(pointInCircle(p.x,p.y,layout.leftFire)){
      touchVisual.fireUntil=performance.now()+150;pressTouchFire(e.pointerId,currentWeapon==='akimbo1887'?'left':'right');return;
    }
    if(pointInCircle(p.x,p.y,layout.crouch)){touchRoles.set(e.pointerId,'crouch');toggleCrouch();return;}
    if(pointInCircle(p.x,p.y,layout.flash)){touchVisual.flashUntil=performance.now()+160;if(!touchRoleActive('equipment')&&beginEquipmentAim(tacticalEquipment))touchRoles.set(e.pointerId,'equipment');return;}
    if(pointInCircle(p.x,p.y,layout.sticky)){touchVisual.stickyUntil=performance.now()+160;if(!touchRoleActive('equipment')&&beginEquipmentAim(lethalEquipment))touchRoles.set(e.pointerId,'equipment');return;}
    if(pointInCircle(p.x,p.y,layout.fire)){
      touchVisual.fireUntil=performance.now()+150;pressTouchFire(e.pointerId);return;
    }
    if(pointInCircle(p.x,p.y,layout.reload)){
      touchRoles.set(e.pointerId,'reload');touchVisual.reloadUntil=performance.now()+150;doReload();return;
    }
    if(pointInCircle(p.x,p.y,layout.swap)){
      touchRoles.set(e.pointerId,'swap');touchVisual.swapUntil=performance.now()+150;switchWeapon(nextWeapon(currentWeapon));return;
    }
    if(currentWeapon==='assault'&&pointInCircle(p.x,p.y,layout.mode)){
      touchRoles.set(e.pointerId,'mode');touchVisual.modeUntil=performance.now()+150;toggleFireMode();return;
    }
    if(pointInCircle(p.x,p.y,layout.jump)){
      touchRoles.set(e.pointerId,'jump');
      touchVisual.jumpUntil=performance.now()+150;
      tryJump();
      return;
    }
    const moveBoundary=viewW*MOBILE_MOVE_ZONE_RATIO;
    if(!touchRoleActive('joy') && joystickSpawnAllowed(p,layout)){
      joy.centerX=p.x;
      joy.centerY=p.y;
      touchRoles.set(e.pointerId,'joy');
      updateJoy(p.x,p.y,{x:joy.centerX,y:joy.centerY,r:layout.joy.r});
      return;
    }
    if(p.x>moveBoundary&&!touchRoleActive('look')){
      touchRoles.set(e.pointerId,'look');look.x=p.x;look.y=p.y;
    }
    return;
  }

}

// Pointer events signal contact transitions; mouse events also report chorded
// buttons (for example, aiming while the fire button is already held).
function onMouseButtonDown(e){
  if(e.target!==canvas||(document.pointerLockElement||document.webkitPointerLockElement)!==canvas||!shell.canPlay||chatOpen||scoreboardOpen||killstreakTargeting||!matchAllowsCombat(matchState)||hp<=0)return;
  if(e.button===0){if(currentWeapon==='akimbo1887')requestShot('right');else pressMouseFire();}
  else if(e.button===2){if(currentWeapon==='akimbo1887')requestShot('left');else toggleAim();}
}

function onCanvasPointerMove(e){
  gameplayPointers.move(e);
  if(!playerMovementActive())return;
  if(killstreakTargeting)return;
  const role=touchRoles.get(e.pointerId);
  if(!role)return;
  const p=canvasPoint(e);
  e.preventDefault();
  if(role==='scoreboard-scroll'&&scoreboardDrag){const panel=scoreboardPanel;if(panel){scoreboardScroll=Math.max(0,Math.min(panel.maxScroll,scoreboardDrag.startScroll+(scoreboardDrag.startY-p.y)));}return;}
  if(role==='chat-scroll'&&chatDrag&&chatPanel){chatScroll=Math.max(0,Math.min(chatPanel.maxScroll,Math.round(chatDrag.startScroll+(p.y-chatDrag.startY)/Math.max(1,chatDrag.rowH))));hudLastDraw=0;return;}
  if(role==='joy'){const L=hudLayout||computeHudLayout();updateJoy(p.x,p.y,{x:joy.centerX,y:joy.centerY,r:L.joy.r});return;}
  if(role==='look'&&hp>0){
    const dx=p.x-look.x,dy=p.y-look.y;look.x=p.x;look.y=p.y;
    const beforePitch=pitch,sens=aimSensitivityScale()*playerSettings.touchSensitivity;applyPlayerAimDelta(-dx*.006*sens,-dy*.0052*sens);if(diagnosticsRecordingEnabled()&&fireInputHeld()&&Math.abs(pitch-beforePitch)>.02)diagnosticsRecordEvent('touch_look',{dx:diagnosticsRound(dx,2),dy:diagnosticsRound(dy,2),pitchDelta:diagnosticsRound(pitch-beforePitch),pointerId:e.pointerId});
  }
}

function armCanvasAction(event,rect,action){
  const state=gameplayPointers.get(event.pointerId);if(state){state.rect=rect?{...rect}:null;state.action=action;state.context=controllerInputContext();}
}
function releaseCanvasRole(id,completed){
  const role=touchRoles.get(id);touchRoles.delete(id);
  if(role==='fire')endRecoilBurstIfReleased();
  if(role==='joy'){joy.x=joy.y=0;joy.centerX=joy.centerY=0;}
  if(role==='equipment'){if(completed)releaseEquipmentAim();else cancelEquipmentAction();}
  if(role==='scoreboard-scroll')scoreboardDrag=null;
  if(role==='chat-scroll')chatDrag=null;
}
function onCanvasPointerEnd(e){
  const state=gameplayPointers.end(e),completed=e.type==='pointerup';
  releaseCanvasRole(e.pointerId,completed);
  if(e.pointerType==='mouse'&&(e.button===0||!completed)){mouseFireDown=false;endRecoilBurstIfReleased();}
  if(!completed||!state?.action||!shell.canPlay||state.distance>12||state.context!==controllerInputContext())return;
  const p=canvasPoint(e);if(pointInRect(p.x,p.y,state.rect))state.action(p);
}
function resetTouchInput(){
  gameplayPointers.cancelAll();touchRoles.clear();mouseFireDown=false;endRecoilBurst();joy.x=joy.y=0;joy.centerX=joy.centerY=0;scoreboardDrag=null;chatDrag=null;cancelEquipmentAction();setAim(false);
}

function updateJoy(x,y,center){
  let dx=x-center.x,dy=y-center.y;const max=center.r*.46;const len=Math.hypot(dx,dy)||1;
  if(len>max){dx=dx/len*max;dy=dy/len*max;}
  joy.x=dx/max;joy.y=dy/max;
}

function canvasPoint(e){const r=canvas.getBoundingClientRect(),rw=Math.max(1,r.width),rh=Math.max(1,r.height);return{x:(e.clientX-r.left)*(viewW/rw),y:(e.clientY-r.top)*(viewH/rh)};}
function pointInCircle(x,y,c){return Math.hypot(x-c.x,y-c.y)<=c.r;}
function pointNearCircle(x,y,c,padding=0){return Math.hypot(x-c.x,y-c.y)<=c.r+padding;}
function joystickSpawnAllowed(p,layout){
  // Editor HUD consumes its visible controls before this shared movement handler.
  if(builderSession)return p.x<=layout.moveBoundary;
  const buttons=[layout.leftFire,layout.flash,layout.sticky];if(currentWeapon==='assault')buttons.push(layout.mode);
  if(p.x>layout.moveBoundary||buttons.some(c=>pointNearCircle(p.x,p.y,c,TOUCH_JOY_BUTTON_PADDING)))return false;
  return !combatOverviewVisible()||!pointInRect(p.x,p.y,{x:layout.streak.x-TOUCH_JOY_BUTTON_PADDING,y:layout.streak.y-TOUCH_JOY_BUTTON_PADDING,w:layout.streak.w+TOUCH_JOY_BUTTON_PADDING*2,h:layout.streak.h+TOUCH_JOY_BUTTON_PADDING*2});
}
function pointInRect(x,y,r){return !!r&&x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h;}
function onScoreboardWheel(e){const p=canvasPoint(e);if(chatOpen&&chatPanel?.maxScroll>0&&pointInRect(p.x,p.y,(hudLayout||computeHudLayout()).chatFeed)){e.preventDefault();chatScroll=Math.max(0,Math.min(chatPanel.maxScroll,chatScroll-Math.sign(e.deltaY)));hudLastDraw=0;return;}if(!scoreboardOpen||!scoreboardPanel)return;e.preventDefault();scoreboardScroll=Math.max(0,Math.min(scoreboardPanel.maxScroll,scoreboardScroll+e.deltaY));}

let matchesRefreshPromise=null;
async function refreshMatches(){
  if(matchesRefreshPromise)return matchesRefreshPromise;
  matchesRefreshPromise=(async()=>{
    try{
      const response=await fetch(`${ONLINE_API}/rooms`,{cache:'no-store'});if(!response.ok)throw new Error('Server unavailable');
      const data=await response.json();renderMatches(Array.isArray(data.rooms)?data.rooms:[]);
    }catch(err){if(!shell.inMatch){matchList.innerHTML='<div class="empty">Multiplayer server unavailable.</div>';matchCount.textContent='';}}
    finally{matchesRefreshPromise=null;}
  })();
  return matchesRefreshPromise;
}
function renderMatches(rooms){
  const visible=rooms;
  matchCount.textContent=rooms.length?String(rooms.length):'';
  if(!rooms.length){matchList.innerHTML='<div class="empty">No live matches.</div>';return;}
  matchList.innerHTML='';
  for(const room of visible){
    const row=document.createElement('div');row.className='match';
    const left=document.createElement('div');const blue=Number(room.blue)||0,red=Number(room.red)||0,blueBots=Number(room.blueBots)||0,redBots=Number(room.redBots)||0;
    const codeEl=document.createElement('div');codeEl.className='match-code';codeEl.textContent=String(room.code||'');
    const botMeta=document.createElement('div');botMeta.className='match-meta';const roomMode=normalizeGameMode(room.mode),roomSpec=gameModeSpec(roomMode),scoreText=roomSpec.scoreType==='team'?`${Number(room.blueScore)||0}-${Number(room.redScore)||0} / ${Number(room.scoreLimit)||roomSpec.scoreLimit}`:roomSpec.scoreType==='player'?`First ${Number(room.scoreLimit)||roomSpec.scoreLimit}`:'Open play';botMeta.textContent=`${room.custom?'CUSTOM · ':''}${room.mapId==='custom-map'&&room.mapName?String(room.mapName).slice(0,24):displayMapSpec(room.mapId).short} · ${roomSpec.short} · ${String(room.matchStatus||'waiting').toUpperCase()} · ${scoreText} · Bots ${blueBots+redBots}`;if(room.custom)codeEl.classList.add('custom-match');
    const teamCounts=document.createElement('div');teamCounts.className='team-counts';
    if(roomSpec.teamBased){const blueChip=document.createElement('span');blueChip.className='team-chip alpha';blueChip.textContent=`ALPHA ${blue}`;const redChip=document.createElement('span');redChip.className='team-chip bravo';redChip.textContent=`BRAVO ${red}`;teamCounts.append(blueChip,redChip);}else{const ffaChip=document.createElement('span');ffaChip.className='team-chip ffa';ffaChip.textContent=`COMBATANTS ${blue+red}`;teamCounts.append(ffaChip);}
    left.append(codeEl,botMeta,teamCounts);
    const meta=document.createElement('div');meta.className='match-meta';meta.textContent=`${Number(room.players)||0}/${Number(room.maxPlayers)||0}`;
    const btn=document.createElement('button');btn.className='btn icon-btn';btn.dataset.controllerKey=`room:${String(room.code||'')}`;btn.setAttribute('aria-label',`Join ${room.code}`);btn.innerHTML='<svg class="ui-icon"><use href="#i-enter"/></svg>';btn.addEventListener('click',()=>joinMatch(room.code));
    row.append(left,meta,btn);matchList.append(row);
  }
  
}

async function createMatch(){
  const attempt=beginInitialConnectionAttempt('Creating lobby…');
  myName=safeName();setLocalTeam(preferredTeam,{remember:false,source:'create_prepare',refresh:false});godMode=false;primaryWeapon=preferredPrimary;secondaryWeapon=preferredSecondary;primaryAttachments={...preferredPrimaryAttachments};secondaryAttachments={...preferredSecondaryAttachments};tacticalEquipment=preferredTactical;lethalEquipment=preferredLethal;pendingLoadout=null;pendingTeam='';
  preferences.setItem('breachName',myName);disableMenu(true);setStatus('Creating lobby…');
  try{
    const response=await fetch(`${ONLINE_API}/rooms`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({protocol:PROTOCOL_VERSION,client:clientId,auth:clientAuth}),cache:'no-store',signal:initialConnectionSignal(attempt)});
    const data=await response.json();if(!initialConnectionCurrent(attempt))return;if(!response.ok){if(response.status===409)void checkForClientUpdate('create-protocol');throw new Error(data.error||'Could not create lobby.');}void connectMatch(data.code,false,attempt);
  }catch(err){if(err?.name==='AbortError'||!initialConnectionCurrent(attempt))return;finishInitialConnectionAttempt();shell.cancelConnection();setStatus(err.message||'Could not create lobby.','error');disableMenu(false);}
}
async function joinMatch(code){
  if(code.length!==ROOM_CODE_LENGTH){setStatus('Enter a 4-character room code.','error');return;}
  const attempt=beginInitialConnectionAttempt(`Joining ${code}…`);myName=safeName();setLocalTeam(preferredTeam,{remember:false,source:'join_prepare',refresh:false});godMode=false;loadoutClasses=normalizeLoadoutClasses(preferredLoadoutClasses);activeClassId=normalizeLoadoutClassId(preferredActiveClassId);pendingClassId='';{const c=loadoutClassById(loadoutClasses,activeClassId);primaryWeapon=c.primaryWeapon;secondaryWeapon=c.secondaryWeapon;primaryAttachments={...c.primaryAttachments};secondaryAttachments={...c.secondaryAttachments};tacticalEquipment=c.tactical;lethalEquipment=c.lethal;}pendingLoadout=null;pendingTeam='';
  preferences.setItem('breachName',myName);disableMenu(true);setStatus(`Joining ${code}…`);void connectMatch(code,false,attempt);
}
function disableMenu(disabled){
  $('createBtn').disabled=disabled;$('joinBtn').disabled=disabled;$('refreshBtn').disabled=disabled;nameInput.disabled=disabled;
  for(const btn of deployTabs)btn.disabled=disabled;
}

async function connectMatch(code, reconnecting=false, initialAttempt=null){
  clearTimeout(reconnectTimer);currentRoom=normalizeCode(code);if(!currentRoom)return;
  if(!reconnecting)shell.updateConnection(`Connecting to ${currentRoom}…`);
  if(socket){try{socket.close(1000,'Replacing connection')}catch{}}
  let ticket='';
  try{
    const signal=!reconnecting?initialConnectionSignal(initialAttempt):null;if(!reconnecting&&!signal)return;const ticketResponse=await fetch(`${ONLINE_API}/rooms/${currentRoom}/ticket`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({protocol:PROTOCOL_VERSION,client:clientId,auth:clientAuth,name:myName||safeName(),team:myTeam,primaryWeapon,secondaryWeapon,primaryAttachments,secondaryAttachments,tactical:tacticalEquipment,lethal:lethalEquipment,loadoutClasses,activeClassId,killstreakSelection}),cache:'no-store',signal});
    const ticketData=await ticketResponse.json();if(!ticketResponse.ok){if(ticketResponse.status===409)void checkForClientUpdate('join-protocol');throw new Error(ticketData.error||'Could not authorize match connection.');}ticket=String(ticketData.ticket||'');if(!ticket)throw new Error('Server did not issue a join ticket.');
  }catch(err){if(err?.name==='AbortError'&&!reconnecting)return;if(!shell.inMatch&&!reconnecting){finishInitialConnectionAttempt();shell.cancelConnection();disableMenu(false);setStatus(err.message||'Could not join match.','error');}else scheduleReconnect();return;}
  if(!reconnecting&&!initialConnectionCurrent(initialAttempt))return;const url=`${apiToWs(ONLINE_API)}/rooms/${currentRoom}/socket?protocol=${PROTOCOL_VERSION}&ticket=${encodeURIComponent(ticket)}`;
  let ws;try{ws=new WebSocket(url);socket=ws;}catch{if(!shell.inMatch&&!reconnecting){finishInitialConnectionAttempt();shell.cancelConnection();disableMenu(false);setStatus('Could not open multiplayer connection.','error');}else scheduleReconnect();return;}
  ws.addEventListener('open',()=>{if(ws!==socket)return;reconnectAttempt=0;if(reconnecting){netDiag.reconnects++;netDiagEvent('reconnect');showToast('Reconnected');}});
  ws.addEventListener('message',e=>{if(ws!==socket)return;try{handleMessage(JSON.parse(e.data))}catch(error){netDiag.messageErrors++;console.error('WebSocket message handling failed',error);}});
  ws.addEventListener('close',e=>{
    if(ws!==socket)return;
    netDiag.socketCloses++;netDiagEvent('close',{code:e.code||0});
    if(!reconnecting&&initialConnectionAttempt){finishInitialConnectionAttempt();shell.cancelConnection();disableMenu(false);setStatus(e.reason||'Could not join match.','error');return;}
    if(!roomSessionActive()&&!reconnecting){shell.cancelConnection();disableMenu(false);setStatus(e.reason||'Could not join match.','error');return;}
    if(roomSessionActive()&&e.code!==1000){showToast('Connection lost · reconnecting',{priority:3,key:'connection-lost'});scheduleReconnect();}
  });
  ws.addEventListener('error',()=>{if(ws!==socket)return;netDiag.socketErrors++;netDiagEvent('socket_error');if(!shell.inMatch)setStatus('Multiplayer server unreachable.','error');});
}
function scheduleReconnect(){
  if(!roomSessionActive()||!currentRoom)return;clearTimeout(reconnectTimer);reconnectAttempt++;
  reconnectTimer=setTimeout(()=>connectMatch(currentRoom,true),Math.min(5000,700*reconnectAttempt));
}
function send(payload){if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify(payload));}
function serverNow(){return Date.now()+serverClockOffset;}
function normalizeClientMatch(value){const v=value&&typeof value==='object'?value:{};return{...normalizeSharedMatchState(v,Date.now(),v),serverTime:Number(v.serverTime)||serverNow()};}
function applyMatchPhaseTransition(previous,next){
  if(!matchPhaseChanged(previous,next))return;
  if(!matchAllowsCombat(next)){clearFireInput();cancelEquipmentAction();setAim(false);reloadRequestPending=false;}
  if(next.status===MATCH_STATUS.ENDED){
    clearKillstreakFx();resetKillstreakClientState();
    // Final results own the match surface. Tear down the active UI through its
    // normal owner before exposing the read-only post-match presentation.
    if(gameTextEditorTarget)cancelGameTextEditor();
    if(shell.panel===SHELL_PANEL.SETTINGS)cancelPlayerSettings();
    else if(shell.panel===SHELL_PANEL.ADMIN)closeAdminPanel();
    else if(shell.panel===SHELL_PANEL.LOADOUT)closeMatchLoadout();
    shell.showMatchPresentation?.();clearControllerUiFocus();
    reloadUntil=0;reloadWeapon='';reloadStartedAt=0;pendingWeapon='';weaponSwapStartedAt=0;localEquipmentCooldownUntil=0;sprintActionReadyAt=0;clearQueuedSprintShot();resetRecoilBookkeeping();
    if(chatOpen)void dismissChat({restorePointer:false});else chatComposer.classList.add('hide');
    scoreboardOpen=false;scoreboardScroll=0;scoreboardDrag=null;scoreboardPanel=null;clearToastNotifications();announcerCurrent=null;announcerQueue.length=0;killConfirmUntil=0;damageIndicators.length=0;bloodSplats.length=0;
  }
  if(!matchAllowsMovement(next)){
    traversal=null;ladderState=null;traversalIntentUntil=0;traversalIntentSeq=0;traversalConsumedIntentSeq=0;
    moveVelocityX=moveVelocityZ=0;verticalVelocity=0;knockX=knockZ=0;jumpBufferedUntil=0;localMoveAmount=0;
    crouchWanted=false;crouched=false;stopSlide();cancelSprint();
  }
  if(next.status===MATCH_STATUS.ACTIVE){
    clearFireInput();cancelEquipmentAction();lastStateSent=0;fireReadyAt=freshClientFireReady();
    traversal=null;ladderState=null;traversalIntentUntil=0;jumpBufferedUntil=0;moveVelocityX=moveVelocityZ=0;knockX=knockZ=0;
  }
}
function applyClientMatchState(value){const previous=matchState,next=normalizeClientMatch(value);matchState=next;applyMatchPhaseTransition(previous,next);
  if(next.mode==='zombies'&&next.status==='active'){
    if(next.wave>previous.wave){clearBullets();clearThrowables();clearSmokeClouds();clearKillstreakFx();queueAnnouncer(`WAVE ${next.wave}`,`${next.waveTotal} ZOMBIES`,1800,2);}
    else if(next.nextWaveAt&&!previous.nextWaveAt)queueAnnouncer('WAVE CLEARED','REGROUP · NEXT WAVE IN 8 SECONDS',1800,2);
  }
  return next;}
function matchClockText(){const m=matchState,now=serverNow(),spec=gameModeSpec(m.mode);if(m.status==='warmup')return `START ${(Math.max(0,m.warmupEndsAt-now)/1000).toFixed(1)}`;if(m.status==='active'){if(spec.cooperative)return m.nextWaveAt?`NEXT ${Math.max(0,Math.ceil((m.nextWaveAt-now)/1000))}s`:`WAVE ${m.wave}`;if(spec.scoreType==='none')return 'SANDBOX';const sec=Math.max(0,Math.ceil((m.endsAt-now)/1000)),min=Math.floor(sec/60);return `${min}:${String(sec%60).padStart(2,'0')}`;}if(m.status==='ended'){if(m.winner==='draw')return 'DRAW';if(m.winnerName)return `${String(m.winnerName).toUpperCase()} WINS`;return `${gameModeSpec(m.mode).teamBased?teamLabel(m.winner):String(m.winner||'').toUpperCase()} WINS`;}return 'LOBBY';}

function resetMatchPresentationForLobby(){
  if(chatOpen)void dismissChat({restorePointer:false});else chatComposer.classList.add('hide');
  chatMessages.length=0;scoreboardOpen=false;scoreboardScroll=0;scoreboardDrag=null;scoreboardPanel=null;clearToastNotifications();announcerCurrent=null;announcerQueue.length=0;
  resetTouchInput();clearFireInput();cancelEquipmentAction();keys.clear();clearReplayState();clearRemotes();clearTeammateDeathMarkers();clearBullets();clearRocketTrailPuffs();clearThrowables();clearTacticalFx();clearSmokeClouds();clearKillstreakFx();resetKillstreakClientState();
  killFeed.length=0;bloodSplats.length=0;damageIndicators.length=0;flashUntil=flashPeakUntil=0;hurtUntil=hitUntil=0;blastFeedbackUntil=blastFeedbackPower=blastFeedbackSeed=0;headshotUntil=0;killConfirmUntil=0;killConfirmHeadshot=false;killConfirmDistance=0;lastShotVisualAt=0;wastedUntil=0;lastWastedBy='';lastWastedWeapon='';lastWastedHeadshot=false;lastWastedDistance=0;deathViewStartYaw=0;deathViewTargetYaw=NaN;deathViewStartPitch=0;
  traversal=null;ladderState=null;traversalIntentUntil=0;traversalIntentSeq=0;traversalConsumedIntentSeq=0;moveVelocityX=moveVelocityZ=0;verticalVelocity=0;knockX=knockZ=0;jumpBufferedUntil=0;crouchWanted=false;crouched=false;crouchBlend=0;stopSlide();cancelSprint();setAim(false);hudLayout=null;hudLastDraw=0;resetLocalPredictionHistory();resetRemoteNetworkTiming();
}
function handleMatchLobby(m){
  if(m.customMapDefinition){try{installCustomMapDefinition(m.customMapDefinition,{persist:false,source:'room',quiet:true});}catch(error){showToast(`CUSTOM MAP SYNC FAILED · ${String(error?.message||'invalid map')}`,{priority:3});}}if(m.mapId)setActiveMap(m.mapId,{rebuild:true});
  applyClientMatchState(m.match);matchCustom=!!m.custom;const players=Array.isArray(m.players)?m.players:[],bots=Array.isArray(m.bots)?m.bots:[],self=players.find(player=>samePlayerId(player?.id,clientId))||null;
  if(self){setLocalTeam(self.team||myTeam,{source:'match_lobby_self',refresh:false});pendingTeam='';if(self.activeClassId)activeClassId=normalizeLoadoutClassId(self.activeClassId);pendingClassId=self.pendingClassId?normalizeLoadoutClassId(self.pendingClassId):'';primaryWeapon=PRIMARY_WEAPONS.includes(self.primaryWeapon)?self.primaryWeapon:primaryWeapon;secondaryWeapon=SECONDARY_WEAPONS.includes(self.secondaryWeapon)?self.secondaryWeapon:secondaryWeapon;applyAttachmentState(self);tacticalEquipment=normalizeTactical(self.tactical);lethalEquipment=normalizeLethal(self.lethal);pendingLoadout=null;rememberPrimary(primaryWeapon);rememberSecondary(secondaryWeapon);rememberAttachments(primaryAttachments,secondaryAttachments);rememberEquipment(tacticalEquipment,lethalEquipment);currentWeapon=primaryWeapon;godMode=!!self.godMode;hp=Math.max(0,Math.min(100,Number(self.hp??100)||0));myStats={kills:Number(self.kills)||0,deaths:Number(self.deaths)||0};ammo=normalizeClientAmmo(self.ammo);equipment=normalizeEquipment(self.equipment);selfColor=localDisplayColor();syncLocalWeaponModel();}
  lobbyLoadoutDraft=null;lobbyClassDrafts=null;lobbyLoadoutDirty=false;lobbyStartingClassId=normalizeLoadoutClassId(activeClassId);loadoutEditClass.lobby=normalizeLoadoutClassId(activeClassId);rememberLoadoutClasses(loadoutClasses,activeClassId);pendingGameSnapshot=self?gameSnapshot(self,players,bots,m.match?.serverTime):null;replaceLobbyParticipants(players,bots);resetMatchPresentationForLobby();syncRelationshipPresentation();syncPauseContext();showLobby();
}

function handleMessage(m){
  if(m.t==='welcome'){
    finishInitialConnectionAttempt();
    if(Number(m.protocol)!==PROTOCOL_VERSION){void checkForClientUpdate('welcome-protocol');showToast('CLIENT / SERVER VERSION MISMATCH');leaveMatch();return;}
    if(m.gameVersion&&String(m.gameVersion)!==APP_VERSION)void checkForClientUpdate('welcome-version');else if(m.buildId&&String(m.buildId)!==BUILD_ID)console.debug('Breach rolling deploy build differs',m.buildId,BUILD_ID);
    if(Number.isFinite(Number(m.serverTime)))serverClockOffset=Number(m.serverTime)-Date.now();
    if(m.customMapDefinition){try{installCustomMapDefinition(m.customMapDefinition,{persist:false,source:'room',quiet:true});}catch(error){showToast(`CUSTOM MAP SYNC FAILED · ${String(error?.message||'invalid map')}`,{priority:3});}}setActiveMap(m.mapId,{rebuild:true});currentRoom=m.code;isMatchAdmin=!!m.isAdmin;matchOwnerId=String(m.ownerClientId||'');applyWorldSettings(m.settings||DEFAULT_WORLD_SETTINGS);botConfig=normalizeBotConfig(m.botConfig);matchState=normalizeClientMatch(m.match);matchCustom=!!m.custom;setLocalTeam(m.self.team||myTeam,{source:'welcome',refresh:false});godMode=!!m.self.godMode;verticalVelocity=Number.isFinite(Number(m.self.verticalVelocity))?Number(m.self.verticalVelocity):0;moveVelocityX=moveVelocityZ=0;onGround=m.self.grounded!==false;lastGroundedAt=onGround?performance.now():0;jumpBufferedUntil=0;crouched=!!m.self.crouched;crouchWanted=crouched;crouchBlend=crouched?1:0;stopSlide();cancelSprint();jumpSeq=Math.max(0,Math.floor(Number(m.self.jumpSeq)||0));traversal=null;ladderState=null;traversalIntentUntil=0;traversalIntentSeq=0;traversalConsumedIntentSeq=0;hp=m.self.hp??100;myStats={kills:Number(m.self.kills)||0,deaths:Number(m.self.deaths)||0};applyKillstreakState(m.self.killstreak||{});wastedUntil=m.self.wastedUntil||0;loadoutClasses=normalizeLoadoutClasses(m.self.loadoutClasses??loadoutClasses,selectedLoadout());activeClassId=normalizeLoadoutClassId(m.self.activeClassId??activeClassId);pendingClassId=m.self.pendingClassId?normalizeLoadoutClassId(m.self.pendingClassId):'';primaryWeapon=PRIMARY_WEAPONS.includes(m.self.primaryWeapon)?m.self.primaryWeapon:primaryWeapon;secondaryWeapon=SECONDARY_WEAPONS.includes(m.self.secondaryWeapon)?m.self.secondaryWeapon:secondaryWeapon;applyAttachmentState(m.self);tacticalEquipment=normalizeTactical(m.self.tactical);lethalEquipment=normalizeLethal(m.self.lethal);pendingLoadout=m.self.pendingLoadout?normalizeLoadoutChoice(m.self.pendingLoadout):null;rememberPrimary(primaryWeapon);rememberSecondary(secondaryWeapon);rememberAttachments(primaryAttachments,secondaryAttachments);rememberEquipment(tacticalEquipment,lethalEquipment);rememberLoadoutClasses(loadoutClasses,pendingClassId||activeClassId);pendingTeam=m.self.pendingTeam||'';currentWeapon=(m.self.weapon===secondaryWeapon||m.self.weapon===primaryWeapon)?m.self.weapon:primaryWeapon;ammo=normalizeClientAmmo(m.self.ammo);equipment=normalizeEquipment(m.self.equipment);pendingWeapon='';reloadRequestPending=false;reloadUntil=m.self.reloadAt||0;reloadWeapon=m.self.reloadWeapon||'';reloadStartedAt=reloadUntil?reloadUntil-weaponRules(reloadWeapon||currentWeapon).reloadMs:0;warmWeaponAudio(currentWeapon);syncLocalWeaponModel();
    yaw=m.self.yaw||0;pitch=m.self.pitch||0;recoilDebtPitch=recoilDebtYaw=recoilPatternPitch=recoilPatternYaw=0;recoilBurstActive=false;recoilBurstWeapon='';recoilBurstReleaseAt=0;recoilBurstEndedAt=performance.now();weaponKickZ=weaponKickVelocity=0;resetLocalPredictionHistory();resetRemoteNetworkTiming();pendingGameSnapshot=gameSnapshot(m.self,m.players||[],m.bots||[],m.serverTime);replaceLobbyParticipants(m.players||[],m.bots||[]);
    syncRelationshipPresentation();syncLocalStatus();syncPauseContext();if(matchAllowsLobbyEdits(matchState))showLobby();else{void enterGame(pendingGameSnapshot);}return;
  }
  if(m.t==='join'){upsertLobbyParticipant(m.player);if(shell.inMatch&&engineReady)upsertRemote(m.player,true);syncPauseContext();renderAdminPlayers();if(shell.inLobby)renderLobbyRoster(lobbyDisplayMode());showToast(`${m.player.name} joined`);return;}
  if(m.t==='leave'){const lobbyRow=lobbyParticipants.get(String(m.id||'')),r=remotes.get(m.id);if((lobbyRow&&!lobbyRow.bot)||(r&&!r.bot))showToast(`${lobbyRow?.name||r?.name||'Player'} left`);removeLobbyParticipant(m.id);if(engineReady)removeRemote(m.id);syncPauseContext();renderAdminPlayers();if(shell.inLobby)renderLobbyRoster(lobbyDisplayMode());return;}
  if(m.t==='lobbyPlayer'){
    const p=m.player;if(!p?.id)return;
    const rev=Math.max(0,Math.floor(Number(m.rev)||0));
    if(p.id===clientId){
      // A lobby loadout broadcast can arrive after the player has already moved
      // to a newer local selection. Never let an older broadcast repaint it.
      if(!(shell.inLobby&&rev&&rev<lobbyLoadoutRevision)){pendingTeam=p.pendingTeam||'';godMode=!!p.godMode;setLocalTeam(p.team||myTeam,{source:'lobby_player'});if(p.activeClassId)activeClassId=normalizeLoadoutClassId(p.activeClassId);pendingClassId=p.pendingClassId?normalizeLoadoutClassId(p.pendingClassId):'';primaryWeapon=PRIMARY_WEAPONS.includes(p.primaryWeapon)?p.primaryWeapon:primaryWeapon;secondaryWeapon=SECONDARY_WEAPONS.includes(p.secondaryWeapon)?p.secondaryWeapon:secondaryWeapon;applyAttachmentState(p);tacticalEquipment=normalizeTactical(p.tactical);lethalEquipment=normalizeLethal(p.lethal);pendingLoadout=null;rememberPrimary(primaryWeapon);rememberSecondary(secondaryWeapon);rememberAttachments(primaryAttachments,secondaryAttachments);rememberEquipment(tacticalEquipment,lethalEquipment);currentWeapon=primaryWeapon;ammo=normalizeClientAmmo(p.ammo);equipment=normalizeEquipment(p.equipment);selfColor=localDisplayColor();syncLocalWeaponModel();}
    }else{upsertLobbyParticipant(p);if(shell.inMatch&&engineReady)upsertRemote(p,true);}
    syncPauseContext();syncLobby();return;
  }
  if(m.t==='state'){const r=remotes.get(m.id);if(r)updateRemoteTarget(r,m);return;}
  if(m.t==='traverse'){if(samePlayerId(m.id,clientId)&&m.accepted===false)recordNetReject('traverse',m.reason||'rejected');handleTraversalMessage(m);return;}
  if(m.t==='ladder'){if(samePlayerId(m.id,clientId)&&m.accepted===false)recordNetReject('ladder',m.reason||m.action);handleLadderMessage(m);return;}
  if(m.t==='correction'){applyServerCorrection(m);return;}
  if(m.t==='botState'){for(const b of m.bots||[])upsertRemote({...b,at:m.at},false);return;}
  if(m.t==='shot'){handleShot(m);return;}
  if(m.t==='projectileState'){updateLauncherProjectileState(m);return;}
  if(m.t==='bulletImpact'){spawnBulletImpactFx(m);return;}
  if(m.t==='bulletEnd'){removeBullet(m.id);return;}
  if(m.t==='equipment'){equipment=normalizeEquipment(m.equipment);return;}
  if(m.t==='killstreakLoadout'){applyKillstreakLoadoutAck(m);return;}
  if(m.t==='killstreakState'){applyKillstreakState(m);return;}
  if(m.t==='killstreakAck'){if(m.accepted===false){showToast(m.reason==='not_ready'?'KILLSTREAK NOT READY':m.reason==='not_selected'?'KILLSTREAK NOT EQUIPPED':'KILLSTREAK UNAVAILABLE');}return;}
  if(m.t==='killstreakControl'){if(m.kind==='ufo')killstreakControlUntil=Math.max(killstreakControlUntil,Number(m.until)||0);else if(m.kind==='earthquake'){earthquakeControlUntil=Math.max(earthquakeControlUntil,Number(m.until)||0);earthquakeControlSeed=Math.floor(Number(m.seed)||earthquakeControlSeed||1);earthquakeControlStrength=Math.max(earthquakeControlStrength,Math.max(.7,Number(m.strength)||1));knockX+=Number(m.pushX)||0;knockZ+=Number(m.pushZ)||0;}return;}
  if(m.t==='killstreakFx'){handleKillstreakFx(m);return;}
  if(m.t==='equipmentAction'){if(m.accepted===false)recordNetReject('equipment',m.reason||m.action);if(m.action==='begin'&&m.accepted===false&&combatAction.phase===COMBAT_ACTION.EQUIPMENT_AIM)cancelEquipmentAction({notify:false});return;}
  if(m.t==='throwable'){spawnThrowableVisual(m);return;}
  if(m.t==='throwableState'){updateThrowableVisual(m);return;}
  if(m.t==='throwableImpact'){handleThrowableImpact(m);return;}
  if(m.t==='throwAck'){if(m.accepted===false){recordNetReject('throw',m.reason);removeThrowableVisual(m.id);}return;}
  if(m.t==='throwableEnd'){removeThrowableVisual(m.id);return;}
  if(m.t==='flashDetonate'){recordReplayDetonation('flash',m);if(!replayPlayback)soundTacticalDetonation('flash',m);spawnDetonationFx('flash',m);removeThrowableVisual(m.id);return;}
  if(m.t==='smokeDetonate'){if(!replayPlayback)soundTacticalDetonation('smoke',m);spawnSmokeCloud(m);removeThrowableVisual(m.id);return;}
  if(m.t==='flashEffect'){applyFlashEffect(m);return;}
  if(m.t==='explosion'){recordReplayDetonation(m.kind||'sticky',m);if(!replayPlayback)applyExplosionFeedback(m.kind||'sticky',m);const projectile=bullets.get(m.id);if(projectile?.type==='launcher')projectile.root.position.set(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0);if(!replayPlayback)soundTacticalDetonation(m.kind||'sticky',m);spawnDetonationFx(m.kind||'sticky',m);removeBullet(m.id);removeThrowableVisual(m.id);return;}
  if(m.t==='chat'){receiveChatMessage(m);return;}
  if(m.t==='loadout'){applyAuthoritativeLoadout(m);return;}
  if(m.t==='weapon'){const r=remotes.get(m.id);if(r){r.weapon=m.weapon||'pistol';r.swapStartedAt=performance.now();syncRemoteWeapon(r);}return;}
  if(m.t==='reload'){const r=remotes.get(m.id);if(r){r.reloadUntil=Number(m.reloadAt)||0;r.reloadStartedAt=serverNow();r.reloadWeapon=m.weapon||r.weapon;if(r.reloadWeapon!=='shotgun'&&r.reloadUntil)playSpatialCue(reloadSoundId(r.reloadWeapon),r.group.position.x,r.group.position.y+1,r.group.position.z,34,.72);}return;}
  if(m.t==='reloadShell'){const r=remotes.get(m.id);if(r){r.reloadUntil=Number(m.reloadAt)||0;r.reloadStartedAt=r.reloadUntil?serverNow():0;r.reloadWeapon=r.reloadUntil?'shotgun':'';playSpatialCue('reloadShotgun',r.group.position.x,r.group.position.y+1,r.group.position.z,34,.72);}return;}
  if(m.t==='god'){if(typeof m.custom==='boolean')matchCustom=m.custom;if(m.id===clientId){godMode=!!m.enabled;diagnosticsVisualEvent('god_mode_changed',{id:String(clientId||''),self:true,enabled:godMode,team:String(myTeam||'')});syncLobby();syncPauseContext();if(shell.panel===SHELL_PANEL.LOADOUT)syncMatchLoadoutEditor();}else{const row=lobbyParticipants.get(String(m.id||''));if(row)row.godMode=!!m.enabled;const r=remotes.get(m.id);if(r){r.godMode=!!m.enabled;if(r.godRing)r.godRing.visible=r.godMode;diagnosticsVisualEvent('god_mode_changed',{id:String(r.id||''),self:false,enabled:r.godMode,team:String(r.team||''),role:gameplayRelation(r.team,r.bot)});}}renderAdminPlayers();syncLobby();return;}
  if(m.t==='adminRole'){if(m.id===clientId){isMatchAdmin=!!m.enabled;syncPauseContext();if(!isMatchAdmin&&shell.panel===SHELL_PANEL.ADMIN)closeAdminPanel();showToast(isMatchAdmin?'ADMIN PRIVILEGES GRANTED':'ADMIN PRIVILEGES REMOVED');}else{const row=lobbyParticipants.get(String(m.id||''));if(row)row.admin=!!m.enabled;const r=remotes.get(m.id);if(r)r.admin=!!m.enabled;}renderAdminPlayers();syncLobby();return;}
  if(m.t==='teamQueued'){if(m.id===clientId){pendingTeam=m.pendingTeam||'';syncPauseContext();showToast(pendingTeam?`TEAM SWITCH QUEUED · ${teamLabel(pendingTeam)}`:'TEAM SWITCH CANCELED');syncLobby();}return;}
  if(m.t==='matchLobby'){handleMatchLobby(m);return;}
  if(m.t==='match'){applyClientMatchState(m.match);matchCustom=!!m.custom;if(shell.panel===SHELL_PANEL.ADMIN&&m.rulesUpdated&&m.by===clientId)setAdminStatus('');if(matchAllowsLobbyEdits(matchState)){syncLobby();syncRelationshipPresentation();}return;}
  if(m.t==='matchReset'){if(m.customMapDefinition){try{installCustomMapDefinition(m.customMapDefinition,{persist:false,source:'room',quiet:true});}catch(error){showToast(`CUSTOM MAP SYNC FAILED · ${String(error?.message||'invalid map')}`,{priority:3});}}if(m.mapId)setActiveMap(m.mapId,{rebuild:true});if(m.settings)applyWorldSettings(m.settings);if(m.botConfig)botConfig=normalizeBotConfig(m.botConfig);lobbyMatchDraft=null;lobbyMatchDirty=false;lobbyMapDraft='';lobbyMapDirty=false;lobbyLoadoutDraft=null;lobbyClassDrafts=null;lobbyLoadoutDirty=false;lobbyLoadoutRevision=0;lobbyLoadoutAckRevision=0;lobbyKillstreakDraft=[...killstreakSelection];lobbyKillstreakRevision=0;lobbyKillstreakAckRevision=0;lobbyKillstreakSyncPending=false;applyClientMatchState(m.match);matchCustom=!!m.custom;myStats={kills:0,deaths:0};resetKillstreakClientState();const players=m.players||[],bots=m.bots||[],self=players.find(pl=>pl?.id===clientId)||null;if(self){setLocalTeam(self.team||myTeam,{source:'match_reset',refresh:false});pendingTeam='';if(self.activeClassId)activeClassId=normalizeLoadoutClassId(self.activeClassId);pendingClassId=self.pendingClassId?normalizeLoadoutClassId(self.pendingClassId):'';primaryWeapon=PRIMARY_WEAPONS.includes(self.primaryWeapon)?self.primaryWeapon:primaryWeapon;secondaryWeapon=SECONDARY_WEAPONS.includes(self.secondaryWeapon)?self.secondaryWeapon:secondaryWeapon;applyAttachmentState(self);tacticalEquipment=normalizeTactical(self.tactical);lethalEquipment=normalizeLethal(self.lethal);pendingLoadout=null;rememberPrimary(primaryWeapon);rememberSecondary(secondaryWeapon);rememberAttachments(primaryAttachments,secondaryAttachments);rememberEquipment(tacticalEquipment,lethalEquipment);rememberLoadoutClasses(loadoutClasses,activeClassId);}pendingGameSnapshot=gameSnapshot(self,players,bots,m.match?.serverTime);replaceLobbyParticipants(players,bots);syncRelationshipPresentation();if(shell.inLobby||!engineReady){void enterGame(pendingGameSnapshot,{resetRound:true});}else applyGameSnapshot(pendingGameSnapshot,{resetRound:true});return;}
  if(m.t==='kill'){handleKill(m);return;}
  if(m.t==='replaySkip'){if(m.accepted&&Number.isFinite(Number(m.respawnAt)))wastedUntil=Math.min(wastedUntil||Number(m.respawnAt),Number(m.respawnAt));return;}
  if(m.t==='settings'){applyWorldSettings(m.settings||DEFAULT_WORLD_SETTINGS);if(typeof m.custom==='boolean')matchCustom=m.custom;const section=m.section==='advanced'?'advanced':'gameplay';if(shell.panel===SHELL_PANEL.ADMIN){if(m.by===clientId){if(section==='advanced')populateAdminWeapons(worldSettings);else populateAdminGameplay(worldSettings);setAdminStatus('');}else if(activeAdminTab!==section){if(section==='advanced')populateAdminWeapons(worldSettings);else populateAdminGameplay(worldSettings);}}syncLobby();return;}
  if(m.t==='bots'){botConfig=normalizeBotConfig(m.config);syncLobbyBots(m.bots||[]);if(shell.inMatch&&engineReady)syncBotRoster(m.bots||[]);syncLobby();if(shell.panel===SHELL_PANEL.ADMIN){populateAdminBots(botConfig);renderAdminPlayers(true);setAdminStatus('');}return;}
  if(m.t==='notice'){showToast(m.text||'Server notice',{priority:m.tone==='error'?3:1,key:`notice:${m.text||'server'}`});if(shell.panel===SHELL_PANEL.ADMIN)setAdminStatus(m.text||'Server notice',m.tone==='error'?'error':'');return;}
  if(m.t==='pong'){const echoed=Number(m.clientAt)||lastPingLocalAt;if(echoed&&Number.isFinite(Number(m.at))){const received=Date.now(),mid=echoed+(received-echoed)/2,estimate=Number(m.at)-mid;recordNetPong(echoed,received,m.net);serverClockOffset=serverClockOffset*.7+estimate*.3;}return;}
  if(m.t==='health'){if(m.id===clientId){hp=Math.max(0,Math.min(100,Number(m.hp)||0));syncLocalStatus();}else{const r=remotes.get(m.id);if(r)r.hp=Math.max(0,Math.min(100,Number(m.hp)||0));}return;}
  if(m.t==='hit'){handleHit(m);return;}
  if(m.t==='respawn'){handleRespawn(m.player);return;}
}

async function enterGame(snapshot=pendingGameSnapshot,{resetRound=false}={}){
  finishInitialConnectionAttempt();stopIntroMusic();shell.beginConnection('Loading game…');
  if(!(await prepareGameRuntime())){shell.cancelConnection();if(matchAllowsLobbyEdits(matchState))shell.enterLobby();return;}
  if(snapshot)applyGameSnapshot(snapshot,{resetRound});
  await shell.enterMatch();syncPauseContext();disableMenu(false);setStatus('');
  const url=new URL(location.href);url.searchParams.set('room',currentRoom);history.replaceState(null,'',url);onResize();
}

function returnToLobby(){
  if(!shell.inMatch)return;
  if(socket?.readyState!==WebSocket.OPEN||!currentRoom){showToast('LOBBY CONNECTION UNAVAILABLE',{priority:3,key:'lobby-return-unavailable'});return;}
  const button=$('leaveBtn');if(button){button.disabled=true;const label=button.querySelector('span');if(label)label.textContent='Returning…';}
  send({t:'returnLobby'});
}

let lobbyQuitReturnFocusKey='';
function lobbyQuitPromptOpen(){return !!lobbyQuitConfirm&&!lobbyQuitConfirm.classList.contains('hide');}
function openLobbyQuitConfirm(){
  if(!shell.inLobby||!lobbyQuitConfirm)return false;lobbyQuitReturnFocusKey=controllerFocusKey(controllerUiFocus);clearControllerUiEditing();lobbyQuitConfirm.classList.remove('hide');clearControllerUiFocus();
  if(controllerInputActive())requestAnimationFrame(()=>setControllerUiFocus($('lobbyQuitStayBtn')));return true;
}
function closeLobbyQuitConfirm(){
  if(!lobbyQuitPromptOpen())return false;const restore=lobbyQuitReturnFocusKey;lobbyQuitReturnFocusKey='';lobbyQuitConfirm.classList.add('hide');clearControllerUiFocus();
  if(controllerInputActive())requestAnimationFrame(()=>{const list=controllerFocusableElements(),target=(restore&&list.find(el=>controllerFocusKey(el)===restore))||$('lobbyLeaveBtn');if(target)setControllerUiFocus(target);});return true;
}
function confirmLobbyQuit(){if(lobbyQuitConfirm)lobbyQuitConfirm.classList.add('hide');lobbyQuitReturnFocusKey='';leaveMatch();}

function leaveMatch(){
  if(lobbyQuitConfirm)lobbyQuitConfirm.classList.add('hide');if(mapDeleteConfirm)mapDeleteConfirm.classList.add('hide');pendingMapDelete=null;lobbyQuitReturnFocusKey='';cancelInitialConnection('',{silent:true});if(chatOpen)void dismissChat({restorePointer:false});chatMessages.length=0;
  shell.leaveToMenu();disableMenu(false);serverClockOffset=0;lastPingLocalAt=0;resetLocalPredictionHistory();resetRemoteNetworkTiming();clearTimeout(reconnectTimer);if(socket){try{socket.close(1000,'Left match')}catch{}}socket=null;currentRoom='';isMatchAdmin=false;matchOwnerId='';lobbyParticipants.clear();pendingGameSnapshot=null;lobbyMatchDraft=null;lobbyMatchDirty=false;lobbyMapDraft='';lobbyMapDirty=false;lobbyLoadoutDraft=null;lobbyClassDrafts=null;lobbyLoadoutDirty=false;lobbyLoadoutRevision=0;lobbyLoadoutAckRevision=0;syncLobbyHostControlPlacement();applyWorldSettings(DEFAULT_WORLD_SETTINGS);
  resetTouchInput();clearReplayState();clearRemotes();clearTeammateDeathMarkers();clearBullets();clearBulletImpactFx();clearRocketTrailPuffs();clearThrowables();clearTacticalFx();clearSmokeClouds();keys.clear();hp=100;wastedUntil=0;godMode=false;pendingTeam='';matchState=normalizeClientMatch(null);matchCustom=false;loadoutClasses=normalizeLoadoutClasses(preferredLoadoutClasses);activeClassId=normalizeLoadoutClassId(preferredActiveClassId);pendingClassId='';killstreakSelection=normalizeKillstreakSelection(preferredKillstreakSelection);lobbyKillstreakDraft=null;lobbyKillstreakRevision=0;lobbyKillstreakAckRevision=0;lobbyKillstreakSyncPending=false;{const c=loadoutClassById(loadoutClasses,activeClassId);primaryWeapon=c.primaryWeapon;secondaryWeapon=c.secondaryWeapon;primaryAttachments={...c.primaryAttachments};secondaryAttachments={...c.secondaryAttachments};tacticalEquipment=c.tactical;lethalEquipment=c.lethal;}pendingLoadout=null;currentWeapon=primaryWeapon;crouchWanted=false;crouched=false;crouchBlend=0;stopSlide();cancelSprint();viewFeetY=NaN;verticalVelocity=moveVelocityX=moveVelocityZ=0;lastGroundedAt=0;jumpBufferedUntil=0;recoilDebtPitch=recoilDebtYaw=recoilPatternPitch=recoilPatternYaw=0;recoilBurstActive=false;recoilBurstWeapon='';recoilBurstReleaseAt=0;recoilBurstEndedAt=performance.now();weaponKickZ=weaponKickVelocity=0;lastLocalShotAt=0;localShotHeat=Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));localShotHeatAt=Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));localRecoilStep=Object.fromEntries(WEAPON_ORDER.map(name=>[name,-1]));localWeaponShotSequence=Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));traversal=null;ladderState=null;traversalIntentUntil=0;traversalIntentSeq=0;traversalConsumedIntentSeq=0;ammo=freshClientAmmo();equipment=freshClientEquipment(tacticalEquipment,lethalEquipment);reloadRequestPending=false;lastStateSent=0;lastSentState={x:NaN,y:NaN,z:NaN,yaw:NaN,pitch:NaN,ads:false,adsAmount:0,crouched:false,sprinting:false,sliding:false,grounded:true,moveX:0,moveZ:0,ladderId:'',ladderMove:0};pendingWeapon='';reloadUntil=0;reloadWeapon='';reloadStartedAt=0;weaponSwapStartedAt=0;deathAnimStartedAt=0;localMoveAmount=0;landingKick=0;nextFootstepAt=0;footstepSide=0;shotgunPumpStartedAt=0;shotgunPumpSoundPlayed=false;fireReadyAt=freshClientFireReady();akimboReadyAt={left:0,right:0};akimboLeftCycleStartedAt=akimboRightCycleStartedAt=0;akimboCycleSoundPlayed={left:false,right:false};clearFireInput();resetSniperBreath();localEquipmentCooldownUntil=0;lastSimHeartbeat=0;cancelEquipmentAction();killFeed.length=0;bloodSplats.length=0;damageIndicators.length=0;flashUntil=flashPeakUntil=0;hurtUntil=hitUntil=0;blastFeedbackUntil=blastFeedbackPower=blastFeedbackSeed=0;lastShotVisualAt=0;myStats={kills:0,deaths:0};scoreboardOpen=false;killConfirmUntil=0;killConfirmHeadshot=false;killConfirmDistance=0;headshotUntil=0;announcerCurrent=null;announcerQueue.length=0;clearToastNotifications();setAim(false);syncLocalWeaponModel();
  const url=new URL(location.href);url.searchParams.delete('room');history.replaceState(null,'',url);refreshMatches();
}

function normalizeBotConfig(value){const v=value&&typeof value==='object'?value:{};const blueBots=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(v.blueBots)||0))),redBots=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,Math.floor(Number(v.redBots)||0)));const diff=['easy','normal','hard','elite'].includes(String(v.difficulty||'normal').toLowerCase())?String(v.difficulty||'normal').toLowerCase():'normal';return{blueBots,redBots,difficulty:diff};}
function syncBotRoster(list){const incoming=new Set((list||[]).map(b=>b.id));for(const [id,r] of remotes){if(r.bot&&!incoming.has(id))removeRemote(id);}for(const b of list||[])upsertRemote(b,true);syncPauseContext();}
function setAdminStatus(text,tone=''){const el=$('adminStatus');el.textContent=text;el.className=`admin-status ${tone}`;}
let activeAdminTab='gameplay';
function availableAdminTabs(){return [...document.querySelectorAll('[data-admin-tab]')].filter(tab=>!tab.classList.contains('hide'));}
function syncAdminContext(){
  $('adminTitle').textContent='Host Options';
  const liveBots=$('adminBotsCard');
  liveBots?.classList.toggle('hide',!shell.inMatch||!!currentModeSpec().cooperative);
  }
function switchAdminTab(tab){
  const tabs=availableAdminTabs(),requested=tabs.find(btn=>btn.dataset.adminTab===tab);
  activeAdminTab=requested?.dataset.adminTab||tabs[0]?.dataset.adminTab||'match';
  for(const page of document.querySelectorAll('[data-admin-page]'))page.classList.toggle('hide',page.dataset.adminPage!==activeAdminTab);
  for(const b of document.querySelectorAll('[data-admin-tab]')){const active=b.dataset.adminTab===activeAdminTab;b.classList.toggle('active',active);b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;}
  const players=activeAdminTab==='players',closeBtn=$('adminCancelBtn');if(closeBtn)closeBtn.textContent='CLOSE';document.querySelector('.admin-shell').dataset.page=activeAdminTab;if(players){setAdminStatus('');populateAdminBots(botConfig);renderAdminPlayers(true);}
}
function syncAdminBotDraftSummary(){
  const cfg=normalizeBotConfig(botConfig),total=Math.min(MAX_MATCH_BOTS,cfg.blueBots+cfg.redBots);if($('adminBotSummary'))$('adminBotSummary').textContent=`${total}/${MAX_MATCH_BOTS} BOTS`;
}
function populateAdminBots(value=botConfig){
  const cfg=normalizeBotConfig(value);if($('adminBotDifficulty'))$('adminBotDifficulty').value=cfg.difficulty;syncAdminBotDraftSummary();
}
function collectAdminBotConfig(){
  const cfg=normalizeBotConfig(botConfig);return{blueBots:cfg.blueBots,redBots:cfg.redBots,difficulty:String($('adminBotDifficulty')?.value||cfg.difficulty||'normal')};
}
function adjustAdminBotCount(team,delta){
  if(!shell.inMatch||!isMatchAdmin||socket?.readyState!==WebSocket.OPEN||!delta||currentModeSpec().cooperative)return;const cfg=normalizeBotConfig(botConfig),diff=String($('adminBotDifficulty')?.value||cfg.difficulty||'normal'),ffa=normalizeGameMode(matchState.mode)==='ffa';let blue=cfg.blueBots,red=cfg.redBots;
  if(ffa){const total=Math.max(0,Math.min(MAX_MATCH_BOTS,blue+red+Math.sign(delta)));blue=Math.ceil(total/2);red=Math.floor(total/2);}
  else{const normalized=normalizeTeam(team);if(normalized==='red')red=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,red+Math.sign(delta)));else blue=Math.max(0,Math.min(MAX_BOTS_PER_TEAM,blue+Math.sign(delta)));}
  send({t:'adminBots',blueBots:blue,redBots:red,difficulty:diff});setAdminStatus('UPDATING BOTS…');
}
function populateAdminGameplay(value){const x=normalizeWorldSettings(value);$('setRunSpeed').value=x.movement.runSpeed;$('setWalkSpeed').value=x.movement.walkSpeed;$('setJumpHeight').value=x.movement.jumpHeight;$('setGravity').value=x.movement.gravity;$('setRegenDelay').value=(x.combat.regenDelayMs/1000).toFixed(1);$('setRegenRate').value=x.combat.regenPerSecond;$('setRespawnDelay').value=(x.combat.respawnMs/1000).toFixed(1);}
function populateAdminWeapons(value){const x=normalizeWorldSettings(value);for(const name of WEAPON_ORDER){const cap=name[0].toUpperCase()+name.slice(1),w=x.weapons[name];$(`set${cap}Damage`).value=w.damage;$(`set${cap}Speed`).value=w.speed;$(`set${cap}Reload`).value=(w.reloadMs/1000).toFixed(2);$(`set${cap}Cooldown`).value=Math.round(60000/w.cooldownMs);$(`set${cap}Recoil`).value=Math.round(w.recoilScale);}}
function populateAdminSettings(value){populateAdminGameplay(value);populateAdminWeapons(value);populateAdminBots(botConfig);}
function collectAdminGameplayPatch(){return{movement:{runSpeed:$('setRunSpeed').value,walkSpeed:$('setWalkSpeed').value,jumpHeight:$('setJumpHeight').value,gravity:$('setGravity').value},combat:{regenDelayMs:Number($('setRegenDelay').value)*1000,regenPerSecond:$('setRegenRate').value,respawnMs:Number($('setRespawnDelay').value)*1000}};}
function collectAdminWeaponsPatch(){return{weapons:Object.fromEntries(WEAPON_ORDER.map(name=>{const cap=name[0].toUpperCase()+name.slice(1);return[name,{damage:$(`set${cap}Damage`).value,speed:$(`set${cap}Speed`).value,reloadMs:Number($(`set${cap}Reload`).value)*1000,cooldownMs:60000/Math.max(24,Number($(`set${cap}Cooldown`).value)||60),recoilScale:$(`set${cap}Recoil`).value}]}))};}
function adminPlayerSnapshot(){if(shell.inLobby)return lobbyRosterSnapshot(lobbyDisplayMode()).map(r=>({id:r.id,name:r.name,team:r.team,bot:!!r.bot,zombie:!!r.zombie,godMode:!!r.godMode,admin:!!r.admin,self:!!r.self}));return[{id:clientId,name:myName||'You',team:myTeam,bot:false,zombie:false,godMode,admin:isMatchAdmin,self:true},...Array.from(remotes.values()).map(r=>({id:r.id,name:r.name,team:r.team,bot:!!r.bot,zombie:!!r.zombie,godMode:!!r.godMode,admin:!!r.admin,self:false}))].sort((a,b)=>Number(b.self)-Number(a.self)||Number(a.bot)-Number(b.bot)||a.team.localeCompare(b.team)||a.name.localeCompare(b.name));}
function renderAdminPlayers(force=false){
  const root=$('adminPlayerList');if(!root)return;if(!force&&(shell.panel!==SHELL_PANEL.ADMIN||activeAdminTab!=='players'))return;root.innerHTML='';const rows=adminPlayerSnapshot(),spec=currentModeSpec(),editable=!!isMatchAdmin&&shell.inMatch;
  const playerMarkup=pl=>{const owner=pl.id===matchOwnerId,self=!!pl.self,safeId=escapeHtml(pl.id),role=pl.zombie?'ZOMBIE':pl.bot?'BOT':owner?'HOST':pl.admin?'ADMIN':'',roleChip=role?`<span class="admin-role-chip">${role}</span>`:'',godAction=pl.bot?'':`<div class="admin-player-toggle"><span>GOD MODE</span><button aria-checked="${pl.godMode}" aria-label="God Mode for ${escapeHtml(pl.name)}" class="switch-toggle admin-god-toggle ${pl.godMode?'active':''}" data-admin-god="${safeId}" data-controller-key="admin-player:${safeId}:god" role="switch" type="button"><span></span></button></div>`,roleAction=(pl.bot||owner||self)?'':`<button class="btn admin-mini ${pl.admin?'danger':''}" data-admin-role="${safeId}" data-controller-key="admin-player:${safeId}:role">${pl.admin?'REMOVE ADMIN':'MAKE ADMIN'}</button>`;return`<div class="admin-player-row${pl.bot?' bot':''}"><div class="admin-player-identity"><span class="admin-team-dot ${spec.teamBased?teamKey(pl.team):'ffa'}"></span><div><strong>${escapeHtml(pl.name)}${self?' (You)':''}${roleChip}</strong><small>${pl.bot?'AI':spec.teamBased?teamLabel(pl.team):'FFA'}</small></div></div><div class="admin-player-actions">${godAction}${roleAction}</div></div>`;};
  const botControl=(team,count)=>{if(!editable||spec.cooperative)return'';const max=team==='ffa'?MAX_MATCH_BOTS:MAX_BOTS_PER_TEAM;return`<div class="admin-team-bot-control"><span>BOTS</span><button data-admin-bot-step="${team}" data-bot-delta="-1" data-controller-key="admin-bots:${team}:down" type="button"${count<=0?' disabled':''}>−</button><b>${count}</b><button data-admin-bot-step="${team}" data-bot-delta="1" data-controller-key="admin-bots:${team}:up" type="button"${count>=max?' disabled':''}>+</button></div>`;};
  const section=(label,list,team='ffa',botCount=0)=>{const humans=list.filter(x=>!x.bot&&!x.zombie).length,bots=list.filter(x=>x.bot).length,zombies=list.filter(x=>x.zombie).length,meta=zombies?`${humans}P · ${zombies}Z`:`${humans}P · ${bots}B`;return`<section class="admin-team-section ${team==='ffa'?'ffa':teamKey(team)}"><header><div><strong>${label}</strong><small>${meta}</small></div>${botControl(team,botCount)}</header><div class="admin-team-rows">${list.map(playerMarkup).join('')||'<div class="admin-team-empty">No players</div>'}</div></section>`;};
  if(spec.cooperative)root.innerHTML=section('SURVIVORS',rows,'ffa',0);
  else if(!spec.teamBased){const cfg=normalizeBotConfig(botConfig),total=Math.min(MAX_MATCH_BOTS,cfg.blueBots+cfg.redBots);root.innerHTML=section('FREE FOR ALL',rows,'ffa',total);}
  else{const cfg=normalizeBotConfig(botConfig),blue=rows.filter(x=>x.team==='blue'),red=rows.filter(x=>x.team==='red');root.innerHTML=section('ALPHA',blue,'blue',cfg.blueBots)+section('BRAVO',red,'red',cfg.redBots);}
  for(const btn of root.querySelectorAll('[data-admin-god]'))btn.addEventListener('click',()=>{const id=btn.dataset.adminGod,pl=adminPlayerSnapshot().find(x=>x.id===id);if(pl)send({t:'adminPlayer',targetId:id,action:'god',enabled:!pl.godMode});});
  for(const btn of root.querySelectorAll('[data-admin-role]'))btn.addEventListener('click',()=>{const id=btn.dataset.adminRole,pl=adminPlayerSnapshot().find(x=>x.id===id);if(pl&&!pl.self)send({t:'adminPlayer',targetId:id,action:'admin',enabled:!pl.admin});});
  for(const btn of root.querySelectorAll('[data-admin-bot-step]'))btn.addEventListener('click',()=>adjustAdminBotCount(btn.dataset.adminBotStep,Number(btn.dataset.botDelta)||0));
}
function requestTeamChange(team){if(!shell.inMatch||socket?.readyState!==WebSocket.OPEN)return;send({t:'team',team:normalizeTeam(team)});}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
const REMOTE_HIT_FLASH_MS=120;
function createFactionUniformTexture(style='desert'){
  const key=['desert','woodland','urban'].includes(style)?style:'desert',canvas=document.createElement('canvas');canvas.width=canvas.height=128;const ctx=canvas.getContext('2d'),desert=key==='desert',urban=key==='urban';
  ctx.fillStyle=desert?'#e2ded3':urban?'#d9dcda':'#d5d9ce';ctx.fillRect(0,0,128,128);
  let seed=desert?0x51a7:urban?0x7d21:0x9b37;const rnd=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
  const shades=desert?['#c4beb1','#aaa496','#8d887e','#d4cec1']:urban?['#c4c7c4','#9da29f','#747a78','#afb4b1']:['#b7bcae','#92998a','#707867','#c7ccbd'];
  for(let i=0;i<(desert?34:urban?38:40);i++){const x=rnd()*128,y=rnd()*128,rx=7+rnd()*22,ry=4+rnd()*14,rot=rnd()*Math.PI;ctx.save();ctx.translate(x,y);ctx.rotate(rot);ctx.fillStyle=shades[i%shades.length];ctx.globalAlpha=.88;ctx.beginPath();ctx.ellipse(0,0,rx,ry,0,0,Math.PI*2);ctx.fill();ctx.restore();}
  for(let i=0;i<34;i++){const x=rnd()*128,y=rnd()*128,r=1+rnd()*3;ctx.fillStyle=desert?'rgba(77,66,48,.24)':urban?'rgba(35,41,42,.22)':'rgba(38,50,34,.26)';ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();}
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.wrapS=texture.wrapT=THREE.RepeatWrapping;texture.repeat.set(desert?2.2:urban?2.8:2.5,desert?2.8:urban?3.2:3.0);texture.anisotropy=Math.min(4,renderer?.capabilities?.getMaxAnisotropy?.()||1);texture.userData.factionUniform=true;texture.userData.uniformKey=key;return texture;
}
function syncFactionUniformMaterial(material,team,{zombie=false,leg=false}={}){
  if(!material)return;const normalized=normalizeTeam(team),meta=remoteUniformMeta(normalized,zombie);
  if(zombie){if(material.map?.userData?.factionUniform){material.map.dispose?.();material.map=null;material.needsUpdate=true;}material.color?.set(leg?0x34332d:ZOMBIE_BODY_COLOR);material.roughness=leg?.92:.78;material.metalness=0;material.userData.factionUniform='zombie';material.userData.factionTeam='';return;}
  if(!material.map?.userData?.factionUniform||material.map.userData.uniformKey!==meta.pattern){material.map?.dispose?.();material.map=createFactionUniformTexture(meta.pattern);material.needsUpdate=true;}
  material.color?.set(leg?meta.dark:meta.base);material.roughness=leg?.94:.88;material.metalness=0;material.userData.factionUniform=meta.pattern;material.userData.factionTeam=currentModeSpec().teamBased?normalized:'ffa';
}
function syncRemoteBodyVisual(r,now=performance.now()){
  if(!r)return;const bodyMat=r.thermalBaseMaterials?.body||r.body?.material,legLMat=r.thermalBaseMaterials?.legL||r.legL?.material,legRMat=r.thermalBaseMaterials?.legR||r.legR?.material;if(!bodyMat)return;
  const bodyColor=remoteFactionColor(r.team,r.zombie),flashing=now<Number(r.hitFlashUntil||0),flashColor=0xd8d1c0;r.factionColor=bodyColor;
  syncFactionUniformMaterial(bodyMat,r.team,{zombie:r.zombie,leg:false});syncFactionUniformMaterial(legLMat,r.team,{zombie:r.zombie,leg:true});if(legRMat!==legLMat)syncFactionUniformMaterial(legRMat,r.team,{zombie:r.zombie,leg:true});
  for(const material of new Set([bodyMat,legLMat,legRMat]))if(material?.emissive){material.emissive.set(flashing?flashColor:0x000000);material.emissiveIntensity=flashing?.34:1;}
}
function disposeRemoteTag(r){if(!r?.tag)return;r.group.remove(r.tag);r.tag.material?.map?.dispose?.();r.tag.material?.dispose?.();r.tag=null;}
function remoteNameTagVisible(r){if(!r||r.hp<=0)return false;const role=gameplayRelation(r.team,r.bot);return role!==RELATIONSHIP.ENEMY||samePlayerId(r.id,aimedRemoteId);}
function updateRemoteNameTagPresentation(r){
  if(!r?.tag)return;const role=gameplayRelation(r.team,r.bot),visible=remoteNameTagVisible(r);r.tag.visible=visible;if(!visible)return;
  const distance=camera?.position?camera.position.distanceTo(r.group.position):0,enemy=role===RELATIONSHIP.ENEMY,opacity=enemy?.96:THREE.MathUtils.clamp(.96-Math.max(0,distance-24)/220,.56,.96);r.tag.material.opacity=opacity;
}
function syncRemoteRelationshipVisual(r,{forceTag=false,source='relationship'}={}){
  if(!r)return;const role=gameplayRelation(r.team,r.bot),color=relationshipColor(role),label=r.bot&&!r.zombie?`[BOT] ${r.name}`:r.name,tagChanged=forceTag||!r.tag||r.tagColor!==color||r.tagLabel!==label;
  r.relationship=role;r.relationshipColor=color;r.minimapColor=color;
  if(tagChanged){disposeRemoteTag(r);r.tag=makeNameTag(label,color);r.tag.position.set(0,2.18,0);r.group.add(r.tag);r.tagColor=color;r.tagLabel=label;}
  updateRemoteNameTagPresentation(r);
  diagnosticsVisualEvent('remote_relationship_visual',{id:String(r.id||''),team:String(r.team||''),teamLabel:teamLabel(r.team),role,color,source:String(source||'relationship')});
}
function applyRemoteIdentityVisual(r,{team=r?.team,bot=r?.bot,zombie=r?.zombie,name=r?.name,source='identity'}={}){
  if(!r)return;r.team=normalizeTeam(team);r.bot=!!bot;r.zombie=!!zombie;r.name=String(name||r.name||'Player');syncRemoteBodyVisual(r);syncRemoteRelationshipVisual(r,{forceTag:true,source});diagnosticsVisualEvent('remote_identity_visual',{id:String(r.id||''),team:r.team,teamLabel:teamLabel(r.team),factionColor:r.factionColor,bot:r.bot,zombie:r.zombie,source:String(source||'identity')});
}
function syncAdminWeaponEditor(name='assault'){
  const state=$('adminWeaponSelect'),next=WEAPON_ORDER.includes(name)?name:(WEAPON_ORDER[0]||'assault');adminWeaponSelection=next;if(state)state.dataset.value=next;
  for(const button of document.querySelectorAll('[data-admin-weapon-choice]')){const active=button.dataset.adminWeaponChoice===next;button.classList.toggle('active',active);button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;}
  for(const card of document.querySelectorAll('[data-admin-weapon-editor]')){const active=card.dataset.adminWeaponEditor===next;card.hidden=!active;card.inert=!active;}
}
function openAdminPanel(initialTab='gameplay'){if(shell.inMatch&&matchState.status===MATCH_STATUS.ENDED)return;if(!isMatchAdmin){showToast('HOST ACCESS REQUIRED');return;}if(shell.inLobby){syncLobbyHostControlPlacement();if(initialTab==='players'){switchLobbySide('players');return;}switchLobbySide('cheats');switchSubTabs('[data-lobby-cheat-tab]','[data-lobby-cheat-page]','data-lobby-cheat-tab','data-lobby-cheat-page',initialTab==='advanced'?'weapons':'gameplay');return;}syncLobbyHostControlPlacement();syncAdminContext();populateAdminSettings(worldSettings);switchAdminTab(initialTab);syncAdminWeaponEditor(currentAdminWeaponSelection());setAdminStatus('');shell.openPanel(SHELL_PANEL.ADMIN);renderAdminPlayers(true);}
function closeAdminPanel(){shell.closePanel(SHELL_PANEL.ADMIN);}
function saveAdminSettings(section=activeAdminTab){
  if(shell.inLobby){setAdminStatus('');return;}
  if(!isMatchAdmin||socket?.readyState!==WebSocket.OPEN){setAdminStatus('Host connection unavailable.','error');return;}
  if(section==='gameplay'){send({t:'adminSettings',section:'gameplay',patch:collectAdminGameplayPatch()});setAdminStatus('');return;}
  if(section==='players'){const bots=collectAdminBotConfig();if(!bots){setAdminStatus(`Maximum ${MAX_MATCH_BOTS} bots per match.`,'error');return;}send({t:'adminBots',...bots});setAdminStatus('');return;}
  if(section==='advanced'){send({t:'adminSettings',section:'advanced',patch:collectAdminWeaponsPatch()});setAdminStatus('');}
}

function openPause(){if(!shell.inMatch||shell.paused||matchState.status===MATCH_STATUS.ENDED)return;shell.pause('user-pause');}
async function copyInvite(){
  const url=new URL(location.href);url.searchParams.set('room',currentRoom);try{await navigator.clipboard.writeText(url.toString());showToast('Invite copied');}catch{showToast(`Match code: ${currentRoom}`);}
}

function gameSnapshot(self,players=[],bots=[],at=undefined){const stamp=Number(at),mark=p=>p&&Number.isFinite(stamp)&&!Number.isFinite(Number(p.at))?{...p,at:stamp}:p;return {self:mark(self)||null,players:Array.isArray(players)?players.map(mark):[],bots:Array.isArray(bots)?bots.map(mark):[]};}
function applyGameSnapshot(snapshot,{resetRound=false}={}){
  if(!engineReady||!position||!snapshot)return false;
  if(resetRound){clearReplayState();killFeed.length=0;clearBullets();clearRocketTrailPuffs();clearThrowables();clearTacticalFx();clearSmokeClouds();clearKillstreakFx();resetKillstreakClientState();}
  clearRemotes();clearTeammateDeathMarkers();
  const self=snapshot.self||snapshot.players.find(player=>player?.id===clientId)||null;
  if(self)handleRespawn(self);
  for(const player of snapshot.players){if(player?.id&&!samePlayerId(player.id,clientId))upsertRemote(player,true);}
  for(const bot of snapshot.bots)upsertRemote(bot,true);
  syncPauseContext();return true;
}
function currentRemoteViewDelayMs(){return THREE.MathUtils.clamp(remoteViewDelayMs,REMOTE_INTERPOLATION_MIN_MS,REMOTE_INTERPOLATION_MAX_MS);}
function resetRemoteNetworkTiming(){remoteViewDelayMs=REMOTE_INTERPOLATION_MS;remoteDelayMeanMs=REMOTE_INTERPOLATION_MS;remoteDelayJitterMs=0;remoteDelaySamples=0;}
function observeRemoteNetworkTime(value){
  const at=Number(value);if(!Number.isFinite(at))return;
  const age=THREE.MathUtils.clamp(serverNow()-at,0,360);
  if(remoteDelaySamples===0){remoteDelayMeanMs=age;remoteDelayJitterMs=0;remoteViewDelayMs=THREE.MathUtils.clamp(Math.max(REMOTE_INTERPOLATION_MS,age+18),REMOTE_INTERPOLATION_MIN_MS,REMOTE_INTERPOLATION_MAX_MS);}
  else{
    const previousMean=remoteDelayMeanMs;remoteDelayMeanMs=THREE.MathUtils.lerp(remoteDelayMeanMs,age,.08);remoteDelayJitterMs=THREE.MathUtils.lerp(remoteDelayJitterMs,Math.abs(age-previousMean),.12);
    const desired=THREE.MathUtils.clamp(remoteDelayMeanMs+Math.max(18,remoteDelayJitterMs*1.6),REMOTE_INTERPOLATION_MIN_MS,REMOTE_INTERPOLATION_MAX_MS);
    remoteViewDelayMs=THREE.MathUtils.lerp(remoteViewDelayMs,desired,remoteDelaySamples<4?.45:.08);
  }
  remoteDelaySamples=Math.min(100000,remoteDelaySamples+1);
}
function pushRemoteSnapshot(r,player,{reset=false}={}){
  const history=r.snapshots||(r.snapshots=[]),at=Number.isFinite(Number(player.at))?Number(player.at):serverNow();
  const sample={at,x:Number(player.x)||0,y:Number(player.y)||0,z:Number(player.z)||0,yaw:Number(player.yaw)||0,pitch:Number.isFinite(Number(player.pitch))?Number(player.pitch):(Number(r.targetPitch)||0),ads:player.ads??r.ads,crouched:player.crouched??r.crouched,sprinting:player.sprinting??r.sprinting,sliding:player.sliding??r.sliding};
  if(reset)history.length=0;
  const previous=history[history.length-1];
  if(previous&&sample.at<=previous.at){if(Math.abs(sample.at-previous.at)<=2)history[history.length-1]=sample;return sample;}
  history.push(sample);const cutoff=sample.at-REMOTE_HISTORY_MS;while(history.length>2&&(history[0].at<cutoff||history.length>REMOTE_HISTORY_MAX_SAMPLES))history.shift();return sample;
}
function remoteSnapshotAt(r,renderAt){
  const history=r.snapshots||[];if(!history.length)return null;if(history.length===1)return {...history[0]};
  if(renderAt<=history[0].at)return {...history[0]};
  for(let i=1;i<history.length;i++){
    const b=history[i];if(renderAt>b.at)continue;const a=history[i-1],span=Math.max(1,b.at-a.at),t=THREE.MathUtils.clamp((renderAt-a.at)/span,0,1),yawDelta=normalizeAngle(b.yaw-a.yaw);
    return {at:renderAt,x:THREE.MathUtils.lerp(a.x,b.x,t),y:THREE.MathUtils.lerp(a.y,b.y,t),z:THREE.MathUtils.lerp(a.z,b.z,t),yaw:a.yaw+yawDelta*t,pitch:THREE.MathUtils.lerp(Number(a.pitch)||0,Number(b.pitch)||0,t),ads:t<.5?a.ads:b.ads,crouched:t<.5?a.crouched:b.crouched,sprinting:t<.5?a.sprinting:b.sprinting,sliding:t<.5?a.sliding:b.sliding};
  }
  const b=history[history.length-1],a=history[history.length-2],sourceSpan=Math.max(1,b.at-a.at),extra=Math.min(REMOTE_EXTRAPOLATION_MAX_MS,Math.max(0,renderAt-b.at));if(extra<=0)return {...b};
  const seconds=sourceSpan/1000,extrapSec=extra/1000,maxPlanar=Math.max(4,movementSettings.runSpeed*1.35),vx=THREE.MathUtils.clamp((b.x-a.x)/seconds,-maxPlanar,maxPlanar),vz=THREE.MathUtils.clamp((b.z-a.z)/seconds,-maxPlanar,maxPlanar),vy=THREE.MathUtils.clamp((b.y-a.y)/seconds,-13,9),yawRate=THREE.MathUtils.clamp(normalizeAngle(b.yaw-a.yaw)/seconds,-7,7);
  return {at:b.at+extra,x:b.x+vx*extrapSec,y:b.y+vy*extrapSec,z:b.z+vz*extrapSec,yaw:b.yaw+yawRate*extrapSec,pitch:Number(b.pitch)||0,ads:b.ads,crouched:b.crouched,sprinting:b.sprinting,sliding:b.sliding};
}
function makeRemote(player){
  const group=new THREE.Group(),model=new THREE.Group();model.userData.remoteId=String(player.id||'');group.add(model);
  const team=normalizeTeam(player.team);
  const color=new THREE.Color(remoteFactionColor(team,!!player.zombie));
  const mat=new THREE.MeshStandardMaterial({color,roughness:.75,metalness:player.bot?.18:0,emissive:0x000000});
  const skin=new THREE.MeshStandardMaterial({color:player.zombie?0x9ca578:player.bot?0x9faab3:0xe4aa82,roughness:.8});
  const body=new THREE.Mesh(new THREE.CapsuleGeometry(.34,.78,5,9),mat);body.position.y=.94;
  const head=new THREE.Mesh(new THREE.SphereGeometry(.25,12,8),skin);head.position.y=1.66;
  if(player.zombie){const eyeMat=new THREE.MeshStandardMaterial({color:0xff5f32,emissive:0xff3c16,emissiveIntensity:1.8});for(const side of [-1,1]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.035,6,5),eyeMat);eye.position.set(side*.085,.04,-.225);head.add(eye);}}
  const armL=new THREE.Mesh(new THREE.CapsuleGeometry(.105,.52,4,7),skin);const armR=armL.clone();armL.position.set(-.44,1.05,0);armR.position.set(.44,1.05,0);armL.rotation.z=-.12;armR.rotation.z=.12;
  const legMat=new THREE.MeshStandardMaterial({color:player.zombie?0x34332d:player.bot?0x414b52:0x27333d,roughness:.92});
  const legL=new THREE.Mesh(new THREE.CapsuleGeometry(.12,.48,4,7),legMat);const legR=legL.clone();legL.position.set(-.18,.38,0);legR.position.set(.18,.38,0);
  const gunMat=new THREE.MeshStandardMaterial({color:0x252a30,roughness:.5,metalness:.25}),polyMat=new THREE.MeshStandardMaterial({color:0x31373c,roughness:.76,metalness:.10}),woodMat=new THREE.MeshStandardMaterial({color:0x654832,roughness:.84,metalness:.04}),lensMat=new THREE.MeshStandardMaterial({color:0xcfe6ef,roughness:.06,metalness:.08,transparent:true,opacity:.16,emissive:0x10252e,emissiveIntensity:.07,depthWrite:false,side:THREE.DoubleSide});
  const pistol=new THREE.Group();
  const pSlide=new THREE.Mesh(new THREE.BoxGeometry(.12,.075,.30),gunMat);pSlide.position.set(0,.04,.02);
  const pFrame=new THREE.Mesh(new THREE.BoxGeometry(.11,.065,.18),polyMat);pFrame.position.set(0,0,.06);
  const pBarrel=new THREE.Mesh(new THREE.CylinderGeometry(.014,.014,.10,8),gunMat);pBarrel.rotation.x=Math.PI/2;pBarrel.position.set(0,.03,-.13);
  const pGrip=new THREE.Mesh(new THREE.BoxGeometry(.10,.18,.10),polyMat);pGrip.position.set(0,-.10,.15);pGrip.rotation.x=-.30;const pMagRemote=new THREE.Mesh(new THREE.BoxGeometry(.065,.13,.075),gunMat.clone());pMagRemote.position.set(0,-.145,.15);pMagRemote.rotation.x=-.30;
  bakeWeaponGeometry({receivers:[pSlide,pFrame],grips:[pGrip],magazines:[pMagRemote],tubes:[pBarrel],detail:.55});pistol.add(pSlide,pFrame,pBarrel,pGrip,pMagRemote);
  const akimbo1887=new THREE.Group(),akL=new THREE.Group(),akR=new THREE.Group();
  const buildRemote1887=(gun)=>{const recv=new THREE.Mesh(new THREE.BoxGeometry(.11,.09,.24),gunMat.clone()),brl=new THREE.Mesh(new THREE.CylinderGeometry(.015,.015,.54,8),gunMat.clone()),tube=new THREE.Mesh(new THREE.CylinderGeometry(.011,.011,.42,8),gunMat.clone()),fore=new THREE.Mesh(new THREE.BoxGeometry(.09,.07,.18),woodMat.clone()),grip=new THREE.Mesh(new THREE.BoxGeometry(.09,.15,.09),woodMat.clone()),stock=new THREE.Mesh(new THREE.BoxGeometry(.08,.10,.22),woodMat.clone()),lever=new THREE.Mesh(new THREE.TorusGeometry(.045,.008,5,14),gunMat.clone());recv.position.z=-.10;brl.rotation.x=Math.PI/2;brl.position.set(0,.02,-.43);tube.rotation.x=Math.PI/2;tube.position.set(0,-.01,-.39);fore.position.set(0,-.005,-.26);grip.position.set(0,-.09,.04);grip.rotation.x=-.30;stock.position.set(0,-.005,.16);stock.rotation.x=-.10;lever.rotation.x=Math.PI/2;lever.scale.set(1,.7,1);lever.position.set(0,-.07,.01);bakeWeaponGeometry({receivers:[recv],handguards:[fore],grips:[grip],stocks:[stock],tubes:[brl,tube],detail:.55});gun.add(recv,brl,tube,fore,grip,stock,lever);return{brl,stock};};
  const akLParts=buildRemote1887(akL),akRParts=buildRemote1887(akR);akL.position.set(-.32,1.08,-.25);akR.position.set(.32,1.08,-.25);akL.rotation.set(-.08,.14,-.03);akR.rotation.set(-.08,-.14,.03);akimbo1887.add(akL,akR);
  const assault=new THREE.Group();
  const arRecv=new THREE.Mesh(new THREE.BoxGeometry(.12,.085,.26),gunMat.clone()),arHand=new THREE.Mesh(new THREE.BoxGeometry(.11,.07,.20),new THREE.MeshStandardMaterial({color:0x7a6e5a,roughness:.82,metalness:.05})),arBar=new THREE.Mesh(new THREE.CylinderGeometry(.013,.013,.34,8),gunMat.clone()),arStock=new THREE.Mesh(new THREE.BoxGeometry(.10,.10,.16),new THREE.MeshStandardMaterial({color:0x61574a,roughness:.74,metalness:.08})),arGrip=new THREE.Mesh(new THREE.BoxGeometry(.08,.16,.08),gunMat.clone());arRecv.position.set(0,.01,.16);arHand.position.set(0,-.01,-.04);arBar.rotation.x=Math.PI/2;arBar.position.set(0,-.01,-.22);arStock.position.set(0,-.03,.35);arGrip.position.set(0,-.10,.29);arGrip.rotation.x=-.24;const arMagRemote=new THREE.Mesh(new THREE.BoxGeometry(.08,.18,.10),new THREE.MeshStandardMaterial({color:0x676f75,roughness:.62,metalness:.18}));arMagRemote.position.set(0,-.10,.20);arMagRemote.rotation.x=.18;bakeWeaponGeometry({receivers:[arRecv],handguards:[arHand],grips:[arGrip],magazines:[arMagRemote],stocks:[arStock],tubes:[arBar],detail:.55});assault.add(arRecv,arHand,arBar,arStock,arGrip,arMagRemote);assault.visible=false;
  const ump=new THREE.Group();
  const uRecv=new THREE.Mesh(new THREE.BoxGeometry(.12,.10,.24),gunMat.clone()),uFront=new THREE.Mesh(new THREE.BoxGeometry(.10,.07,.14),polyMat.clone()),uBar=new THREE.Mesh(new THREE.CylinderGeometry(.013,.013,.16,8),gunMat.clone()),uGrip=new THREE.Mesh(new THREE.BoxGeometry(.08,.16,.08),polyMat.clone()),uStock=new THREE.Mesh(new THREE.BoxGeometry(.08,.08,.14),new THREE.MeshStandardMaterial({color:0x454b50,roughness:.68,metalness:.12}));uRecv.position.set(0,.01,.16);uFront.position.set(0,-.02,.01);uBar.rotation.x=Math.PI/2;uBar.position.set(0,-.01,-.14);uGrip.position.set(0,-.09,.24);uGrip.rotation.x=-.28;uStock.position.set(0,-.01,.35);const uMagRemote=new THREE.Mesh(new THREE.BoxGeometry(.08,.19,.09),polyMat.clone());uMagRemote.position.set(0,-.10,.17);uMagRemote.rotation.x=.10;bakeWeaponGeometry({receivers:[uRecv],handguards:[uFront],grips:[uGrip],magazines:[uMagRemote],stocks:[uStock],tubes:[uBar],detail:.55});ump.add(uRecv,uFront,uBar,uGrip,uStock,uMagRemote);ump.visible=false;

  const machineGun=new THREE.Group();
  const mgRecvRemote=new THREE.Mesh(new THREE.BoxGeometry(.14,.10,.30),gunMat.clone()),mgHandRemote=new THREE.Mesh(new THREE.BoxGeometry(.12,.08,.24),new THREE.MeshStandardMaterial({color:0x596053,roughness:.76,metalness:.08})),mgBarRemote=new THREE.Mesh(new THREE.CylinderGeometry(.014,.014,.42,8),gunMat.clone()),mgGasRemote=new THREE.Mesh(new THREE.CylinderGeometry(.009,.009,.28,8),polyMat.clone()),mgStockRemote=new THREE.Mesh(new THREE.BoxGeometry(.12,.12,.22),new THREE.MeshStandardMaterial({color:0x596053,roughness:.76,metalness:.08})),mgGripRemote=new THREE.Mesh(new THREE.BoxGeometry(.08,.17,.09),polyMat.clone()),mgBoxRemote=new THREE.Mesh(new THREE.BoxGeometry(.14,.18,.14),new THREE.MeshStandardMaterial({color:0x596053,roughness:.76,metalness:.08}));mgRecvRemote.position.set(0,.01,.16);mgHandRemote.position.set(0,-.01,-.08);mgBarRemote.rotation.x=Math.PI/2;mgBarRemote.position.set(0,-.01,-.32);mgGasRemote.rotation.x=Math.PI/2;mgGasRemote.position.set(0,.02,-.24);mgStockRemote.position.set(0,-.03,.39);mgGripRemote.position.set(0,-.10,.27);mgGripRemote.rotation.x=-.24;mgBoxRemote.position.set(-.025,-.10,.15);
  const mgCarryRearRemoteL=new THREE.Mesh(new THREE.BoxGeometry(.010,.042,.016),polyMat.clone());mgCarryRearRemoteL.position.set(-.030,.080,.08);
  const mgCarryRearRemoteR=mgCarryRearRemoteL.clone();mgCarryRearRemoteR.position.x=.030;
  const mgCarryFrontRemoteL=new THREE.Mesh(new THREE.BoxGeometry(.010,.038,.016),polyMat.clone());mgCarryFrontRemoteL.position.set(-.030,.078,-.05);
  const mgCarryFrontRemoteR=mgCarryFrontRemoteL.clone();mgCarryFrontRemoteR.position.x=.030;
  const mgCarryBarRemote=new THREE.Mesh(new THREE.BoxGeometry(.090,.012,.16),polyMat.clone());mgCarryBarRemote.position.set(0,.104,.01);
  bakeWeaponGeometry({receivers:[mgRecvRemote],handguards:[mgHandRemote],grips:[mgGripRemote],magazines:[mgBoxRemote],rails:[mgCarryBarRemote],stocks:[mgStockRemote],tubes:[mgBarRemote,mgGasRemote],detail:.55});machineGun.add(mgRecvRemote,mgHandRemote,mgBarRemote,mgGasRemote,mgStockRemote,mgGripRemote,mgBoxRemote,mgCarryRearRemoteL,mgCarryRearRemoteR,mgCarryFrontRemoteL,mgCarryFrontRemoteR,mgCarryBarRemote);machineGun.visible=false;
  const shotgun=new THREE.Group();
  const sgRecv=new THREE.Mesh(new THREE.BoxGeometry(.11,.09,.24),gunMat.clone()),sgBar=new THREE.Mesh(new THREE.CylinderGeometry(.015,.015,.58,8),gunMat.clone()),sgTube=new THREE.Mesh(new THREE.CylinderGeometry(.011,.011,.46,8),gunMat.clone()),sgStock=new THREE.Mesh(new THREE.BoxGeometry(.09,.12,.24),woodMat.clone()),sgGrip=new THREE.Mesh(new THREE.BoxGeometry(.09,.15,.09),woodMat.clone());sgRecv.position.set(0,.01,.23);sgBar.rotation.x=Math.PI/2;sgBar.position.set(0,.02,-.09);sgTube.rotation.x=Math.PI/2;sgTube.position.set(0,-.03,-.04);sgStock.position.set(0,-.03,.41);sgGrip.position.set(0,-.11,.33);sgGrip.rotation.x=-.26;const sgPumpRemote=new THREE.Mesh(new THREE.BoxGeometry(.09,.07,.16),woodMat.clone());sgPumpRemote.position.set(0,-.05,.09);bakeWeaponGeometry({receivers:[sgRecv],handguards:[sgPumpRemote],grips:[sgGrip],stocks:[sgStock],tubes:[sgBar,sgTube],detail:.55});shotgun.add(sgRecv,sgBar,sgTube,sgStock,sgGrip,sgPumpRemote);shotgun.visible=false;
  const semiShotgun=new THREE.Group();
  const ssRecv=new THREE.Mesh(new THREE.BoxGeometry(.11,.09,.24),gunMat.clone()),ssHand=new THREE.Mesh(new THREE.BoxGeometry(.09,.07,.16),new THREE.MeshStandardMaterial({color:0x4d5548,roughness:.78,metalness:.08})),ssBar=new THREE.Mesh(new THREE.CylinderGeometry(.014,.014,.48,8),gunMat.clone()),ssTube=new THREE.Mesh(new THREE.CylinderGeometry(.010,.010,.30,8),gunMat.clone()),ssStock=new THREE.Mesh(new THREE.BoxGeometry(.09,.12,.20),new THREE.MeshStandardMaterial({color:0x4d5548,roughness:.78,metalness:.08})),ssGrip=new THREE.Mesh(new THREE.BoxGeometry(.08,.15,.08),gunMat.clone());ssRecv.position.set(0,.01,.22);ssHand.position.set(0,-.04,.06);ssBar.rotation.x=Math.PI/2;ssBar.position.set(0,.01,-.06);ssTube.rotation.x=Math.PI/2;ssTube.position.set(0,-.03,0);ssStock.position.set(0,-.03,.41);ssGrip.position.set(0,-.11,.33);ssGrip.rotation.x=-.25;const ssMagRemote=new THREE.Mesh(new THREE.BoxGeometry(.08,.12,.09),gunMat.clone());ssMagRemote.position.set(0,-.09,.25);bakeWeaponGeometry({receivers:[ssRecv],handguards:[ssHand],grips:[ssGrip],magazines:[ssMagRemote],stocks:[ssStock],tubes:[ssBar,ssTube],detail:.55});semiShotgun.add(ssRecv,ssHand,ssBar,ssTube,ssStock,ssGrip,ssMagRemote);semiShotgun.visible=false;

  const sniper=new THREE.Group();
  const snRecv=new THREE.Mesh(new THREE.BoxGeometry(.11,.08,.30),gunMat.clone()),snHand=new THREE.Mesh(new THREE.BoxGeometry(.08,.07,.22),new THREE.MeshStandardMaterial({color:0x5a5e4a,roughness:.84,metalness:.06})),snBar=new THREE.Mesh(new THREE.CylinderGeometry(.012,.012,.56,8),gunMat.clone()),snStock=new THREE.Mesh(new THREE.BoxGeometry(.09,.12,.24),new THREE.MeshStandardMaterial({color:0x5a5e4a,roughness:.84,metalness:.06})),snScope=new THREE.Mesh(new THREE.CylinderGeometry(.026,.026,.18,14,1,true),gunMat.clone());snRecv.position.set(0,.01,.27);snHand.position.set(0,-.03,.05);snBar.rotation.x=Math.PI/2;snBar.position.set(0,.01,-.11);snStock.position.set(0,-.03,.47);snScope.rotation.x=Math.PI/2;snScope.position.set(0,.08,.27);const snScopeInner=new THREE.Mesh(new THREE.CylinderGeometry(.020,.020,.17,14,1,true),new THREE.MeshStandardMaterial({color:0x090c10,roughness:.96,metalness:.02,side:THREE.BackSide}));snScopeInner.rotation.x=Math.PI/2;snScopeInner.position.copy(snScope.position);const snFrontRing=new THREE.Mesh(new THREE.TorusGeometry(.0225,.0035,8,18),gunMat.clone());snFrontRing.position.set(0,.08,.18);const snRearRing=new THREE.Mesh(new THREE.TorusGeometry(.0225,.0035,8,18),gunMat.clone());snRearRing.position.set(0,.08,.36);const snFrontLens=new THREE.Mesh(new THREE.CircleGeometry(.021,18),lensMat.clone());snFrontLens.position.set(0,.08,.183);const snRearLens=new THREE.Mesh(new THREE.CircleGeometry(.021,18),lensMat.clone());snRearLens.position.set(0,.08,.357);const snScopeMountRear=new THREE.Mesh(new THREE.BoxGeometry(.042,.042,.020),gunMat.clone());snScopeMountRear.position.set(0,.045,.33);const snScopeMountFront=new THREE.Mesh(new THREE.BoxGeometry(.042,.042,.020),gunMat.clone());snScopeMountFront.position.set(0,.045,.22);const sniperBoltRemote=new THREE.Mesh(new THREE.BoxGeometry(.034,.034,.10),gunMat.clone());sniperBoltRemote.position.set(.07,.02,.33);const snMagRemote=new THREE.Mesh(new THREE.BoxGeometry(.07,.11,.085),gunMat.clone());snMagRemote.position.set(0,-.075,.26);snMagRemote.rotation.x=.08;bakeWeaponGeometry({receivers:[snRecv],handguards:[snHand],magazines:[snMagRemote],stocks:[snStock],tubes:[snBar,snScope],detail:.55});sniper.add(snRecv,snHand,snBar,snStock,snScopeMountRear,snScopeMountFront,snScope,snScopeInner,snFrontRing,snRearRing,snFrontLens,snRearLens,sniperBoltRemote,snMagRemote);sniper.visible=false;
  const grenadeLauncher=new THREE.Mesh(new THREE.CylinderGeometry(.065,.065,.68,12),gunMat.clone());addBakedTubeBands(grenadeLauncher,{count:3});grenadeLauncher.rotation.x=Math.PI/2+GRENADE_LAUNCH_PITCH;grenadeLauncher.position.set(.45,1.08,-.40);grenadeLauncher.visible=false;
  const rpg=new THREE.Group(),rpgTubeRemote=new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,.88,12),gunMat.clone());addBakedTubeBands(rpgTubeRemote,{count:3});rpgTubeRemote.rotation.x=Math.PI/2;rpg.add(rpgTubeRemote);rpg.position.set(.38,1.42,-.43);rpg.visible=false;
  const godRing=new THREE.Mesh(new THREE.TorusGeometry(.42,.035,6,28),new THREE.MeshBasicMaterial({color:0xffdd67,transparent:true,opacity:.9}));godRing.rotation.x=Math.PI/2;godRing.position.y=2.03;godRing.visible=!!player.godMode;
  setupWeaponAttachmentVisuals(pistol,'pistol',{muzzle:{x:0,y:.03,z:-.18},mag:pMagRemote,redDot:{sightY:.078,z:.05,mountY:.052,eyeZ:-.09},suppressor:{radius:.019,length:.13,overlap:.012},compensator:{radius:.018,length:.055,overlap:.010},laser:{x:.030,z:-.08,y:-.035,scale:.55},fastMag:{width:.068,depth:.078,y:.035}});
  setupWeaponAttachmentVisuals(akL,'akimbo1887',{muzzle:{x:0,y:.02,z:-.70},barrelMesh:akLParts.brl,stockBaseParts:[akLParts.stock],suppressor:{radius:.018,length:.12,overlap:.010},laser:{x:.030,z:-.28,y:-.035,scale:.55},lightweightStock:{z:.22,y:-.01,width:.075},fastMag:{z:-.02,y:-.10,width:.065}});
  setupWeaponAttachmentVisuals(akR,'akimbo1887',{muzzle:{x:0,y:.02,z:-.70},barrelMesh:akRParts.brl,stockBaseParts:[akRParts.stock],suppressor:{radius:.018,length:.12,overlap:.010},laser:{x:.030,z:-.28,y:-.035,scale:.55},lightweightStock:{z:.22,y:-.01,width:.075},fastMag:{z:-.02,y:-.10,width:.065}});
  setupWeaponAttachmentVisuals(assault,'assault',{muzzle:{x:0,y:-.01,z:-.39},mag:arMagRemote,barrelMesh:arBar,stockBaseParts:[arStock],redDot:{sightY:.080,z:.105,mountY:.052,eyeZ:-.09},holoSight:{sightY:.094,z:.105,mountY:.052,eyeZ:-.09},combatOptic:{sightY:.106,z:.145,mountY:.052,eyeZ:-.09,length:.125},thermalScope4x:{sightY:.106,z:.145,mountY:.052,eyeZ:-.09,length:.125,radius:.025},thermalScope6x:{sightY:.110,z:.150,mountY:.052,eyeZ:-.09,length:.140,radius:.027,long:true},suppressor:{radius:.020,length:.15,overlap:.013},compensator:{radius:.019,length:.065,overlap:.010},verticalGrip:{z:-.07,y:-.10},angledGrip:{z:-.06,y:-.095},laser:{x:.040,z:-.06,y:-.090,scale:.65},lightweightStock:{z:.41,y:-.03,width:.10},fullStock:{z:.39,y:-.03,width:.11},compactStock:{z:.30,y:-.01,width:.075},fastMag:{width:.082,depth:.10,y:.05}});
  setupWeaponAttachmentVisuals(ump,'ump',{muzzle:{x:0,y:-.01,z:-.22},mag:uMagRemote,barrelMesh:uBar,stockBaseParts:[uStock],redDot:{sightY:.078,z:.095,mountY:.050,eyeZ:-.09},holoSight:{sightY:.092,z:.095,mountY:.050,eyeZ:-.09},thermalScope4x:{sightY:.094,z:.105,mountY:.050,eyeZ:-.09,length:.120,radius:.024},thermalScope6x:{sightY:.098,z:.110,mountY:.050,eyeZ:-.09,length:.135,radius:.026,long:true},suppressor:{radius:.020,length:.13,overlap:.012},compensator:{radius:.019,length:.055,overlap:.010},verticalGrip:{z:-.01,y:-.10},angledGrip:{z:0,y:-.095},laser:{x:.040,z:0,y:-.090,scale:.65},lightweightStock:{z:.39,y:-.01,width:.085},fullStock:{z:.37,y:-.015,width:.095},compactStock:{z:.29,y:0,width:.07},fastMag:{width:.082,depth:.09,y:.05}});
  setupWeaponAttachmentVisuals(machineGun,'machineGun',{muzzle:{x:0,y:-.01,z:-.53},mag:mgBoxRemote,barrelMesh:mgBarRemote,stockBaseParts:[mgStockRemote],redDot:{sightY:.090,z:.110,mountY:.062,eyeZ:-.10},holoSight:{sightY:.106,z:.110,mountY:.062,eyeZ:-.10},combatOptic:{sightY:.119,z:.150,mountY:.062,eyeZ:-.10,length:.135},thermalScope4x:{sightY:.119,z:.150,mountY:.062,eyeZ:-.10,length:.135,radius:.026},thermalScope6x:{sightY:.123,z:.155,mountY:.062,eyeZ:-.10,length:.150,radius:.028,long:true},suppressor:{radius:.023,length:.18,overlap:.015},compensator:{radius:.021,length:.075,overlap:.011},verticalGrip:{z:-.10,y:-.11},angledGrip:{z:-.09,y:-.105},laser:{x:.045,z:-.09,y:-.100,scale:.70},bipod:{z:-.13,y:-.16,scale:.72},lightweightStock:{z:.47,y:-.03,width:.12},fullStock:{z:.45,y:-.03,width:.13},fastMag:{width:.14,depth:.14,y:.04}});
  setupWeaponAttachmentVisuals(shotgun,'shotgun',{muzzle:{x:0,y:.02,z:-.38},barrelMesh:sgBar,redDot:{sightY:.075,z:.12,mountY:.050,eyeZ:-.09},thermalScope4x:{sightY:.082,z:.125,mountY:.050,eyeZ:-.09,length:.115,radius:.022},thermalScope6x:{sightY:.086,z:.130,mountY:.050,eyeZ:-.09,length:.130,radius:.024,long:true},suppressor:{radius:.018,length:.13,overlap:.010},shotgunChoke:{radius:.018,length:.065,overlap:.010},laser:{x:.038,z:-.12,y:-.035,scale:.65}});
  setupWeaponAttachmentVisuals(semiShotgun,'semiShotgun',{muzzle:{x:0,y:.01,z:-.30},mag:ssMagRemote,barrelMesh:ssBar,redDot:{sightY:.080,z:.165,mountY:.050,eyeZ:-.09},holoSight:{sightY:.096,z:.165,mountY:.050,eyeZ:-.09},combatOptic:{sightY:.108,z:.205,mountY:.050,eyeZ:-.09,length:.125},shotgunChoke:{radius:.017,length:.065,overlap:.010},laser:{x:.038,z:-.06,y:-.045,scale:.65},fastMag:{width:.082,depth:.09,y:.035}});
  setupWeaponAttachmentVisuals(sniper,'sniper',{muzzle:{x:0,y:.01,z:-.39},mag:snMagRemote,barrelMesh:snBar,precisionScope6x:{z:.27,y:.08,radius:.029,kind:'precision'},longRangeScope8x:{z:.27,y:.08,radius:.029,kind:'long'},thermalScope4x:{z:.27,y:.08,radius:.029,kind:'thermal'},thermalScope6x:{z:.27,y:.08,radius:.029,kind:'thermal-long'},laser:{x:.035,z:-.08,y:-.035,scale:.65},suppressor:{radius:.020,length:.17,overlap:.014},fastMag:{width:.072,depth:.088,y:.03}});
  setupWeaponAttachmentVisuals(rpg,'rpg',{thermalScope4x:{sightY:.095,z:.050,mountY:.060,eyeZ:-.09,length:.125,radius:.025},thermalScope6x:{sightY:.100,z:.055,mountY:.060,eyeZ:-.09,length:.140,radius:.027,long:true},laser:{x:.045,z:-.12,y:-.035,scale:.75}});
  model.add(body,head,armL,armR,legL,legR,pistol,akimbo1887,assault,ump,machineGun,shotgun,semiShotgun,sniper,grenadeLauncher,rpg,godRing);group.position.set(player.x||0,player.y||0,player.z||0);scene.add(group);
  const initialRelation=gameplayRelation(team,!!player.bot),initialRelationColor=relationshipColor(initialRelation),tagLabel=player.bot&&!player.zombie?`[BOT] ${player.name||'Bot'}`:(player.name||'Player'),tag=makeNameTag(tagLabel,initialRelationColor);tag.position.set(0,2.18,0);group.add(tag);
  const now=performance.now();
  const remote={id:player.id,name:player.name||'Player',team,bot:!!player.bot,zombie:!!player.zombie,factionColor:remoteFactionColor(team,!!player.zombie),relationship:initialRelation,relationshipColor:initialRelationColor,minimapColor:initialRelationColor,tagColor:initialRelationColor,tagLabel,attackAt:Number(player.attackAt)||0,weapon:player.weapon||'pistol',primaryWeapon:PRIMARY_WEAPONS.includes(player.primaryWeapon)?player.primaryWeapon:'assault',secondaryWeapon:SECONDARY_WEAPONS.includes(player.secondaryWeapon)?player.secondaryWeapon:'pistol',primaryAttachments:normalizeWeaponAttachments(PRIMARY_WEAPONS.includes(player.primaryWeapon)?player.primaryWeapon:'assault',player.primaryAttachments),secondaryAttachments:normalizeWeaponAttachments(SECONDARY_WEAPONS.includes(player.secondaryWeapon)?player.secondaryWeapon:'pistol',player.secondaryAttachments),group,model,tag,target:new THREE.Vector3(player.x||0,player.y||0,player.z||0),targetYaw:player.yaw||0,targetPitch:Number(player.pitch)||0,renderPitch:Number(player.pitch)||0,hp:player.hp??100,kills:Number(player.kills)||0,deaths:Number(player.deaths)||0,armL,armR,legL,legR,body,head,pistol,akimbo1887,akimboLeft:akL,akimboRight:akR,akimboCycleStartedAt:{left:0,right:0},assault,ump,machineGun,shotgun,semiShotgun,sniper,grenadeLauncher,rpg,godRing,godMode:!!player.godMode,admin:!!player.admin,lastSeen:now,lastNetAt:now,lastNetServerAt:Number.isFinite(Number(player.at))?Number(player.at):serverNow(),lastNetX:player.x||0,lastNetY:player.y||0,lastNetZ:player.z||0,snapshots:[],moveSpeed:0,airborne:false,ads:!!player.ads,crouched:!!player.crouched,sprinting:!!player.sprinting,sliding:!!player.sliding,crouchBlend:player.crouched?1:0,sprintBlend:player.sprinting?1:0,slideBlend:player.sliding?1:0,animPhase:Math.random()*Math.PI*2,deathPose:player.hp<=0?1:0,reloadUntil:Number(player.reloadAt)||0,reloadStartedAt:0,reloadWeapon:player.reloadWeapon||'',swapStartedAt:0,fireKickUntil:0,revealedUntil:0,hitFlashUntil:0,nextFootstepAt:now+300+Math.random()*260,footstepSide:Math.random()<.5?0:1,traversal:player.traversal?traversalPlanFromServer({id:player.id,accepted:true,...player.traversal}):null,ladder:player.ladder?ladderStateFromServer(player.ladder):null};tag.visible=remote.hp>0&&modeFriendly(team);
  syncRemoteBodyVisual(remote,now);syncRemoteWeapon(remote);return remote;
}
function makeNameTag(name,color){
  const c=document.createElement('canvas');c.width=512;c.height=96;const x=c.getContext('2d');x.clearRect(0,0,c.width,c.height);x.textBaseline='middle';x.textAlign='center';x.font='800 34px system-ui';x.lineWidth=6;x.strokeStyle='rgba(0,0,0,.82)';x.strokeText(name,256,48);x.fillStyle=color;x.fillText(name,256,48);
  const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.minFilter=THREE.LinearFilter;tex.magFilter=THREE.LinearFilter;const sprite=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true,opacity:.92,depthTest:true,depthWrite:false,toneMapped:false}));sprite.scale.set(1.45,.27,1);return sprite;
}
function getTeammateDeathSkullTexture(){
  if(teammateDeathSkullTexture)return teammateDeathSkullTexture;const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.clearRect(0,0,128,128);x.fillStyle='#fff';x.beginPath();x.arc(64,50,28,0,Math.PI*2);x.fill();x.fillRect(46,67,36,22);x.fillStyle='#101416';x.beginPath();x.arc(54,49,7,0,Math.PI*2);x.arc(74,49,7,0,Math.PI*2);x.fill();x.beginPath();x.moveTo(64,57);x.lineTo(58,68);x.lineTo(70,68);x.closePath();x.fill();x.fillStyle='#101416';for(const px of [52,60,68,76])x.fillRect(px,77,5,12);const tex=new THREE.CanvasTexture(c);tex.colorSpace=THREE.SRGBColorSpace;tex.minFilter=THREE.LinearFilter;tex.magFilter=THREE.LinearFilter;tex.userData.preserveTransient=true;teammateDeathSkullTexture=tex;return tex;
}
function teammateDeathMarkerAlpha(marker,now=performance.now()){if(!marker)return 0;const remaining=Number(marker.expiresAt||0)-now;if(remaining<=0)return 0;return remaining>1000?1:THREE.MathUtils.clamp(remaining/1000,0,1);}
function removeTeammateDeathMarker(marker,reason='expired'){
  const i=teammateDeathMarkers.indexOf(marker);if(i>=0)teammateDeathMarkers.splice(i,1);if(marker?.sprite){try{scene?.remove(marker.sprite);}catch{}disposeMaterialResources(marker.sprite.material);}if(marker)diagnosticsVisualEvent('teammate_death_marker_removed',{actorId:String(marker.actorId||''),reason:String(reason||'expired')});
}
function clearTeammateDeathMarkers(){for(const marker of [...teammateDeathMarkers])removeTeammateDeathMarker(marker,'clear');}
function createTeammateDeathMarker(r,player={}){
  if(!r||r.zombie)return null;const role=gameplayRelation(r.team,r.bot);if(role===RELATIONSHIP.ENEMY||role===RELATIONSHIP.SELF)return null;const now=performance.now(),recent=teammateDeathMarkers.find(marker=>samePlayerId(marker.actorId,r.id)&&now-marker.createdAt<750);if(recent)return recent;const x=Number.isFinite(Number(player.x))?Number(player.x):r.group.position.x,y=Number.isFinite(Number(player.y))?Number(player.y):r.group.position.y,z=Number.isFinite(Number(player.z))?Number(player.z):r.group.position.z,color=relationshipColor(role),material=new THREE.SpriteMaterial({map:getTeammateDeathSkullTexture(),color,transparent:true,opacity:.82,depthTest:false,depthWrite:false,toneMapped:false}),sprite=new THREE.Sprite(material);sprite.position.set(x,y+1.25,z);sprite.scale.set(.52,.52,1);sprite.renderOrder=40;sprite.visible=!replayPlayback;scene?.add(sprite);const marker={id:`death-${String(r.id)}-${Math.round(now)}`,actorId:String(r.id||''),name:String(r.name||''),team:normalizeTeam(r.team),bot:!!r.bot,role,color,x,y,z,createdAt:now,expiresAt:now+4000,sprite};teammateDeathMarkers.push(marker);while(teammateDeathMarkers.length>20)removeTeammateDeathMarker(teammateDeathMarkers[0],'limit');diagnosticsVisualEvent('teammate_death_marker_created',{actorId:marker.actorId,name:marker.name,team:marker.team,teamLabel:teamLabel(marker.team),role,color,x:diagnosticsRound(x,3),y:diagnosticsRound(y,3),z:diagnosticsRound(z,3),lifetimeMs:4000});return marker;
}
function updateTeammateDeathMarkers(now=performance.now()){
  for(const marker of [...teammateDeathMarkers]){if(now>=marker.expiresAt){removeTeammateDeathMarker(marker,'expired');continue;}const role=relationshipFor({viewerTeam:myTeam,actorTeam:marker.team,teamBased:currentModeSpec().teamBased,self:false,bot:marker.bot});if(role===RELATIONSHIP.ENEMY){removeTeammateDeathMarker(marker,'relationship');continue;}const alpha=teammateDeathMarkerAlpha(marker,now),sprite=marker.sprite;if(sprite){sprite.visible=alpha>0;sprite.material.opacity=.82*alpha;if(camera?.position){const distance=camera.position.distanceTo(sprite.position),size=.48+THREE.MathUtils.clamp((distance-15)/160,0,.28);sprite.scale.set(size,size,1);}}}
}
function replayEnvironmentSnapshot(){
  return{exposure:Number(renderer?.toneMappingExposure)||1.05,sunIntensity:Number(worldSunLight?.intensity)||2.15,hemiIntensity:Number(worldHemiLight?.intensity)||2.2};
}
function replayActorSnapshotLocal(){
  if(!position)return null;return{id:String(clientId),name:String(myName||'You'),team:normalizeTeam(myTeam),bot:false,zombie:false,x:Number(position.x)||0,y:Number(position.y)||0,z:Number(position.z)||0,yaw:Number(yaw)||0,pitch:Number(pitch)||0,hp:Number(hp)||0,weapon:WEAPON_SPECS[currentWeapon]?currentWeapon:'pistol',ads:!!adsWanted,crouched:!!crouched,sprinting:!!sprinting,sliding:!!sliding};
}
function replayActorSnapshotRemote(r){
  if(!r)return null;return{id:String(r.id||''),name:String(r.name||'Player'),team:normalizeTeam(r.team),bot:!!r.bot,zombie:!!r.zombie,x:Number(r.group?.position?.x)||0,y:Number(r.group?.position?.y)||0,z:Number(r.group?.position?.z)||0,yaw:Number(r.group?.rotation?.y)||Number(r.targetYaw)||0,pitch:Number.isFinite(Number(r.renderPitch))?Number(r.renderPitch):(Number(r.targetPitch)||0),hp:Number(r.hp)||0,weapon:WEAPON_SPECS[r.weapon]?r.weapon:'pistol',ads:!!r.ads,crouched:!!r.crouched,sprinting:!!r.sprinting,sliding:!!r.sliding};
}
function pruneReplayBuffers(now=serverNow()){
  const cutoff=now-REPLAY_HISTORY_MS;while(replayHistory.length&&replayHistory[0].at<cutoff)replayHistory.shift();while(replayHistory.length>REPLAY_MAX_FRAMES)replayHistory.shift();const eventCutoff=now-REPLAY_EVENT_HISTORY_MS;while(replayEvents.length&&replayEvents[0].at<eventCutoff)replayEvents.shift();
}
function captureReplayFrame(force=false){
  if(!shell.inMatch||!position||replayPlayback)return;const perf=performance.now();if(!force&&perf-replayLastCaptureAt<REPLAY_SAMPLE_MS)return;replayLastCaptureAt=perf;const at=serverNow(),actors=[];const self=replayActorSnapshotLocal();if(self)actors.push(self);for(const r of remotes.values()){const actor=replayActorSnapshotRemote(r);if(actor)actors.push(actor);}replayHistory.push({at,actors,environment:replayEnvironmentSnapshot()});pruneReplayBuffers(at);
}
function replayEventTime(m){for(const value of [m?.at,m?.bornAt,m?.startedAt]){const n=Number(value);if(Number.isFinite(n)&&n>0)return n;}return serverNow();}
function recordReplayEvent(event){if(!event)return;replayEvents.push(event);pruneReplayBuffers(Number(event.at)||serverNow());}
function recordReplayShot(m){
  if(!m||!shotPacketPrimary(m))return;recordReplayEvent({type:'shot',at:replayEventTime(m),ownerId:String(m.ownerId||''),weapon:WEAPON_SPECS[m.weapon]?m.weapon:'pistol',hand:m.hand==='left'?'left':'right',suppressed:!!m.suppressed,x:Number(m.x)||0,y:Number(m.y)||0,z:Number(m.z)||0});
}
function recordReplayDetonation(kind,m){
  if(!m)return;recordReplayEvent({type:'detonation',at:replayEventTime(m),id:String(m.id||''),kind:String(kind||m.kind||'frag'),x:Number(m.x)||0,y:Number(m.y)||0,z:Number(m.z)||0,radius:Math.max(0,Number(m.radius)||0)});
}
function replayFramesForKill(killAt){
  const start=killAt-REPLAY_PRE_MS,end=killAt+REPLAY_POST_MS,inside=replayHistory.filter(frame=>frame.at>=start&&frame.at<=end);if(replayHistory.length){const before=[...replayHistory].reverse().find(frame=>frame.at<start);if(before)inside.unshift(before);const after=replayHistory.find(frame=>frame.at>end);if(after)inside.push(after);}return inside;
}
function replayActorMap(frame){const out=new Map();for(const actor of frame?.actors||[])out.set(String(actor.id||''),actor);return out;}
function replayFramePairAt(playAt){
  const frames=replayPlayback?.frames||[];if(!frames.length)return{a:null,b:null,t:0};let a=frames[0],b=frames[frames.length-1];if(playAt<=a.at)return{a,b:a,t:0};if(playAt>=b.at)return{a:b,b,t:0};for(let i=1;i<frames.length;i++){if(playAt<=frames[i].at){a=frames[i-1];b=frames[i];break;}}const span=Math.max(1,b.at-a.at),t=THREE.MathUtils.clamp((playAt-a.at)/span,0,1);return{a,b,t};
}
function replayActorsAt(playAt){
  const {a,b,t}=replayFramePairAt(playAt);if(!a)return new Map();const am=replayActorMap(a),bm=replayActorMap(b),out=new Map();for(const id of new Set([...am.keys(),...bm.keys()])){const av=am.get(id),bv=bm.get(id);if(!av){out.set(id,{...bv});continue;}if(!bv){out.set(id,{...av});continue;}const yawDelta=normalizeAngle((Number(bv.yaw)||0)-(Number(av.yaw)||0));out.set(id,{...bv,x:THREE.MathUtils.lerp(Number(av.x)||0,Number(bv.x)||0,t),y:THREE.MathUtils.lerp(Number(av.y)||0,Number(bv.y)||0,t),z:THREE.MathUtils.lerp(Number(av.z)||0,Number(bv.z)||0,t),yaw:(Number(av.yaw)||0)+yawDelta*t,pitch:THREE.MathUtils.lerp(Number(av.pitch)||0,Number(bv.pitch)||0,t),hp:t<.5?av.hp:bv.hp,weapon:t<.5?av.weapon:bv.weapon,ads:t<.5?av.ads:bv.ads,crouched:t<.5?av.crouched:bv.crouched,sprinting:t<.5?av.sprinting:bv.sprinting,sliding:t<.5?av.sliding:bv.sliding});}return out;
}
function replayEnvironmentAt(playAt){
  const {a,b,t}=replayFramePairAt(playAt),ae=a?.environment,be=b?.environment;if(!ae&&!be)return null;if(!ae)return{...be};if(!be)return{...ae};return{exposure:THREE.MathUtils.lerp(Number(ae.exposure)||1.05,Number(be.exposure)||1.05,t),sunIntensity:THREE.MathUtils.lerp(Number(ae.sunIntensity)||2.15,Number(be.sunIntensity)||2.15,t),hemiIntensity:THREE.MathUtils.lerp(Number(ae.hemiIntensity)||2.2,Number(be.hemiIntensity)||2.2,t)};
}
function applyReplayEnvironment(env){if(!env)return;if(renderer&&Number.isFinite(env.exposure))renderer.toneMappingExposure=env.exposure;if(worldSunLight&&Number.isFinite(env.sunIntensity))worldSunLight.intensity=env.sunIntensity;if(worldHemiLight&&Number.isFinite(env.hemiIntensity))worldHemiLight.intensity=env.hemiIntensity;}
function replayTiming(kind,killAt){
  const clipStartAt=killAt-REPLAY_PRE_MS,clipEndAt=killAt+REPLAY_POST_MS,final=kind==='final',slowRate=final?REPLAY_FINAL_SLOW_RATE:1,slowStartAt=final?Math.max(clipStartAt,killAt-REPLAY_FINAL_SLOW_PRE_MS):killAt,slowEndAt=final?Math.min(clipEndAt,killAt+REPLAY_FINAL_SLOW_POST_MS):killAt,normalBeforeMs=Math.max(0,slowStartAt-clipStartAt),slowTimelineMs=final?Math.max(0,slowEndAt-slowStartAt):0,slowWallMs=slowTimelineMs/Math.max(.05,slowRate),normalAfterMs=Math.max(0,clipEndAt-slowEndAt),playbackDurationMs=normalBeforeMs+slowWallMs+normalAfterMs;return{clipStartAt,clipEndAt,slowStartAt,slowEndAt,slowRate,normalBeforeMs,slowTimelineMs,slowWallMs,normalAfterMs,playbackDurationMs};
}
function replayPlayAtFromElapsed(replay,elapsed){
  if(elapsed<=replay.normalBeforeMs)return replay.clipStartAt+elapsed;if(elapsed<=replay.normalBeforeMs+replay.slowWallMs)return replay.slowStartAt+(elapsed-replay.normalBeforeMs)*replay.slowRate;return Math.min(replay.clipEndAt,replay.slowEndAt+(elapsed-replay.normalBeforeMs-replay.slowWallMs));
}
function replayPlaybackRateAtElapsed(replay,elapsed){return replay.slowTimelineMs>0&&elapsed>=replay.normalBeforeMs&&elapsed<replay.normalBeforeMs+replay.slowWallMs?replay.slowRate:1;}
function syncReplayRemoteWeapon(r,weapon){
  if(!r)return;const liveWeapon=r.weapon;r.weapon=WEAPON_SPECS[weapon]?weapon:'pistol';syncRemoteWeapon(r);r.weapon=liveWeapon;
}
function syncReplayActorVisual(r,actor){
  if(!r||!actor)return;const bodyMat=r.thermalBaseMaterials?.body||r.body?.material,legLMat=r.thermalBaseMaterials?.legL||r.legL?.material,legRMat=r.thermalBaseMaterials?.legR||r.legR?.material,team=normalizeTeam(actor.team),zombie=!!actor.zombie;
  syncFactionUniformMaterial(bodyMat,team,{zombie,leg:false});syncFactionUniformMaterial(legLMat,team,{zombie,leg:true});if(legRMat!==legLMat)syncFactionUniformMaterial(legRMat,team,{zombie,leg:true});for(const material of new Set([bodyMat,legLMat,legRMat]))if(material?.emissive){material.emissive.set(0x000000);material.emissiveIntensity=1;}syncReplayRemoteWeapon(r,actor.weapon);if(r.tag)r.tag.visible=false;if(r.godRing)r.godRing.visible=false;
}
function replaySetActorPose(r,actor,{cameraActor=false}={}){
  if(!r?.group||!actor)return;r.group.visible=!cameraActor;r.group.position.set(Number(actor.x)||0,Number(actor.y)||0,Number(actor.z)||0);r.group.rotation.y=Number(actor.yaw)||0;syncReplayActorVisual(r,actor);const dead=Number(actor.hp)<=0,dp=dead?1:0;r.model.rotation.z=1.34*dp;r.model.rotation.x=.10*dp;r.model.position.y=-.18*dp;r.model.scale.y=actor.crouched?CROUCH_HEIGHT/PLAYER_HEIGHT:1;
}
function restoreRemoteAfterReplay(r){
  if(!r?.group)return;r.group.visible=true;r.group.position.copy(r.target);r.group.rotation.y=Number(r.targetYaw)||0;const dp=Number(r.hp)<=0?1:0;r.deathPose=dp;r.model.rotation.z=1.34*dp;r.model.rotation.x=.10*dp;r.model.position.y=-.18*dp;r.model.scale.y=r.crouched?CROUCH_HEIGHT/PLAYER_HEIGHT:1;syncRemoteBodyVisual(r,performance.now());syncRemoteWeapon(r);syncRemoteRelationshipVisual(r,{forceTag:false,source:'replay_restore'});if(r.godRing)r.godRing.visible=!!r.godMode;
}
function scheduleReplayFromKill(m,kind){
  if(!m?.attacker?.id||!m?.victim?.id||currentModeSpec().cooperative)return false;const final=kind==='final';if(!final&&samePlayerId(m.attacker.id,m.victim.id))return false;if(final&&replayPlayback?.kind==='final')return false;if(final&&replayPlayback?.kind==='killcam')stopReplayPlayback({reason:'final-override',sendSkip:false});if(replayPending?.kind==='final'&&!final)return false;const killAt=Number.isFinite(Number(m.at))?Number(m.at):serverNow();captureReplayFrame(true);replayPending={kind:final?'final':'killcam',killAt,readyAt:performance.now()+REPLAY_POST_MS,attacker:{...m.attacker},victim:{...m.victim},weapon:String(m.weapon||'pistol'),headshot:!!m.headshot,distance:Math.max(0,Number(m.distance)||0)};diagnosticsVisualEvent('replay_scheduled',{kind:replayPending.kind,attackerId:String(m.attacker.id),victimId:String(m.victim.id),killAt,postCaptureMs:REPLAY_POST_MS});hudLastDraw=0;return true;
}
function maybeStartPendingReplay(now=performance.now()){
  const pending=replayPending;if(!pending||replayPlayback||now<pending.readyAt)return false;const frames=replayFramesForKill(pending.killAt),killerId=String(pending.attacker.id||''),hasKiller=frames.some(frame=>(frame.actors||[]).some(actor=>samePlayerId(actor.id,killerId)));replayPending=null;if(frames.length<2||!hasKiller){if(pending.kind==='killcam'&&socket?.readyState===WebSocket.OPEN)send({t:'replaySkip'});diagnosticsVisualEvent('replay_unavailable',{kind:pending.kind,frames:frames.length,killerId});return false;}return startReplayPlayback(pending,frames);
}
function startReplayPlayback(descriptor,frames){
  if(replayPlayback)stopReplayPlayback({reason:'replace',sendSkip:false});const killerId=String(descriptor.attacker.id||''),localFirst=frames.flatMap(frame=>frame.actors||[]).find(actor=>samePlayerId(actor.id,clientId)),returnPaused=!!shell.paused||!!shell.panel,timing=replayTiming(descriptor.kind,descriptor.killAt);for(const r of remotes.values()){restoreRemoteThermalSignature(r,false);if(r.tag)r.tag.visible=false;if(r.godRing)r.godRing.visible=false;}
  if(localFirst){replayLocalActor=makeRemote({...localFirst,id:clientId,name:myName||localFirst.name||'You',bot:false,zombie:false});disposeRemoteTag(replayLocalActor);if(replayLocalActor.godRing)replayLocalActor.godRing.visible=false;}
  const saved={weapon:currentWeapon,adsWanted,adsBlend,cameraFov:camera.fov,cameraPosition:camera.position.clone(),cameraRotation:camera.rotation.clone(),markerVisibility:teammateDeathMarkers.map(marker=>[marker,!!marker.sprite?.visible]),returnPaused,liveEnvironment:replayEnvironmentSnapshot()};for(const [marker] of saved.markerVisibility)if(marker.sprite)marker.sprite.visible=false;suppressLiveTransientPresentation();clearReplayTransientFx();shell.showMatchPresentation?.();if(chatOpen)void dismissChat({restorePointer:false});scoreboardOpen=false;scoreboardScroll=0;scoreboardDrag=null;scoreboardPanel=null;resetTouchInput();clearControllerUiFocus();
  const killerWeapon=WEAPON_SPECS[descriptor.weapon]?descriptor.weapon:'pistol';currentWeapon=killerWeapon;adsWanted=false;adsBlend=0;clearFireInput();cancelEquipmentAction();syncLocalWeaponModel();camera.fov=baseFov;camera.updateProjectionMatrix();
  const events=replayEvents.filter(event=>event.at>=timing.clipStartAt&&event.at<=timing.clipEndAt).sort((a,b)=>a.at-b.at);replayPlayback={...descriptor,...timing,frames,events,eventIndex:0,startedAt:performance.now(),killerId,currentRate:1,saved};applyReplayEnvironment(replayEnvironmentAt(timing.clipStartAt));diagnosticsVisualEvent('replay_started',{kind:descriptor.kind,killerId,victimId:String(descriptor.victim.id||''),timelineMs:Math.round(timing.clipEndAt-timing.clipStartAt),playbackMs:Math.round(timing.playbackDurationMs),slowPreMs:descriptor.kind==='final'?REPLAY_FINAL_SLOW_PRE_MS:0,slowPostMs:descriptor.kind==='final'?REPLAY_FINAL_SLOW_POST_MS:0,slowRate:timing.slowRate});hudLastDraw=0;return true;
}
function replayShotFeedback(event){
  if(!event)return;if(samePlayerId(event.ownerId,replayPlayback?.killerId)){const muzzle=localMuzzleObject(event.weapon,event.hand);if(muzzle?.material)muzzle.material.opacity=1;const v=weaponShotVariation(event.weapon);playSoundCue(weaponShotSoundId(event.weapon,!!event.suppressed),.86*v.volume,{playbackRate:v.playbackRate*Math.max(.72,replayPlayback?.currentRate||1),priority:4});weaponKickVelocity=Math.max(weaponKickVelocity,.40);}
  else playSpatialCue(weaponShotSoundId(event.weapon,!!event.suppressed),event.x,event.y,event.z,weaponAudibleDistance(event.weapon,!!event.suppressed),.65,{playbackRate:Math.max(.72,replayPlayback?.currentRate||1),priority:1});
}
function spawnReplayDetonationFx(event){
  const fx=createDetonationFx(event.kind,event);if(!fx)return;scene?.add(fx.root);replayTransientFx.push(fx);
}
function replayEventFeedback(event){if(!event)return;if(event.type==='shot')replayShotFeedback(event);else if(event.type==='detonation'){spawnReplayDetonationFx(event);soundTacticalDetonation(event.kind,event,{playbackRate:Math.max(.70,replayPlayback?.currentRate||1)});}}
function updateReplayTransientFx(dt){
  for(let i=replayTransientFx.length-1;i>=0;i--){const fx=replayTransientFx[i];if(advanceDetonationFx(fx,dt)){replayTransientFx.splice(i,1);try{scene?.remove(fx.root);}catch{}disposeObject3D(fx.root);}}
}
function clearReplayTransientFx(){const pending=replayTransientFx.splice(0);for(const fx of pending){try{scene?.remove(fx.root);}catch{}disposeObject3D(fx.root);}}
function updateReplayPlayback(dt,now=performance.now()){
  const replay=replayPlayback;if(!replay)return false;const elapsed=Math.max(0,now-replay.startedAt);if(elapsed>=replay.playbackDurationMs){stopReplayPlayback({reason:'complete',sendSkip:replay.kind==='killcam'});return false;}const playAt=replayPlayAtFromElapsed(replay,elapsed),rate=replayPlaybackRateAtElapsed(replay,elapsed);replay.currentRate=rate;while(replay.eventIndex<replay.events.length&&replay.events[replay.eventIndex].at<=playAt){replayEventFeedback(replay.events[replay.eventIndex]);replay.eventIndex++;}
  const liveDt=Math.min(.10,Math.max(0,Number(dt)||0));updateRocketTrailPuffs(liveDt);updateBulletImpactFx(liveDt);updateTacticalFx(liveDt);updateReplayTransientFx(liveDt*rate);const actors=replayActorsAt(playAt),killer=actors.get(replay.killerId);if(!killer){stopReplayPlayback({reason:'killer-missing',sendSkip:replay.kind==='killcam'});return false;}for(const r of remotes.values()){const key=String(r.id),actor=actors.get(key);if(!actor){r.group.visible=false;continue;}restoreRemoteThermalSignature(r,false);replaySetActorPose(r,actor,{cameraActor:samePlayerId(r.id,replay.killerId)});}if(replayLocalActor){const localActor=actors.get(String(clientId));replayLocalActor.group.visible=!!localActor&&!samePlayerId(clientId,replay.killerId);if(localActor)replaySetActorPose(replayLocalActor,localActor,{cameraActor:samePlayerId(clientId,replay.killerId)});}
  applyReplayEnvironment(replayEnvironmentAt(playAt));const eyeHeight=killer.crouched?CROUCH_HEIGHT:PLAYER_HEIGHT;camera.position.set(Number(killer.x)||0,(Number(killer.y)||0)+eyeHeight,Number(killer.z)||0);camera.rotation.y=Number(killer.yaw)||0;let replayPitch=Number(killer.pitch)||0;if(killer.bot&&Math.abs(replayPitch)<.001){const victim=actors.get(String(replay.victim.id||''));if(victim){const dx=(Number(victim.x)||0)-(Number(killer.x)||0),dz=(Number(victim.z)||0)-(Number(killer.z)||0),dy=(Number(victim.y)||0)+1.1-camera.position.y;replayPitch=Math.atan2(dy,Math.max(.01,Math.hypot(dx,dz)));}}camera.rotation.x=THREE.MathUtils.clamp(replayPitch,-1.40,1.40);camera.rotation.z=0;updateWeaponView(Math.min(.05,liveDt*rate));return true;
}
function stopReplayPlayback({reason='stop',sendSkip=false}={}){
  const replay=replayPlayback;if(!replay)return false;if(sendSkip&&replay.kind==='killcam'&&socket?.readyState===WebSocket.OPEN)send({t:'replaySkip'});for(const r of remotes.values())restoreRemoteAfterReplay(r);if(replayLocalActor){try{scene?.remove(replayLocalActor.group);}catch{}disposeObject3D(replayLocalActor.group);replayLocalActor=null;}for(const [marker,visible] of replay.saved.markerVisibility||[])if(marker?.sprite)marker.sprite.visible=visible;clearReplayTransientFx();restoreLiveTransientPresentation();applyReplayEnvironment(replay.saved.liveEnvironment);for(const fx of killstreakFx){if(fx?.type==='solarnuke'&&fx.deferredReplayBlast){fx.deferredReplayBlast=false;updateSolarBurnProgress(fx,1,performance.now(),true);}}currentWeapon=replay.saved.weapon;adsWanted=!!replay.saved.adsWanted;adsBlend=Number(replay.saved.adsBlend)||0;camera.position.copy(replay.saved.cameraPosition);camera.rotation.copy(replay.saved.cameraRotation);camera.fov=replay.saved.cameraFov;camera.updateProjectionMatrix();syncLocalWeaponModel();replayPlayback=null;updateTeammateDeathMarkers(performance.now());if(replay.kind==='killcam'&&replay.saved.returnPaused&&matchState.status!==MATCH_STATUS.ENDED)shell.pause('replay-return');hudLastDraw=0;diagnosticsVisualEvent('replay_stopped',{kind:replay.kind,reason:String(reason||'stop')});return true;
}
function skipReplayPlayback(){if(replayPlayback?.kind!=='killcam')return false;return stopReplayPlayback({reason:'skip',sendSkip:true});}
function clearReplayState(){replayPending=null;if(replayPlayback)stopReplayPlayback({reason:'clear',sendSkip:false});clearReplayTransientFx();replayHistory.length=0;replayEvents.length=0;replayLastCaptureAt=0;}
function replayProgress(){const replay=replayPlayback;if(!replay)return 0;return THREE.MathUtils.clamp((performance.now()-replay.startedAt)/Math.max(1,replay.playbackDurationMs),0,1);}
function drawReplayHud(c,w,h){
  const replay=replayPlayback;if(!replay)return;c.save();const topH=Math.max(54,Math.min(72,h*.14));c.fillStyle='rgba(4,7,9,.78)';c.fillRect(0,0,w,topH);c.fillStyle=replay.kind==='final'?HUD_ACCENT:'#fff';c.font=`1000 ${Math.max(16,Math.min(24,h*.052))}px system-ui`;c.textAlign='center';c.fillText(replay.kind==='final'?'FINAL KILL':'KILLCAM',w/2,20);c.font='900 11px system-ui';c.fillStyle='#dfe7eb';const weapon=WEAPON_SPECS[replay.weapon]?.name||String(replay.weapon||'WEAPON').toUpperCase(),detail=[weapon,replay.headshot?'HEADSHOT':'',replay.distance>=1?`${replay.distance.toFixed(1)} m`:''].filter(Boolean).join(' · ');c.fillText(`${replay.attacker.name||'Player'}  →  ${replay.victim.name||'Player'}`,w/2,40);c.fillStyle='#98a5ad';c.font='850 9px system-ui';c.fillText(detail,w/2,56);if((Number(replay.currentRate)||1)<.999){c.fillStyle=replay.kind==='final'?HUD_ACCENT:'#d7ff58';c.font='1000 9px system-ui';c.textAlign='right';c.fillText(`SLOW ${Number(replay.currentRate||1).toFixed(1)}×`,w-12,20);c.textAlign='center';}const barW=Math.min(360,w*.52),barX=(w-barW)/2,barY=h-18;c.fillStyle='rgba(255,255,255,.18)';c.fillRect(barX,barY,barW,3);c.fillStyle=replay.kind==='final'?HUD_ACCENT:'#fff';c.fillRect(barX,barY,barW*replayProgress(),3);if(replay.kind==='killcam'){c.fillStyle='rgba(255,255,255,.82)';c.font='900 9px system-ui';const hint=controllerInputActive()?'A / B · SKIP':isTouch?'TAP · SKIP':'SPACE / ESC · SKIP';c.fillText(hint,w/2,h-32);}c.restore();
}
function drawReplayPendingHud(c,w,h){
  if(replayPending?.kind!=='final')return;c.save();c.fillStyle='rgba(3,6,8,.34)';c.fillRect(0,0,w,h);c.fillStyle=HUD_ACCENT;c.font=`1000 ${Math.max(18,Math.min(28,h*.06))}px system-ui`;c.textAlign='center';c.fillText('FINAL KILL',w/2,Math.max(28,h*.12));c.fillStyle='rgba(235,241,244,.78)';c.font='900 10px system-ui';c.fillText('REPLAY',w/2,Math.max(48,h*.12+22));c.restore();
}

function updateRemoteTarget(r,player,instant=false){
  const now=performance.now(),x=Number(player.x)||0,y=Number(player.y)||0,z=Number(player.z)||0,serverAt=Number.isFinite(Number(player.at))?Number(player.at):serverNow(),elapsed=Math.max(.016,(serverAt-r.lastNetServerAt)/1000),dist=Math.hypot(x-r.lastNetX,z-r.lastNetZ);
  if(Number.isFinite(Number(player.at)))observeRemoteNetworkTime(player.at);pushRemoteSnapshot(r,{...player,at:serverAt},{reset:instant});
  r.moveSpeed=THREE.MathUtils.lerp(r.moveSpeed,Math.min(16,dist/elapsed),.55);if(Object.prototype.hasOwnProperty.call(player,'ladderId')){if(player.ladderId){if(!r.ladder||String(r.ladder.id)!==String(player.ladderId))r.ladder={id:String(player.ladderId),seq:0,phase:'climb',entry:''};}else r.ladder=null;}r.airborne=!!r.ladder||y>worldSupportHeight(x,z,y)+.08;r.ads=player.ads??r.ads;r.crouched=player.crouched??r.crouched;r.lastNetAt=now;r.lastNetServerAt=serverAt;r.lastNetX=x;r.lastNetY=y;r.lastNetZ=z;r.target.set(x,y,z);r.targetYaw=Number(player.yaw)||0;if(Number.isFinite(Number(player.pitch)))r.targetPitch=Number(player.pitch);r.lastSeen=now;
  if(Number(player.reloadAt)>0){r.reloadUntil=Number(player.reloadAt);r.reloadWeapon=player.reloadWeapon||r.weapon;if(!r.reloadStartedAt)r.reloadStartedAt=serverNow();}
  if(instant){r.group.position.copy(r.target);r.group.rotation.y=r.targetYaw;}
}
function upsertRemote(player,instant=false){
  if(!player?.id)return;if(samePlayerId(player.id,clientId)){for(const [id] of remotes){if(samePlayerId(id,clientId))removeRemote(id);}return;}
  let r=remotes.get(player.id);if(!r){r=makeRemote(player);remotes.set(player.id,r);}
  const oldTeam=r.team,oldBot=!!r.bot,oldZombie=!!r.zombie,oldName=r.name,oldHp=Number(r.hp)||0,nextTeam=normalizeTeam(player.team||r.team),nextBot=!!player.bot,nextZombie=!!player.zombie,nextName=player.name||r.name,nextHp=player.hp??r.hp;
  r.name=nextName;r.bot=nextBot;r.zombie=nextZombie;r.attackAt=Number(player.attackAt)||r.attackAt||0;r.team=nextTeam;r.admin=player.admin??r.admin;r.weapon=player.weapon||r.weapon;
  if(PRIMARY_WEAPONS.includes(player.primaryWeapon))r.primaryWeapon=player.primaryWeapon;if(SECONDARY_WEAPONS.includes(player.secondaryWeapon))r.secondaryWeapon=player.secondaryWeapon;if(Object.prototype.hasOwnProperty.call(player,'primaryAttachments'))r.primaryAttachments=normalizeWeaponAttachments(r.primaryWeapon,player.primaryAttachments);if(Object.prototype.hasOwnProperty.call(player,'secondaryAttachments'))r.secondaryAttachments=normalizeWeaponAttachments(r.secondaryWeapon,player.secondaryAttachments);
  r.hp=nextHp;r.kills=Number(player.kills??r.kills)||0;r.deaths=Number(player.deaths??r.deaths)||0;r.godMode=player.godMode??r.godMode;
  if(player.traversal&&typeof player.traversal==='object'&&Number(player.traversal.seq)!==Number(r.traversal?.seq))r.traversal=traversalPlanFromServer({id:player.id,accepted:true,...player.traversal});else if(player.bot&&player.traversal===null)r.traversal=null;if(player.ladder&&typeof player.ladder==='object')r.ladder=ladderStateFromServer(player.ladder);else if(player.ladder===null)r.ladder=null;
  if(r.godRing)r.godRing.visible=!!r.godMode;const identityChanged=oldTeam!==nextTeam||oldBot!==nextBot||oldZombie!==nextZombie;if(identityChanged)applyRemoteIdentityVisual(r,{team:nextTeam,bot:nextBot,zombie:nextZombie,name:nextName,source:'network_identity'});else if(oldName!==nextName)syncRemoteRelationshipVisual(r,{forceTag:true,source:'name'});
  syncRemoteWeapon(r);updateRemoteTarget(r,player,instant);
  if(oldHp>0&&Number(r.hp)<=0)createTeammateDeathMarker(r,player);else if(oldHp<=0&&Number(r.hp)>0)diagnosticsVisualEvent('remote_respawn',{id:String(r.id||''),team:String(r.team||''),teamLabel:teamLabel(r.team),bot:!!r.bot,hp:Number(r.hp)||0});
  updateRemoteNameTagPresentation(r);
}

function removeRemote(id){const r=remotes.get(id);if(!r)return;restoreRemoteThermalSignature(r,true);scene?.remove(r.group);disposeObject3D(r.group);remotes.delete(id);}
function clearRemotes(){for(const id of [...remotes.keys()])removeRemote(id);}

function deathLookYawFromHit(m){
  const attacker=m?.attacker&&m.attacker!==clientId?remotes.get(m.attacker):null;
  if(attacker){const dx=attacker.group.position.x-position.x,dz=attacker.group.position.z-position.z;if(Math.hypot(dx,dz)>.05)return Math.atan2(-dx,-dz);}
  const kx=Number(m?.knockback?.x)||0,kz=Number(m?.knockback?.z)||0;return Math.hypot(kx,kz)>.01?Math.atan2(kx,kz):NaN;
}
function enterLocalDeath(m){
  const now=performance.now();deathViewStartYaw=effectiveAimYaw();deathViewTargetYaw=deathLookYawFromHit(m);deathViewStartPitch=effectiveAimPitch();
  stopSlide();cancelSprint();traversal=null;ladderState=null;traversalIntentUntil=0;traversalIntentSeq=0;traversalConsumedIntentSeq=0;jumpBufferedUntil=0;
  wastedUntil=m.respawnAt||serverNow()+worldSettings.combat.respawnMs;deathAnimStartedAt=now;clearFireInput();cancelEquipmentAction();clearQueuedSprintShot();setAim(false);resetRecoilBookkeeping();
  reloadRequestPending=false;reloadUntil=0;reloadWeapon='';reloadStartedAt=0;pendingWeapon='';weaponSwapStartedAt=0;localEquipmentCooldownUntil=0;sprintActionReadyAt=0;
  moveVelocityX=moveVelocityZ=0;localMoveAmount=0;
}
function handleHit(m){
  const targetRemote=remotes.get(m.target);if(targetRemote){targetRemote.hp=m.hp;if(m.wasted){targetRemote.traversal=null;targetRemote.ladder=null;}flashRemote(targetRemote);}
  if(m.attacker===clientId){showHitmarker(!!m.headshot);if(m.headshot)soundHeadshot();else soundHitmarker(m.weapon||'pistol');}
  if(m.target===clientId){
    if(m.blast&&diagnosticsRecordingEnabled())diagnosticsRecordEvent('blast_hit',{weapon:String(m.weapon||''),damage:Number(m.damage)||0,distance:diagnosticsRound(Number(m.distance)||0,2),directImpact:!!m.directImpact});
    hp=m.hp;knockX+=m.knockback?.x||0;knockZ+=m.knockback?.z||0;verticalVelocity=Math.max(verticalVelocity,m.knockback?.y||0);onGround=false;addDamageFeedback(m);syncLocalStatus();showHurt();soundHurt();
    if(m.wasted)enterLocalDeath(m);
  }
  
}
function addDamageFeedback(m){
  const damage=Math.max(1,Number(m.damage)||1),kx=Number(m.knockback?.x)||0,kz=Number(m.knockback?.z)||0;
  if(Math.hypot(kx,kz)>.01){
    const attacker=m.attacker&&m.attacker!==clientId?remotes.get(m.attacker):null,bearing=Math.atan2(kx,kz),knockLen=Math.hypot(kx,kz),sourceDistance=Math.max(1,Number(m.distance)||8);
    const sourceX=attacker?.group.position.x??(position.x-kx/knockLen*sourceDistance),sourceZ=attacker?.group.position.z??(position.z-kz/knockLen*sourceDistance);
    damageIndicators.push({bearing,sourceX,sourceZ,until:performance.now()+1150,strength:Math.min(1,.35+damage/95)});
    if(damageIndicators.length>6)damageIndicators.shift();
  }
  const count=Math.max(2,Math.min(9,Math.ceil(damage/18)));for(let i=0;i<count;i++){const edge=Math.random(),side=Math.floor(Math.random()*4);let x,y;if(side===0){x=.05+edge*.9;y=.04+Math.random()*.20;}else if(side===1){x=.78+Math.random()*.18;y=.08+edge*.82;}else if(side===2){x=.05+edge*.9;y=.76+Math.random()*.20;}else{x=.04+Math.random()*.18;y=.08+edge*.82;}bloodSplats.push({x,y,r:.006+Math.random()*.018,stretch:.7+Math.random()*1.8,rot:Math.random()*Math.PI,until:performance.now()+6500+Math.random()*3500,alpha:.28+Math.random()*.38});}
  if(bloodSplats.length>42)bloodSplats.splice(0,bloodSplats.length-42);
}
function drawBloodSplatter(c,w,h,now,missingHealth){for(let i=bloodSplats.length-1;i>=0;i--){const s=bloodSplats[i],remain=(s.until-now)/8500;if(remain<=0){bloodSplats.splice(i,1);continue;}const a=s.alpha*Math.min(1,remain*2)*Math.max(.18,missingHealth);c.save();c.translate(s.x*w,s.y*h);c.rotate(s.rot);c.scale(s.stretch,1);c.fillStyle=`rgba(118,0,15,${a})`;c.beginPath();c.arc(0,0,s.r*Math.min(w,h),0,Math.PI*2);c.fill();c.fillStyle=`rgba(76,0,8,${a*.72})`;c.beginPath();c.arc(s.r*Math.min(w,h)*.65,-s.r*Math.min(w,h)*.35,s.r*Math.min(w,h)*.42,0,Math.PI*2);c.fill();c.restore();}}
function drawDamageIndicators(c,w,h,now){
  for(let i=damageIndicators.length-1;i>=0;i--){
    const d=damageIndicators[i],remain=(d.until-now)/1150;if(remain<=0){damageIndicators.splice(i,1);continue;}
    let bearing=d.bearing;if(Number.isFinite(d.sourceX)&&Number.isFinite(d.sourceZ)){const dx=position.x-d.sourceX,dz=position.z-d.sourceZ;if(Math.hypot(dx,dz)>.05)bearing=Math.atan2(dx,dz);}
    const relative=normalizeAngle(bearing-yaw),radius=Math.min(w,h)*.315,x=w/2-Math.sin(relative)*radius,y=h/2-Math.cos(relative)*radius,rot=relative,alpha=Math.min(1,remain*2.35)*d.strength;
    c.save();c.translate(x,y);c.rotate(rot);c.globalAlpha=alpha;c.shadowColor='rgba(0,0,0,.72)';c.shadowBlur=4;c.strokeStyle='#ff4057';c.fillStyle='rgba(255,36,61,.25)';c.lineCap='round';
    c.lineWidth=3.7;c.beginPath();c.moveTo(-22,9);c.quadraticCurveTo(0,-11,22,9);c.stroke();
    c.globalAlpha=alpha*.78;c.lineWidth=2;c.beginPath();c.moveTo(-14,11);c.quadraticCurveTo(0,-2,14,11);c.stroke();
    c.globalAlpha=alpha*.72;c.beginPath();c.moveTo(-8,7);c.lineTo(0,0);c.lineTo(8,7);c.lineTo(0,4);c.closePath();c.fill();c.restore();
  }
}
function handleRespawn(player){if(replayPending?.kind==='killcam')replayPending=null;if(replayPlayback?.kind==='killcam')stopReplayPlayback({reason:'respawn',sendSkip:false});
  if(!player?.id)return;
  const selfRespawn=player.id===clientId;
  diagnosticsRecordEvent('respawn',{playerId:String(player.id),self:selfRespawn,fireHeld:fireInputHeld(),recoilDebtPitch:diagnosticsRound(recoilDebtPitch),recoilPatternPitch:diagnosticsRound(recoilPatternPitch),recoilBurst:!!recoilBurstActive,recoilStep:Number(localRecoilStep[currentWeapon]??-1)});
  if(selfRespawn){resetSniperBreath();recoilDebtPitch=recoilDebtYaw=recoilPatternPitch=recoilPatternYaw=0;recoilBurstActive=false;recoilBurstWeapon='';recoilBurstReleaseAt=0;recoilBurstEndedAt=performance.now();weaponKickZ=weaponKickVelocity=0;lastLocalShotAt=0;localShotHeat=Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));localShotHeatAt=Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));localRecoilStep=Object.fromEntries(WEAPON_ORDER.map(name=>[name,-1]));localWeaponShotSequence=Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));}
  // Snapshot application also uses this entry point. A reconnect can legitimately
  // restore a player who is still inside the death/respawn window; do not treat
  // that snapshot as a respawn merely because the world is being rebuilt.
  if(player.id===clientId&&Math.max(0,Number(player.hp)||0)<=0){
    resetLocalPredictionHistory();hp=0;myStats={kills:Number(player.kills??myStats.kills)||0,deaths:Number(player.deaths??myStats.deaths)||0};wastedUntil=Math.max(serverNow()+120,Number(player.wastedUntil)||serverNow()+worldSettings.combat.respawnMs);
    yaw=Number.isFinite(Number(player.yaw))?Number(player.yaw):yaw;pitch=Number.isFinite(Number(player.pitch))?Number(player.pitch):pitch;deathViewStartYaw=yaw;deathViewTargetYaw=yaw;deathViewStartPitch=pitch;deathAnimStartedAt=performance.now()-700;
    position.set(Number(player.x)||0,Number(player.y)||worldSupportHeight(Number(player.x)||0,Number(player.z)||0,0,false),Number(player.z)||0);moveVelocityX=moveVelocityZ=0;verticalVelocity=0;knockX=knockZ=0;clearCorrectionView();resetViewVertical();clearFireInput();cancelEquipmentAction();setAim(false);reloadRequestPending=false;reloadUntil=0;reloadWeapon='';pendingWeapon='';syncLocalStatus();return;
  }
  if(player.id===clientId){resetLocalPredictionHistory();hp=Math.max(0,Math.min(100,Number(player.hp??100)||0));myStats={kills:Number(player.kills??myStats.kills)||0,deaths:Number(player.deaths??myStats.deaths)||0};wastedUntil=0;lastWastedBy='';lastWastedWeapon='';lastWastedHeadshot=false;lastWastedDistance=0;deathViewStartYaw=0;deathViewTargetYaw=NaN;deathViewStartPitch=0;bloodSplats.length=0;damageIndicators.length=0;flashUntil=flashPeakUntil=0;hurtUntil=hitUntil=0;blastFeedbackUntil=blastFeedbackPower=blastFeedbackSeed=0;lastShotVisualAt=0;localEquipmentCooldownUntil=0;pendingTeam=player.pendingTeam||'';setLocalTeam(player.team||myTeam,{source:'respawn'});if(player.activeClassId)activeClassId=normalizeLoadoutClassId(player.activeClassId);pendingClassId=player.pendingClassId?normalizeLoadoutClassId(player.pendingClassId):'';selfColor=localDisplayColor();primaryWeapon=PRIMARY_WEAPONS.includes(player.primaryWeapon)?player.primaryWeapon:primaryWeapon;secondaryWeapon=SECONDARY_WEAPONS.includes(player.secondaryWeapon)?player.secondaryWeapon:secondaryWeapon;applyAttachmentState(player);tacticalEquipment=normalizeTactical(player.tactical);lethalEquipment=normalizeLethal(player.lethal);pendingLoadout=null;rememberPrimary(primaryWeapon);rememberSecondary(secondaryWeapon);rememberAttachments(primaryAttachments,secondaryAttachments);rememberEquipment(tacticalEquipment,lethalEquipment);rememberLoadoutClasses(loadoutClasses,activeClassId);currentWeapon=(player.weapon===secondaryWeapon||player.weapon===primaryWeapon)?player.weapon:primaryWeapon;resetSniperBreath();adsWanted=false;crouchWanted=false;crouched=false;crouchBlend=0;stopSlide();cancelSprint();ammo=normalizeClientAmmo(player.ammo);equipment=normalizeEquipment(player.equipment);pendingWeapon='';reloadRequestPending=false;reloadUntil=player.reloadAt||0;reloadWeapon=player.reloadWeapon||'';reloadStartedAt=reloadUntil?reloadUntil-weaponRules(reloadWeapon||currentWeapon).reloadMs:0;deathAnimStartedAt=0;landingKick=0;nextFootstepAt=0;shotgunPumpStartedAt=0;shotgunPumpSoundPlayed=false;fireReadyAt=freshClientFireReady();akimboReadyAt={left:0,right:0};akimboLeftCycleStartedAt=akimboRightCycleStartedAt=0;akimboCycleSoundPlayed={left:false,right:false};clearFireInput();warmWeaponAudio(currentWeapon);syncLocalWeaponModel();traversal=player.traversal?traversalPlanFromServer({id:clientId,accepted:true,...player.traversal}):null;ladderState=player.ladder?ladderStateFromServer(player.ladder):null;ladderSeq=Math.max(ladderSeq,Math.floor(Number(player.ladder?.seq)||0));traversalIntentUntil=0;traversalIntentSeq=0;traversalConsumedIntentSeq=0;yaw=Number.isFinite(Number(player.yaw))?Number(player.yaw):yaw;pitch=Number.isFinite(Number(player.pitch))?Number(player.pitch):0;position.set(player.x,player.y,player.z);clearCorrectionView();resetViewVertical();verticalVelocity=Number.isFinite(Number(player.verticalVelocity))?Number(player.verticalVelocity):0;moveVelocityX=moveVelocityZ=0;onGround=player.grounded!==false;lastGroundedAt=onGround?performance.now():0;jumpBufferedUntil=0;jumpSeq=Math.max(jumpSeq,Math.floor(Number(player.jumpSeq)||0));knockX=knockZ=0;camera.rotation.z=0;syncLocalStatus();return;}
  upsertRemote(player,true);const r=remotes.get(player.id);if(r){r.hp=100;}
}
function flashRemote(r){if(!r)return;const now=performance.now();r.hitFlashUntil=Math.max(Number(r.hitFlashUntil)||0,now+REMOTE_HIT_FLASH_MS);syncRemoteBodyVisual(r,now);diagnosticsVisualEvent('remote_hit_flash',{id:String(r.id||''),team:String(r.team||''),hp:Number(r.hp)||0,godMode:!!r.godMode,until:Math.round(r.hitFlashUntil)});}
function showHitmarker(headshot=false){const now=performance.now();hitUntil=now+(headshot?220:155);if(headshot)headshotUntil=now+280;}
function showHurt(){hurtUntil=performance.now()+650;}
function showToast(text,{duration=1600,priority=1,key=''}={}){
  const label=String(text||'').trim();if(!label)return;const toastKey=String(key||label),item={text:label,key:toastKey,duration:Math.max(500,Number(duration)||1600),priority:Math.max(0,Number(priority)||0),queuedAt:performance.now()};
  if(toastCurrent?.key===toastKey||toastQueue.some(entry=>entry.key===toastKey))return;
  toastQueue.push(item);toastQueue.sort((a,b)=>(b.priority-a.priority)||(a.queuedAt-b.queuedAt));if(toastQueue.length>5)toastQueue.length=5;hudLastDraw=0;
}
function activeToast(now){
  if(toastCurrent&&now>=toastCurrent.until)toastCurrent=null;
  if(!toastCurrent&&toastQueue.length){const next=toastQueue.shift();toastCurrent={...next,startedAt:now,until:now+next.duration};}
  return toastCurrent;
}
function clearToastNotifications(){toastCurrent=null;toastQueue.length=0;}
function syncLocalStatus(){if(hp<=0)setAim(false);syncPauseContext();}

function currentPlayerHeight(){return crouched?CROUCH_HEIGHT:PLAYER_HEIGHT;}
function canStandHere(){return !worldHeightExpansionBlockedAt(position.x,position.z,position.y,CROUCH_HEIGHT,PLAYER_HEIGHT,PLAYER_RADIUS);}
function expFollow(current,target,rate,dt){return current+(target-current)*(1-Math.exp(-Math.max(0,rate)*Math.max(0,dt)));}
function approachVector(x,z,targetX,targetZ,maxDelta){const dx=targetX-x,dz=targetZ-z,d=Math.hypot(dx,dz);if(d<=maxDelta||d<1e-7)return{x:targetX,z:targetZ};const scale=maxDelta/d;return{x:x+dx*scale,z:z+dz*scale};}
function smoothstep01(value){const t=THREE.MathUtils.clamp(value,0,1);return t*t*(3-2*t);}
function resetViewVertical(){viewFeetY=position?position.y:NaN;}
function clearCorrectionView(){correctionViewX=0;correctionViewY=0;correctionViewZ=0;}
function traversalPlanFromServer(m){
  const durationMs=Math.max(1,Number(m.durationMs)||1),elapsed=Math.max(0,serverNow()-(Number(m.startedAt)||serverNow()));
  return {seq:Math.max(0,Math.floor(Number(m.seq)||0)),mode:m.mode==='vault'?'vault':'mantle',role:String(m.role||''),portalId:String(m.portalId||''),affordanceId:String(m.affordanceId||''),startX:Number(m.startX)||0,startY:Number(m.startY)||0,startZ:Number(m.startZ)||0,endX:Number(m.endX)||0,endY:Number(m.endY)||0,endZ:Number(m.endZ)||0,peakY:Number(m.peakY)||Number(m.endY)||0,durationMs,startedAt:performance.now()-Math.min(durationMs,elapsed),endGrounded:m.endGrounded!==false,exitVelocityY:Number.isFinite(Number(m.exitVelocityY))?Number(m.exitVelocityY):0,viewMaxY:m.viewMaxY!=null&&Number.isFinite(Number(m.viewMaxY))?Number(m.viewMaxY):null};
}
function handleTraversalMessage(m){
  if(samePlayerId(m.id,clientId)){
    if(m.accepted===false){traversal=null;const x=Number(m.x),y=Number(m.y),z=Number(m.z);if(Number.isFinite(x)&&Number.isFinite(y)&&Number.isFinite(z)){position.set(x,y,z);clearCorrectionView();resetViewVertical();}return;}
    ladderState=null;traversal=traversalPlanFromServer(m);clearCorrectionView();resetViewVertical();verticalVelocity=0;onGround=false;return;
  }
  const r=remotes.get(m.id);if(!r||m.accepted===false)return;r.traversal=traversalPlanFromServer(m);
}

function ladderStateFromServer(value){
  const state=value&&typeof value==='object'?value:null;if(!state?.id)return null;
  return {id:String(state.id),seq:Math.max(0,Math.floor(Number(state.seq)||0)),phase:'climb',entry:state.entry==='top'?'top':'bottom'};
}
function activeLadder(){return ladderById(LADDERS,ladderState?.id);}
function ladderInputAmount(){
  const input=movementInput(),raw=THREE.MathUtils.clamp(-input.mz,-1,1);
  // A top entry starts by continuing downward while the player keeps holding
  // the same forward input used to step onto the ladder. Once released, the
  // ladder uses the normal rule everywhere: forward = up, back = down.
  if(ladderState?.entry==='top'){
    if(Math.abs(raw)<.12){ladderState.entry='';return 0;}
    if(raw>0)return -raw;
    ladderState.entry='';
  }
  return raw;
}
function ladderDirection(){const input=movementInput();if(input.len<.20)return null;const sin=Math.sin(yaw),cos=Math.cos(yaw),dx=input.mx*cos+input.mz*sin,dz=-input.mx*sin+input.mz*cos,len=Math.hypot(dx,dz);return len>.001?{x:dx/len,z:dz/len}:null;}
function lockLadderReattach(id){ladderAttachLockId=String(id||'');ladderAttachLockUntil=performance.now()+260;ladderAttachNeedsRelease=true;}
function updateLadderAttachLock(now=performance.now()){
  if(!ladderAttachLockId)return;
  const input=movementInput();if(input.len<.12)ladderAttachNeedsRelease=false;
  if(!ladderAttachNeedsRelease&&now>=ladderAttachLockUntil){ladderAttachLockId='';ladderAttachLockUntil=0;}
}
function ladderAttachLocked(id){return !!ladderAttachLockId&&String(id||'')===ladderAttachLockId&&(ladderAttachNeedsRelease||performance.now()<ladderAttachLockUntil);}
function markLadderHandoff(){localPredictionHistory.length=0;lastCorrectionSeq=Math.max(lastCorrectionSeq,stateSeq);}
function tryAttachLadder(){
  if(ladderState||traversal||!playerMovementActive()||hp<=0||!onGround)return false;
  const direction=ladderDirection();if(!direction)return false;
  const faceX=-Math.sin(yaw),faceZ=-Math.cos(yaw),entry=findLadderEntry({ladders:LADDERS,x:position.x,y:position.y,z:position.z,dirX:direction.x,dirZ:direction.z,faceX,faceZ,radius:PLAYER_RADIUS,grounded:onGround});if(!entry||ladderAttachLocked(entry.ladderId))return false;
  // Send the current free-movement pose first. The server then validates the
  // attach from the same position the client used instead of a stale network pose.
  sendCurrentState(true);markLadderHandoff();
  const seq=++ladderSeq;
  stopSlide();cancelSprint();ladderState={id:String(entry.ladderId),seq,phase:'climb',entry:entry.entry==='top'?'top':'bottom'};
  position.set(Number(entry.attachX),Number(entry.attachY),Number(entry.attachZ));
  clearCorrectionView();resetViewVertical();verticalVelocity=0;moveVelocityX=moveVelocityZ=0;onGround=false;landingKick=0;crouchWanted=false;crouched=false;setAim(false);cancelEquipmentAction();
  !builderSession&&send({t:'ladder',action:'attach',seq,at:Math.round(serverNow()),ladderId:entry.ladderId,dirX:round3(direction.x),dirZ:round3(direction.z)});return true;
}
function finishLadder(end){
  if(!ladderState)return false;const ladder=activeLadder();if(!ladder)return false;
  const target=end==='top'?ladderTopExitPoint(ladder,PLAYER_RADIUS):ladderBottomExitPoint(ladder,PLAYER_RADIUS);
  if(worldBlockedAt(target.x,target.z,target.y,PLAYER_HEIGHT,PLAYER_RADIUS)||remoteActorBlocked(target.x,target.z,target.y,position.x,position.z,PLAYER_HEIGHT)){showToast('LADDER EXIT BLOCKED',{duration:900,key:'ladder-exit-blocked'});return false;}
  // Flush the final on-ladder pose before asking the server to dismount. This
  // removes the old race where the server could reject an exit using an older y.
  sendCurrentState(true);markLadderHandoff();
  const seq=++ladderSeq;
  position.set(target.x,target.y,target.z);ladderState=null;lockLadderReattach(ladder.id);verticalVelocity=0;moveVelocityX=moveVelocityZ=0;onGround=true;lastGroundedAt=performance.now();clearCorrectionView();resetViewVertical();localMoveAmount=0;
  !builderSession&&send({t:'ladder',action:'dismount',end,seq,at:Math.round(serverNow()),ladderId:String(ladder.id)});sendCurrentState(true);return true;
}
function detachLadder(){
  if(!ladderState)return false;const ladder=activeLadder();if(!ladder)return false;
  const cp=ladderClimbPoint(ladder,PLAYER_RADIUS),targetX=cp.x+Number(ladder.nx)*.24,targetZ=cp.z+Number(ladder.nz)*.24;
  if(worldBlockedAt(targetX,targetZ,position.y,PLAYER_HEIGHT,PLAYER_RADIUS)||remoteActorBlocked(targetX,targetZ,position.y,position.x,position.z,PLAYER_HEIGHT)){showToast('LADDER EXIT BLOCKED',{duration:900,key:'ladder-exit-blocked'});return false;}
  sendCurrentState(true);markLadderHandoff();
  const seq=++ladderSeq;
  position.x=targetX;position.z=targetZ;ladderState=null;lockLadderReattach(ladder.id);verticalVelocity=2.15;onGround=false;lastGroundedAt=0;clearCorrectionView();resetViewVertical();!builderSession&&send({t:'ladder',action:'detach',seq,ladderId:String(ladder.id)});sendCurrentState(true);soundJump();return true;
}
function updateLadder(nowServer,dt){
  if(!ladderState)return false;const ladder=activeLadder();if(!ladder){ladderState=null;return false;}
  const cp=ladderClimbPoint(ladder,PLAYER_RADIUS),input=ladderInputAmount();position.x=cp.x;position.z=cp.z;position.y=ladderClimbStep(ladder,position.y,input,dt);verticalVelocity=0;moveVelocityX=moveVelocityZ=0;onGround=false;localMoveAmount=THREE.MathUtils.lerp(localMoveAmount,Math.abs(input),Math.min(1,dt*12));
  if(input>.18&&position.y>=Number(ladder.topY)-.105){finishLadder('top');return true;}
  if(input<-.18&&position.y<=Number(ladder.bottomY)+.005){finishLadder('bottom');return true;}
  return true;
}
function handleLadderMessage(m){
  if(samePlayerId(m.id,clientId)){
    if(m.accepted===false){const x=Number(m.x),y=Number(m.y),z=Number(m.z);ladderState=m.ladder?ladderStateFromServer(m.ladder):null;if(Number.isFinite(x)&&Number.isFinite(y)&&Number.isFinite(z)){position.set(x,y,z);clearCorrectionView();resetViewVertical();}return;}
    const x=Number(m.x),y=Number(m.y),z=Number(m.z);
    if(m.action==='dismount'){
      const sameLocalAction=Number(m.seq)===Number(ladderSeq);ladderState=null;
      // The local exit was already predicted to this exact server-defined point.
      // Do not apply the same teleport a second time when its acknowledgement arrives.
      if(!sameLocalAction&&Number.isFinite(x)&&Number.isFinite(y)&&Number.isFinite(z)){position.set(x,y,z);clearCorrectionView();resetViewVertical();}
      verticalVelocity=0;moveVelocityX=moveVelocityZ=0;onGround=true;lastGroundedAt=performance.now();return;
    }
    if(m.action==='detach'){
      ladderState=null;const sameLocalAction=Number(m.seq)===Number(ladderSeq);if(!sameLocalAction&&Number.isFinite(x)&&Number.isFinite(y)&&Number.isFinite(z))position.set(x,y,z);verticalVelocity=Number.isFinite(Number(m.verticalVelocity))?Number(m.verticalVelocity):2.15;onGround=false;clearCorrectionView();resetViewVertical();return;
    }
    const authoritative=ladderStateFromServer(m.ladder);if(!ladderState||Number(ladderState.seq)!==Number(m.seq)){ladderState=authoritative;if(Number.isFinite(x)&&Number.isFinite(y)&&Number.isFinite(z))position.set(x,y,z);}clearCorrectionView();resetViewVertical();verticalVelocity=0;moveVelocityX=moveVelocityZ=0;onGround=false;return;
  }
  const r=remotes.get(m.id);if(!r||m.accepted===false)return;r.ladder=m.ladder?ladderStateFromServer(m.ladder):null;if(m.action==='detach'||m.action==='dismount')r.ladder=null;
}

function predictionStateForSeq(seq){for(let i=localPredictionHistory.length-1;i>=0;i--)if(localPredictionHistory[i].seq===seq)return localPredictionHistory[i];return null;}
function rebasePredictionsAfter(seq,dx,dy,dz){
  if(!seq||(!dx&&!dy&&!dz))return;
  for(const sample of localPredictionHistory){
    if(sample.seq<=seq)continue;
    sample.x+=dx;sample.y+=dy;sample.z+=dz;
  }
}
function discardPredictionThrough(seq){while(localPredictionHistory.length&&localPredictionHistory[0].seq<=seq)localPredictionHistory.shift();}
function resetLocalPredictionHistory(){localPredictionHistory.length=0;stateSeq=0;lastCorrectionSeq=0;lastStateSent=0;lastSentState={x:NaN,y:NaN,z:NaN,yaw:NaN,pitch:NaN,ads:false,adsAmount:0,crouched:false,sprinting:false,sliding:false,grounded:true,moveX:0,moveZ:0,ladderId:'',ladderMove:0};}
function applyServerCorrection(m){
  // Traversal is deterministic once accepted. A correction for an earlier
  // free-movement state must not pull the player back into the obstacle.
  if(traversal){clearCorrectionView();return;}
  const cx=Number(m.x),cy=Number(m.y),cz=Number(m.z),seq=Math.max(0,Math.floor(Number(m.seq)||0));
  if(seq&&seq<=lastCorrectionSeq)return;
  const serverX=Number.isFinite(cx)?cx:position.x,serverY=Number.isFinite(cy)?cy:position.y,serverZ=Number.isFinite(cz)?cz:position.z;
  const visualX=position.x+correctionViewX,visualY=Number.isFinite(viewFeetY)?viewFeetY:position.y+correctionViewY,visualZ=position.z+correctionViewZ;
  const predicted=seq?predictionStateForSeq(seq):null;
  // If the state has already aged out of the prediction window, snapping to
  // an old correction is worse than keeping the newer authoritative stream.
  if(seq&&!predicted){lastCorrectionSeq=Math.max(lastCorrectionSeq,seq);return;}
  let deltaX,deltaY,deltaZ;
  if(predicted){deltaX=serverX-predicted.x;deltaY=serverY-predicted.y;deltaZ=serverZ-predicted.z;}
  else{deltaX=serverX-position.x;deltaY=serverY-position.y;deltaZ=serverZ-position.z;}
  position.x+=deltaX;position.y+=deltaY;position.z+=deltaZ;
  // Every prediction newer than the corrected snapshot was simulated in the
  // same old coordinate frame. Rebase it once with the authoritative delta so
  // later correction packets only contain NEW error instead of re-applying the
  // same network correction over and over after a packet stall.
  if(seq)rebasePredictionsAfter(seq,deltaX,deltaY,deltaZ);
  const correctionMagnitude=Math.hypot(deltaX,deltaY,deltaZ),recent=!seq||stateSeq-seq<=2;recordNetCorrection(m,correctionMagnitude);if(diagnosticsRecordingEnabled()&&(fireInputHeld()||correctionMagnitude>.08))diagnosticsRecordEvent('server_correction',{seq,dx:diagnosticsRound(deltaX,4),dy:diagnosticsRound(deltaY,4),dz:diagnosticsRound(deltaZ,4),magnitude:diagnosticsRound(correctionMagnitude,4),reason:String(m?.reason||''),fire:fireInputHeld(),positionY:diagnosticsRound(position.y,3),viewFeetY:diagnosticsRound(viewFeetY,3)});
  if(correctionMagnitude>CORRECTION_HARD_SNAP_DISTANCE||Math.abs(deltaY)>.9){clearCorrectionView();resetViewVertical();}
  else{
    const errorX=visualX-position.x,errorY=visualY-position.y,errorZ=visualZ-position.z,horizontal=Math.hypot(errorX,errorZ),scale=horizontal>CORRECTION_MAX_HORIZONTAL?CORRECTION_MAX_HORIZONTAL/horizontal:1;
    correctionViewX=errorX*scale;correctionViewZ=errorZ*scale;correctionViewY=THREE.MathUtils.clamp(errorY,-CORRECTION_MAX_VERTICAL,CORRECTION_MAX_VERTICAL);
  }
  if(seq){lastCorrectionSeq=seq;discardPredictionThrough(seq);}
  if(recent&&typeof m.crouched==='boolean'){crouched=m.crouched;if(crouched)crouchWanted=true;else if(!crouchWanted)crouched=false;}
  if(recent&&m.vertical){const serverVy=Number(m.verticalVelocity);if(Number.isFinite(serverVy))verticalVelocity=serverVy;onGround=typeof m.grounded==='boolean'?m.grounded:Math.abs(position.y-worldSupportHeight(position.x,position.z,position.y))<=.08;}
}
function updateCorrectionView(dt){
  const decay=Math.exp(-CORRECTION_VIEW_RATE*Math.max(0,dt));correctionViewX*=decay;correctionViewY*=decay;correctionViewZ*=decay;
  if(Math.abs(correctionViewX)<.0003)correctionViewX=0;if(Math.abs(correctionViewY)<.0003)correctionViewY=0;if(Math.abs(correctionViewZ)<.0003)correctionViewZ=0;
}
function updateViewVertical(dt){
  const target=position.y+correctionViewY;if(traversal||ladderState){viewFeetY=target;return viewFeetY;}if(!Number.isFinite(viewFeetY)||Math.abs(target-viewFeetY)>VIEW_VERTICAL_SNAP_DISTANCE){viewFeetY=target;return viewFeetY;}
  const rate=onGround?(target>=viewFeetY?GROUND_VIEW_UP_RATE:GROUND_VIEW_DOWN_RATE):AIR_VIEW_RATE;viewFeetY=expFollow(viewFeetY,target,rate,dt);
  // Ground support already uses continuous ramps for stairs. Keep only a very
  // small visual filter here: allowing the camera to trail 30-50 cm behind a
  // steep stair ramp caused a visible catch-up pop at the top/bottom of flights.
  if(onGround){const lag=target-viewFeetY;if(lag>GROUND_VIEW_MAX_LAG)viewFeetY=target-GROUND_VIEW_MAX_LAG;else if(lag<-GROUND_VIEW_MAX_LAG)viewFeetY=target+GROUND_VIEW_MAX_LAG;}
  if(Math.abs(target-viewFeetY)<.0005)viewFeetY=target;return viewFeetY;
}
function updateCrouchState(dt=0){
  const next=crouchWanted||(crouched&&!canStandHere());crouched=next;
  const target=crouched?1:0;crouchBlend=expFollow(crouchBlend,target,CROUCH_VIEW_RATE,Math.max(.001,dt));if(Math.abs(target-crouchBlend)<.002)crouchBlend=target;
}
function weaponSprintOutMs(weapon=currentWeapon){return Math.max(0,Number(effectiveWeaponSpec(weapon)?.sprintOutMs)||0);}
function weaponSprintAdsMs(weapon=currentWeapon){return Math.max(0,Number(effectiveWeaponSpec(weapon)?.sprintAdsMs)||weaponSprintOutMs(weapon)*.8);}
function clearQueuedSprintShot(){pendingSprintShot='';pendingSprintShotExpiresAt=0;}
function registerSprintExit(now=performance.now(),weapon=currentWeapon){sprintActionReadyAt=Math.max(sprintActionReadyAt,now+weaponSprintOutMs(weapon));}
function cancelSprint({lockMs=0}={}){const now=performance.now(),wasSprinting=sprinting;sprintLatched=false;sprinting=false;if(wasSprinting&&!sliding)registerSprintExit(now);if(lockMs>0)sprintBlockedUntil=Math.max(sprintBlockedUntil,now+lockMs);}
function sprintInputRequested(input=movementInput()){const touchAuto=touchGameplayControlsVisible()&&touchRoleActive('joy')&&input.len>=TOUCH_SPRINT_MIN_INPUT&&input.mz<=-TOUCH_SPRINT_MIN_FORWARD;return keys.has('ShiftLeft')||keys.has('ShiftRight')||sprintLatched||touchAuto;}
function sprintEligible(input=movementInput()){
  const now=performance.now();return now>=sprintBlockedUntil&&!fireInputHeld()&&!combatActionActive()&&!sliding&&!adsWanted&&!crouched&&!crouchWanted&&onGround&&!traversal&&!ladderState&&input.len>=SPRINT_MIN_INPUT&&input.mz<=-SPRINT_MIN_FORWARD;
}
function toggleSprint(){
  const now=performance.now();if(!playerMovementActive()||hp<=0||traversal||ladderState||sliding||now<sprintBlockedUntil)return;
  sprintLatched=!sprintLatched;if(!sprintLatched)sprinting=false;sendCurrentState(true);
}
function updateSprintState(input){
  if(sliding){sprinting=false;return false;}
  const now=performance.now(),requested=sprintInputRequested(input),eligible=requested&&sprintEligible(input),wasSprinting=sprinting;sprinting=eligible;if(wasSprinting&&!sprinting&&!sliding)registerSprintExit(now);
  if(sprintLatched&&!eligible&&(now<sprintBlockedUntil||fireInputHeld()||combatActionActive()||adsWanted||crouched||crouchWanted||input.len<.12||input.mz>-.05||!onGround))sprintLatched=false;
  return sprinting;
}
function stopSlide({recover=false}={}){const wasSliding=sliding;sliding=false;slideStartedAt=0;slideDirX=slideDirZ=0;slideStartSpeed=0;if(recover&&wasSliding){const now=performance.now();slideRecoveryUntil=Math.max(slideRecoveryUntil,now+SLIDE_RECOVERY_MS);sprintBlockedUntil=Math.max(sprintBlockedUntil,slideRecoveryUntil);crouchWanted=false;if(canStandHere())crouched=false;}else if(!recover)slideRecoveryUntil=0;}
function startSlide(){
  if(!sprinting||!onGround||adsWanted||traversal||ladderState)return false;
  const speed=Math.hypot(moveVelocityX,moveVelocityZ),movement=movementSettings;if(speed<movement.runSpeed*.72)return false;
  const input=movementInput();if(input.len<.35)return false;
  const inv=speed>1e-5?1/speed:0;slideDirX=inv?moveVelocityX*inv:Math.sin(yaw)*-1;slideDirZ=inv?moveVelocityZ*inv:Math.cos(yaw)*-1;
  slideRecoveryUntil=0;slideStartSpeed=Math.max(speed,movement.runSpeed*SLIDE_START_SPEED_MULTIPLIER);slideStartedAt=performance.now();sliding=true;crouchWanted=true;crouched=true;cancelSprint();setAim(false);soundSlide();sendCurrentState(true);return true;
}
function setCrouch(active){if(sliding&&!active)stopSlide({recover:true});crouchWanted=!!active;if(crouchWanted)crouched=true;else if(canStandHere())crouched=false;sendCurrentState(true);}
function toggleCrouch(){
  if(!playerMovementActive()||hp<=0||traversal||ladderState)return;
  if(startSlide())return;
  const next=!crouchWanted;if(!next&&!canStandHere()){crouched=true;crouchWanted=false;showToast('NEED CLEARANCE');sendCurrentState(true);return;}setCrouch(next);
}
function traversalDirection(){
  const input=movementInput();if(input.len<.15)return null;
  const sin=Math.sin(yaw),cos=Math.cos(yaw),dx=input.mx*cos+input.mz*sin,dz=-input.mx*sin+input.mz*cos,len=Math.hypot(dx,dz);return len>.001?{x:dx/len,z:dz/len}:null;
}
function traversalCandidate(direction,airborne=!onGround){
  if(!direction||traversal)return null;
  return findTraversalCandidate({x:position.x,y:position.y,z:position.z,dirX:direction.x,dirZ:direction.z,height:currentPlayerHeight(),radius:PLAYER_RADIUS,airborne});
}
function beginTraversal(candidate,direction,{playJump=false}={}){
  if(!candidate||!direction||traversal||ladderState||!playerMovementActive()||hp<=0)return false;
  if(remoteActorBlocked(candidate.endX,candidate.endZ,candidate.endY,position.x,position.z,currentPlayerHeight()))return false;
  const now=performance.now(),seq=++traversalSeq,plan=createTraversalPlan(candidate,position.x,position.y,position.z,now,seq);if(!plan)return false;
  stopSlide();cancelSprint();traversal={...plan,dirX:direction.x,dirZ:direction.z};traversalConsumedIntentSeq=traversalIntentSeq;traversalIntentUntil=0;clearCorrectionView();resetViewVertical();verticalVelocity=0;onGround=false;landingKick=0;setAim(false);clearFireInput();cancelEquipmentAction();
  sendCurrentState(true);!builderSession&&send({t:'traverse',seq,at:Math.round(serverNow()),dirX:round3(direction.x),dirZ:round3(direction.z)});if(playJump)soundJump();return true;
}
function tryTraversal({vaultOnly=false}={}){
  const direction=traversalDirection(),candidate=traversalCandidate(direction,!onGround);if(!candidate||vaultOnly&&candidate.mode!=='vault')return false;return beginTraversal(candidate,direction,{playJump:onGround});
}
function updateTraversal(now){
  if(!traversal)return false;const pose=traversalPose(traversal,now);if(!pose){traversal=null;return false;}
  position.set(pose.x,pose.y,pose.z);verticalVelocity=0;onGround=false;
  if(pose.done){const finished=traversal;position.set(finished.endX,finished.endY,finished.endZ);traversal=null;onGround=finished.endGrounded!==false;verticalVelocity=onGround?0:(Number.isFinite(Number(finished.exitVelocityY))?Number(finished.exitVelocityY):-1.15);if(onGround){lastGroundedAt=now;landingKick=.32;nextFootstepAt=now+120;soundLanding(.28);}else{landingKick=0;}sendCurrentState(true);}
  return true;
}
function startPlayerJump(now=performance.now(),{allowTraversal=true}={}){
  if(sliding){stopSlide();crouchWanted=false;if(canStandHere())crouched=false;}cancelSprint();
  // A crouched player at a window/low barrier gets first chance to vault it.
  // Only require standing headroom when an actual free jump is needed.
  if((crouched||crouchWanted)&&allowTraversal&&tryTraversal())return true;
  if(crouched||crouchWanted){crouchWanted=false;if(!canStandHere()){crouched=true;showToast('LOW CEILING');sendCurrentState(true);return false;}crouched=false;}
  if(allowTraversal&&onGround&&tryTraversal({vaultOnly:true}))return true;
  jumpBufferedUntil=0;jumpSeq+=1;verticalVelocity=Math.sqrt(2*movementSettings.gravity*movementSettings.jumpHeight);onGround=false;landingKick=0;sendCurrentState(true);soundJump();return true;
}
function tryJump(){
  if(!playerMovementActive()||hp<=0||traversal)return;if(ladderState){detachLadder();return;}const now=performance.now();traversalIntentSeq+=1;traversalIntentUntil=now+560;
  if(onGround||now-lastGroundedAt<=COYOTE_TIME_MS){startPlayerJump(now);return;}
  if(tryTraversal()){jumpBufferedUntil=0;return;}
  jumpBufferedUntil=now+JUMP_BUFFER_MS;
}
function movementInput(){
  let mx=0,mz=0;
  if(!chatOpen&&!scoreboardOpen&&!killstreakTargeting&&playerMovementActive()&&hp>0){
    if(controllerInputActive()){const controllerMove=controllerMoveAxes();mx=controllerMove.x;mz=controllerMove.y;}
    else if(touchGameplayControlsVisible()){mx=joy.x;mz=joy.y;}
    else{if(keys.has('KeyA'))mx--;if(keys.has('KeyD'))mx++;if(keys.has('KeyW'))mz--;if(keys.has('KeyS'))mz++;}
  }
  const len=Math.hypot(mx,mz);if(len>1){mx/=len;mz/=len;}
  moveInput.mx=mx;moveInput.mz=mz;moveInput.len=Math.min(1,len);return moveInput;
}
function effectiveAimYaw(){return yaw+(currentWeapon==='sniper'?sniperSwayYaw:0);}
function effectiveAimPitch(){return THREE.MathUtils.clamp(pitch+(currentWeapon==='sniper'?sniperSwayPitch:0),-1.28,1.28);}
function statePayload(seq=stateSeq){const input=movementInput(),ladderMove=ladderState?ladderInputAmount():0;return {t:'state',seq:Math.max(0,Math.floor(Number(seq)||0)),at:Math.round(serverNow()),x:round3(position.x),y:round3(position.y),z:round3(position.z),yaw:round3(yaw),pitch:round3(pitch),ads:currentWeapon==='akimbo1887'?false:adsWanted,adsAmount:currentWeapon==='akimbo1887'?0:round3(adsBlend),crouched,sprinting,sliding,grounded:onGround,jumpSeq,moveX:round3(input.mx),moveZ:round3(input.mz),ladderId:ladderState?.id||'',ladderMove:round3(ladderMove)};}
function stateChanged(p){return !Number.isFinite(lastSentState.x)||Math.abs(p.x-lastSentState.x)>.008||Math.abs(p.y-lastSentState.y)>.008||Math.abs(p.z-lastSentState.z)>.008||Math.abs(normalizeAngle(p.yaw-lastSentState.yaw))>.0025||Math.abs(p.pitch-lastSentState.pitch)>.0025||Math.abs(p.moveX-lastSentState.moveX)>.02||Math.abs(p.moveZ-lastSentState.moveZ)>.02||Math.abs((p.ladderMove||0)-(lastSentState.ladderMove||0))>.02||String(p.ladderId||'')!==String(lastSentState.ladderId||'')||p.ads!==lastSentState.ads||Math.abs((p.adsAmount||0)-(lastSentState.adsAmount||0))>.025||p.crouched!==lastSentState.crouched||p.sprinting!==lastSentState.sprinting||p.sliding!==lastSentState.sliding||p.grounded!==lastSentState.grounded;}
function rememberPredictionState(p,now=performance.now()){
  localPredictionHistory.push({seq:p.seq,at:p.at,localAt:now,x:p.x,y:p.y,z:p.z,grounded:p.grounded,crouched:p.crouched});
  const cutoff=now-LOCAL_PREDICTION_HISTORY_MS;while(localPredictionHistory.length&&(localPredictionHistory[0].localAt<cutoff||localPredictionHistory.length>LOCAL_PREDICTION_MAX_SAMPLES))localPredictionHistory.shift();
}
function sendCurrentState(force=false){
  if(builderSession)return false;
  const now=performance.now(),preview=statePayload(stateSeq+1),changed=stateChanged(preview),interval=changed?ACTIVE_STATE_INTERVAL:IDLE_STATE_INTERVAL;
  if(!force&&now-lastStateSent<interval)return false;
  stateSeq+=1;preview.seq=stateSeq;recordNetStateSend(now);lastStateSent=now;lastSentState={x:preview.x,y:preview.y,z:preview.z,yaw:preview.yaw,pitch:preview.pitch,ads:preview.ads,adsAmount:preview.adsAmount||0,crouched:preview.crouched,sprinting:preview.sprinting,sliding:preview.sliding,grounded:preview.grounded,moveX:preview.moveX,moveZ:preview.moveZ,ladderId:preview.ladderId||'',ladderMove:preview.ladderMove||0};rememberPredictionState(preview,now);send(preview);return true;
}
function applyAuthoritativeLoadout(m){
  if(m?.action==='fire')diagnosticsRecordEvent('fire_loadout_ack',{accepted:m.accepted!==false,reason:String(m.reason||''),weapon:String(m.weapon||''),currentWeapon,stateSeq,serverAmmo:Number(m?.ammo?.[m.weapon]),localAmmo:Number(ammo[m.weapon]??-1),reloadAt:Number(m.reloadAt)||0,pendingWeapon:String(pendingWeapon||'')});
  if(m?.accepted===false&&m.action)recordNetReject(m.action,m.reason);
  const ackRev=Math.max(0,Math.floor(Number(m.rev)||0));
  if(shell.inLobby&&m.action==='loadout'&&ackRev&&ackRev<lobbyLoadoutRevision)return;
  if(shell.inMatch&&m.action==='loadout'&&ackRev&&ackRev<matchLoadoutRevision)return;
  if(shell.inLobby&&m.action==='loadout'&&ackRev)lobbyLoadoutAckRevision=Math.max(lobbyLoadoutAckRevision,ackRev);
  if(shell.inMatch&&m.action==='loadout'&&ackRev)matchLoadoutAckRevision=Math.max(matchLoadoutAckRevision,ackRev);
  if(Array.isArray(m.loadoutClasses))loadoutClasses=normalizeLoadoutClasses(m.loadoutClasses,selectedLoadout());if(Object.prototype.hasOwnProperty.call(m,'activeClassId')){activeClassId=normalizeLoadoutClassId(m.activeClassId);if(shell.inLobby)lobbyStartingClassId=activeClassId;}if(Object.prototype.hasOwnProperty.call(m,'pendingClassId'))pendingClassId=m.pendingClassId?normalizeLoadoutClassId(m.pendingClassId):'';if(Array.isArray(m.loadoutClasses))rememberLoadoutClasses(loadoutClasses,pendingClassId||activeClassId);
  if(PRIMARY_WEAPONS.includes(m.primaryWeapon)){primaryWeapon=m.primaryWeapon;if(shell.inLobby)rememberPrimary(primaryWeapon);}
  if(SECONDARY_WEAPONS.includes(m.secondaryWeapon)){secondaryWeapon=m.secondaryWeapon;if(shell.inLobby)rememberSecondary(secondaryWeapon);}
  primaryAttachments=normalizeWeaponAttachments(primaryWeapon,m.primaryAttachments??primaryAttachments);secondaryAttachments=normalizeWeaponAttachments(secondaryWeapon,m.secondaryAttachments??secondaryAttachments);if(shell.inLobby)rememberAttachments(primaryAttachments,secondaryAttachments);
  if(TACTICAL_EQUIPMENT.includes(m.tactical)){tacticalEquipment=normalizeTactical(m.tactical);if(shell.inLobby)rememberEquipment(tacticalEquipment,lethalEquipment);}
  if(LETHAL_EQUIPMENT.includes(m.lethal)){lethalEquipment=normalizeLethal(m.lethal);if(shell.inLobby)rememberEquipment(tacticalEquipment,lethalEquipment);}
  pendingLoadout=m.pendingLoadout&&typeof m.pendingLoadout==='object'?normalizeLoadoutChoice(m.pendingLoadout):null;
  if(typeof m.pendingTeam==='string')pendingTeam=m.pendingTeam;
  const serverWeapon=(m.weapon===secondaryWeapon||m.weapon===primaryWeapon)?m.weapon:currentWeapon;
  if(!pendingWeapon||serverWeapon===pendingWeapon){currentWeapon=serverWeapon;if(pendingWeapon===serverWeapon)pendingWeapon='';}
  syncClientAmmo(m.ammo);if(m.equipment)equipment=normalizeEquipment(m.equipment);
  reloadUntil=Math.max(0,Number(m.reloadAt)||0);reloadWeapon=m.reloadWeapon||'';reloadStartedAt=reloadUntil?reloadUntil-weaponRules(reloadWeapon||currentWeapon).reloadMs:0;reloadRequestPending=false;
  if(m.action==='weapon'&&m.accepted!==false)pendingWeapon='';
  if(m.action==='reloadShell')soundReload('shotgun');
  if(m.action==='fire'&&m.accepted===false&&(m.reason==='cooldown'||m.reason==='weapon_switch'||m.reason==='sprint_out'))delayFire(Math.max(8,Math.min(180,Number(m.retryAfterMs)||35)),m.weapon);
  if(m.pending===true&&pendingLoadout){rememberLoadoutClasses(loadoutClasses,activeClassId);showToast(`${loadoutClassById(loadoutClasses,pendingClassId||activeClassId).name} QUEUED · NEXT SPAWN`);}
  if(shell.inLobby&&lobbyLoadoutDraft){if(Array.isArray(m.loadoutClasses))lobbyClassDrafts=normalizeLoadoutClasses(loadoutClasses,selectedLoadout());markLobbyLoadoutDirty();}
  if(shell.panel===SHELL_PANEL.LOADOUT&&Array.isArray(m.loadoutClasses)){matchClassDrafts=normalizeLoadoutClasses(loadoutClasses,selectedLoadout());matchClassBase=normalizeLoadoutClasses(loadoutClasses,selectedLoadout());loadoutDraft=classLoadout(matchClassDrafts,loadoutEditClass.match);loadoutBaseDraft=classLoadout(matchClassBase,loadoutEditClass.match);syncMatchLoadoutEditor();}syncLocalWeaponModel();syncPauseContext();if(shell.inLobby){renderLobbySetupControls();setLobbyActionState();renderLobbyRoster(lobbyDisplayMode());}
}

function freshClientFireReady(){return Object.fromEntries(WEAPON_ORDER.map(name=>[name,0]));}
function touchRoleActive(role){for(const value of touchRoles.values())if(value===role)return true;return false;}
function fireInputHeld(){return mouseFireDown||touchRoleActive('fire')||gamepadFireDown;}
function beginRecoilBurst(weapon=currentWeapon){
  if(!automaticRecoilActive(weapon))return;
  recoilBurstReleaseAt=0;
  if(recoilBurstActive&&recoilBurstWeapon===weapon)return;
  recoilBurstActive=true;recoilBurstWeapon=weapon;localRecoilStep[weapon]=-1;
  // A quick re-trigger can happen before the previous burst has recovered. The
  // remaining vertical recoil debt is the new burst's baseline; starting the
  // envelope from zero here would stack a second full climb on top of it.
  recoilPatternPitch=Math.max(0,recoilDebtPitch);recoilPatternYaw=0;
}
function endRecoilBurst(releasedAt=performance.now()){
  if(recoilBurstWeapon&&localRecoilStep[recoilBurstWeapon]!==undefined)localRecoilStep[recoilBurstWeapon]=-1;
  recoilBurstActive=false;recoilBurstWeapon='';recoilBurstReleaseAt=0;recoilBurstEndedAt=releasedAt;recoilPatternPitch=0;recoilPatternYaw=0;
}
function scheduleRecoilBurstRelease(){
  if(!recoilBurstActive||!recoilBurstWeapon||recoilBurstReleaseAt)return;
  // One/two bad mobile input frames must not split an automatic burst, but this
  // qualification window is independent from recoil recovery timing.
  recoilBurstReleaseAt=performance.now();
}
function endRecoilBurstIfReleased(){if(!fireInputHeld())scheduleRecoilBurstRelease();else recoilBurstReleaseAt=0;}
function clearFireInput(){mouseFireDown=false;gamepadFireDown=false;for(const [id,role] of touchRoles)if(role==='fire'||role==='fire-left'||role==='fire-right')touchRoles.delete(id);endRecoilBurst();clearQueuedSprintShot();}
function delayFire(ms,weapon=currentWeapon){weapon=WEAPON_SPECS[weapon]?weapon:currentWeapon;if(ms>0)fireReadyAt[weapon]=Math.max(fireReadyAt[weapon]||0,performance.now()+ms);}
function pressMouseFire(){if(mouseFireDown||!combatWeaponAvailable())return;const wasHeld=fireInputHeld();mouseFireDown=true;if(!wasHeld)requestShot();}
function pressTouchFire(pointerId,hand='right'){if(touchRoles.has(pointerId)||!combatWeaponAvailable())return;if(currentWeapon==='akimbo1887'){touchRoles.set(pointerId,hand==='left'?'fire-left':'fire-right');requestShot(hand);return;}const wasHeld=fireInputHeld();touchRoles.set(pointerId,'fire');if(!wasHeld)requestShot();}
function bipodRecoilScale(weapon=currentWeapon){if(weapon!=='machineGun'||weapon!==currentWeapon)return 1;const mods=attachmentsForWeapon(weapon),item=ATTACHMENTS.bipod,still=Math.hypot(moveVelocityX,moveVelocityZ)<=Math.max(.18,movementSettings.walkSpeed*.10);return weaponHasAttachment(weapon,mods,'bipod')&&crouched&&onGround&&!sliding&&still?Math.max(.45,Math.min(1,Number(item?.conditionalRecoilScale)||.62)):1;}
function recoilSpec(weapon){const safe=WEAPON_SPECS[weapon]?weapon:'pistol',resolved=effectiveWeaponSpec(safe),scale=bipodRecoilScale(safe);if(scale>=.999)return resolved;return{...resolved,recoilPitch:Number(resolved.recoilPitch||0)*scale,recoilYaw:Number(resolved.recoilYaw||0)*scale,recoilMaxPitch:Number(resolved.recoilMaxPitch||resolved.recoilPitch||0)*scale,recoilMaxYaw:Number(resolved.recoilMaxYaw||resolved.recoilYaw||0)*scale};}
// Automatic recoil uses a bounded CoD-style envelope instead of climbing
// forever. The first ~1 second climbs mostly vertically, the next section bends
// right, then sustained fire moves around that elevated/rightward hold area.
// The hold-area motion changes the real aim/bullet ray; it is not viewmodel-only.
const RECOIL_SINGLE_YAW_PATTERN=[0,.04,.10,.17,.24,.30,.32,.28,.20,.10,0,-.10,-.17,-.20,-.15,-.07,.02,.09];
function recoilSmooth01(v){v=Math.max(0,Math.min(1,Number(v)||0));return v*v*(3-2*v);}
function automaticRecoilTarget(step,weapon,recoilScale=1,adsScale=1,heatScale=1){
  const r=recoilSpec(weapon),s=Math.max(0,Number(step)||0),cooldown=Math.max(50,Number(weaponRules(weapon).cooldownMs)||100),elapsed=s*cooldown;
  const climbMs=weapon==='machineGun'?1150:weapon==='assault'?1000:900,curveMs=weapon==='machineGun'?760:weapon==='assault'?650:560;
  const maxPitch=Math.max(.001,Number(r.recoilMaxPitch)||.08)*recoilScale*adsScale;
  const maxYaw=Math.max(.001,Number(r.recoilMaxYaw)||.025)*recoilScale*adsScale;
  const firstPitch=Math.max(0,Number(r.recoilPitch)||0)*recoilScale*adsScale*Math.max(.18,Math.min(1,Number(r.firstShotRecoilScale)||.5));
  let pitchTarget,yawTarget;
  // A small deterministic spread is present from the first few rounds so the
  // climb never traces a ruler-straight line. Keep it low-frequency/bounded:
  // recoil should feel hand-driven and controllable, not randomly teleport.
  const spreadRamp=recoilSmooth01(Math.min(1,s/3)),weaponSpread=weapon==='machineGun'?1.12:weapon==='assault'?1:.78;
  const earlyYawSpread=maxYaw*weaponSpread*spreadRamp*(.120*Math.sin(s*1.71+.55)+.052*Math.sin(s*2.83+1.15));
  const earlyPitchSpread=maxPitch*weaponSpread*spreadRamp*(.025*Math.sin(s*1.37+.25)+.014*Math.sin(s*2.31+1.40));
  if(elapsed<=climbMs){
    const p=recoilSmooth01(elapsed/climbMs);
    pitchTarget=firstPitch+(maxPitch*.78-firstPitch)*p+earlyPitchSpread;
    yawTarget=-maxYaw*.08*p+earlyYawSpread;
  }else if(elapsed<=climbMs+curveMs){
    const p=recoilSmooth01((elapsed-climbMs)/curveMs);
    const curveSpread=1-.35*p;
    pitchTarget=maxPitch*(.78+.10*p)+earlyPitchSpread*curveSpread;
    yawTarget=-maxYaw*(.08+.72*p)+earlyYawSpread*curveSpread;
  }else{
    const h=(elapsed-climbMs-curveMs)/Math.max(60,cooldown);
    const pitchWander=.068*Math.sin(h*.79+.35)+.038*Math.sin(h*1.73+1.10)+.022*Math.sin(h*2.41+.20);
    const yawWander=.19*Math.sin(h*.63+.70)+.098*Math.sin(h*1.37+.15)+.058*Math.sin(h*2.11+1.30);
    pitchTarget=maxPitch*((weapon==='machineGun'?.82:.88)+pitchWander*(weapon==='machineGun'?1.12:1));
    yawTarget=-maxYaw*((weapon==='machineGun'?.68:.80)+yawWander*(weapon==='machineGun'?1.18:1));
  }
  // Sustained heat adds a little instability but does not move the hold area's
  // center upward forever.
  const heat=Math.max(1,Math.min(1.24,Number(heatScale)||1));
  if(elapsed>climbMs+curveMs){
    const extra=heat-1;
    pitchTarget+=maxPitch*extra*.10*Math.sin(s*1.91+.40);
    yawTarget+=maxYaw*extra*.18*Math.sin(s*1.57+.90);
  }
  return {pitch:Math.max(0,pitchTarget),yaw:yawTarget};
}
function recoilYawShape(step,weapon=currentWeapon){
  const s=Math.max(0,Number(step)||0);
  return RECOIL_SINGLE_YAW_PATTERN[Math.min(RECOIL_SINGLE_YAW_PATTERN.length-1,Math.floor(s))]||0;
}
function singleShotRecoilImpulse(weapon,{step=0,sequence=0,hand='right',basePitch=0,baseYaw=0,adsScale=1,heatScale=1,firstScale=1}={}){
  const seq=Math.max(0,Math.floor(Number(sequence)||0)),follow=Math.max(0,Math.floor(Number(step)||0));
  // These are recoil directions, not accuracy spread. Heavy single-shot weapons
  // get a characteristic shoulder/launcher impulse while the RPG stays on its
  // dedicated straight shove. Deterministic sequences avoid random aim jumps.
  if(weapon==='pistol'){
    const side=[.42,-.34,.58,-.46,.30,-.55][seq%6];
    return{pitch:basePitch*adsScale*heatScale*firstScale,yaw:baseYaw*adsScale*side};
  }
  if(weapon==='sniper'){
    const side=(seq%4===0?.78:seq%4===1?-.58:seq%4===2?.42:-.72);
    return{pitch:basePitch*adsScale*heatScale*Math.max(.88,firstScale)*1.02,yaw:baseYaw*side};
  }
  if(weapon==='shotgun'){
    const side=[.62,-.38,.46,-.55][seq%4];
    return{pitch:basePitch*adsScale*heatScale*Math.max(.86,firstScale)*1.06,yaw:baseYaw*side};
  }
  if(weapon==='semiShotgun'){
    const side=[.48,-.62,.70,-.36,.56,-.50][seq%6],followScale=1+Math.min(.18,follow*.035);
    return{pitch:basePitch*adsScale*heatScale*firstScale*followScale,yaw:baseYaw*side*followScale};
  }
  if(weapon==='akimbo1887'){
    const outward=hand==='left'?.72:-.72;
    return{pitch:basePitch*adsScale*heatScale*Math.max(.82,firstScale),yaw:baseYaw*outward};
  }
  if(weapon==='grenadeLauncher'){
    const side=[.16,-.10,.12,-.14][seq%4];
    return{pitch:basePitch*adsScale*heatScale*Math.max(.78,firstScale)*.72,yaw:baseYaw*side};
  }
  if(weapon==='rpg')return{pitch:basePitch*adsScale*heatScale*firstScale,yaw:0};
  const yawShape=recoilYawShape(follow,weapon);
  return{pitch:basePitch*adsScale*heatScale*firstScale,yaw:baseYaw*adsScale*firstScale*yawShape};
}
function automaticRecoilActive(weapon){const r=recoilSpec(weapon);return !!r.automatic&&(weapon!=='assault'||assaultFireMode==='auto');}
function resetRecoilBookkeeping({kick=true}={}){
  // This resets only recoil bookkeeping. It must never alter yaw/pitch.
  recoilDebtPitch=0;recoilDebtYaw=0;recoilPatternPitch=0;recoilPatternYaw=0;endRecoilBurst();if(kick)weaponKickZ=weaponKickVelocity=0;
}
function weaponVisualKickProfile(weapon=currentWeapon){
  return ({
    pistol:{impulse:1.62,stiffness:330,damping:29,maxTravel:.145,rear:.98,lift:.22,pitch:.54,yaw:.010,roll:.013,adsRear:.90,actionMs:86},
    assault:{impulse:2.10,stiffness:220,damping:21,maxTravel:.205,rear:1.12,lift:.27,pitch:.68,yaw:.008,roll:.011,adsRear:.94,actionMs:58},
    ump:{impulse:1.68,stiffness:315,damping:27,maxTravel:.160,rear:.98,lift:.18,pitch:.46,yaw:.007,roll:.010,adsRear:.90,actionMs:46},
    machineGun:{impulse:2.62,stiffness:176,damping:18.5,maxTravel:.255,rear:1.30,lift:.34,pitch:.86,yaw:.014,roll:.020,adsRear:.95,actionMs:60},
    shotgun:{impulse:3.35,stiffness:152,damping:17,maxTravel:.300,rear:1.38,lift:.46,pitch:1.14,yaw:.020,roll:.032,adsRear:.95,actionMs:126},
    semiShotgun:{impulse:2.48,stiffness:205,damping:21,maxTravel:.228,rear:1.18,lift:.33,pitch:.84,yaw:.017,roll:.024,adsRear:.94,actionMs:86},
    akimbo1887:{impulse:1.28,stiffness:238,damping:22.5,maxTravel:.170,rear:.82,lift:.14,pitch:.23,yaw:0,roll:0,adsRear:1,actionMs:116},
    sniper:{impulse:3.72,stiffness:128,damping:16,maxTravel:.325,rear:1.50,lift:.48,pitch:1.18,yaw:.022,roll:.035,adsRear:.96,actionMs:142},
    grenadeLauncher:{impulse:3.28,stiffness:148,damping:17.5,maxTravel:.300,rear:1.42,lift:.29,pitch:.72,yaw:.012,roll:.018,adsRear:.96,actionMs:145},
    rpg:{impulse:3.38,stiffness:135,damping:16,maxTravel:.305,rear:1.40,lift:.35,pitch:.92,yaw:.004,roll:.008,adsRear:.97,actionMs:150},
  })[weapon]||{impulse:1.6,stiffness:250,damping:23,maxTravel:.18,rear:1,lift:.22,pitch:.55,yaw:.008,roll:.012,adsRear:.92,actionMs:80};
}
function weaponVisualAttachmentRecoilScale(weapon=currentWeapon){const safe=WEAPON_SPECS[weapon]?weapon:'pistol',base=WEAPON_SPECS[safe],resolved=effectiveWeaponSpec(safe),pitch=Math.max(.2,Number(resolved.recoilPitch||base.recoilPitch)/Math.max(.000001,Number(base.recoilPitch)||1)),yaw=Math.max(.2,Number(resolved.recoilYaw||base.recoilYaw||base.recoilPitch)/Math.max(.000001,Number(base.recoilYaw||base.recoilPitch)||1));return THREE.MathUtils.clamp(Math.sqrt(pitch*yaw)*bipodRecoilScale(safe),.48,1.18);}
function weaponKickImpulse(weapon){
  const profile=weaponVisualKickProfile(weapon),recoilScale=Math.max(0,Math.min(3,(Number(weaponRules(weapon).recoilScale)||0)/100)),attachmentScale=weaponVisualAttachmentRecoilScale(weapon);
  return profile.impulse*recoilScale*attachmentScale;
}
function addWeaponKick(weapon){const profile=weaponVisualKickProfile(weapon),attachmentScale=weaponVisualAttachmentRecoilScale(weapon);weaponKickVelocity=Math.min(7.2,weaponKickVelocity+weaponKickImpulse(weapon));weaponKickZ=Math.min(profile.maxTravel*attachmentScale,weaponKickZ);}
function updateWeaponKick(dt){
  // Visual weapon kick is intentionally separate from aim recoil. Resetting or
  // finishing this spring can never change the bullet/camera aim direction.
  const profile=weaponVisualKickProfile(currentWeapon),attachmentScale=weaponVisualAttachmentRecoilScale(currentWeapon),maxTravel=profile.maxTravel*attachmentScale;let remaining=Math.min(.05,Math.max(0,Number(dt)||0));
  while(remaining>.000001){const step=Math.min(1/120,remaining);weaponKickVelocity+=(-profile.stiffness*weaponKickZ-profile.damping*weaponKickVelocity)*step;weaponKickZ+=weaponKickVelocity*step;weaponKickZ=THREE.MathUtils.clamp(weaponKickZ,-.025,maxTravel);remaining-=step;}
  if(Math.abs(weaponKickZ)<.00005&&Math.abs(weaponKickVelocity)<.001){weaponKickZ=0;weaponKickVelocity=0;}
}
function weaponActionPulse(weapon=currentWeapon,now=performance.now()){
  const ms=weaponVisualKickProfile(weapon).actionMs,elapsed=now-(lastLocalShotAt||0);if(elapsed<0||elapsed>=ms)return 0;const p=elapsed/Math.max(1,ms);return Math.sin(Math.PI*p);
}
function registerLocalShotHeat(weapon,now){
  const previousAt=localShotHeatAt[weapon]||0,automatic=automaticRecoilActive(weapon),freshBurst=automatic&&(localRecoilStep[weapon]??-1)<0,firstShot=automatic?freshBurst:(!previousAt||now-previousAt>420),heat=weaponHeatAfterDelay(weapon,localShotHeat[weapon]||0,previousAt?now-previousAt:0);
  localShotHeat[weapon]=weaponHeatAfterShot(weapon,heat);localShotHeatAt[weapon]=now;
  if(firstShot)localRecoilStep[weapon]=0;else localRecoilStep[weapon]+=1;
  return {heat,firstShot};
}
function applyAimRecoilDelta(deltaPitch=0,deltaYaw=0){
  const beforePitch=pitch,beforeYaw=yaw;pitch=THREE.MathUtils.clamp(pitch+(Number(deltaPitch)||0),-1.28,1.28);yaw+=Number(deltaYaw)||0;
  const appliedPitch=pitch-beforePitch,appliedYaw=yaw-beforeYaw;recoilDebtPitch+=appliedPitch;recoilDebtYaw+=appliedYaw;
  return{pitch:appliedPitch,yaw:appliedYaw};
}
function applyAimRecoil(weapon,preShotHeat=0,firstShot=false,hand='right'){
  const r=recoilSpec(weapon),automatic=automaticRecoilActive(weapon),recoilScale=Math.max(0,Math.min(3,(Number(weaponRules(weapon).recoilScale)||0)/100)),adsScale=1-.20*Math.max(0,Math.min(1,adsBlend)),heatScale=1+Math.min(.24,Math.max(0,preShotHeat)*.04),step=localRecoilStep[weapon]||0;
  const basePitch=Math.max(0,Number(r.recoilPitch)||0)*recoilScale,baseYaw=Math.max(0,Number(r.recoilYaw)||0)*recoilScale,firstScale=firstShot?Math.max(.18,Math.min(1,Number(r.firstShotRecoilScale)||.5)):1;
  const softPitch=Math.max(0,(Number(r.recoilMaxPitch)||Math.max(0,Number(r.recoilPitch)||0))*recoilScale),softYaw=Math.max(0,(Number(r.recoilMaxYaw)||Number(r.recoilYaw)||.020)*recoilScale),hardPitch=softPitch*1.08,hardYaw=softYaw*1.12;
  if(automatic){
    const target=automaticRecoilTarget(step,weapon,recoilScale,adsScale,heatScale),nextPatternPitch=Math.max(recoilPatternPitch,Math.max(0,target.pitch)),nextPatternYaw=THREE.MathUtils.clamp(target.yaw,-hardYaw,hardYaw),deltaPitch=Math.max(0,nextPatternPitch-recoilPatternPitch),deltaYaw=nextPatternYaw-recoilPatternYaw;
    recoilPatternPitch=nextPatternPitch;recoilPatternYaw=nextPatternYaw;
    // Debt is the actual unresolved aim displacement. Clamp that displacement
    // to the weapon envelope as well as clamping the pattern itself, otherwise
    // rapid release/re-trigger cycles can stack multiple bounded envelopes.
    const nextDebtPitch=THREE.MathUtils.clamp(recoilDebtPitch+deltaPitch,0,hardPitch),nextDebtYaw=THREE.MathUtils.clamp(recoilDebtYaw+deltaYaw,-hardYaw,hardYaw);
    applyAimRecoilDelta(nextDebtPitch-recoilDebtPitch,nextDebtYaw-recoilDebtYaw);return;
  }
  const impulse=singleShotRecoilImpulse(weapon,{step,sequence:localWeaponShotSequence[weapon]||0,hand,basePitch,baseYaw,adsScale,heatScale,firstScale}),nextDebtPitch=THREE.MathUtils.clamp(recoilDebtPitch+impulse.pitch,0,hardPitch),nextDebtYaw=THREE.MathUtils.clamp(recoilDebtYaw+impulse.yaw,-hardYaw,hardYaw);
  applyAimRecoilDelta(nextDebtPitch-recoilDebtPitch,nextDebtYaw-recoilDebtYaw);
}
function updateAimRecoil(dt){
  const r=recoilSpec(currentWeapon),automatic=automaticRecoilActive(currentWeapon),totalDt=Math.min(.05,Math.max(0,Number(dt)||0)),now=performance.now();
  if(automatic&&recoilBurstActive&&recoilBurstWeapon===currentWeapon&&recoilBurstReleaseAt){
    if(fireInputHeld())recoilBurstReleaseAt=0;
    else if(now-recoilBurstReleaseAt>=34)endRecoilBurst(recoilBurstReleaseAt);
  }
  const releaseAt=recoilBurstReleaseAt||recoilBurstEndedAt,recoveryAge=automatic?now-releaseAt:now-lastLocalShotAt,delay=Math.max(0,Number(r.recoilRecoveryDelayMs)||0),canRecover=!fireInputHeld()&&recoveryAge>=delay;
  if(canRecover&&(Math.abs(recoilDebtPitch)>.000001||Math.abs(recoilDebtYaw)>.000001)){
    const recovery=Math.max(5,Number(r.recoilRecovery)||12),pitchShare=1-Math.exp(-recovery*.46*totalDt),yawShare=1-Math.exp(-recovery*.58*totalDt),recoverPitch=recoilDebtPitch*pitchShare,recoverYaw=recoilDebtYaw*yawShare;
    pitch=THREE.MathUtils.clamp(pitch-recoverPitch,-1.28,1.28);yaw-=recoverYaw;recoilDebtPitch-=recoverPitch;recoilDebtYaw-=recoverYaw;
    if(Math.abs(recoilDebtPitch)<.00002)recoilDebtPitch=0;if(Math.abs(recoilDebtYaw)<.00002)recoilDebtYaw=0;
  }
}
function presentLocalShot(weapon,now=performance.now(),hand='right'){
  // Shooter-side prediction: weapon feedback must happen on the trigger frame,
  // not after a WebSocket round trip. The server still owns acceptance, damage,
  // hit detection and the authoritative ammo state returned in the fire ack.
  if(!godMode)ammo[weapon]=Math.max(0,(ammo[weapon]||0)-1);
  lastShotVisualAt=now;if(weapon==='akimbo1887'){const side=hand==='left'?'left':'right';if(side==='left')akimboLeftCycleStartedAt=now;else akimboRightCycleStartedAt=now;akimboCycleSoundPlayed[side]=false;soundShot(weapon,side);}else{addWeaponKick(weapon);soundShot(weapon);}
  if(weapon==='shotgun'){shotgunPumpStartedAt=now;shotgunPumpSoundPlayed=false;}
  const flash=localMuzzleObject(weapon,hand);if(flash)flash.material.opacity=weaponHasAttachment(weapon,attachmentsForWeapon(weapon),'suppressor')?.18:1;
}
function requestShot(hand='right'){
  const now=performance.now(),weapon=currentWeapon,interruptShotgunReload=!godMode&&weapon==='shotgun'&&!!reloadUntil&&(ammo.shotgun||0)>0;
  if(!shell.canPlay||!matchAllowsCombat(matchState)||hp<=0||traversal||!combatWeaponAvailable(now))return false;
  if(sprinting){const outMs=weaponSprintOutMs(weapon);cancelSprint({lockMs:outMs+90});sprintActionReadyAt=Math.max(sprintActionReadyAt,now+outMs);pendingSprintShot=weapon;pendingSprintShotExpiresAt=sprintActionReadyAt+420;sendCurrentState(true);return false;}
  if(now<sprintActionReadyAt){pendingSprintShot=weapon;pendingSprintShotExpiresAt=Math.max(pendingSprintShotExpiresAt,sprintActionReadyAt+420);return false;}
  const localReady=weapon==='akimbo1887'?(akimboReadyAt[hand==='left'?'left':'right']||0):(fireReadyAt[weapon]||0);
  if(now<localReady||(!godMode&&(reloadRequestPending||(reloadUntil&&!interruptShotgunReload))))return false;
  if(!godMode&&(ammo[weapon]||0)<=0){doReload();return false;}
  if(interruptShotgunReload){reloadUntil=0;reloadWeapon='';reloadStartedAt=0;reloadRequestPending=false;}
  // The reticle is authoritative: fire along the exact camera aim including
  // recoil already accumulated from previous rounds. Applying the new impulse
  // after sending means the first shot is precise and subsequent rounds climb.
  const shotYaw=round4(effectiveAimYaw()),shotPitch=round4(effectiveAimPitch()),preShotHeat=currentShotHeat(weapon,now);diagnosticsRecordEvent('shot_request',{weapon,hand,shotYaw,shotPitch,basePitch:diagnosticsRound(pitch),recoilDebtPitch:diagnosticsRound(recoilDebtPitch),recoilPatternPitch:diagnosticsRound(recoilPatternPitch),stateSeq,ammo:Number(ammo[weapon]||0),rawLookY:diagnosticsRound(gamepadFrame?.rawLookY??gamepadFrame?.lookY),processedLookY:diagnosticsRound(controllerDiagnostics.inputY),rt:diagnosticsRound(gamepadFrame?.buttons?.[GAMEPAD_BUTTON.RT]||0,3)});
  if(weapon==='akimbo1887')akimboReadyAt[hand==='left'?'left':'right']=now+weaponRules(weapon).cooldownMs;else fireReadyAt[weapon]=now+weaponRules(weapon).cooldownMs;
  presentLocalShot(weapon,now,hand);
  sendCurrentState(true);send({t:'fire',weapon,hand:weapon==='akimbo1887'?(hand==='left'?'left':'right'):undefined,yaw:shotYaw,pitch:shotPitch,adsAmount:round3(adsBlend),shotAt:Math.round(serverNow()),viewDelayMs:Math.round(currentRemoteViewDelayMs())});
  beginRecoilBurst(weapon);recoilBurstReleaseAt=0;const recoilShot=registerLocalShotHeat(weapon,now);localWeaponShotSequence[weapon]=(localWeaponShotSequence[weapon]||0)+1;lastLocalShotAt=now;applyAimRecoil(weapon,preShotHeat,recoilShot.firstShot,hand);if(!godMode&&(ammo[weapon]||0)<=0)endRecoilBurst();clearQueuedSprintShot();return true;
}
function updateFireControl(now){
  if(!combatWeaponAvailable(now)){clearQueuedSprintShot();return;}
  if(pendingSprintShot){if(now>pendingSprintShotExpiresAt||pendingSprintShot!==currentWeapon)clearQueuedSprintShot();else if(now>=sprintActionReadyAt){const queued=pendingSprintShot;clearQueuedSprintShot();if(queued===currentWeapon)requestShot();}}
  const spec=effectiveWeaponSpec(currentWeapon);if(fireInputHeld()&&spec?.automatic&&(currentWeapon!=='assault'||assaultFireMode==='auto')&&now>=(fireReadyAt[currentWeapon]||0)&&now>=sprintActionReadyAt)requestShot();
}
function doReload(){
  const spec=effectiveWeaponSpec(currentWeapon);
  if(!shell.canPlay||hp<=0||traversal||ladderState||!combatWeaponAvailable())return;
  // Unlimited/God Mode has no reload transition, so Reload is a true no-op and
  // cannot terminate recoil, cancel sprint, or otherwise change combat state.
  if(godMode){reloadUntil=0;reloadRequestPending=false;return;}
  clearQueuedSprintShot();cancelSprint();
  if((ammo[currentWeapon]||0)>=spec.mag)return;
  if(reloadRequestPending)return;
  if(reloadUntil)return;
  endRecoilBurst();setAim(false);const predictedStart=serverNow(),predictedMs=Math.max(1,Number(weaponRules(currentWeapon).reloadMs)||1);reloadRequestPending=true;reloadWeapon=currentWeapon;reloadStartedAt=predictedStart;reloadUntil=predictedStart+predictedMs;send({t:'reload',weapon:currentWeapon});if(currentWeapon!=='shotgun')soundReload(currentWeapon);
}
function nextWeapon(weapon){return weapon===secondaryWeapon?primaryWeapon:secondaryWeapon;}
function switchWeapon(weapon){
  clearQueuedSprintShot();cancelSprint();
  weapon=weapon===secondaryWeapon?secondaryWeapon:primaryWeapon;
  if(!shell.canPlay||hp<=0||traversal||ladderState||!combatWeaponAvailable()||weapon===currentWeapon)return;
  setAim(false);resetRecoilBookkeeping();currentWeapon=weapon;pendingWeapon=weapon;reloadRequestPending=false;reloadUntil=0;reloadWeapon='';reloadStartedAt=0;weaponSwapStartedAt=performance.now();delayFire(WEAPON_SWITCH_MS,weapon);warmWeaponAudio(weapon);syncLocalWeaponModel();send({t:'weapon',weapon});
}
function setAim(active){
  if(currentWeapon==='akimbo1887')active=false;
  const canAim=!!active&&shell.canPlay&&matchAllowsCombat(matchState)&&hp>0&&!reloadUntil&&!traversal&&!ladderState&&combatWeaponAvailable();
  if(canAim&&sprinting){
    const delay=weaponSprintAdsMs(currentWeapon);cancelSprint({lockMs:delay+70});sendCurrentState(true);
    // Sprint recovery still gates weapon actions through sprintActionReadyAt, but
    // it must never freeze the camera/weapon ADS animation. On touch, forward
    // movement auto-sprints, so the old gate created a very obvious dead pause
    // before every scope raise while moving.
  }
  adsWanted=canAim;
}

function toggleAim(){if(traversal||ladderState)return;if(currentWeapon==='akimbo1887'){setAim(false);showToast('AKIMBO · HIP FIRE');return;}setAim(!adsWanted);}
function toggleFireMode(){if(!combatWeaponAvailable())return;if(currentWeapon!=='assault'){showToast('FIRE MODE · ASSAULT ONLY');return;}assaultFireMode=assaultFireMode==='semi'?'auto':'semi';clearFireInput();touchVisual.modeUntil=performance.now()+180;preferences.setItem('breachAssaultFireMode',assaultFireMode);}
function normalizeClientAmmo(value){const v=value&&typeof value==='object'?value:{};return Object.fromEntries(WEAPON_ORDER.map(name=>{const mag=weaponCapacity(name);return[name,Math.max(0,Math.min(mag,Number(v[name]??mag)))]}));}
function syncClientAmmo(value){const v=value&&typeof value==='object'?value:{};for(const name of WEAPON_ORDER){const mag=weaponCapacity(name);ammo[name]=Math.max(0,Math.min(mag,Number(v[name]??mag)));}}
function normalizeEquipment(v){v=v&&typeof v==='object'?v:{};return Object.fromEntries(Object.entries(EQUIPMENT_CAPS).map(([name,cap])=>[name,Math.max(0,Math.min(cap,Number(v[name]??cap)))]));}
function beginEquipmentAim(kind){
  const now=performance.now();kind=String(kind||'');
  if(kind!==tacticalEquipment&&kind!==lethalEquipment)return false;
  if(!EQUIPMENT_SPECS[kind]||!shell.canPlay||!matchAllowsCombat(matchState)||hp<=0||traversal||ladderState||now<localEquipmentCooldownUntil||(!godMode&&(equipment[kind]||0)<=0)||!combatWeaponAvailable(now))return false;
  clearQueuedSprintShot();clearFireInput();cancelSprint();endRecoilBurst();setAim(false);
  // CoD-style equipment use interrupts a weapon reload. The server receives the
  // same begin action and cancels its authoritative reload state as well.
  if(reloadUntil||reloadRequestPending){reloadUntil=0;reloadWeapon='';reloadStartedAt=0;reloadRequestPending=false;}
  combatAction={phase:COMBAT_ACTION.EQUIPMENT_AIM,kind,startedAt:now,commitAt:0,recoverStartedAt:0,recoverUntil:0,pending:null};
  showTrajectory();sendCurrentState(true);send({t:'equipmentAction',action:'begin',kind});
  if(kind===tacticalEquipment)touchVisual.flashUntil=now+220;else touchVisual.stickyUntil=now+220;
  return true;
}
function makeThrowId(){return crypto.randomUUID().replace(/-/g,'').slice(0,16);}
function releaseEquipmentAim(){
  if(combatAction.phase!==COMBAT_ACTION.EQUIPMENT_AIM||!combatAction.kind)return false;
  const kind=combatAction.kind,now=performance.now(),throwId=makeThrowId(),v=trajectoryVelocity();
  hideTrajectory();
  combatAction={phase:COMBAT_ACTION.EQUIPMENT_THROW,kind,startedAt:combatAction.startedAt,commitAt:now+EQUIPMENT_THROW_COMMIT_MS,recoverStartedAt:0,recoverUntil:0,pending:{id:throwId,kind,yaw:round3(yaw),pitch:round3(pitch),vx:v.vx,vy:v.vy,vz:v.vz,fx:v.fx,fz:v.fz}};
  if(kind===tacticalEquipment)touchVisual.flashUntil=now+EQUIPMENT_THROW_COMMIT_MS+120;else touchVisual.stickyUntil=now+EQUIPMENT_THROW_COMMIT_MS+120;
  return true;
}
function commitEquipmentThrow(now=performance.now()){
  if(combatAction.phase!==COMBAT_ACTION.EQUIPMENT_THROW||!combatAction.pending)return false;
  const pending=combatAction.pending,kind=pending.kind;
  if(!shell.canPlay||!matchAllowsCombat(matchState)||hp<=0){cancelEquipmentAction({notify:true});return false;}
  localEquipmentCooldownUntil=Math.max(localEquipmentCooldownUntil,now+Math.max(360,EQUIPMENT_WEAPON_RECOVER_MS));
  const startX=position.x+pending.fx*.82,startY=position.y+currentPlayerHeight()-.22,startZ=position.z+pending.fz*.82;
  spawnThrowableVisual({id:pending.id,kind,ownerId:clientId,x:startX,y:startY,z:startZ,vx:pending.vx,vy:pending.vy,vz:pending.vz,at:serverNow()});
  sendCurrentState(true);send({t:'throw',id:pending.id,kind,yaw:pending.yaw,pitch:pending.pitch});
  combatAction={phase:COMBAT_ACTION.WEAPON_RECOVER,kind,startedAt:combatAction.startedAt,commitAt:combatAction.commitAt,recoverStartedAt:now,recoverUntil:now+EQUIPMENT_WEAPON_RECOVER_MS,pending:null};
  return true;
}
function updateCombatAction(now=performance.now()){
  if(combatAction.phase===COMBAT_ACTION.EQUIPMENT_THROW&&now>=combatAction.commitAt)commitEquipmentThrow(now);
  if(combatAction.phase===COMBAT_ACTION.WEAPON_RECOVER&&now>=combatAction.recoverUntil)combatAction={phase:COMBAT_ACTION.READY,kind:'',startedAt:0,commitAt:0,recoverStartedAt:0,recoverUntil:0,pending:null};
}
function cancelEquipmentAction({notify=true}={}){
  const wasServerAim=combatAction.phase===COMBAT_ACTION.EQUIPMENT_AIM||combatAction.phase===COMBAT_ACTION.EQUIPMENT_THROW,kind=combatAction.kind;
  combatAction={phase:COMBAT_ACTION.READY,kind:'',startedAt:0,commitAt:0,recoverStartedAt:0,recoverUntil:0,pending:null};hideTrajectory();
  if(notify&&wasServerAim&&kind&&socket?.readyState===WebSocket.OPEN)send({t:'equipmentAction',action:'cancel',kind});
}
function trajectoryVelocity(){return tacticalThrowVelocity(yaw,pitch,TACTICAL_THROW_SPEED,TACTICAL_THROW_LOFT);}
function resetTrajectoryPose(){trajectoryLastX=trajectoryLastY=trajectoryLastZ=trajectoryLastYaw=trajectoryLastPitch=trajectoryLastHeight=NaN;trajectoryLastUpdate=0;}
function showTrajectory(){
  if(!trajectoryRibbon){
    trajectoryCenters=new Float32Array(TRAJECTORY_MAX_POINTS*3);
    trajectoryVertices=new Float32Array(TRAJECTORY_MAX_POINTS*2*3);
    const indices=new Uint16Array((TRAJECTORY_MAX_POINTS-1)*6);
    for(let i=0;i<TRAJECTORY_MAX_POINTS-1;i++){const v=i*2,j=i*6;indices[j]=v;indices[j+1]=v+1;indices[j+2]=v+2;indices[j+3]=v+1;indices[j+4]=v+3;indices[j+5]=v+2;}
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(trajectoryVertices,3));geo.setIndex(new THREE.BufferAttribute(indices,1));geo.setDrawRange(0,0);
    const mat=new THREE.MeshBasicMaterial({color:0xeaf4ff,transparent:true,opacity:.66,side:THREE.DoubleSide,depthTest:true,depthWrite:false});
    trajectoryRibbon=new THREE.Mesh(geo,mat);trajectoryRibbon.frustumCulled=false;trajectoryRibbon.renderOrder=42;scene.add(trajectoryRibbon);
    trajectoryMarker=new THREE.Mesh(new THREE.SphereGeometry(.050,10,7),new THREE.MeshBasicMaterial({color:0xd7ff58,transparent:true,opacity:.94,depthTest:true,depthWrite:false}));trajectoryMarker.renderOrder=44;scene.add(trajectoryMarker);
    trajectoryLandingRing=new THREE.Mesh(new THREE.TorusGeometry(.155,.018,8,28),new THREE.MeshBasicMaterial({color:0xd7ff58,transparent:true,opacity:.90,depthTest:true,depthWrite:false}));trajectoryLandingRing.renderOrder=43;scene.add(trajectoryLandingRing);
    trajectoryLandingDot=new THREE.Mesh(new THREE.CircleGeometry(.040,20),new THREE.MeshBasicMaterial({color:0xd7ff58,transparent:true,opacity:.60,depthTest:true,depthWrite:false,side:THREE.DoubleSide}));trajectoryLandingDot.renderOrder=43;scene.add(trajectoryLandingDot);
    trajectoryScratch={cameraRight:new THREE.Vector3(),point:new THREE.Vector3(),prev:new THREE.Vector3(),next:new THREE.Vector3(),tangent:new THREE.Vector3(),view:new THREE.Vector3(),side:new THREE.Vector3()};
  }
  trajectoryRibbon.visible=true;trajectoryRibbon.geometry.setDrawRange(0,0);trajectoryMarker.visible=false;if(trajectoryLandingRing)trajectoryLandingRing.visible=false;if(trajectoryLandingDot)trajectoryLandingDot.visible=false;resetTrajectoryPose();
}
function hideTrajectory(){
  if(trajectoryRibbon){trajectoryRibbon.visible=false;trajectoryRibbon.geometry.setDrawRange(0,0);}
  if(trajectoryMarker)trajectoryMarker.visible=false;if(trajectoryLandingRing)trajectoryLandingRing.visible=false;if(trajectoryLandingDot)trajectoryLandingDot.visible=false;
  resetTrajectoryPose();
}
function trajectoryTerrainFirstT(ax,ay,az,bx,by,bz,startClearance,endClearance,radius=0){
  if(startClearance<=0)return 0;if(endClearance>0)return null;
  let lo=0,hi=1;
  for(let i=0;i<5;i++){
    const t=(lo+hi)/2,x=ax+(bx-ax)*t,y=ay+(by-ay)*t,z=az+(bz-az)*t;
    if(y<=terrainHeight(x,z)+.08+Math.max(0,Number(radius)||0))hi=t;else lo=t;
  }
  return hi;
}
function trajectorySegmentHit(ax,ay,az,bx,by,bz,startClearance,endClearance,radius=0){
  const obstacleT=trajectoryCollision.firstHitT(ax,ay,az,bx,by,bz,radius);
  const terrainT=trajectoryTerrainFirstT(ax,ay,az,bx,by,bz,startClearance,endClearance,radius);
  if(obstacleT==null&&terrainT==null)return null;
  const terrainFirst=terrainT!=null&&(obstacleT==null||terrainT<=obstacleT),t=terrainFirst?terrainT:obstacleT;
  const x=ax+(bx-ax)*t,z=az+(bz-az)*t;let y=ay+(by-ay)*t;
  if(terrainFirst)y=Math.max(y,terrainHeight(x,z)+.09);
  return{x,y,z};
}
function updateTrajectoryRibbon(count){
  if(!trajectoryRibbon||count<2)return;
  const {cameraRight,point,prev,next,tangent,view,side}=trajectoryScratch;cameraRight.set(1,0,0).applyQuaternion(camera.quaternion);
  for(let i=0;i<count;i++){
    const c=i*3;point.set(trajectoryCenters[c],trajectoryCenters[c+1],trajectoryCenters[c+2]);
    const pi=Math.max(0,i-1)*3,ni=Math.min(count-1,i+1)*3;prev.set(trajectoryCenters[pi],trajectoryCenters[pi+1],trajectoryCenters[pi+2]);next.set(trajectoryCenters[ni],trajectoryCenters[ni+1],trajectoryCenters[ni+2]);
    tangent.copy(next).sub(prev).normalize();view.copy(camera.position).sub(point).normalize();side.crossVectors(tangent,view);
    if(side.lengthSq()<1e-5)side.copy(cameraRight);else side.normalize();
    const progress=i/(count-1),halfWidth=THREE.MathUtils.lerp(.030,.010,Math.pow(progress,.82)),v=i*6;
    trajectoryVertices[v]=point.x+side.x*halfWidth;trajectoryVertices[v+1]=point.y+side.y*halfWidth;trajectoryVertices[v+2]=point.z+side.z*halfWidth;
    trajectoryVertices[v+3]=point.x-side.x*halfWidth;trajectoryVertices[v+4]=point.y-side.y*halfWidth;trajectoryVertices[v+5]=point.z-side.z*halfWidth;
  }
  const attr=trajectoryRibbon.geometry.getAttribute('position');attr.needsUpdate=true;trajectoryRibbon.geometry.setDrawRange(0,(count-1)*6);trajectoryRibbon.visible=true;
}
function trajectoryPoseChanged(playerHeight){
  const changed=!Number.isFinite(trajectoryLastX)||Math.abs(position.x-trajectoryLastX)>.012||Math.abs(position.y-trajectoryLastY)>.012||Math.abs(position.z-trajectoryLastZ)>.012||Math.abs(yaw-trajectoryLastYaw)>.0012||Math.abs(pitch-trajectoryLastPitch)>.0012||Math.abs(playerHeight-trajectoryLastHeight)>.001;
  if(changed){trajectoryLastX=position.x;trajectoryLastY=position.y;trajectoryLastZ=position.z;trajectoryLastYaw=yaw;trajectoryLastPitch=pitch;trajectoryLastHeight=playerHeight;}
  return changed;
}
function updateEquipmentTrajectory(){
  if(combatAction.phase!==COMBAT_ACTION.EQUIPMENT_AIM||!combatAction.kind||!trajectoryRibbon||!position||!trajectoryCenters||!trajectoryVertices)return;
  const now=performance.now();if(now-trajectoryLastUpdate<TRAJECTORY_UPDATE_MS)return;
  const playerHeight=currentPlayerHeight();if(!trajectoryPoseChanged(playerHeight))return;trajectoryLastUpdate=now;
  const v=trajectoryVelocity(),maxT=2.12,radius=equipmentCollisionRadius(combatAction.kind),startX=position.x+v.fx*.82,startY=position.y+playerHeight-.22,startZ=position.z+v.fz*.82;
  let count=0,lastX=startX,lastY=startY,lastZ=startZ,impact=null,lastClearance=startY-(terrainHeight(startX,startZ)+.08+radius);
  for(let t=0;t<=maxT&&count<TRAJECTORY_MAX_POINTS;t+=TRAJECTORY_RENDER_STEP){
    const x=startX+v.vx*t,y=startY+v.vy*t-.5*modGravity(TACTICAL_GRAVITY,worldSettings)*t*t,z=startZ+v.vz*t,i=count*3;
    trajectoryCenters[i]=x;trajectoryCenters[i+1]=y;trajectoryCenters[i+2]=z;count++;
    if(count>1){
      const clearance=y-(terrainHeight(x,z)+.08+radius);impact=trajectorySegmentHit(lastX,lastY,lastZ,x,y,z,lastClearance,clearance,radius);
      if(impact){trajectoryCenters[i]=impact.x;trajectoryCenters[i+1]=impact.y;trajectoryCenters[i+2]=impact.z;break;}
      lastClearance=clearance;
    }
    lastX=x;lastY=y;lastZ=z;
  }
  if(count<2)return;
  updateTrajectoryRibbon(count);
  const end=(count-1)*3,endX=trajectoryCenters[end],endY=trajectoryCenters[end+1],endZ=trajectoryCenters[end+2];
  trajectoryMarker.visible=true;trajectoryMarker.position.set(endX,endY,endZ);trajectoryMarker.material.opacity=impact?.96:.74;const markerScale=THREE.MathUtils.clamp(camera.position.distanceTo(trajectoryMarker.position)*.075,.90,3.0);trajectoryMarker.scale.setScalar(markerScale);if(trajectoryLandingRing){trajectoryLandingRing.visible=true;trajectoryLandingRing.position.set(endX,endY,endZ);trajectoryLandingRing.quaternion.copy(camera.quaternion);trajectoryLandingRing.scale.setScalar(markerScale);trajectoryLandingRing.material.opacity=impact?.94:.72;}if(trajectoryLandingDot){trajectoryLandingDot.visible=true;trajectoryLandingDot.position.set(endX,endY,endZ);trajectoryLandingDot.quaternion.copy(camera.quaternion);trajectoryLandingDot.scale.setScalar(markerScale);trajectoryLandingDot.material.opacity=impact?.68:.48;}
}
function isSimulationLeader(now=performance.now()){
  if(!clientId)return false;
  let leader=clientId;
  for(const r of remotes.values()){
    if(r.bot||!r.id||now-r.lastSeen>SIM_LEADER_STALE_MS)continue;
    if(String(r.id).localeCompare(String(leader))<0)leader=r.id;
  }
  return leader===clientId;
}
function sendSimulationHeartbeat(stateSent=false){
  const now=performance.now();
  if(stateSent){lastSimHeartbeat=now;return;}
  if(!shell.inMatch||socket?.readyState!==WebSocket.OPEN||!isSimulationLeader(now)||now-lastSimHeartbeat<SIM_HEARTBEAT_MS)return;
  lastSimHeartbeat=now;send({t:'simTick'});
}


function syncLocalWeaponModel(){if(pistolGroup)pistolGroup.visible=currentWeapon==='pistol';if(akimboLeftGroup)akimboLeftGroup.visible=currentWeapon==='akimbo1887';if(akimboRightGroup)akimboRightGroup.visible=currentWeapon==='akimbo1887';if(assaultGroup)assaultGroup.visible=currentWeapon==='assault'&&!weaponHiddenForScope('assault');if(umpGroup)umpGroup.visible=currentWeapon==='ump'&&!weaponHiddenForScope('ump');if(machineGunGroup)machineGunGroup.visible=currentWeapon==='machineGun'&&!weaponHiddenForScope('machineGun');if(shotgunGroup)shotgunGroup.visible=currentWeapon==='shotgun'&&!weaponHiddenForScope('shotgun');if(semiShotgunGroup)semiShotgunGroup.visible=currentWeapon==='semiShotgun';if(sniperGroup)sniperGroup.visible=currentWeapon==='sniper'&&!sniperWeaponHiddenForScope();if(grenadeLauncherGroup)grenadeLauncherGroup.visible=currentWeapon==='grenadeLauncher';if(rpgGroup)rpgGroup.visible=currentWeapon==='rpg'&&!weaponHiddenForScope('rpg');syncLocalAttachmentVisuals();syncPauseContext();}
function remoteAttachmentsForWeapon(r,weapon){return weapon===r.primaryWeapon?normalizeWeaponAttachments(weapon,r.primaryAttachments):weapon===r.secondaryWeapon?normalizeWeaponAttachments(weapon,r.secondaryAttachments):normalizeWeaponAttachments(weapon,{});}
function syncRemoteWeapon(r){if(!r)return;for(const name of WEAPON_ORDER){if(!r[name])continue;r[name].visible=!r.zombie&&r.weapon===name;const attachments=remoteAttachmentsForWeapon(r,name);if(name==='akimbo1887'){for(const gun of [r.akimboLeft,r.akimboRight])if(gun)syncWeaponAttachmentVisuals(gun,name,attachments);}else syncWeaponAttachmentVisuals(r[name],name,attachments);}}
function tracerMaterial(color){return new THREE.LineBasicMaterial({color,transparent:true,opacity:.82,depthWrite:false});}
function localMuzzleObject(weapon,hand='right'){if(weapon==='akimbo1887')return hand==='left'?akimboLeftFlash:akimboRightFlash;return weapon==='sniper'?sniperFlash:weapon==='semiShotgun'?semiShotgunFlash:weapon==='shotgun'?shotgunFlash:weapon==='machineGun'?machineGunFlash:weapon==='ump'?umpFlash:weapon==='assault'?assaultFlash:weapon==='grenadeLauncher'?grenadeLauncherFlash:weapon==='rpg'?rpgFlash:pistolFlash;}
function tracerHash(id){let h=0;for(const ch of String(id||''))h=(h*33+ch.charCodeAt(0))>>>0;return h;}
function shotPacketPrimary(m){return m.primaryShot===true||(m.primaryShot==null&&m.consumeAmmo!==false);}
function shouldShowTracer(m){if(['sniper','pistol','grenadeLauncher','rpg'].includes(m.weapon))return true;if(m.weapon==='shotgun'||m.weapon==='semiShotgun'||m.weapon==='akimbo1887')return shotPacketPrimary(m);return tracerHash(m.id)%2===0;}
function createTracer(m){
  if(!shouldShowTracer(m)||['grenadeLauncher','rpg'].includes(m.weapon))return null;
  const velocity=new THREE.Vector3(Number(m.vx)||0,Number(m.vy)||0,Number(m.vz)||0),speed=Math.max(.01,velocity.length()),dir=velocity.clone().multiplyScalar(1/speed),serverStart=new THREE.Vector3(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0),start=serverStart.clone();
  if(m.ownerId===clientId){const muzzle=localMuzzleObject(m.weapon,m.hand||'right');if(muzzle){camera.updateMatrixWorld(true);muzzle.getWorldPosition(start);}}
  let visualDir=dir.clone();if(m.ownerId===clientId){const converge=serverStart.clone().addScaledVector(dir,9);visualDir=converge.sub(start).normalize();}
  const geometry=new THREE.BufferGeometry(),positions=new Float32Array(6);geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const color=m.weapon==='sniper'?0xb8efff:(m.weapon==='shotgun'||m.weapon==='semiShotgun'||m.weapon==='akimbo1887')?0xffc482:(m.weapon==='assault'||m.weapon==='ump'||m.weapon==='machineGun')?0xffdc96:0xffedbd,line=new THREE.Line(geometry,tracerMaterial(color));line.frustumCulled=false;addLiveTransient(line,'tracer');
  const gravity=Math.max(0,Number(m.gravity)||0);
  return{type:'tracer',mesh:line,geometry,start,dir:visualDir,speed,gravity,born:performance.now()-Math.min(500,Math.max(0,Number(m.visualAgeMs)||0)),lifeMs:m.weapon==='sniper'?125:m.weapon==='pistol'?105:(m.weapon==='shotgun'||m.weapon==='semiShotgun'||m.weapon==='akimbo1887')?62:92,length:m.weapon==='sniper'?2.8:(m.weapon==='assault'||m.weapon==='ump'||m.weapon==='machineGun')?1.55:m.weapon==='pistol'?.95:.75};
}
function getSharedSmokeTexture(){
  if(sharedSmokeTexture||!THREE)return sharedSmokeTexture;
  const q=document.createElement('canvas');q.width=96;q.height=96;const c=q.getContext('2d'),g=c.createRadialGradient(48,48,3,48,48,47);
  g.addColorStop(0,'rgba(255,255,255,.98)');g.addColorStop(.34,'rgba(255,255,255,.92)');g.addColorStop(.66,'rgba(235,235,235,.58)');g.addColorStop(.86,'rgba(210,210,210,.20)');g.addColorStop(1,'rgba(190,190,190,0)');c.fillStyle=g;c.fillRect(0,0,96,96);
  sharedSmokeTexture=new THREE.CanvasTexture(q);sharedSmokeTexture.userData.preserveTransient=true;sharedSmokeTexture.colorSpace=THREE.SRGBColorSpace;sharedSmokeTexture.minFilter=THREE.LinearFilter;sharedSmokeTexture.magFilter=THREE.LinearFilter;return sharedSmokeTexture;
}
function spawnRocketTrailPuff(position,velocity){
  if(!scene||!THREE)return;const speed=Math.max(.01,velocity.length()),dir=velocity.clone().multiplyScalar(1/speed),mat=new THREE.SpriteMaterial({map:getSharedSmokeTexture(),color:0xb8b8b4,transparent:true,opacity:.56,depthTest:true,depthWrite:false,toneMapped:false}),sprite=new THREE.Sprite(mat);
  sprite.position.copy(position).addScaledVector(dir,-.28);const startScale=.30+Math.random()*.10;sprite.scale.set(startScale,startScale,1);addLiveTransient(sprite,'rocket-puff');rocketTrailPuffs.push({sprite,age:0,life:.72+Math.random()*.18,startScale,driftX:(Math.random()-.5)*.12,driftY:.08+Math.random()*.08,driftZ:(Math.random()-.5)*.12});
  const cap=playerSettings.graphics==='low'?16:playerSettings.graphics==='medium'?24:34;while(rocketTrailPuffs.length>cap){const old=rocketTrailPuffs.shift();removeLiveTransient(old.sprite);disposeObject3D(old.sprite);}
}
function updateRocketTrailPuffs(dt){
  for(let i=rocketTrailPuffs.length-1;i>=0;i--){const p=rocketTrailPuffs[i];p.age+=dt;const q=Math.min(1,p.age/p.life),scale=p.startScale*(1+q*3.0);p.sprite.scale.set(scale,scale,1);p.sprite.material.opacity=.56*Math.pow(1-q,1.25);p.sprite.position.x+=p.driftX*dt;p.sprite.position.y+=p.driftY*dt;p.sprite.position.z+=p.driftZ*dt;if(q>=1){rocketTrailPuffs.splice(i,1);removeLiveTransient(p.sprite);disposeObject3D(p.sprite);}}
}
function clearRocketTrailPuffs(){const pending=rocketTrailPuffs.splice(0);for(const p of pending){removeLiveTransient(p.sprite);disposeObject3D(p.sprite);}}
function createLauncherProjectile(m){
  if(!scene||!THREE)return null;
  const weapon=m.weapon==='rpg'?'rpg':'grenadeLauncher',root=new THREE.Group(),bodyColor=weapon==='grenadeLauncher'?0x536140:0x50534d,bandColor=weapon==='grenadeLauncher'?0xc5aa62:0x8a8d87;
  // Launcher rounds are intentionally oversized in first/third person so the
  // player can read their arc and impact point, like an arcade/CoD-style 40 mm
  // grenade rather than a thin rifle tracer.
  if(weapon==='grenadeLauncher'){
    const body=new THREE.Mesh(new THREE.CylinderGeometry(.115,.125,.34,12),new THREE.MeshBasicMaterial({color:bodyColor}));root.add(body);
    const nose=new THREE.Mesh(new THREE.SphereGeometry(.118,10,7),new THREE.MeshBasicMaterial({color:0x626f4f}));nose.scale.y=.75;nose.position.y=.20;root.add(nose);
    const band=new THREE.Mesh(new THREE.CylinderGeometry(.132,.132,.055,12),new THREE.MeshBasicMaterial({color:bandColor}));band.position.y=-.07;root.add(band);
  }else{
    const body=new THREE.Mesh(new THREE.CylinderGeometry(.075,.09,.48,12),new THREE.MeshBasicMaterial({color:bodyColor}));root.add(body);
    const nose=new THREE.Mesh(new THREE.ConeGeometry(.09,.22,12),new THREE.MeshBasicMaterial({color:0x6d716b}));nose.position.y=.35;root.add(nose);
    const tail=new THREE.Mesh(new THREE.CylinderGeometry(.11,.075,.12,10),new THREE.MeshBasicMaterial({color:0x343733}));tail.position.y=-.30;root.add(tail);
  }
  const serverPos=new THREE.Vector3(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0),velocity=new THREE.Vector3(Number(m.vx)||0,Number(m.vy)||0,Number(m.vz)||0),visualStart=serverPos.clone();
  if(m.ownerId===clientId){const muzzle=localMuzzleObject(weapon);if(muzzle){camera.updateMatrixWorld(true);muzzle.getWorldPosition(visualStart);}}
  root.position.copy(visualStart);addLiveTransient(root,'launcher');
  return{type:'launcher',weapon,mesh:root,root,snapshotPos:serverPos,snapshotVel:velocity,snapshotAt:Number(m.at)||serverNow(),gravity:Math.max(0,Number(m.gravity)||0),born:performance.now(),lifeMs:Math.max(900,Number(m.lifetimeMs)||3000),visualVelocity:velocity.clone(),lastTrailAt:0};
}
function updateLauncherProjectileState(m){
  const b=bullets.get(m?.id);if(!b||b.type!=='launcher')return;
  const at=Number(m.at)||serverNow();if(at+2<b.snapshotAt)return;
  b.snapshotPos.set(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0);b.snapshotVel.set(Number(m.vx)||0,Number(m.vy)||0,Number(m.vz)||0);b.snapshotAt=at;b.gravity=Math.max(0,Number(m.gravity)||b.gravity||0);
}
function handleShot(m){
  if(!m?.id)return;if(shotPacketPrimary(m))recordReplayShot(m);if(bullets.has(m.id))return;const packetAge=Number.isFinite(Number(m.at))?Math.max(0,serverNow()-Number(m.at)):0;if(packetAge>520)return;
  // Backdate tracer animation by packet age so network latency does not make a
  // server-authoritative projectile appear to start traveling only after it
  // reaches this client.
  const visualPacket=packetAge>0?{...m,visualAgeMs:packetAge}:m;
  const projectile=['grenadeLauncher','rpg'].includes(m.weapon)?createLauncherProjectile(visualPacket):createTracer(visualPacket);if(projectile)bullets.set(m.id,projectile);
  if(m.ownerId===clientId){
    // Local sound, muzzle flash, ammo presentation and weapon kick were already
    // predicted on the trigger frame. The server echo is only authoritative
    // projectile/reconciliation data; replaying feedback here caused the
    // noticeable round-trip-time firing delay.
  }else if(shotPacketPrimary(m)&&!replayPlayback){
    const r=remotes.get(m.ownerId);if(r){const shotNow=performance.now();r.fireKickUntil=shotNow+170;if(m.weapon==='akimbo1887'&&r.akimboCycleStartedAt)r.akimboCycleStartedAt[m.hand==='left'?'left':'right']=shotNow;if(!m.suppressed)r.revealedUntil=shotNow+1500;{const v=weaponShotVariation(m.weapon),mods=remoteAttachmentsForWeapon(r,m.weapon),tone=attachmentShotTone(m.weapon,mods),soundScale=m.suppressed?.90:1;playSpatialCue(weaponShotSoundId(m.weapon,!!m.suppressed),m.x,m.y,m.z,weaponAudibleDistance(m.weapon,!!m.suppressed),.95*v.volume*soundScale*tone.volume,{playbackRate:v.playbackRate*(m.suppressed?.99:1)*tone.rate,priority:1});}}
  }
}
function removeBullet(id){const b=bullets.get(id);if(!b)return;bullets.delete(id);const root=b.root||b.mesh;removeLiveTransient(root);if(b.type==='launcher')disposeObject3D(root);else{try{b.geometry?.dispose?.();}catch{}disposeMaterialResources(b.mesh?.material);}}
function clearBullets(){for(const id of [...bullets.keys()])removeBullet(id);}
let launcherTargetScratch=null,launcherDirectionScratch=null,launcherUpScratch=null;
function updateBullets(dt=1/60){
  const now=performance.now(),srv=serverNow();
  if(!launcherTargetScratch&&THREE){launcherTargetScratch=new THREE.Vector3();launcherDirectionScratch=new THREE.Vector3();launcherUpScratch=new THREE.Vector3(0,1,0);}
  const trailInterval=playerSettings.graphics==='low'?72:playerSettings.graphics==='medium'?56:42;
  for(const [id,b] of bullets){
    const age=now-b.born;if(age>b.lifeMs+250){removeBullet(id);continue;}
    if(b.type==='launcher'){
      const predictionAge=Math.max(0,Math.min(.12,(srv-b.snapshotAt)/1000)),target=launcherTargetScratch.copy(b.snapshotPos).addScaledVector(b.snapshotVel,predictionAge);target.y-=.5*b.gravity*predictionAge*predictionAge;
      const error=b.root.position.distanceTo(target),blend=error>1.5?1:1-Math.exp(-Math.max(.001,dt)*28);b.root.position.lerp(target,blend);
      b.visualVelocity.copy(b.snapshotVel);b.visualVelocity.y-=b.gravity*predictionAge;if(b.visualVelocity.lengthSq()>.0001)b.root.quaternion.setFromUnitVectors(launcherUpScratch,launcherDirectionScratch.copy(b.visualVelocity).normalize());
      if(b.weapon==='rpg'&&now-b.lastTrailAt>=trailInterval){b.lastTrailAt=now;spawnRocketTrailPuff(b.root.position,b.visualVelocity);}
      continue;
    }
    const t=Math.max(.001,age/1000),tailT=Math.max(0,t-b.length/Math.max(.01,b.speed)),speed=b.speed,gravity=b.gravity;
    const headX=b.start.x+b.dir.x*speed*t,headY=b.start.y+b.dir.y*speed*t-.5*gravity*t*t,headZ=b.start.z+b.dir.z*speed*t;
    const tailX=b.start.x+b.dir.x*speed*tailT,tailY=b.start.y+b.dir.y*speed*tailT-.5*gravity*tailT*tailT,tailZ=b.start.z+b.dir.z*speed*tailT;
    const attr=b.geometry.getAttribute('position');attr.setXYZ(0,tailX,tailY,tailZ);attr.setXYZ(1,headX,headY,headZ);attr.needsUpdate=true;b.mesh.material.opacity=.82*Math.max(0,1-age/b.lifeMs);
  }
}
function equipmentFuseMs(kind){return kind==='sticky'?1850:kind==='frag'?2300:kind==='smoke'?1300:1650;}
function spawnThrowableVisual(m){
  if(!m?.id)return;const existing=throwables.get(m.id);if(existing){updateThrowableVisual(m);return;}
  const root=new THREE.Group(),kind=EQUIPMENT_SPECS[m.kind]?m.kind:'flash',flash=kind==='flash',smoke=kind==='smoke',frag=kind==='frag',sticky=kind==='sticky';
  const color=flash?0xd7dde0:smoke?0x5d6468:frag?0x46513b:0x4b5632,bodyMat=new THREE.MeshStandardMaterial({color,roughness:.70,metalness:flash?.42:.26,emissive:sticky?0x130900:0x050505,emissiveIntensity:sticky?.12:.04});
  let geometry;if(flash||smoke)geometry=new THREE.CylinderGeometry(.10,.10,.24,10);else if(frag)geometry=new THREE.DodecahedronGeometry(.14,0);else geometry=new THREE.OctahedronGeometry(.14,1);
  const body=new THREE.Mesh(geometry,bodyMat);if(flash||smoke)body.rotation.z=Math.PI/2;root.add(body);
  const cap=new THREE.Mesh(new THREE.CylinderGeometry(.045,.055,.075,8),new THREE.MeshStandardMaterial({color:0x252a2c,roughness:.55,metalness:.7}));cap.position.y=.13;root.add(cap);
  let indicator=null;if(sticky){indicator=new THREE.Mesh(new THREE.SphereGeometry(.025,6,5),new THREE.MeshBasicMaterial({color:0xff4b29,transparent:true,opacity:1}));indicator.position.set(.10,.04,.07);root.add(indicator);}
  root.position.set(m.x,m.y,m.z);addLiveTransient(root,'throwable');
  const at=Number(m.at)||serverNow(),fuseAt=Number(m.fuseAt)||at+equipmentFuseMs(kind);throwables.set(m.id,{root,mesh:root,body,indicator,kind,ownerId:m.ownerId,radius:equipmentCollisionRadius(kind),target:new THREE.Vector3(m.x,m.y,m.z),snapshotPos:new THREE.Vector3(m.x,m.y,m.z),snapshotVel:new THREE.Vector3(m.vx||0,m.vy||0,m.vz||0),snapshotAt:at,fuseAt,nextBeepAt:sticky?at+170:0,born:performance.now(),stuck:!!m.stuck,rolling:!!m.rolling});
  if(!replayPlayback){if(m.ownerId===clientId)soundThrowableThrow(kind);else playSpatialCue(sticky||frag?'stickyThrow':'flashThrow',m.x,m.y,m.z,30,.55);}
}

function updateThrowableVisual(m){
  const g=throwables.get(m.id);if(!g)return;
  g.snapshotPos.set(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0);g.target.copy(g.snapshotPos);g.snapshotAt=Number(m.at)||serverNow();if(Number.isFinite(Number(m.fuseAt)))g.fuseAt=Number(m.fuseAt);g.stuck=!!m.stuck;g.rolling=!!m.rolling;
  if(g.stuck)g.snapshotVel.set(0,0,0);else g.snapshotVel.set(Number(m.vx)||0,Number(m.vy)||0,Number(m.vz)||0);
}
function handleThrowableImpact(m){if(!replayPlayback)soundThrowableImpact(m.kind||'flash',m);updateThrowableVisual(m);}
function disposeMaterialResources(material){
  const materials=Array.isArray(material)?material:[material];
  for(const mat of materials){
    if(!mat)continue;
    // Transient gameplay effects own their materials. Dispose any texture-like
    // resources defensively, then the material itself. Cleanup must never throw
    // into the animation loop.
    for(const value of Object.values(mat)){if(value?.isTexture&&!value.userData?.preserveTransient&&!value.userData?.preserveWorldTexture){try{value.dispose?.();}catch{}}}
    try{mat.dispose?.();}catch{}
  }
}
function disposeObject3D(root){
  if(!root)return;
  const disposeNode=(node)=>{if(!node)return;try{node.geometry?.dispose?.();}catch{}disposeMaterialResources(node.material);};
  try{if(typeof root.traverse==='function')root.traverse(disposeNode);else disposeNode(root);}catch(error){console.warn('Transient object cleanup failed',error);}
}
function removeThrowableVisual(id){const g=throwables.get(id);if(!g)return;throwables.delete(id);const root=g.root||g.mesh;removeLiveTransient(root);disposeObject3D(root);}
function clearThrowables(){for(const id of [...throwables.keys()])removeThrowableVisual(id);}
function updateThrowables(dt){
  const now=performance.now(),srv=serverNow();
  for(const g of throwables.values()){
    let px=g.snapshotPos.x,py=g.snapshotPos.y,pz=g.snapshotPos.z;
    if(!g.stuck){const age=Math.max(0,Math.min(.34,(srv-g.snapshotAt)/1000));px+=g.snapshotVel.x*age;pz+=g.snapshotVel.z*age;if(!g.rolling)py+=g.snapshotVel.y*age-.5*modGravity(TACTICAL_GRAVITY,worldSettings)*age*age;}
    g.target.set(px,py,pz);const error=g.root.position.distanceTo(g.target);
    if(error>2.5)g.root.position.copy(g.target);else g.root.position.lerp(g.target,1-Math.exp(-dt*18));
    if(g.rolling){g.root.rotation.x+=g.snapshotVel.z*dt*8;g.root.rotation.z-=g.snapshotVel.x*dt*8;}
    else if(!g.stuck){g.root.rotation.x+=dt*7;g.root.rotation.z+=dt*5;}
    if(g.kind==='sticky'&&Number.isFinite(g.fuseAt)&&srv>=g.nextBeepAt&&srv<g.fuseAt-45){const remaining=Math.max(0,g.fuseAt-srv);soundSemtexBeep(g,remaining);g.nextBeepAt=srv+semtexBeepInterval(remaining);}
    if(g.indicator){const remaining=Number.isFinite(g.fuseAt)?Math.max(0,g.fuseAt-srv):900,pulseRate=remaining<650?.035:.020,pulse=.45+.55*Math.sin((now-g.born)*pulseRate);g.indicator.scale.setScalar(.72+pulse*.55);g.indicator.material.opacity=.65+pulse*.35;}
  }
}

function playBulletImpactSound(kind,x,y,z){
  if(kind!=='world')return;
  playSpatialCue('impactWall',Number(x)||0,Number(y)||0,Number(z)||0,42,.92,{playbackRate:.94+Math.random()*.10});
}
function spawnBulletImpactFx(m){
  if(!scene||!THREE)return;const kind=String(m?.kind||'world'),playerHit=kind==='player',x=Number(m?.x)||0,y=Number(m?.y)||0,z=Number(m?.z)||0,root=new THREE.Group();root.position.set(x,y,z);
  const count=playerHit?8:6,positions=new Float32Array(count*3),velocities=new Float32Array(count*3),geometry=new THREE.BufferGeometry();
  for(let i=0;i<count;i++){const j=i*3,a=Math.random()*Math.PI*2,speed=(playerHit?.42:.82)+Math.random()*(playerHit?.72:1.05);velocities[j]=Math.cos(a)*speed;velocities[j+1]=(playerHit?.10:.18)+Math.random()*(playerHit?.70:1.05);velocities[j+2]=Math.sin(a)*speed;}
  geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const color=playerHit?0x9e1828:0xe1c49a,material=new THREE.PointsMaterial({color,size:playerHit?.055:.042,sizeAttenuation:true,transparent:true,opacity:playerHit?.72:.86,depthWrite:false,blending:playerHit?THREE.NormalBlending:THREE.AdditiveBlending});
  const particles=new THREE.Points(geometry,material);particles.frustumCulled=false;root.add(particles);
  let mark=null;if(!playerHit){mark=new THREE.Mesh(new THREE.SphereGeometry(.021,6,4),new THREE.MeshBasicMaterial({color:0x292724,transparent:true,opacity:.84,depthWrite:false}));root.add(mark);}
  const worldMarkDuration=playerSettings.graphics==='low'?2.5:playerSettings.graphics==='medium'?3.4:4.6,impactCap=playerSettings.graphics==='low'?28:playerSettings.graphics==='medium'?44:64;
  addLiveTransient(root,'impact');bulletImpactFx.push({root,particles,velocities,mark,age:0,particleDuration:playerHit?.30:.24,duration:playerHit?.34:worldMarkDuration,playerHit});
  while(bulletImpactFx.length>impactCap){const old=bulletImpactFx.shift();removeLiveTransient(old.root);disposeObject3D(old.root);}
  if(!replayPlayback)playBulletImpactSound(kind,x,y,z);
}
function updateBulletImpactFx(dt){
  for(let i=bulletImpactFx.length-1;i>=0;i--){const f=bulletImpactFx[i];f.age+=dt;const particleP=Math.min(1,f.age/f.particleDuration),attr=f.particles.geometry.getAttribute('position'),pos=attr.array,v=f.velocities;
    if(particleP<1){for(let j=0;j<pos.length;j+=3){v[j+1]-=(f.playerHit?4.8:7.2)*dt;pos[j]+=v[j]*dt;pos[j+1]+=v[j+1]*dt;pos[j+2]+=v[j+2]*dt;}attr.needsUpdate=true;}f.particles.material.opacity=Math.max(0,1-particleP)*(f.playerHit?.72:.86);
    if(f.mark){const fadeStart=Math.max(.35,f.duration-.9),fade=f.blocked?Math.max(0,1-f.age/f.duration):f.age<fadeStart?1:Math.max(0,1-(f.age-fadeStart)/Math.max(.01,f.duration-fadeStart));f.mark.material.opacity=(f.blocked?.72:.84)*fade;}
    if(f.age>=f.duration){bulletImpactFx.splice(i,1);removeLiveTransient(f.root);disposeObject3D(f.root);}
  }
}
function clearBulletImpactFx(){const pending=bulletImpactFx.splice(0);for(const f of pending){removeLiveTransient(f.root);disposeObject3D(f.root);}}

function applyExplosionFeedback(kind,m){
  if(!position||!m)return;const radius=Math.max(1,Number(m.radius)||6),dx=(Number(m.x)||0)-position.x,dy=(Number(m.y)||0)-(camera?.position?.y||position.y),dz=(Number(m.z)||0)-position.z,dist=Math.hypot(dx,dy,dz),reach=radius*2.65,power=THREE.MathUtils.clamp(1-dist/Math.max(1,reach),0,1);if(power<=.01)return;
  const now=performance.now();blastFeedbackPower=Math.max(blastFeedbackPower,power);blastFeedbackUntil=Math.max(blastFeedbackUntil,now+THREE.MathUtils.lerp(150,420,power));blastFeedbackSeed=(Number(m.x)||0)*.73+(Number(m.z)||0)*1.19+now*.001;
  if(diagnosticsRecordingEnabled())diagnosticsRecordEvent('explosion_nearby',{kind:String(kind||''),distance:diagnosticsRound(dist,2),radius:diagnosticsRound(radius,2),power:diagnosticsRound(power,3)});
}
function explosionVisualRoll(now=performance.now()){if(now>=blastFeedbackUntil||blastFeedbackPower<=.001){blastFeedbackPower=0;return 0;}const remaining=THREE.MathUtils.clamp((blastFeedbackUntil-now)/420,0,1),p=blastFeedbackPower*remaining;return Math.sin(now*.071+blastFeedbackSeed)*p*.026;}
function makeUfoVisual(){
  const root=new THREE.Group(),disc=new THREE.Mesh(new THREE.CylinderGeometry(2.15,2.55,.42,24),new THREE.MeshStandardMaterial({color:0x8f9ca5,metalness:.72,roughness:.28,emissive:0x16262c,emissiveIntensity:.32})),dome=new THREE.Mesh(new THREE.SphereGeometry(1.05,20,12,0,Math.PI*2,0,Math.PI*.55),new THREE.MeshStandardMaterial({color:0x6edff5,emissive:0x1f91ac,emissiveIntensity:.88,transparent:true,opacity:.78,roughness:.18,metalness:.15})),ring=new THREE.Mesh(new THREE.TorusGeometry(2.35,.11,8,32),new THREE.MeshBasicMaterial({color:0xd7ff58,transparent:true,opacity:.92})),underGlow=new THREE.Mesh(new THREE.RingGeometry(.85,2.05,28),new THREE.MeshBasicMaterial({color:0x78efff,transparent:true,opacity:.34,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));
  dome.position.y=.22;ring.rotation.x=Math.PI/2;underGlow.rotation.x=-Math.PI/2;underGlow.position.y=-.24;root.add(disc,dome,ring,underGlow);root.userData.underGlow=underGlow;return root;
}
function jaggedLightningPoints(start,end,segments=18,jitter=1){
  const out=[],direction=end.clone().sub(start),side=new THREE.Vector3(1,0,0),cross=new THREE.Vector3().crossVectors(direction,side);if(cross.lengthSq()<.01)cross.set(0,0,1);cross.normalize();const side2=new THREE.Vector3().crossVectors(direction,cross).normalize();
  for(let i=0;i<=segments;i++){const t=i/segments,p=start.clone().lerp(end,t);if(i>0&&i<segments){const taper=Math.sin(Math.PI*t),j=jitter*taper;p.addScaledVector(cross,(Math.random()-.5)*j).addScaledVector(side2,(Math.random()-.5)*j);}out.push(p);}return out;
}
function lightningLine(points,color=0xeaf8ff,opacity=1){
  const material=new THREE.LineBasicMaterial({color,transparent:true,opacity,depthWrite:false,blending:THREE.AdditiveBlending});material.userData.baseOpacity=opacity;return new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),material);
}
function lightningScorchTexture(){
  const q=document.createElement('canvas');q.width=128;q.height=128;const c=q.getContext('2d'),g=c.createRadialGradient(64,64,5,64,64,62);g.addColorStop(0,'rgba(8,5,4,.92)');g.addColorStop(.34,'rgba(24,15,10,.84)');g.addColorStop(.68,'rgba(46,30,19,.52)');g.addColorStop(1,'rgba(34,22,15,0)');c.fillStyle=g;c.fillRect(0,0,128,128);for(let i=0;i<70;i++){const a=Math.random()*Math.PI*2,r=10+Math.random()*49,rr=.5+Math.random()*2.8;c.fillStyle=`rgba(${18+Math.floor(Math.random()*24)},${10+Math.floor(Math.random()*15)},${7+Math.floor(Math.random()*10)},${.18+Math.random()*.35})`;c.beginPath();c.arc(64+Math.cos(a)*r,64+Math.sin(a)*r,rr,0,Math.PI*2);c.fill();}const tex=new THREE.CanvasTexture(q);tex.colorSpace=THREE.SRGBColorSpace;tex.minFilter=THREE.LinearFilter;tex.magFilter=THREE.LinearFilter;return tex;
}
function buildLightningVisual(m){
  const x=Number(m.x)||0,y=Number(m.y)||0,z=Number(m.z)||0,root=new THREE.Group(),boltGroup=new THREE.Group(),structureGroup=new THREE.Group(),boltMaterials=[],structureMaterials=[];root.add(boltGroup,structureGroup);
  const strike=new THREE.Vector3(x,y,z),sky=new THREE.Vector3(x+(Math.random()-.5)*5,y+52,z+(Math.random()-.5)*5),mainPoints=jaggedLightningPoints(sky,strike,24,2.4),main=lightningLine(mainPoints,0xf4fbff,1);boltGroup.add(main);boltMaterials.push(main.material);
  const glow=lightningLine(mainPoints,0x62bfff,.48);boltGroup.add(glow);boltMaterials.push(glow.material);
  for(const idx of [5,8,11,14,17,20]){const origin=mainPoints[Math.min(idx,mainPoints.length-2)],drop=8+Math.random()*14,end=origin.clone().add(new THREE.Vector3((Math.random()-.5)*10,-drop,(Math.random()-.5)*10)),branch=lightningLine(jaggedLightningPoints(origin,end,7,.95),0xaedfff,.62);boltGroup.add(branch);boltMaterials.push(branch.material);}
  // Do not add transient PointLights here. Three.js bakes NUM_POINT_LIGHTS into
  // lit-material shader programs, so changing that count during a strike forces
  // synchronous recompilation of world/weapon/player MeshStandardMaterials.
  const flash=new THREE.Mesh(new THREE.SphereGeometry(2.9,12,8),new THREE.MeshBasicMaterial({color:0xbfe8ff,transparent:true,opacity:.28,depthWrite:false,blending:THREE.AdditiveBlending}));flash.position.copy(strike).add(new THREE.Vector3(0,1.25,0));boltGroup.add(flash);
  const hit=new THREE.Mesh(new THREE.SphereGeometry(.72,12,8),new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.96,depthWrite:false,blending:THREE.AdditiveBlending}));hit.position.copy(strike);boltGroup.add(hit);boltMaterials.push(hit.material);
  const sx=Number(m.structureX),sz=Number(m.structureZ),sw=Math.max(.5,Number(m.structureW)||1),sd=Math.max(.5,Number(m.structureD)||1),roof=Math.max(y,Number(m.structureRoofY)||y),base=terrainHeight(Number.isFinite(sx)?sx:x,Number.isFinite(sz)?sz:z),sh=Math.max(.45,roof-base),structureX=Number.isFinite(sx)?sx:x,structureZ=Number.isFinite(sz)?sz:z;
  if(Number.isFinite(sw)&&Number.isFinite(sd)){
    const boxGeometry=new THREE.BoxGeometry(sw+.12,sh+.12,sd+.12),edgeGeometry=new THREE.EdgesGeometry(boxGeometry);boxGeometry.dispose();const edges=new THREE.LineSegments(edgeGeometry,new THREE.LineBasicMaterial({color:0x6edfff,transparent:true,opacity:.78,depthWrite:false,blending:THREE.AdditiveBlending}));edges.position.set(structureX,base+sh/2,structureZ);structureGroup.add(edges);structureMaterials.push(edges.material);
    const halfW=sw/2,halfD=sd/2;for(let i=0;i<7;i++){const side=i%4,ex=side===0?structureX-halfW:side===1?structureX+halfW:structureX+(Math.random()-.5)*sw,ez=side===2?structureZ-halfD:side===3?structureZ+halfD:structureZ+(Math.random()-.5)*sd,ey=base+Math.random()*sh,end=new THREE.Vector3(ex,ey,ez),arc=lightningLine(jaggedLightningPoints(strike,end,8,.48),0x8de8ff,.7);structureGroup.add(arc);structureMaterials.push(arc.material);}
  }
  const scorch=new THREE.Mesh(new THREE.PlaneGeometry(Math.min(4.2,Math.max(2.1,Math.min(sw,sd)*.42)),Math.min(4.2,Math.max(2.1,Math.min(sw,sd)*.42))),new THREE.MeshBasicMaterial({map:lightningScorchTexture(),transparent:true,opacity:.9,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));scorch.rotation.x=-Math.PI/2;scorch.rotation.z=Math.random()*Math.PI*2;scorch.position.set(x,y+.035,z);root.add(scorch);
  const smokeSprites=[],smokeTex=getSharedSmokeTexture();for(let i=0;i<5;i++){const mat=new THREE.SpriteMaterial({map:smokeTex,color:0x5b6265,transparent:true,opacity:.36,depthWrite:false}),sprite=new THREE.Sprite(mat);sprite.scale.set(1.7+Math.random()*1.5,1.7+Math.random()*1.5,1);sprite.position.set(x+(Math.random()-.5)*.8,y+.4+Math.random()*.8,z+(Math.random()-.5)*.8);sprite.userData={phase:Math.random()*Math.PI*2,baseX:sprite.position.x,baseZ:sprite.position.z,rise:.28+Math.random()*.22};root.add(sprite);smokeSprites.push(sprite);}
  return{root,boltGroup,structureGroup,boltMaterials,structureMaterials,flash,scorch,smokeSprites};
}
function earthquakeMapPoint(seed,index,cycle,limit){
  const a=Math.sin((seed%100003)*.00017+index*12.9898+cycle*4.1414)*43758.5453,b=Math.sin((seed%99991)*.00019+index*78.233+cycle*9.173)*24634.6345,u=a-Math.floor(a),v=b-Math.floor(b),span=Math.max(8,Number(limit)||24)*.92;
  return{x:(u*2-1)*span,z:(v*2-1)*span};
}
function buildEarthquakeVisual(m){
  const root=new THREE.Group(),seed=Math.floor(Number(m.seed)||tracerHash(String(m.id||'quake'))),limit=Math.max(24,minimapWorldLimit()),centerY=worldSupportHeight(0,0,1000,false),count=isTouch?28:52,geometry=new THREE.BoxGeometry(.30,.23,.34),material=new THREE.MeshBasicMaterial({color:0x67584a,transparent:true,opacity:0}),debris=new THREE.InstancedMesh(geometry,material,count),dummy=new THREE.Object3D(),items=[];
  debris.instanceMatrix.setUsage(THREE.DynamicDrawUsage);root.add(debris);
  for(let i=0;i<count;i++){
    const pt=earthquakeMapPoint(seed,i,0,limit),ground=worldSupportHeight(pt.x,pt.z,1000,false),a=((seed+i*977)%6283)/1000,scale=.62+((seed+i*43)%115)/100,spin=1.05+((seed+i*67)%220)/100;
    items.push({x:pt.x,z:pt.z,y:ground+10+((seed+i*211)%1600)/100,vx:Math.sin(a*1.7)*.95,vz:Math.cos(a*1.3)*.95,vy:-(8.8+((seed+i*89)%520)/100),rx:a,ry:a*.7,rz:a*.3,spin,scale,cycle:0});
    dummy.position.set(pt.x,items[i].y,pt.z);dummy.scale.setScalar(scale);dummy.rotation.set(items[i].rx,items[i].ry,items[i].rz);dummy.updateMatrix();debris.setMatrixAt(i,dummy.matrix);
  }
  debris.instanceMatrix.needsUpdate=true;
  const dustCount=isTouch?84:160,dustGeo=new THREE.BufferGeometry(),dustPos=new Float32Array(dustCount*3),dustItems=[];
  for(let i=0;i<dustCount;i++){
    const pt=earthquakeMapPoint(seed+317,i,0,limit),y=worldSupportHeight(pt.x,pt.z,1000,false)+.12+((seed+i*73)%220)/100;
    dustPos[i*3]=pt.x;dustPos[i*3+1]=y;dustPos[i*3+2]=pt.z;dustItems.push({x:pt.x,z:pt.z,baseY:y,speed:.22+((seed+i*29)%60)/100,phase:(seed+i*97)%6283/1000,drift:.55+((seed+i*31)%90)/100});
  }
  dustGeo.setAttribute('position',new THREE.BufferAttribute(dustPos,3));
  const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0x9a8064,size:isTouch?.62:.78,transparent:true,opacity:.34,depthWrite:false,sizeAttenuation:true}));root.add(dust);
  return{root,debris,debrisDummy:dummy,debrisItems:items,dust,dustItems,seed,limit,centerY};
}
function captureSolarEnvironment(){
  if(solarEnvironmentBaseline)return solarEnvironmentBaseline;
  solarEnvironmentBaseline={
    exposure:Number.isFinite(Number(renderer?.toneMappingExposure))?Number(renderer.toneMappingExposure):1.05,
    sunIntensity:Number.isFinite(Number(worldSunLight?.intensity))?Number(worldSunLight.intensity):2.15,
    hemiIntensity:Number.isFinite(Number(worldHemiLight?.intensity))?Number(worldHemiLight.intensity):2.2,
  };
  return solarEnvironmentBaseline;
}
function buildSolarNukeVisual(m){
  const baseline=captureSolarEnvironment(),limit=Math.max(72,minimapWorldLimit()),root=new THREE.Group(),core=new THREE.Mesh(new THREE.SphereGeometry(1,34,26),new THREE.MeshBasicMaterial({color:0xfff3b8,depthWrite:true})),halo=new THREE.Mesh(new THREE.SphereGeometry(1.18,26,18),new THREE.MeshBasicMaterial({color:0xffa43a,transparent:true,opacity:.15,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.BackSide}));
  root.add(halo,core);root.position.set(limit*.94,Math.max(160,limit*1.45),limit*.78);root.scale.setScalar(7.5);
  const endPos=new THREE.Vector3(limit*.08,48,limit*.06),retreatPos=new THREE.Vector3(limit*.08,Math.max(178,limit*1.52),limit*.06);
  return{root,core,halo,startPos:root.position.clone(),endPos,retreatPos,baseExposure:baseline.exposure,baseSunIntensity:baseline.sunIntensity,baseHemiIntensity:baseline.hemiIntensity,burnField:null};
}
function activeEarthquakeVisual(){const now=serverNow();for(let i=killstreakFx.length-1;i>=0;i--){const f=killstreakFx[i];if(f.type==='earthquake'&&f.affectsLocal!==false&&now>=f.start&&now<f.end)return f;}return null;}
function activeSolarNukeVisual(){const now=serverNow();for(let i=killstreakFx.length-1;i>=0;i--){const f=killstreakFx[i];if(f.type==='solarnuke'&&now>=f.start&&now<f.end)return f;}return null;}
function restoreSolarEnvironment(){
  const baseline=solarEnvironmentBaseline;if(!baseline)return;
  if(renderer&&Number.isFinite(baseline.exposure))renderer.toneMappingExposure=baseline.exposure;
  if(worldSunLight&&Number.isFinite(baseline.sunIntensity))worldSunLight.intensity=baseline.sunIntensity;
  if(worldHemiLight&&Number.isFinite(baseline.hemiIntensity))worldHemiLight.intensity=baseline.hemiIntensity;
  solarEnvironmentBaseline=null;
}
function solarBurnTexture(seed=1){
  const q=document.createElement('canvas');q.width=256;q.height=256;const c=q.getContext('2d');c.clearRect(0,0,256,256);c.save();c.translate(128,128);
  const points=34;c.beginPath();for(let i=0;i<points;i++){const a=i/points*Math.PI*2,j=.78+.12*Math.sin(a*5+seed*.0017)+.07*Math.sin(a*11+seed*.0031),r=111*j,x=Math.cos(a)*r,y=Math.sin(a)*r;if(i)c.lineTo(x,y);else c.moveTo(x,y);}c.closePath();c.clip();
  const g=c.createRadialGradient(-12,-10,4,0,0,118);g.addColorStop(0,'rgba(5,4,3,.98)');g.addColorStop(.32,'rgba(17,10,6,.96)');g.addColorStop(.66,'rgba(48,23,11,.88)');g.addColorStop(.86,'rgba(98,42,13,.60)');g.addColorStop(1,'rgba(122,54,16,.12)');c.fillStyle=g;c.fillRect(-128,-128,256,256);
  for(let i=0;i<46;i++){const a=((seed+i*239)%6283)/1000,r=18+((seed+i*83)%7600)/100,rr=1.2+((seed+i*29)%260)/100;c.fillStyle=`rgba(${70+(i*17)%70},${18+(i*11)%34},${4+(i*7)%12},${.18+(i%5)*.055})`;c.beginPath();c.arc(Math.cos(a)*r,Math.sin(a)*r,rr,0,Math.PI*2);c.fill();}
  c.lineCap='round';for(let i=0;i<14;i++){const a=((seed+i*421)%6283)/1000,len=28+((seed+i*71)%5200)/100;c.strokeStyle=i%3===0?'rgba(255,92,18,.34)':'rgba(9,5,3,.66)';c.lineWidth=i%3===0?1.2:2.1;c.beginPath();let x=Math.cos(a)*12,y=Math.sin(a)*12;c.moveTo(x,y);for(let k=1;k<=4;k++){const d=len*k/4,aa=a+Math.sin(seed*.0003+i*1.7+k)*.16;x=Math.cos(aa)*d;y=Math.sin(aa)*d;c.lineTo(x,y);}c.stroke();}
  c.restore();const tex=new THREE.CanvasTexture(q);tex.colorSpace=THREE.SRGBColorSpace;tex.minFilter=THREE.LinearFilter;tex.magFilter=THREE.LinearFilter;return tex;
}
function prepareSolarBurnField(solar,m={}){
  if(!scene||!THREE||!solar)return null;const seed=tracerHash(`${m.id||'solar'}:${Math.floor(Number(m.startedAt)||serverNow())}`),root=new THREE.Group(),texture=solarBurnTexture(seed),markGeo=new THREE.PlaneGeometry(1,1),markMat=new THREE.MeshBasicMaterial({map:texture,transparent:true,opacity:.90,depthWrite:false,side:THREE.DoubleSide,polygonOffset:true,polygonOffsetFactor:-3}),smokeTex=getSharedSmokeTexture(),candidates=[];
  const addCandidate=(x,z,w,d,y,kind,index)=>{if(!Number.isFinite(x)||!Number.isFinite(z)||!Number.isFinite(y))return;const width=Math.max(1.5,Math.min(7.2,Number(w)||3.2)),depth=Math.max(1.5,Math.min(7.2,Number(d)||3.2)),mark=new THREE.Mesh(markGeo,markMat);mark.rotation.x=-Math.PI/2;mark.rotation.z=((seed+index*313)%6283)/1000;mark.position.set(x,y+.035,z);mark.scale.set(width*.18,depth*.18,1);mark.visible=false;root.add(mark);const smoke=[];const smokeCount=kind==='building'&&!isTouch?2:1;for(let s=0;s<smokeCount;s++){const mat=new THREE.SpriteMaterial({map:smokeTex,color:0x4b4540,transparent:true,opacity:0,depthWrite:false}),sprite=new THREE.Sprite(mat),size=1.8+Math.min(width,depth)*.22+s*.25;sprite.scale.set(size,size,1);sprite.position.set(x+(s?width*.16:-width*.08),y+.22,z+(s?-depth*.12:depth*.07));sprite.visible=false;root.add(sprite);smoke.push(sprite);}const heatFactor=.88+((seed+index*97)%250)/1000;candidates.push({x,y,z,width,depth,kind,mark,smoke,heatFactor,burnAt:0});};
  const spreadPick=(items,count)=>{if(items.length<=count)return items;const out=[];for(let i=0;i<count;i++)out.push(items[Math.min(items.length-1,Math.floor(i*(items.length-1)/Math.max(1,count-1)))]);return out;};
  const buildingItems=[];for(let i=0;i<BUILDINGS.length;i++){const b=BUILDINGS[i];if(!b)continue;const x=Number(b.x),z=Number(b.z);if(!Number.isFinite(x)||!Number.isFinite(z))continue;buildingItems.push({x,z,w:Number(b.w)||5,d:Number(b.d)||5,y:worldSupportHeight(x,z,1000,false)+.04,kind:'building',index:i});}
  const propItems=[];for(let i=0;i<STATIC_BOXES.length;i++){const o=STATIC_BOXES[i];if(!o||Number(o.h)<1.2||String(o.kind||'')==='boundary')continue;const x=Number(o.x),z=Number(o.z);if(!Number.isFinite(x)||!Number.isFinite(z))continue;propItems.push({x,z,w:Number(o.w)||3,d:Number(o.d)||3,y:worldSupportHeight(x,z,1000,false)+.04,kind:'prop',index:1000+i});}
  const groundItems=[],limit=Math.max(22,minimapWorldLimit()*.88),groundCount=isTouch?7:12;for(let i=0;i<groundCount*2&&groundItems.length<groundCount;i++){const a=i*2.3999632297+((seed%6283)/1000),r=12+(i/(groundCount*2-1))*Math.max(8,limit-12),x=Math.cos(a)*r,z=Math.sin(a)*r,ground=terrainHeight(x,z),support=worldSupportHeight(x,z,1000,false);if(support-ground>.55)continue;groundItems.push({x,z,w:3.4+(i%4)*.45,d:2.9+((i+2)%4)*.42,y:ground+.04,kind:'ground',index:2000+i});}
  const selected=[...spreadPick(buildingItems,isTouch?11:18),...spreadPick(propItems,isTouch?8:12),...groundItems];selected.forEach((item,i)=>addCandidate(item.x,item.z,item.w,item.d,item.y,item.kind,item.index+i*17));addLiveTransient(root,'solar-aftermath');const field={root,candidates,createdAt:performance.now(),seed};solarBurnFx.push(field);return field;
}
function igniteSolarCandidate(candidate,now){if(!candidate||candidate.burnAt)return;candidate.burnAt=now;candidate.mark.visible=true;for(const sprite of candidate.smoke){sprite.visible=true;sprite.userData={startX:sprite.position.x,startY:sprite.position.y,startZ:sprite.position.z,phase:(candidate.x*.17+candidate.z*.11+candidate.smoke.indexOf(sprite)*1.7),lifetime:22000+(candidate.kind==='building'?5000:0)};}}
function updateSolarBurnProgress(solar,approach,now=performance.now(),force=false){
  const field=solar?.burnField;if(!field)return;const sun=solar.root.position,radius=Math.max(1,solar.root.scale.x),heatReach=force?170:THREE.MathUtils.lerp(4,138,smoothstep01(Math.max(0,(approach-.10)/.90)));
  for(const candidate of field.candidates){if(candidate.burnAt)continue;const dx=candidate.x-sun.x,dy=candidate.y-sun.y,dz=candidate.z-sun.z,shellDistance=Math.max(0,Math.hypot(dx,dy,dz)-radius);if(shellDistance<=heatReach*candidate.heatFactor)igniteSolarCandidate(candidate,now);}
}
function updateSolarBurnAftermath(dt,now=performance.now()){
  for(const field of solarBurnFx){for(const candidate of field.candidates||[]){if(!candidate.burnAt)continue;const age=Math.max(0,now-candidate.burnAt),grow=smoothstep01(Math.min(1,age/520));candidate.mark.scale.set(candidate.width*(.18+.82*grow),candidate.depth*(.18+.82*grow),1);for(let i=0;i<candidate.smoke.length;i++){const sprite=candidate.smoke[i],u=sprite.userData||{},life=Math.max(1,u.lifetime||22000),lifeP=Math.min(1,age/life),fade=lifeP<.72?1:Math.max(0,1-(lifeP-.72)/.28),smokeGrow=smoothstep01(Math.min(1,age/900));sprite.material.opacity=.34*smokeGrow*fade;sprite.position.x=(u.startX||candidate.x)+Math.sin(now*.00105+(u.phase||0))*(.24+i*.08);sprite.position.z=(u.startZ||candidate.z)+Math.cos(now*.00092+(u.phase||0))*(.22+i*.07);sprite.position.y=(u.startY||candidate.y)+Math.min(7.5,age*.00042*(1+i*.08));if(lifeP>=1)sprite.visible=false;}}}
}
function clearSolarBurnAftermath(){const pending=solarBurnFx.splice(0);for(const f of pending){removeLiveTransient(f.root);disposeObject3D(f.root);}}
function stopKillstreakAudio(entry){for(const handle of entry?.audioHandles||[]){try{handle?.stop?.();}catch{}}if(entry)entry.audioHandles=[];}
function applyEarthquakeAimPull(dt){if(serverNow()>=earthquakeControlUntil||hp<=0)return;const t=performance.now()*.001,seed=earthquakeControlSeed||1,strength=Math.max(.8,earthquakeControlStrength||1),yawPull=(Math.sin(t*5.1+seed*.013)+.55*Math.sin(t*9.6+seed*.021))*.092*strength,pitchPull=(Math.cos(t*4.4+seed*.017)+.48*Math.sin(t*8.2+seed*.009))*.052*strength;applyPlayerAimDelta(yawPull*dt,pitchPull*dt);}
function drawKillstreakEnvironmentOverlay(c,w,h,now){
  const quake=activeEarthquakeVisual();if(quake){const p=THREE.MathUtils.clamp((serverNow()-quake.start)/Math.max(1,quake.end-quake.start),0,1),fade=Math.min(1,p/.07,Math.max(0,(1-p)/.14));c.fillStyle=`rgba(137,109,79,${.082*fade})`;c.fillRect(0,0,w,h);}
  const solar=activeSolarNukeVisual();if(!solar)return;const srv=serverNow(),pre=THREE.MathUtils.clamp((srv-solar.start)/Math.max(1,solar.blastAt-solar.start),0,1),lightRamp=smoothstep01(Math.max(0,(pre-.10)/.90)),post=Math.max(0,srv-solar.blastAt),heat=solar.blasted?Math.max(0,1-smoothstep01(post/Math.max(1,solar.end-solar.blastAt))):.72*lightRamp,veil=Math.min(.24,heat*.15);if(veil>.002){c.fillStyle=`rgba(255,117,34,${veil})`;c.fillRect(0,0,w,h);}if(heat>.01){const g=c.createRadialGradient(w/2,h/2,Math.min(w,h)*.06,w/2,h/2,Math.max(w,h)*.76);g.addColorStop(0,'rgba(255,236,184,0)');g.addColorStop(1,`rgba(116,24,0,${.12*heat})`);c.fillStyle=g;c.fillRect(0,0,w,h);}if(solar.blasted){const hold=520,fadeMs=980,white=post<hold?1:post<hold+fadeMs?1-smoothstep01((post-hold)/fadeMs):0;if(white>0){c.fillStyle=`rgba(255,255,255,${white})`;c.fillRect(0,0,w,h);}}
}
function addKillstreakVisual(entry){killstreakFx.push(entry);if(entry.root)addLiveTransient(entry.root,'killstreak');return entry;}
function handleKillstreakFx(m){
  const kind=normalizeKillstreak(m.kind);if(!kind)return;const replayMuted=!!replayPlayback,mine=samePlayerId(m.ownerId,clientId),enemy=!mine&&(!currentModeSpec().teamBased||!modeFriendly(m.ownerTeam));
  if(m.phase==='start'){
    if(!replayMuted){if(mine)queueAnnouncer(`${KILLSTREAK_SPECS[kind]?.name||kind.toUpperCase()} DEPLOYED`,'',1500,5);else if(enemy)queueAnnouncer(`ENEMY ${KILLSTREAK_SPECS[kind]?.short||kind.toUpperCase()} INBOUND`,'',1500,5);}
    if(kind==='ufo'){if(!replayMuted)playSoundCue('ksUfoInbound',.92,{priority:7});for(let i=0;i<3;i++){const root=makeUfoVisual();root.scale.setScalar(.74+i*.07);addKillstreakVisual({type:'ufoFlyby',root,start:Number(m.startedAt)||serverNow(),end:(Number(m.startedAt)||serverNow())+1700+i*130,index:i});}}
    else if(kind==='earthquake'){const fx=buildEarthquakeVisual(m),rumble=replayMuted?null:playSoundCue('ksEarthquakeRumble',.92,{loop:true,priority:7});addKillstreakVisual({type:'earthquake',id:String(m.id||''),...fx,affectsLocal:enemy,audioHandles:rumble?[rumble]:[],start:Number(m.startedAt)||serverNow(),end:Number(m.endsAt)||serverNow()+15000});}
    else if(kind==='solarnuke'){const fx=buildSolarNukeVisual(m),charge=replayMuted?null:playSoundCue('ksSolarCharge',.94,{priority:8,maxDuration:9.2}),entry=addKillstreakVisual({type:'solarnuke',id:String(m.id||''),...fx,audioHandles:charge?[charge]:[],start:Number(m.startedAt)||serverNow(),blastAt:Number(m.blastAt)||serverNow()+9000,end:Number(m.endsAt)||serverNow()+15500,blasted:false});entry.burnField=prepareSolarBurnField(entry,m);}
    return;
  }
  if(m.phase==='end'&&(kind==='earthquake'||kind==='solarnuke')){
    const endId=String(m.id||'');for(let i=killstreakFx.length-1;i>=0;i--){const f=killstreakFx[i];if(f.type!==kind||(endId&&String(f.id||'')!==endId))continue;stopKillstreakAudio(f);removeLiveTransient(f.root);disposeObject3D(f.root);killstreakFx.splice(i,1);}
    if(kind==='solarnuke')restoreSolarEnvironment();else{earthquakeControlUntil=0;earthquakeControlSeed=0;earthquakeControlStrength=0;}return;
  }
  if(m.phase==='ufoAbduct'){
    const targetX=Number(m.x)||0,targetY=Number(m.y)||0,targetZ=Number(m.z)||0,root=makeUfoVisual(),beam=new THREE.Mesh(new THREE.CylinderGeometry(.28,2.55,10.2,22,1,true),new THREE.MeshBasicMaterial({color:0x8ef5ff,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending})),beamGlow=new THREE.Mesh(new THREE.CircleGeometry(2.25,28),new THREE.MeshBasicMaterial({color:0xb8fbff,transparent:true,opacity:0,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));beam.position.y=-5.1;beamGlow.rotation.x=-Math.PI/2;beamGlow.position.y=-10.05;root.add(beam,beamGlow);const seed=tracerHash(`${m.id||''}:${m.targetId||''}`),angle=(seed%6283)/1000,distance=58+(seed%17),startPos=new THREE.Vector3(targetX+Math.cos(angle)*distance,targetY+30+(seed%9),targetZ+Math.sin(angle)*distance);root.position.copy(startPos);const beamAudio=replayMuted?null:playSpatialCue('ksUfoBeam',targetX,targetY,targetZ,105,.92,{priority:7,maxDuration:3.4});addKillstreakVisual({type:'ufoAbduct',root,beam,beamGlow,audioHandles:beamAudio?[beamAudio]:[],targetId:String(m.targetId||''),targetX,targetY,targetZ,startPos,start:Number(m.startAt)||serverNow(),killAt:Number(m.killAt)||serverNow()+3200,end:(Number(m.killAt)||serverNow()+3200)+650});return;
  }
  if(m.phase==='asteroidIncoming'){
    const root=new THREE.Group(),rock=new THREE.Mesh(new THREE.IcosahedronGeometry(.8,1),new THREE.MeshStandardMaterial({color:0x6c2614,emissive:0xff4e16,emissiveIntensity:1.8,roughness:.72})),glow=new THREE.Mesh(new THREE.SphereGeometry(1.4,10,8),new THREE.MeshBasicMaterial({color:0xff8b35,transparent:true,opacity:.3,depthWrite:false,blending:THREE.AdditiveBlending}));root.add(rock,glow);if(!replayMuted)playSpatialCue('ksAsteroidIncoming',Number(m.x)||0,(Number(m.y)||0)+18,Number(m.z)||0,125,.88,{priority:6,maxDuration:1.45});addKillstreakVisual({type:'asteroid',root,x:Number(m.x)||0,y:Number(m.y)||0,z:Number(m.z)||0,start:serverNow(),impactAt:Number(m.impactAt)||serverNow()+720,end:(Number(m.impactAt)||serverNow()+720)+180});return;
  }
  if(m.phase==='asteroidImpact'){
    for(let i=killstreakFx.length-1;i>=0;i--){const f=killstreakFx[i];if(f.type==='asteroid'&&Math.hypot(f.x-(Number(m.x)||0),f.z-(Number(m.z)||0))<2.2){removeLiveTransient(f.root);disposeObject3D(f.root);killstreakFx.splice(i,1);break;}}
    if(!replayMuted){applyExplosionFeedback('rpg',m);playSpatialCue('ksAsteroidImpact',Number(m.x)||0,Number(m.y)||0,Number(m.z)||0,150,1,{priority:9});}spawnDetonationFx('rpg',m);return;
  }
  if(m.phase==='lightningStrike'){
    const fx=buildLightningVisual(m),now=performance.now();if(!replayMuted)playSpatialCue('ksLightning',Number(m.x)||0,Number(m.y)||0,Number(m.z)||0,155,1,{priority:9});addKillstreakVisual({type:'lightning',...fx,start:now,boltEnd:now+430,electricEnd:now+1050,smokeEnd:now+8200,end:now+12000});if(!replayMuted)applyExplosionFeedback('flash',{...m,radius:Number(m.radius)||6.6});return;
  }
  if(m.phase==='solarBlast'){
    const fx=killstreakFx.find(f=>f.type==='solarnuke'&&String(f.id||'')===String(m.id||''))||[...killstreakFx].reverse().find(f=>f.type==='solarnuke');if(fx){fx.blasted=true;fx.blastLocalAt=performance.now();if(replayMuted)fx.deferredReplayBlast=true;else updateSolarBurnProgress(fx,1,performance.now(),true);stopKillstreakAudio(fx);}if(!replayMuted){blastFeedbackPower=1;blastFeedbackUntil=Math.max(blastFeedbackUntil,performance.now()+1800);blastFeedbackSeed=performance.now()*.001;playSoundCue('ksSolarBlast',1,{priority:10});}return;
  }
}
function updateKillstreakFx(dt){
  const srv=serverNow(),now=performance.now();ufoLocalLift=0;
  for(let i=killstreakFx.length-1;i>=0;i--){const f=killstreakFx[i];let expired=false;
    if(f.type==='ufoFlyby'){const duration=Math.max(1,f.end-f.start),p=Math.max(0,Math.min(1,(srv-f.start)/duration)),limit=minimapWorldLimit()+42,dir=f.index%2?-1:1,curve=Math.sin(Math.PI*p);f.root.position.set(dir*(-limit+2*limit*p),31+f.index*3-curve*5,(-.72+f.index*.72)*minimapWorldLimit());f.root.rotation.y=dir>0?-Math.PI/2:Math.PI/2;f.root.rotation.z=Math.sin(p*Math.PI*5)*.04;expired=srv>f.end;}
    else if(f.type==='ufoAbduct'){
      const actor=samePlayerId(f.targetId,clientId)?null:remotes.get(f.targetId),baseX=actor?.group?.position?.x??f.targetX,baseZ=actor?.group?.position?.z??f.targetZ,baseY=actor?.group?.position?.y??position?.y??f.targetY,total=Math.max(1,f.killAt-f.start),p=Math.max(0,Math.min(1,(srv-f.start)/total)),approach=smoothstep01(p/.28),hoverY=baseY+11.2,targetPos=new THREE.Vector3(baseX,hoverY,baseZ);f.root.position.lerpVectors(f.startPos,targetPos,approach);f.root.rotation.y+=dt*(approach<.98?3.5:1.6);f.root.rotation.z=(1-approach)*Math.sin(p*Math.PI*3)*.12;
      const beamP=smoothstep01((p-.25)/.16),liftP=smoothstep01((p-.34)/.56),lift=9.6*liftP;f.beam.visible=beamP>.01;f.beamGlow.visible=beamP>.01;f.beam.material.opacity=beamP*(.18+.16*Math.sin(now*.026));f.beamGlow.material.opacity=beamP*(.18+.12*Math.sin(now*.019));if(f.root.userData.underGlow)f.root.userData.underGlow.material.opacity=.3+.18*beamP;
      if(samePlayerId(f.targetId,clientId))ufoLocalLift=Math.max(ufoLocalLift,lift);else if(actor?.group)actor.group.position.y+=lift;expired=srv>f.end;
    }
    else if(f.type==='asteroid'){const p=Math.max(0,Math.min(1,(srv-f.start)/Math.max(1,f.impactAt-f.start))),height=42*(1-p);f.root.position.set(f.x+7*(1-p),f.y+height,f.z-6*(1-p));f.root.rotation.x+=dt*9;f.root.rotation.z+=dt*6;f.root.scale.setScalar(.72+.6*p);expired=srv>f.end;}
    else if(f.type==='lightning'){
      const boltRemain=Math.max(0,(f.boltEnd-now)/Math.max(1,f.boltEnd-f.start)),boltAlive=boltRemain>0,flicker=boltAlive?(.6+.4*Math.abs(Math.sin(now*.11))):0;if(f.boltGroup)f.boltGroup.visible=boltAlive;if(boltAlive){for(const mat of f.boltMaterials)mat.opacity=Math.min(1,(mat.userData?.baseOpacity||1)*flicker);if(f.flash){f.flash.material.opacity=.30*boltRemain*(.45+.55*Math.abs(Math.sin(now*.13)));f.flash.scale.setScalar(.82+(1-boltRemain)*.42);}}const electricRemain=Math.max(0,(f.electricEnd-now)/Math.max(1,f.electricEnd-f.start)),electricAlive=electricRemain>0;if(f.structureGroup)f.structureGroup.visible=electricAlive;if(electricAlive)for(const mat of f.structureMaterials)mat.opacity=.78*electricRemain*(.55+.45*Math.abs(Math.sin(now*.072)));
      const smokeRemain=Math.max(0,(f.smokeEnd-now)/Math.max(1,f.smokeEnd-f.start));for(const sprite of f.smokeSprites){const u=sprite.userData||{};sprite.position.y+=dt*(u.rise||.35);sprite.position.x=(u.baseX||sprite.position.x)+Math.sin(now*.0012+(u.phase||0))*.22;sprite.position.z=(u.baseZ||sprite.position.z)+Math.cos(now*.0010+(u.phase||0))*.22;sprite.material.opacity=.34*smokeRemain;}if(f.scorch){const fade=now<f.smokeEnd?1:Math.max(0,(f.end-now)/Math.max(1,f.end-f.smokeEnd));f.scorch.material.opacity=.88*fade;}expired=now>f.end;
    }else if(f.type==='earthquake'){
      const p=THREE.MathUtils.clamp((srv-f.start)/Math.max(1,f.end-f.start),0,1),fade=Math.min(1,p/.06,Math.max(0,(1-p)/.12)),limit=Math.max(24,Number(f.limit)||minimapWorldLimit());
      for(let j=0;j<f.debrisItems.length;j++){
        const item=f.debrisItems[j];item.x+=item.vx*dt;item.z+=item.vz*dt;item.y+=item.vy*dt;item.rx+=item.spin*dt;item.ry+=item.spin*.73*dt;item.rz+=item.spin*.49*dt;
        const ground=worldSupportHeight(item.x,item.z,item.y,false);
        if(item.y<ground-.4||Math.abs(item.x)>limit||Math.abs(item.z)>limit){item.cycle=(item.cycle||0)+1;const pt=earthquakeMapPoint(f.seed,j,item.cycle,limit);item.x=pt.x;item.z=pt.z;item.y=worldSupportHeight(item.x,item.z,1000,false)+10+((f.seed+j*233+item.cycle*47)%1600)/100;item.vx=Math.sin((f.seed+j*37+item.cycle*19)*.013)*.95;item.vz=Math.cos((f.seed+j*53+item.cycle*23)*.011)*.95;item.vy=-(8.8+((f.seed+j*89+item.cycle*31)%520)/100);}
        f.debrisDummy.position.set(item.x,item.y,item.z);f.debrisDummy.scale.setScalar(item.scale);f.debrisDummy.rotation.set(item.rx,item.ry,item.rz);f.debrisDummy.updateMatrix();f.debris.setMatrixAt(j,f.debrisDummy.matrix);
      }
      f.debris.instanceMatrix.needsUpdate=true;f.debris.material.opacity=fade;
      const attr=f.dust.geometry.attributes.position;for(let j=0;j<f.dustItems.length;j++){const item=f.dustItems[j],drift=item.drift||1;attr.array[j*3]=item.x+Math.sin(now*.0014+item.phase)*drift;attr.array[j*3+1]=item.baseY+((now*.001*item.speed)%5.6);attr.array[j*3+2]=item.z+Math.cos(now*.0011+item.phase)*drift;}attr.needsUpdate=true;f.dust.material.opacity=.42*fade;expired=srv>f.end;
    }else if(f.type==='solarnuke'){
      const pre=THREE.MathUtils.clamp((srv-f.start)/Math.max(1,f.blastAt-f.start),0,1),approach=smoothstep01(pre),lightRamp=smoothstep01(Math.max(0,(pre-.10)/.90)),post=Math.max(0,srv-f.blastAt),postDuration=Math.max(1,f.end-f.blastAt),postP=THREE.MathUtils.clamp(post/postDuration,0,1),retreatP=f.blasted?smoothstep01(Math.max(0,(post-700)/Math.max(1,postDuration-700))):0;
      if(!f.blasted){f.root.position.lerpVectors(f.startPos,f.endPos,approach);f.root.scale.setScalar(THREE.MathUtils.lerp(7.5,34,approach));updateSolarBurnProgress(f,approach,now,false);}else{f.root.position.lerpVectors(f.endPos,f.retreatPos,retreatP);f.root.scale.setScalar(THREE.MathUtils.lerp(34,8.5,retreatP));}
      f.root.rotation.y+=dt*.045;f.halo.material.opacity=.15;const recovery=f.blasted?1-smoothstep01(postP):1,exposureBoost=f.blasted?.92*recovery:.46*lightRamp,sunBoost=f.blasted?2.45*recovery:1.38*lightRamp,hemiBoost=f.blasted?.42*recovery:.24*lightRamp;if(renderer)renderer.toneMappingExposure=f.baseExposure*(1+exposureBoost);if(worldSunLight)worldSunLight.intensity=f.baseSunIntensity*(1+sunBoost);if(worldHemiLight)worldHemiLight.intensity=f.baseHemiIntensity*(1+hemiBoost);expired=srv>f.end;if(expired)restoreSolarEnvironment();
    }
    if(expired){stopKillstreakAudio(f);removeLiveTransient(f.root);disposeObject3D(f.root);killstreakFx.splice(i,1);}
  }
  updateSolarBurnAftermath(dt,now);
  if(srv>=killstreakControlUntil)killstreakControlUntil=0;if(srv>=earthquakeControlUntil){earthquakeControlUntil=0;earthquakeControlSeed=0;earthquakeControlStrength=0;}
}
function clearKillstreakFx(){const pending=killstreakFx.splice(0);for(const f of pending){stopKillstreakAudio(f);removeLiveTransient(f.root);disposeObject3D(f.root);}clearSolarBurnAftermath();restoreSolarEnvironment();killstreakTargeting=null;killstreakTargetRect=null;killstreakTargetConfirmRect=null;killstreakTargetCancelRect=null;killstreakControlUntil=0;earthquakeControlUntil=0;earthquakeControlSeed=0;earthquakeControlStrength=0;ufoLocalLift=0;}

function createDetonationFx(kind,m){
  if(!scene||!THREE)return null;
  const sticky=kind==='sticky',frag=kind==='frag',launcher=kind==='rpg'||kind==='grenadeLauncher',damaging=sticky||frag||launcher;
  const blastRadius=damaging?Math.max(1,Number(m?.radius)||6):5.5,root=new THREE.Group();root.position.set(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0);
  const coreColor=sticky?0xff8a35:launcher?0xffb05d:frag?0xffc77a:0xffffff,ringColor=sticky?0xffb15c:launcher?0xffd19a:frag?0xffddb0:0xeafaff;
  const core=new THREE.Mesh(new THREE.SphereGeometry(1,12,8),new THREE.MeshBasicMaterial({color:coreColor,transparent:true,opacity:1,depthWrite:false,blending:THREE.AdditiveBlending}));core.scale.setScalar(.08);root.add(core);
  const ring=new THREE.Mesh(new THREE.RingGeometry(.82,1,28),new THREE.MeshBasicMaterial({color:ringColor,transparent:true,opacity:.92,side:THREE.DoubleSide,depthWrite:false,blending:THREE.AdditiveBlending}));ring.rotation.x=-Math.PI/2;ring.scale.setScalar(.12);root.add(ring);
  const count=sticky?18:launcher?22:frag?16:10,positions=new Float32Array(count*3),velocities=new Float32Array(count*3),geometry=new THREE.BufferGeometry(),duration=sticky?.72:launcher?.68:frag?.60:.48;
  for(let i=0;i<count;i++){const a=Math.random()*Math.PI*2,e=.12+Math.random()*.92,targetSpeed=(blastRadius*(.62+Math.random()*.28))/duration,j=i*3;velocities[j]=Math.cos(a)*Math.cos(e)*targetSpeed;velocities[j+1]=Math.sin(e)*targetSpeed*.72;velocities[j+2]=Math.sin(a)*Math.cos(e)*targetSpeed;}
  geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const particleMaterial=new THREE.PointsMaterial({color:sticky?0xffae68:launcher?0xffc17a:frag?0xffd19a:0xffffff,size:sticky?.10:launcher?.13:frag?.10:.08,sizeAttenuation:true,transparent:true,opacity:.92,depthWrite:false,blending:THREE.AdditiveBlending});
  const particles=new THREE.Points(geometry,particleMaterial);particles.frustumCulled=false;root.add(particles);return{kind,root,core,ring,particles,velocities,age:0,duration,blastRadius};
}
function spawnDetonationFx(kind,m){
  const fx=createDetonationFx(kind,m);if(!fx)return;addLiveTransient(fx.root,'detonation');tacticalFx.push(fx);const cap=playerSettings.graphics==='low'?12:playerSettings.graphics==='medium'?18:28;while(tacticalFx.length>cap){const old=tacticalFx.shift();removeLiveTransient(old.root);disposeObject3D(old.root);}
}
function advanceDetonationFx(f,dt){
  if(!f)return true;f.age+=dt;const p=Math.min(1,f.age/f.duration),sticky=f.kind==='sticky',frag=f.kind==='frag',launcher=f.kind==='rpg'||f.kind==='grenadeLauncher',radius=Math.max(1,f.blastRadius||5.5);
  f.core.scale.setScalar(radius*(sticky?.46:launcher?.52:frag?.48:.42)*(1-Math.pow(1-p,3))+.05);f.core.material.opacity=(1-p)*(sticky?.62:launcher?.74:frag?.68:.88);
  f.ring.scale.setScalar(radius*Math.min(1,Math.pow(p,.62)));f.ring.material.opacity=(1-p)*(sticky?.70:launcher?.78:frag?.74:.86);
  const attr=f.particles.geometry.getAttribute('position'),pos=attr.array,v=f.velocities;for(let j=0;j<pos.length;j+=3){v[j+1]-=9*dt;pos[j]+=v[j]*dt;pos[j+1]+=v[j+1]*dt;pos[j+2]+=v[j+2]*dt;}attr.needsUpdate=true;f.particles.material.opacity=Math.max(0,1-p);f.particles.material.size=(sticky?.10:launcher?.13:frag?.10:.08)*(1+p*1.1);return p>=1;
}
function updateTacticalFx(dt){
  for(let i=tacticalFx.length-1;i>=0;i--){const f=tacticalFx[i];if(advanceDetonationFx(f,dt)){tacticalFx.splice(i,1);removeLiveTransient(f.root);disposeObject3D(f.root);}}
}
function clearTacticalFx(){const pending=tacticalFx.splice(0);for(const f of pending){removeLiveTransient(f.root);disposeObject3D(f.root);}}
function smokePointCounts(){return playerSettings.graphics==='low'?{core:10,outer:12}:playerSettings.graphics==='medium'?{core:14,outer:18}:{core:18,outer:26};}
function makeSmokePointLayer(count,radius,core,texture){
  const positions=new Float32Array(count*3);for(let i=0;i<count;i++){const a=(i*2.399963229728653)+Math.random()*.28,radial=(core?Math.sqrt(Math.random())*.43:(.28+Math.sqrt(Math.random())*.50))*radius,yBand=core?(-.08+Math.random()*.34):(-.12+Math.random()*.48),j=i*3;positions[j]=Math.cos(a)*radial;positions[j+1]=yBand*radius;positions[j+2]=Math.sin(a)*radial;}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
  const material=new THREE.PointsMaterial({map:texture,color:core?0x74797a:0x686d6f,size:radius*(core?.50:.42),sizeAttenuation:true,transparent:true,opacity:0,depthTest:true,depthWrite:false,toneMapped:false,alphaTest:.015});
  const points=new THREE.Points(geometry,material);points.frustumCulled=false;points.userData={baseOpacity:core?.76:.60,phase:core?.4:1.7};return points;
}
function spawnSmokeCloud(m){
  if(!scene||!THREE||!m?.id)return;const existing=smokeClouds.get(m.id);if(existing){existing.expiresAt=Math.max(existing.expiresAt,Number(m.expiresAt)||serverNow()+SMOKE_DURATION_MS);return;}
  const radius=Math.max(4,Number(m.radius)||9.6),root=new THREE.Group();root.position.set(Number(m.x)||0,Number(m.y)||0,Number(m.z)||0);const texture=getSharedSmokeTexture(),counts=smokePointCounts(),core=makeSmokePointLayer(counts.core,radius,true,texture),outer=makeSmokePointLayer(counts.outer,radius,false,texture),layers=[core,outer];root.add(core,outer);
  // Two batched point layers replace 48 individually-materialed sprites. The
  // gameplay cloud radius and LOS behavior are unchanged, while a smoke cloud
  // now costs two transparent draw calls instead of dozens on mobile.
  const srvNow=serverNow(),serverBornAt=Number(m.bornAt)||srvNow;addLiveTransient(root,'smoke');smokeClouds.set(m.id,{root,layers,bornAt:serverBornAt,expiresAt:Number(m.expiresAt)||srvNow+SMOKE_DURATION_MS,radius});
}
function updateSmokeCloudVisibility(now=performance.now()){
  if(now-lastSmokeVisibilityAt<240)return;lastSmokeVisibilityAt=now;const limit=playerSettings.graphics==='low'?8:playerSettings.graphics==='medium'?12:16,clouds=[...smokeClouds.values()];
  if(clouds.length<=limit){for(const c of clouds)if(c.root)c.root.visible=true;return;}
  const cx=Number(camera?.position?.x)||0,cy=Number(camera?.position?.y)||0,cz=Number(camera?.position?.z)||0;clouds.sort((a,b)=>{const ap=a.root?.position,bp=b.root?.position,ad=ap?(ap.x-cx)**2+(ap.y-cy)**2+(ap.z-cz)**2:Infinity,bd=bp?(bp.x-cx)**2+(bp.y-cy)**2+(bp.z-cz)**2:Infinity;return ad-bd;});
  for(let i=0;i<clouds.length;i++)if(clouds[i].root)clouds[i].root.visible=i<limit;
}
function radiusVisualDrift(radius){return Math.min(.08,Math.max(.025,(Number(radius)||9.6)*.006));}
function updateSmokeClouds(dt){
  const now=performance.now(),srv=serverNow(),thermalSmokeScale=THREE.MathUtils.lerp(1,.18,thermalOpticWorldAmount());updateSmokeCloudVisibility(now);for(const [id,c] of smokeClouds){const ageMs=Math.max(0,srv-(Number(c.bornAt)||srv)),grow=Math.min(1,ageMs/SMOKE_GROW_MS),remaining=c.expiresAt-srv;if(remaining<=0){smokeClouds.delete(id);removeLiveTransient(c.root);disposeObject3D(c.root);continue;}if(c.root.visible===false)continue;const fade=Math.min(1,remaining/1800),visualScale=SMOKE_START_SCALE+(1-SMOKE_START_SCALE)*grow;c.root.scale.setScalar(visualScale);c.root.rotation.y+=dt*.018;for(const layer of c.layers){const u=layer.userData||{},pulse=.97+.03*Math.sin(now*.0007+(u.phase||0));layer.material.opacity=(u.baseOpacity||.62)*pulse*grow*fade*thermalSmokeScale;layer.position.x=Math.sin(now*.00019+(u.phase||0))*radiusVisualDrift(c.radius);layer.position.y=Math.sin(now*.00024+(u.phase||0))*.018;layer.position.z=Math.cos(now*.00017+(u.phase||0))*radiusVisualDrift(c.radius);}}
}
function clearSmokeClouds(){const pending=[...smokeClouds.values()];smokeClouds.clear();lastSmokeVisibilityAt=0;for(const c of pending){removeLiveTransient(c.root);disposeObject3D(c.root);}}

function applyFlashEffect(m){const power=Math.max(0,Math.min(1,Number(m.power)||0));if(power<=0)return;const now=performance.now(),duration=Math.max(350,Number(m.durationMs)||700+power*2600);flashPeakUntil=Math.max(flashPeakUntil,now+180+power*520);flashUntil=Math.max(flashUntil,now+duration);}
function renderReplayFrame(now=performance.now()){
  drawHud(now);renderer.autoClear=true;renderer.render(scene,camera);renderer.autoClear=false;renderer.clearDepth();renderer.render(hudScene,hudCamera);renderer.autoClear=true;
}
function animate(){
  requestAnimationFrame(animate);
  const rawFrameDt=Math.max(0,clock.getDelta()),frameDt=Math.min(rawFrameDt,CLIENT_MAX_FRAME_SEC);recordNetFrame(rawFrameDt);
  updateGamepadInput(frameDt);updateLoadoutPreviewFrame(performance.now(),Math.min(rawFrameDt,.10));
  if(shell.inBuilder&&builderSession){if(!document.hidden)frameBuilderRuntime(frameDt);return;}
  if(!shell.inMatch||document.hidden)return;
  if(replayPlayback){updatePausedNetwork();updateReplayPlayback(Math.min(frameDt,.10),performance.now());if(replayPlayback)renderReplayFrame(performance.now());return;}
  if(shell.canPlay){
    // Keep prediction caught up without a fixed-step backlog. A render hitch used
    // to trigger as many as 18 collision/physics passes in the very next frame,
    // which turned one missed frame into a repeating hitch. Normal elapsed time
    // is now divided into at most four bounded substeps; only extreme suspended
    // frames are clipped and the server correction path handles that recovery.
    const steps=Math.max(1,Math.min(CLIENT_MAX_SIM_STEPS,Math.ceil(frameDt/(CLIENT_FIXED_STEP_SEC*1.35))));
    const stepDt=Math.min(MAX_PLAYER_PHYSICS_STEP_SEC,frameDt/steps);
    for(let i=0;i<steps;i++)updateGameSimulation(stepDt);
    updateGameFrame(Math.min(frameDt,MAX_PLAYER_PHYSICS_STEP_SEC));
  }else updatePausedNetwork();
  const visualDt=Math.min(frameDt,.10);updateAim(visualDt);updateRemoteVisuals(visualDt);captureReplayFrame();maybeStartPendingReplay(performance.now());if(replayPlayback){updateReplayPlayback(0,performance.now());if(replayPlayback)renderReplayFrame(performance.now());return;}updateThermalOpticWorld();syncThermalOpticSignatures();updateWeaponView(visualDt);updateGameplayLaserBeams(performance.now());
  // Cosmetic systems are fault-contained from the gameplay/simulation path.
  // A malformed transient effect must be discarded rather than poisoning every
  // following render frame and making the match appear frozen.
  try{updateBullets(visualDt);}catch(error){console.error('Tracer update failed; clearing transient tracers.',error);clearBullets();}
  try{updateRocketTrailPuffs(visualDt);}catch(error){console.error('Rocket trail update failed; clearing transient rocket smoke.',error);clearRocketTrailPuffs();}
  try{updateThrowables(visualDt);}catch(error){console.error('Throwable visual update failed; clearing transient throwables.',error);clearThrowables();}
  try{updateTacticalFx(visualDt);}catch(error){console.error('Explosion visual update failed; clearing transient explosion FX.',error);clearTacticalFx();}
  try{updateBulletImpactFx(visualDt);}catch(error){console.error('Bullet impact visual update failed; clearing transient impact FX.',error);clearBulletImpactFx();}
  try{updateSmokeClouds(visualDt);}catch(error){console.error('Smoke visual update failed; clearing transient smoke FX.',error);clearSmokeClouds();}
  try{updateKillstreakFx(visualDt);}catch(error){console.error('Killstreak visual update failed; clearing transient killstreak FX.',error);clearKillstreakFx();}
  updateEquipmentTrajectory();captureGameplayDiagnostics(rawFrameDt,performance.now());
  // Draw the 2D HUD texture before the compositing pass so visual state and the
  // world frame are presented together.
  const renderNow=performance.now();if(shell.canPlay)drawHud(renderNow);
  renderer.autoClear=true;
  renderer.render(scene,camera);
  if(shell.canPlay){renderer.autoClear=false;renderer.clearDepth();renderer.render(hudScene,hudCamera);renderer.autoClear=true;}
}
function maintainNetwork(){
  if(builderSession)return;
  const now=performance.now(),stateSent=sendCurrentState(false);sendSimulationHeartbeat(stateSent);
  const diagnosticsOn=diagnosticsRecordingEnabled();if(now-lastPing<=(diagnosticsOn?2000:15000))return;
  lastPing=now;lastPingLocalAt=Date.now();send({t:'ping',clientAt:lastPingLocalAt,diag:diagnosticsOn?1:0});
}
function updatePausedNetwork(){if(traversal)updateTraversal(performance.now());maintainNetwork();}
function finishControllerUiAdjustment(){
  const state=controllerUiAdjusting;if(!state)return;
  controllerUiAdjusting=null;state.el?.classList?.remove('controller-adjusting');
  if(state.el&&String(state.el.value)!==state.startValue)state.el.dispatchEvent(new Event('change',{bubbles:true}));
}
function clearControllerUiEditing(){
  finishControllerUiAdjustment();
  if(controllerUiEditing?.classList)controllerUiEditing.classList.remove('controller-editing');
  controllerUiEditing=null;
}
function controllerFocusKey(el){
  if(!el)return'';if(el.dataset?.controllerKey)return`controller:${el.dataset.controllerKey}`;if(el.id)return`id:${el.id}`;
  const stableData=['deployTab','lobbySideTab','lobbyCheatTab','lobbyAdminGod','lobbyAdminRole','adminGod','adminRole','lobbyMapChoice','lobbyMode','killstreakChoice','loadoutChoice','loadoutClass','loadoutEditItem','loadoutBackClass','loadoutBackClasses','loadoutWeaponPickerToggle','loadoutAdsPreview','calloutSlot','matchPrimaryChoice','matchTacticalChoice','matchLethalChoice','settingsTab','adminTab','chatChar','chatAction','editorChar','editorAction','gameControl'];
  for(const key of stableData){const value=el.dataset?.[key];if(value!=null&&value!=='')return`data:${key}:${value}`;}
  const text=String(el.textContent||'').replace(/\s+/g,' ').trim().slice(0,48);return`${el.tagName||''}:${text}`;
}
function clearControllerUiFocus(){
  clearControllerUiEditing();
  if(controllerUiFocus?.classList){controllerUiFocus.closest?.('.loadout-class-card')?.classList.remove('controller-card-focus');controllerUiFocus.classList.remove('controller-focus');}
  controllerUiFocus=null;controllerUiFocusKey='';
}
function resetControllerUiAxis(){controllerUiAxisDirection='';controllerUiAxisNextAt=0;controllerUiAxisStartedAt=0;}
function controllerEditableField(el){return !!el?.matches?.('[data-game-control="cycle"],[data-game-control="stepper"],[data-game-control="slider"],select:not([disabled]),input[type="range"]:not([disabled]),input[type="number"]:not([disabled])');}
function setControllerUiEditing(el){
  if(!controllerEditableField(el))return false;
  clearControllerUiEditing();controllerUiEditing=el;el.classList.add('controller-editing');return true;
}
function controllerUiSurface(){
  if(!rotateGate.classList.contains('hide'))return rotateGate;
  if(!entryScreen.classList.contains('hide'))return entryScreen;
  if(mapDeletePromptOpen())return mapDeleteConfirm;
  if(lobbyQuitPromptOpen())return lobbyQuitConfirm;
  if(shell.connecting)return connectionOverlay;
  if(gameTextEditorTarget)return gameTextEditor;
  if(chatOpen)return chatComposer;
  if(shell.panel===SHELL_PANEL.SETTINGS)return $('settingsPanel');
  if(shell.panel===SHELL_PANEL.ADMIN)return $('adminPanel');
  if(shell.panel===SHELL_PANEL.LOADOUT)return $('loadoutPanel');
  if(shell.paused)return pause;
  if(shell.inLobby)return lobbyScreen;
  if(!menu.classList.contains('hide'))return menu;
  return null;
}
function controllerPrimaryTablist(surface){return surface?.querySelector?.('[data-controller-primary-tabs="true"]')||null;}
function controllerLoadoutScope(surface){const slot=loadoutFocusSlot[surface]||'primary',key=`${surface}-${slot}`,layer=loadoutWeaponPickerOpen.has(key)?'picker':loadoutAttachmentTrayOpen.has(key)?`attachment:${loadoutAttachmentSlot[key]}`:'overview';return `${loadoutWorkspaceMode[surface]}:${slot}:${layer}`;}
function controllerUiScopeId(surface=controllerUiSurface()){
  if(!surface)return'';
  if(surface===lobbyScreen){const side=surface.querySelector('[data-lobby-side-tab].active')?.dataset?.lobbySideTab||'players';return side==='loadout'?`lobby:${side}:${controllerLoadoutScope('lobby')}`:`lobby:${side}`;}
  if(surface===menu)return`menu:${surface.querySelector('[data-deploy-view]:not([hidden]):not(.hide)')?.dataset?.deployView||'play'}`;
  if(surface===$('settingsPanel'))return`settings:${surface.querySelector('[data-settings-tab].active')?.dataset?.settingsTab||'controls'}`;
  if(surface===$('adminPanel'))return`admin:${activeAdminTab||'gameplay'}`;
  if(surface===$('loadoutPanel'))return`loadout:${controllerLoadoutScope('match')}`;
  if(surface===mapDeleteConfirm)return'map-delete';
  if(surface===lobbyQuitConfirm)return'lobby-quit';
  if(surface===pause)return'pause';
  if(surface===chatComposer)return'chat';
  if(surface===gameTextEditor)return'editor';
  if(surface===entryScreen)return'entry';
  return surface.id?`surface:${surface.id}`:'surface';
}
function controllerRememberFocus(el,surface=controllerUiSurface()){const scope=controllerUiScopeId(surface),key=controllerFocusKey(el);if(scope&&key)controllerUiFocusMemory.set(scope,key);}
function controllerElementVisible(el,surface){
  if(!el||!surface||!surface.contains(el)||el.disabled)return false;
  if(el.closest('[hidden],.hide,[inert],[aria-hidden="true"],[aria-disabled="true"]'))return false;
  const style=getComputedStyle(el);if(style.display==='none'||style.visibility==='hidden'||Number(style.opacity)===0)return false;
  const r=el.getBoundingClientRect();if(r.width<=2||r.height<=2)return false;
  return true;
}
function controllerFocusableElements(){
  const surface=controllerUiSurface();if(!surface)return[];
  const selector='button:not([disabled]):not(.game-control-arrow):not(.gunsmith-ads-preview),[role="tab"]:not([disabled]),[data-game-control][tabindex="0"]:not(.disabled),[data-controller-focusable="true"],select:not([disabled]),input[type="range"]:not([disabled]),input[type="number"]:not([disabled]),input[type="checkbox"]:not([disabled]),input[type="radio"]:not([disabled])';
  return [...new Set(surface.querySelectorAll(selector))].filter(el=>controllerElementVisible(el,surface));
}
function controllerRevealFocusedElement(el,surface){
  if(!el||!surface)return;let node=el.parentElement,er=el.getBoundingClientRect();
  while(node&&node!==document.body){const style=getComputedStyle(node),canY=/(auto|scroll)/.test(style.overflowY)&&node.scrollHeight>node.clientHeight+2,canX=/(auto|scroll)/.test(style.overflowX)&&node.scrollWidth>node.clientWidth+2;if(canY||canX){const r=node.getBoundingClientRect();if(canY){if(er.top<r.top)node.scrollTop-=r.top-er.top;else if(er.bottom>r.bottom)node.scrollTop+=er.bottom-r.bottom;}if(canX){if(er.left<r.left)node.scrollLeft-=r.left-er.left;else if(er.right>r.right)node.scrollLeft+=er.right-r.right;}er=el.getBoundingClientRect();}if(node===surface)break;node=node.parentElement;}
}
function setControllerUiFocus(el){
  const surface=controllerUiSurface();if(!controllerElementVisible(el,surface))return false;
  if(controllerUiFocus===el){return true;}
  if(controllerUiEditing&&controllerUiEditing!==el)clearControllerUiEditing();else finishControllerUiAdjustment();
  if(controllerUiFocus?.classList){controllerUiFocus.closest?.('.loadout-class-card')?.classList.remove('controller-card-focus');controllerUiFocus.classList.remove('controller-focus');}
  controllerUiFocus=el;controllerUiFocusKey=controllerFocusKey(el);controllerRememberFocus(el,surface);el.classList.add('controller-focus');el.closest?.('.loadout-class-card')?.classList.add('controller-card-focus');
  try{el.focus?.({preventScroll:true});}catch{try{el.focus?.();}catch{}}
  controllerRevealFocusedElement(el,surface);return true;
}
function queueControllerUiFocus(key,{fallback=null}={}){
  if(!controllerInputActive()||!key)return;
  const origin=controllerUiScopeId(),expected=String(key),attempt=()=>{if(controllerUiScopeId()!==origin)return true;const surface=controllerUiSurface(),list=controllerFocusableElements();if(!surface||!list.length)return false;const target=list.find(el=>el.dataset?.controllerKey===expected||controllerFocusKey(el)===expected||controllerFocusKey(el)===`controller:${expected}`)||(typeof fallback==='function'?fallback(list,surface):null);return target?setControllerUiFocus(target):false;};
  requestAnimationFrame(()=>{if(!attempt())requestAnimationFrame(attempt);});
}
function controllerPreferredRegion(surface){
  if(!surface)return null;
  if(surface===mapDeleteConfirm)return surface.querySelector('.lobby-quit-card')||surface;
  if(surface===lobbyQuitConfirm)return surface.querySelector('.lobby-quit-card')||surface;
  if(surface===lobbyScreen)return surface.querySelector('[data-lobby-side-view].active:not([hidden])')||surface;
  if(surface===menu)return surface.querySelector('.deploy-view:not([hidden]):not(.hide)')||surface;
  if(surface===$('settingsPanel'))return surface.querySelector('[data-settings-page].active:not([hidden])')||surface;
  if(surface===$('adminPanel'))return surface.querySelector('[data-admin-page]:not([hidden]):not(.hide)')||surface;
  if(surface===$('loadoutPanel'))return surface.querySelector('[data-loadout-classes-view="match"]:not([hidden]),[data-loadout-class-view="match"]:not([hidden]),[data-loadout-item-view="match"]:not([hidden])')||surface;
  return surface;
}
function preferredControllerFocus(list,surface){
  if(!list.length)return null;
  const chatDefault=surface===chatComposer?list.find(el=>el.dataset?.chatChar==='q'):surface===gameTextEditor?list.find(el=>el.dataset?.editorChar==='q'):null;if(chatDefault)return chatDefault;
  const region=controllerPreferredRegion(surface),regionList=region&&region!==surface?list.filter(el=>region.contains(el)):list;if(regionList.length)list=regionList;
  const activeNestedTab=list.find(el=>el.closest?.('[role="tablist"]')&&!el.closest?.('[data-controller-primary-tabs="true"]')&&el.getAttribute('aria-selected')==='true');if(activeNestedTab)return activeNestedTab;
  const primary=list.find(el=>el.dataset?.controllerDefault==='true')||list.find(el=>el.classList?.contains('active'));if(primary)return primary;
  const rr=(region||surface).getBoundingClientRect();
  return list.reduce((best,el)=>{
    const r=el.getBoundingClientRect(),top=Math.max(0,r.top-rr.top),left=Math.max(0,r.left-rr.left),score=top*1.2+left*.08;
    return !best||score<best.score?{el,score}:best;
  },null)?.el||list[0];
}
function ensureControllerUiFocus(){
  const surface=controllerUiSurface(),list=controllerFocusableElements();if(!surface||!list.length){clearControllerUiFocus();return null;}
  const scope=controllerUiScopeId(surface);
  if(scope!==controllerFocusScope||!list.includes(controllerUiFocus)){
    controllerFocusScope=scope;
    const rememberedKey=controllerUiFocusMemory.get(controllerUiScopeId(surface))||'',priorKey=controllerUiFocusKey||controllerFocusKey(controllerUiFocus);
    const restored=(rememberedKey&&list.find(el=>controllerFocusKey(el)===rememberedKey))||(priorKey&&list.find(el=>controllerFocusKey(el)===priorKey))||null;
    setControllerUiFocus(restored||preferredControllerFocus(list,surface));
  }
  return controllerUiFocus;
}
function intervalGap(a0,a1,b0,b1){if(a1<b0)return b0-a1;if(b1<a0)return a0-b1;return 0;}
const CONTROLLER_NAV_GROUP_SELECTOR='.settings-grid,.weapon-fields,.loadout-choice-grid,.attachment-editor,.gunsmith-attachment-options,.loadout-class-list,.class-detail-grid,.gunsmith-callout-overlay,.gunsmith-inspector,.loadout-view-nav,.lobby-mode-picker,.lobby-setup-row,.lobby-team-picker,.lobby-side-tabs,.lobby-header-actions,.lobby-footer-actions,.lobby-player-actions,.admin-bot-controls,.pause-actions,.pause-actions-player,.pause-actions-system,.join-controls,.lobby-map-choice-grid,.killstreak-choice-grid,.lobby-cheat-tabs,.chat-key-row,.game-text-key-row';
function controllerNavGroup(el){return el?.closest?.(CONTROLLER_NAV_GROUP_SELECTOR)||null;}
function controllerDirectionScore(a,r,dx,dy){
  const ax=a.left+a.width/2,ay=a.top+a.height/2,bx=r.left+r.width/2,by=r.top+r.height/2,vx=bx-ax,vy=by-ay;
  if((dx<0&&vx>=-3)||(dx>0&&vx<=3)||(dy<0&&vy>=-3)||(dy>0&&vy<=3))return null;
  const horizontal=dx!==0;
  const primary=horizontal?Math.max(0,dx>0?r.left-a.right:a.left-r.right):Math.max(0,dy>0?r.top-a.bottom:a.top-r.bottom);
  const crossGap=horizontal?intervalGap(a.top,a.bottom,r.top,r.bottom):intervalGap(a.left,a.right,r.left,r.right);
  const crossCenter=horizontal?Math.abs(vy):Math.abs(vx),centerPrimary=horizontal?Math.abs(vx):Math.abs(vy);
  const angleRatio=crossCenter/Math.max(1,centerPrimary);
  const aligned=crossGap<=Math.max(8,(horizontal?Math.min(a.height,r.height):Math.min(a.width,r.width))*.18);
  if(!aligned&&angleRatio>1.0)return null;
  const direct=aligned||angleRatio<=.55;
  return{score:primary+crossGap*5.5+crossCenter*.28+centerPrimary*.03,direct};
}
const GUNSMITH_CONTROLLER_POINTS=Object.freeze({optic:[1,0],muzzle:[0,1],barrel:[0,2],magazine:[1,3],underbarrel:[2,3],stock:[2,2]});
function controllerGridColumnCount(group){const raw=getComputedStyle(group).gridTemplateColumns||'';const cols=raw.split(/\s+/).filter(Boolean).length;return Math.max(1,cols||1);}
function controllerGridMove(current,list,group,dx,dy){
  const items=list.filter(el=>controllerNavGroup(el)===group);if(items.length<2)return null;
  if(group.classList.contains('gunsmith-callout-overlay')){const slot=current.dataset?.calloutSlot,from=GUNSMITH_CONTROLLER_POINTS[slot];if(!from)return null;let best=null,bestScore=Infinity;for(const el of items){if(el===current)continue;const to=GUNSMITH_CONTROLLER_POINTS[el.dataset?.calloutSlot];if(!to)continue;const vx=to[0]-from[0],vy=to[1]-from[1];if((dx<0&&vx>=0)||(dx>0&&vx<=0)||(dy<0&&vy>=0)||(dy>0&&vy<=0))continue;const primary=dx?Math.abs(vx):Math.abs(vy),cross=dx?Math.abs(vy):Math.abs(vx),score=primary+cross*1.35;if(score<bestScore){best=el;bestScore=score;}}if(best)return best;const key=String(current.dataset?.controllerKey||'').match(/^gunsmith:(.+):slot:/)?.[1]||'';if(dy<0&&key){const change=list.find(el=>el.dataset?.controllerKey===`weapon-toggle:${key}`);if(change)return change;}return null;}
  if(group.matches('.class-detail-grid,.gunsmith-attachment-options,.loadout-choice-grid,.equipment-choice-grid,.killstreak-choice-grid')){const cols=controllerGridColumnCount(group),idx=items.indexOf(current);if(idx<0)return current;if(dx){const next=idx+(dx>0?1:-1);if(next<0||next>=items.length||Math.floor(next/cols)!==Math.floor(idx/cols))return null;return items[next]||current;}if(dy){const next=idx+(dy>0?cols:-cols);if(next<0||next>=items.length)return null;return items[next]||null;}return current;}
  return null;
}
function moveControllerUiFocus(dx,dy){
  const list=controllerFocusableElements();if(!list.length)return false;const current=ensureControllerUiFocus();if(!current)return false;
  const a=current.getBoundingClientRect(),group=controllerNavGroup(current),explicit=group?controllerGridMove(current,list,group,dx,dy):null;if(explicit){setControllerUiFocus(explicit);return true;}
  let sameDirect=null,sameDirectScore=Infinity,direct=null,directScore=Infinity,sameFallback=null,sameFallbackScore=Infinity,fallback=null,fallbackScore=Infinity;
  for(const el of list){if(el===current)continue;const result=controllerDirectionScore(a,el.getBoundingClientRect(),dx,dy);if(!result)continue;
    const sameGroup=!!group&&controllerNavGroup(el)===group;
    if(result.direct&&sameGroup&&result.score<sameDirectScore){sameDirect=el;sameDirectScore=result.score;}
    if(result.direct&&result.score<directScore){direct=el;directScore=result.score;}
    if(sameGroup&&result.score<sameFallbackScore){sameFallback=el;sameFallbackScore=result.score;}
    if(result.score<fallbackScore){fallback=el;fallbackScore=result.score;}
  }
  const best=sameDirect||direct||sameFallback||fallback;if(best){setControllerUiFocus(best);return true;}return false;
}
function controllerUiDirection(pressed){
  const held=gamepadFrame.held||[],enterThreshold=.68,releaseThreshold=.40;let dx=0,dy=0,source='';
  const dl=!!held[GAMEPAD_BUTTON.DPAD_LEFT],dr=!!held[GAMEPAD_BUTTON.DPAD_RIGHT],du=!!held[GAMEPAD_BUTTON.DPAD_UP],dd=!!held[GAMEPAD_BUTTON.DPAD_DOWN];
  const ddx=(dr?1:0)-(dl?1:0),ddy=(dd?1:0)-(du?1:0);
  if(ddx||ddy){
    source='d';
    if(ddx&&ddy){
      const horizontalPressed=pressed[GAMEPAD_BUTTON.DPAD_LEFT]||pressed[GAMEPAD_BUTTON.DPAD_RIGHT],verticalPressed=pressed[GAMEPAD_BUTTON.DPAD_UP]||pressed[GAMEPAD_BUTTON.DPAD_DOWN];
      if(horizontalPressed&&!verticalPressed)dx=ddx;else if(verticalPressed&&!horizontalPressed)dy=ddy;else if(controllerUiAxisDirection.endsWith(`${ddx},0`))dx=ddx;else dy=ddy;
    }else{dx=ddx;dy=ddy;}
  }else{
    const x=Number(gamepadFrame.moveX)||0,y=Number(gamepadFrame.moveY)||0,latched=controllerUiAxisDirection.startsWith('s:'),threshold=latched?releaseThreshold:enterThreshold;
    if(Math.max(Math.abs(x),Math.abs(y))>=threshold){source='s';if(Math.abs(x)>=Math.abs(y))dx=x>0?1:-1;else dy=y>0?1:-1;}
  }
  if(!dx&&!dy){resetControllerUiAxis();return null;}
  const key=`${source}:${dx},${dy}`,now=performance.now(),justPressed=source==='d'&&(pressed[GAMEPAD_BUTTON.DPAD_LEFT]||pressed[GAMEPAD_BUTTON.DPAD_RIGHT]||pressed[GAMEPAD_BUTTON.DPAD_UP]||pressed[GAMEPAD_BUTTON.DPAD_DOWN]);
  if(key!==controllerUiAxisDirection||justPressed){controllerUiAxisDirection=key;controllerUiAxisStartedAt=now;controllerUiAxisNextAt=now+360;return{dx,dy};}
  if(now>=controllerUiAxisNextAt){const heldFor=now-controllerUiAxisStartedAt,delay=heldFor>=2400?55:heldFor>=1200?80:115;controllerUiAxisNextAt=now+delay;return{dx,dy};}
  return null;
}
function controllerFieldAdjustHeld(){
  const held=gamepadFrame.held||[];if(held[GAMEPAD_BUTTON.DPAD_LEFT]||held[GAMEPAD_BUTTON.DPAD_RIGHT])return true;
  return Math.abs(Number(gamepadFrame.moveX)||0)>=.40;
}
function stepControllerField(el,dir){
  if(!controllerEditableField(el)||!dir)return false;
  if(controllerUiAdjusting?.el!==el){finishControllerUiAdjustment();controllerUiAdjusting={el,startValue:String(el.value)};el.classList.add('controller-adjusting');}
  if(el.matches?.('[data-game-control]'))return adjustGameControl(el,dir,{commit:false});
  if(el.tagName==='SELECT'){
    const options=[...el.options].filter(option=>!option.disabled);if(!options.length)return false;
    let index=options.indexOf(el.selectedOptions?.[0]);if(index<0)index=0;const next=options[(index+dir+options.length)%options.length];
    el.value=next.value;el.dispatchEvent(new Event('change',{bubbles:true}));return true;
  }
  if(el.matches?.('input[type="range"],input[type="number"]')){
    const cur=Number(el.value)||0,min=Number.isFinite(Number(el.min))?Number(el.min):-Infinity,max=Number.isFinite(Number(el.max))?Number(el.max):Infinity,step=Math.abs(Number(el.step))>0?Math.abs(Number(el.step)):1;
    el.value=String(Math.max(min,Math.min(max,cur+step*dir)));el.dispatchEvent(new Event('input',{bubbles:true}));return true;
  }
  return false;
}
function cycleControllerTabs(direction){
  const surface=controllerUiSurface();if(!surface)return false;const tablist=controllerPrimaryTablist(surface);if(!tablist)return false;
  const tabs=[...tablist.querySelectorAll('[role="tab"],button')].filter(el=>controllerElementVisible(el,surface)&&!el.disabled);if(tabs.length<2)return false;
  let cur=tabs.findIndex(el=>el.getAttribute('aria-selected')==='true'||el.classList.contains('active'));if(cur<0)cur=0;
  const next=(cur+direction+tabs.length)%tabs.length;finishControllerUiAdjustment();tabs[next].click();
  requestAnimationFrame(()=>{if(controllerUiSurface()!==surface)return;clearControllerUiFocus();ensureControllerUiFocus();});
  return true;
}
function handleControllerUiNavigation(pressed){
  if(shell.inBuilder)return !!integratedMapBuilder?.handleControllerFrame?.(gamepadFrame,0);
  const surface=controllerUiSurface();if(!surface){clearControllerUiFocus();resetControllerUiAxis();return false;}const focus=ensureControllerUiFocus();
  if(controllerUiAdjusting&&(controllerUiAdjusting.el!==focus||!controllerFieldAdjustHeld()))finishControllerUiAdjustment();
  if(gameTextEditorTarget){
    if(pressed[GAMEPAD_BUTTON.X]){backspaceGameText();return true;}
    if(pressed[GAMEPAD_BUTTON.Y]){if(gameTextMode()!=='code')appendGameTextChar(' ');return true;}
    if(pressed[GAMEPAD_BUTTON.RS]){if(gameTextMode()!=='code'){gameTextEditorShift=!gameTextEditorShift;renderGameTextEditor();}return true;}
    if(pressed[GAMEPAD_BUTTON.MENU]){commitGameTextEditor();return true;}
  }else if(chatOpen){
    if(pressed[GAMEPAD_BUTTON.X]){backspaceChat();return true;}
    if(pressed[GAMEPAD_BUTTON.Y]){appendChatCharacter(' ');return true;}
    if(pressed[GAMEPAD_BUTTON.RS]){chatShift=!chatShift;renderChatDraft();return true;}
    if(pressed[GAMEPAD_BUTTON.MENU]){submitChat();return true;}
  }
  if(pressed[GAMEPAD_BUTTON.B]){
    if(mapDeletePromptOpen()){closeMapDeleteConfirm();return true;}
    if(lobbyQuitPromptOpen()){closeLobbyQuitConfirm();return true;}
    if(shell.connecting&&initialConnectionAttempt){cancelInitialConnection('Connection canceled.');return true;}
    if(controllerUiEditing){clearControllerUiEditing();return true;}
    finishControllerUiAdjustment();
    if(chatOpen){void dismissChat({restorePointer:false});return true;}
    if(gameTextEditorTarget){cancelGameTextEditor();return true;}
    if(shell.panel===SHELL_PANEL.SETTINGS){closePlayerSettings();return true;}
    if(shell.panel===SHELL_PANEL.ADMIN){closeAdminPanel();return true;}
    if(shell.panel===SHELL_PANEL.LOADOUT){if(loadoutWorkspaceMode.match==='item'){const slot=loadoutFocusSlot.match,key=`match-${slot}`;if((slot==='primary'||slot==='secondary')&&loadoutWeaponPickerOpen.has(key)){loadoutWeaponPickerOpen.delete(key);renderAttachmentEditor('match',slot,loadoutDraftForSurface('match'));queueControllerUiFocus(`weapon-toggle:${key}`);return true;}if((slot==='primary'||slot==='secondary')&&loadoutAttachmentTrayOpen.has(key)){const activeSlot=loadoutAttachmentSlot[key];loadoutAttachmentTrayOpen.delete(key);clearLoadoutAttachmentComparisonBase(key);loadoutAttachmentSlot[key]='';renderAttachmentEditor('match',slot,loadoutDraftForSurface('match'));queueControllerUiFocus(`gunsmith:${key}:slot:${activeSlot}`);return true;}setLoadoutWorkspaceMode('match','class',{ensurePreview:false});return true;}if(loadoutWorkspaceMode.match==='class'){setLoadoutWorkspaceMode('match','classes',{ensurePreview:false});return true;}closeMatchLoadout();return true;}
    if(shell.inLobby&&loadoutWorkspaceMode.lobby!=='classes'&&document.querySelector('[data-lobby-side-tab="loadout"]')?.classList.contains('active')){if(loadoutWorkspaceMode.lobby==='item'){const slot=loadoutFocusSlot.lobby,key=`lobby-${slot}`;if((slot==='primary'||slot==='secondary')&&loadoutWeaponPickerOpen.has(key)){loadoutWeaponPickerOpen.delete(key);renderAttachmentEditor('lobby',slot,loadoutDraftForSurface('lobby'));queueControllerUiFocus(`weapon-toggle:${key}`);return true;}if((slot==='primary'||slot==='secondary')&&loadoutAttachmentTrayOpen.has(key)){const activeSlot=loadoutAttachmentSlot[key];loadoutAttachmentTrayOpen.delete(key);clearLoadoutAttachmentComparisonBase(key);loadoutAttachmentSlot[key]='';renderAttachmentEditor('lobby',slot,loadoutDraftForSurface('lobby'));queueControllerUiFocus(`gunsmith:${key}:slot:${activeSlot}`);return true;}}setLoadoutWorkspaceMode('lobby',loadoutWorkspaceMode.lobby==='item'?'class':'classes',{ensurePreview:false});return true;}
    if(shell.inLobby){openLobbyQuitConfirm();return true;}
    if(shell.paused){shell.resumeFromAlternateInput();clock?.getDelta();return true;}
  }
  if(pressed[GAMEPAD_BUTTON.LB]){clearControllerUiEditing();if(cycleControllerTabs(-1))return true;}
  if(pressed[GAMEPAD_BUTTON.RB]){clearControllerUiEditing();if(cycleControllerTabs(1))return true;}
  if(pressed[GAMEPAD_BUTTON.A]&&focus){
    finishControllerUiAdjustment();
    if(controllerEditableField(focus)){if(controllerUiEditing===focus)clearControllerUiEditing();else setControllerUiEditing(focus);return true;}
    if(focus.tagName==='BUTTON'||focus.dataset?.gameControl==='text'||focus.matches?.('input[type="checkbox"],input[type="radio"]')){focus.click();return true;}
    return true;
  }
  const nav=controllerUiDirection(pressed);
  if(nav){
    if(controllerUiEditing===focus&&controllerEditableField(focus)){if(nav.dx)stepControllerField(focus,nav.dx);return true;}
    finishControllerUiAdjustment();return moveControllerUiFocus(nav.dx,nav.dy);
  }
  return false;
}

function activeControllerLoadoutPreviewKey(){
  let surface='';
  if(shell.panel===SHELL_PANEL.LOADOUT&&loadoutWorkspaceMode.match==='item')surface='match';
  else if(shell.inLobby&&loadoutWorkspaceMode.lobby==='item'&&document.querySelector('[data-lobby-side-tab="loadout"]')?.classList.contains('active'))surface='lobby';
  if(!surface)return'';const slot=loadoutFocusSlot[surface];return slot==='primary'||slot==='secondary'?`${surface}-${slot}`:'';
}
function rotateLoadoutPreviewFromController(dt){
  const key=activeControllerLoadoutPreviewKey();if(!key)return false;const x=Number(gamepadFrame.lookX)||0;if(Math.abs(x)<.01)return false;const ctx=loadoutPreviewContexts.get(key);if(!ctx||ctx.adsPreview)return false;
  // Match touch-drag exactly: the stick produces horizontal drag distance and
  // the shared preview-angle path converts that distance into yaw rotation.
  return adjustLoadoutPreviewAngle(ctx,x*240*Math.max(0,Math.min(.10,Number(dt)||0)));
}
function updateControllerLoadoutAdsPreview(){
  const key=activeControllerLoadoutPreviewKey(),held=!!key&&(Number(gamepadFrame.buttons?.[GAMEPAD_BUTTON.LT])||0)>=CONTROLLER_TRIGGER_THRESHOLD;
  for(const activeKey of [...loadoutPreviewAdsKeys])if((activeKey.startsWith('lobby-')||activeKey.startsWith('match-'))&&(activeKey!==key||!held))setLoadoutAdsPreview(activeKey,false);
  if(key&&held&&!loadoutPreviewAdsKeys.has(key))setLoadoutAdsPreview(key,true);
}

function controllerDisplayName(id){
  const raw=String(id||'Controller').replace(/\s*\([^)]*\)\s*/g,' ').replace(/\s+/g,' ').trim();
  return /xbox/i.test(raw)?'XBOX CONTROLLER':raw.slice(0,28).toUpperCase()||'CONTROLLER';
}
function controllerInputContext(){
  const surface=controllerUiSurface();if(surface)return controllerUiScopeId(surface);
  return `${shell.location}:${killstreakTargeting?'target':scoreboardOpen?'scoreboard':'play'}:${matchState.status}:${hp>0?'alive':'dead'}`;
}
function updateGamepadInput(dt){
  const previousConnected=!!gamepadFrame.connected;
  const enabled=!document.hidden&&shell.snapshot().focused;
  gamepadFrame=gamepadInput.poll({context:controllerInputContext(),enabled});
  if(!enabled){clearControllerGameplayInput();return;}
  const key=gamepadFrame.connected?`${gamepadFrame.index}:${gamepadFrame.id}`:'';
  if(gamepadFrame.connected&&key!==lastGamepadKey){
    lastGamepadKey=key;
    
  }else if(!gamepadFrame.connected&&previousConnected){
    lastGamepadKey='';
    if(activeInputMode===INPUT_MODE.CONTROLLER){clearControllerGameplayInput();if(shell.inMatch&&!shell.paused)shell.pause('controller-disconnect');setActiveInputMode(isTouch?INPUT_MODE.TOUCH:INPUT_MODE.KEYBOARD_MOUSE,{quiet:true});if(shell.inMatch)showToast('CONTROLLER DISCONNECTED · GAME PAUSED',{duration:2200,key:'controller-disconnect'});}
  }else if(gamepadFrame.connected&&gamepadFrame.meaningful&&activeInputMode!==INPUT_MODE.CONTROLLER)setActiveInputMode(INPUT_MODE.CONTROLLER,{quiet:true});
  if(!controllerInputActive())return;

  const pressed=gamepadFrame.pressed,released=gamepadFrame.released,buttons=gamepadFrame.buttons;
  if(replayPlayback){clearControllerGameplayInput();clearControllerUiFocus();if(replayPlayback.kind==='killcam'&&(pressed[GAMEPAD_BUTTON.A]||pressed[GAMEPAD_BUTTON.B]))skipReplayPlayback();return;}
  if(shell.inBuilder){clearControllerUiFocus();if(playerMovementActive()){applyControllerAim(dt);if(builderSession.editor.state.phase==='test'){if(pressed[GAMEPAD_BUTTON.A])tryJump();if(pressed[GAMEPAD_BUTTON.B])toggleCrouch();if(pressed[GAMEPAD_BUTTON.LS])toggleSprint();}}integratedMapBuilder?.handleControllerFrame?.(gamepadFrame,dt);return;}
  if(chatOpen||gameTextEditorTarget){
    clearControllerGameplayInput();
    handleControllerUiNavigation(pressed);
    if(chatPanel?.maxScroll>0&&Math.abs(gamepadFrame.lookY)>.18){chatScroll=Math.max(0,Math.min(chatPanel.maxScroll,chatScroll-gamepadFrame.lookY*9*dt));hudLastDraw=0;}
    return;
  }
  if(shell.inMatch&&pressed[GAMEPAD_BUTTON.MENU]){
    clearFireInput();cancelEquipmentAction();
    if(shell.panel===SHELL_PANEL.SETTINGS){closePlayerSettings();return;}
    if(shell.panel===SHELL_PANEL.ADMIN){closeAdminPanel();return;}
    if(shell.panel===SHELL_PANEL.LOADOUT){closeMatchLoadout();return;}
    if(shell.paused){if(shell.resumeFromAlternateInput()){clock?.getDelta();return;}showToast('RETURN TO GAME VIEW');return;}
    openPause();return;
  }
  if(!shell.canPlay){gamepadFireDown=false;endRecoilBurst();resetControllerAimMotion();if(controllerOwnsAim){controllerOwnsAim=false;setAim(false);}updateControllerLoadoutAdsPreview();rotateLoadoutPreviewFromController(dt);handleControllerUiNavigation(pressed);return;}for(const activeKey of [...loadoutPreviewAdsKeys])if(activeKey.startsWith('match-')||activeKey.startsWith('lobby-'))setLoadoutAdsPreview(activeKey,false);
  if(pressed[GAMEPAD_BUTTON.VIEW]){controllerScoreboardHeld=true;scoreboardOpen=true;scoreboardScroll=0;keys.clear();resetTouchInput();clearFireInput();cancelEquipmentAction();}
  if(controllerScoreboardHeld&&!gamepadFrame.physicalHeld[GAMEPAD_BUTTON.VIEW]){controllerScoreboardHeld=false;scoreboardOpen=false;return;}
  if(scoreboardOpen&&scoreboardPanel&&Math.abs(gamepadFrame.lookY)>.02)scoreboardScroll=Math.max(0,Math.min(scoreboardPanel.maxScroll,scoreboardScroll+gamepadFrame.lookY*620*dt));
  if(!matchAllowsMovement(matchState)){clearControllerGameplayInput();clearControllerUiFocus();return;}
  clearControllerUiFocus();
  if(killstreakTargeting){clearControllerGameplayInput();updateControllerKillstreakTarget(dt,pressed);return;}
  // Scoreboard is a read-only hold overlay. While View is held, consume the
  // controller so D-pad shortcuts cannot accidentally deploy streaks or open chat.
  if(scoreboardOpen){clearControllerGameplayInput();if(pressed[GAMEPAD_BUTTON.B]){controllerScoreboardHeld=false;scoreboardOpen=false;}return;}

  if(hp<=0&&pressed[GAMEPAD_BUTTON.Y]){openMatchLoadout();return;}
  // Conventional FPS controller contract: LS sprint / sniper steady, Down chat,
  // Left fire mode, Up killstreak select, Right killstreak use. Y alone swaps weapons.
  if(hp>0&&pressed[GAMEPAD_BUTTON.LS]&&!(currentWeapon==='sniper'&&adsWanted))toggleSprint();
  if(hp>0&&pressed[GAMEPAD_BUTTON.DPAD_DOWN]){openChat();return;}
  if(hp>0&&pressed[GAMEPAD_BUTTON.DPAD_LEFT]&&currentWeapon==='assault'){toggleFireMode();return;}
  if(hp>0&&pressed[GAMEPAD_BUTTON.DPAD_UP]){cycleKillstreak(1);return;}
  if(hp>0&&pressed[GAMEPAD_BUTTON.DPAD_RIGHT]){requestKillstreak();return;}

  if(currentWeapon==='akimbo1887'){
    if(controllerOwnsAim){controllerOwnsAim=false;setAim(false);}
    if(pressed[GAMEPAD_BUTTON.LT])requestShot('left');
    if(pressed[GAMEPAD_BUTTON.RT])requestShot('right');
    gamepadFireDown=false;
  }else{
    const adsHeld=buttons[GAMEPAD_BUTTON.LT]>=CONTROLLER_TRIGGER_THRESHOLD;
    if(adsHeld){controllerOwnsAim=true;if(!adsWanted)setAim(true);}else if(controllerOwnsAim){controllerOwnsAim=false;setAim(false);}
    const rtValue=buttons[GAMEPAD_BUTTON.RT]||0,fireHeld=gamepadFireDown?rtValue>=CONTROLLER_TRIGGER_RELEASE_THRESHOLD:rtValue>=CONTROLLER_TRIGGER_THRESHOLD;
    if(fireHeld&&!gamepadFireDown){gamepadFireDown=true;requestShot();}
    else if(!fireHeld&&gamepadFireDown){gamepadFireDown=false;endRecoilBurstIfReleased();}
  }
  if(hp>0)applyControllerAim(dt);else resetControllerAimMotion();

  if(pressed[GAMEPAD_BUTTON.A])tryJump();
  if(pressed[GAMEPAD_BUTTON.B])toggleCrouch();
  if(pressed[GAMEPAD_BUTTON.X])doReload();
  if(pressed[GAMEPAD_BUTTON.Y])switchWeapon(nextWeapon(currentWeapon));
  if(pressed[GAMEPAD_BUTTON.LB])beginEquipmentAim(tacticalEquipment);
  if(pressed[GAMEPAD_BUTTON.RB])beginEquipmentAim(lethalEquipment);
  if(released[GAMEPAD_BUTTON.LB]&&equipmentAimKind()===tacticalEquipment)releaseEquipmentAim();
  if(released[GAMEPAD_BUTTON.RB]&&equipmentAimKind()===lethalEquipment)releaseEquipmentAim();
}
function updateGameSimulation(dt){const now=performance.now();updateCombatAction(now);if(hp>0){if(killstreakTargeting||serverNow()<killstreakControlUntil){moveVelocityX=moveVelocityZ=0;clearFireInput();cancelSprint();return;}applyEarthquakeAimPull(dt);updateCrouchState(dt);updateMovement(dt);updateFireControl(now);}}
function updateGameFrame(dt){
  const now=performance.now();updateCorrectionView(dt);updateAimRecoil(dt);updateSniperBreathing(dt,now);
  const deathP=hp<=0?THREE.MathUtils.clamp((now-(deathAnimStartedAt||now))/700,0,1):0,deathEase=deathP*deathP*(3-2*deathP),viewY=updateViewVertical(dt),stanceEase=smoothstep01(crouchBlend),traversePose=traversal?traversalPose(traversal,now):null,traverseWave=traversePose?Math.sin(Math.PI*traversePose.progress):0;
  const stanceHeight=THREE.MathUtils.lerp(PLAYER_HEIGHT,CROUCH_HEIGHT,stanceEase);
  let cameraY=viewY+stanceHeight-.42*deathEase-slideViewBlend*.13+ufoLocalLift;
  if(traversePose){
    // Traversal is a deterministic forced path. Prediction-correction offsets
    // from the previous free-movement frame must not shift the camera sideways
    // into a wall/window frame. Duck the first-person eye through the opening
    // and also respect the exact portal ceiling supplied by collision geometry.
    const duck=traversal?.role==='window'?0.24:traversal?.mode==='mantle'?0.15:0.11;
    cameraY-=duck*traverseWave;
    if(traversal?.viewMaxY!=null&&Number.isFinite(Number(traversal.viewMaxY)))cameraY=Math.min(cameraY,Number(traversal.viewMaxY));
  }
  const cameraCorrectionX=(traversal||ladderState)?0:correctionViewX,cameraCorrectionZ=(traversal||ladderState)?0:correctionViewZ,quake=hp>0?activeEarthquakeVisual():null,quakeP=quake?THREE.MathUtils.clamp((serverNow()-quake.start)/Math.max(1,quake.end-quake.start),0,1):0,quakeFade=quake?Math.min(1,quakeP/.06,Math.max(0,(1-quakeP)/.12)):0,quakeSeed=Number(quake?.seed)||0,quakeX=quakeFade*(Math.sin(now*.047+quakeSeed*.01)*.115+Math.sin(now*.096)*.050),quakeY=quakeFade*(Math.sin(now*.064+1.4)*.082),quakeZ=quakeFade*(Math.cos(now*.043+quakeSeed*.013)*.115);
  camera.position.set(position.x+cameraCorrectionX+quakeX,cameraY+quakeY,position.z+cameraCorrectionZ+quakeZ);const liveYaw=effectiveAimYaw(),deathYaw=Number.isFinite(deathViewTargetYaw)?deathViewStartYaw+normalizeAngle(deathViewTargetYaw-deathViewStartYaw)*deathEase:deathViewStartYaw;camera.rotation.y=hp<=0?deathYaw:liveYaw;const livePitch=effectiveAimPitch(),deathPitch=THREE.MathUtils.clamp(deathViewStartPitch+.10*deathEase,-1.40,1.40);camera.rotation.x=THREE.MathUtils.clamp((hp<=0?deathPitch:livePitch)-.045*traverseWave+quakeFade*Math.sin(now*.057)*.028,-1.40,1.40);camera.rotation.z=.72*deathEase+(hp>0?explosionVisualRoll(now):0)+quakeFade*Math.sin(now*.039+quakeSeed*.005)*.052;
  maintainNetwork();
}
function updateMovement(dt){
  const now=performance.now();
  if(!builderSession&&!matchAllowsMovement(matchState)){
    stopSlide();cancelSprint();traversal=null;ladderState=null;moveVelocityX=moveVelocityZ=0;verticalVelocity=0;knockX=knockZ=0;onGround=true;lastGroundedAt=now;jumpBufferedUntil=0;traversalIntentUntil=0;localMoveAmount=THREE.MathUtils.lerp(localMoveAmount,0,Math.min(1,dt*12));position.y=worldSupportHeight(position.x,position.z,position.y,false);return;
  }
  if(updateLadder(serverNow(),dt)){sendCurrentState();return;}
  if(updateTraversal(now)){localMoveAmount=THREE.MathUtils.lerp(localMoveAmount,0,Math.min(1,dt*10));moveVelocityX=moveVelocityZ=0;return;}
  if(onGround)lastGroundedAt=now;
  updateLadderAttachLock(now);
  if(onGround&&tryAttachLadder()){sendCurrentState(true);return;}
  if((keys.has('Space')||touchRoleActive('jump')||(controllerInputActive()&&gamepadFrame.held[GAMEPAD_BUTTON.A]))&&traversalConsumedIntentSeq!==traversalIntentSeq)traversalIntentUntil=Math.max(traversalIntentUntil,now+110);
  const input=movementInput(),mx=input.mx,mz=input.mz,len=input.len,movement=movementSettings;
  const sin=Math.sin(yaw),cos=Math.cos(yaw);updateSprintState(input);
  if(sliding){
    const elapsed=now-slideStartedAt,progress=Math.max(0,Math.min(1,elapsed/Math.max(1,SLIDE_DURATION_MS)));
    if(!onGround||elapsed>=SLIDE_DURATION_MS){stopSlide({recover:onGround});}
    else{
      const desiredX=mx*cos+mz*sin,desiredZ=-mx*sin+mz*cos,desiredLen=Math.hypot(desiredX,desiredZ);
      if(desiredLen>.15){const nx=desiredX/desiredLen,nz=desiredZ/desiredLen,steer=Math.min(1,SLIDE_STEER*dt*60);slideDirX=slideDirX*(1-steer)+nx*steer;slideDirZ=slideDirZ*(1-steer)+nz*steer;const dl=Math.hypot(slideDirX,slideDirZ)||1;slideDirX/=dl;slideDirZ/=dl;}
      // Hold the burst briefly, then shed speed hard so a slide feels like a
      // committed movement action instead of crouch carrying sprint momentum.
      const decel=progress*progress,endSpeed=movement.runSpeed*SLIDE_END_SPEED_MULTIPLIER,slideSpeed=THREE.MathUtils.lerp(slideStartSpeed,endSpeed,decel);moveVelocityX=slideDirX*slideSpeed;moveVelocityZ=slideDirZ*slideSpeed;
    }
  }
  if(!sliding){
    const recovering=now<slideRecoveryUntil,adsMove=smoothstep01(adsBlend),adsMoveSpeedScale=Math.max(.5,Math.min(1,Number(effectiveWeaponSpec(currentWeapon)?.adsMoveSpeedScale)||1)),baseMoveSpeed=THREE.MathUtils.lerp(movement.runSpeed,movement.walkSpeed*adsMoveSpeedScale,adsMove),targetSpeed=recovering?0:baseMoveSpeed*(sprinting?SPRINT_SPEED_MULTIPLIER:1)*(crouched?CROUCH_SPEED_MULTIPLIER:1),targetX=recovering?0:(mx*cos+mz*sin)*targetSpeed,targetZ=recovering?0:(-mx*sin+mz*cos)*targetSpeed;
    if(onGround){const accel=recovering?GROUND_BRAKING*1.45:(len>.04?GROUND_ACCELERATION:GROUND_BRAKING),next=approachVector(moveVelocityX,moveVelocityZ,targetX,targetZ,accel*dt);moveVelocityX=next.x;moveVelocityZ=next.z;}
    else if(len>.04){const next=approachVector(moveVelocityX,moveVelocityZ,targetX,targetZ,AIR_ACCELERATION*dt);moveVelocityX=next.x;moveVelocityZ=next.z;const airSpeed=Math.hypot(moveVelocityX,moveVelocityZ),airCap=movement.runSpeed;if(airSpeed>airCap){moveVelocityX=moveVelocityX/airSpeed*airCap;moveVelocityZ=moveVelocityZ/airSpeed*airCap;}}
  }
  const knock=advanceKnockback(knockX,knockZ,dt),dx=moveVelocityX*dt+knock.dx,dz=moveVelocityZ*dt+knock.dz,startX=position.x,startZ=position.z;
  knockX=knock.xVelocity;knockZ=knock.zVelocity;
  // Collision resolution already removes the blocked displacement and slides
  // the capsule along the free axis. Do not damp the full velocity merely
  // because one contact occurred: that made continuous wall contact destroy
  // tangential speed every simulation step and could reduce a run to a crawl.
  const horizontalMove=moveHorizontal(dx,dz);
  const moved=Math.hypot(position.x-startX,position.z-startZ),wasGround=onGround,previousY=position.y;
  const verticalStep=advanceVerticalMotion(previousY,verticalVelocity,movement.gravity,dt);
  const vertical=resolveCeilingCollision(previousY,verticalStep.y,position.x,position.z,currentPlayerHeight());position.y=vertical.y;verticalVelocity=verticalStep.velocity;if(vertical.hit&&verticalVelocity>0)verticalVelocity=0;const ground=worldSupportHeight(position.x,position.z,position.y);
  if(position.y<=ground||(wasGround&&verticalVelocity<=0&&position.y<ground+.3)){
    const landingSpeed=!wasGround?Math.max(0,-verticalVelocity):0;
    position.y=ground;verticalVelocity=0;onGround=true;lastGroundedAt=now;
    if(!wasGround){landingKick=1;nextFootstepAt=now+120;if(landingSpeed>2.4)soundLanding(THREE.MathUtils.clamp((landingSpeed-2.4)/8,.28,.82));}
    if(jumpBufferedUntil>now){startPlayerJump(now,{allowTraversal:false});return;}
  }else onGround=false;
  if(jumpBufferedUntil&&jumpBufferedUntil<=now)jumpBufferedUntil=0;
  if(horizontalMove?.blocked&&traversalConsumedIntentSeq!==traversalIntentSeq&&now<traversalIntentUntil&&tryTraversal())return;
  const planarSpeed=Math.hypot(moveVelocityX,moveVelocityZ),moveRatio=THREE.MathUtils.clamp(planarSpeed/Math.max(.1,movement.runSpeed),0,1);localMoveAmount=THREE.MathUtils.lerp(localMoveAmount,moved>0.0005?moveRatio:0,Math.min(1,dt*12));
  const walking=onGround&&hp>0&&planarSpeed>.35&&moved>.0005;
  if(walking){
    const pace=THREE.MathUtils.lerp(530,310,moveRatio);
    if(now>=nextFootstepAt){soundFootstep(footstepSide,THREE.MathUtils.lerp(.22,.38,moveRatio));footstepSide^=1;nextFootstepAt=now+pace;}
  }else if(!onGround||planarSpeed<=.25)nextFootstepAt=Math.max(nextFootstepAt,now+90);
}

function remoteActorBlocked(x,z,y,fromX,fromZ,playerHeight=currentPlayerHeight()){
  for(const r of remotes.values()){
    if(!r||Number(r.hp)<=0)continue;
    const actor=r.target||r.group?.position;if(!actor)continue;
    const ax=Number(actor.x),ay=Number(actor.y),az=Number(actor.z);if(!Number.isFinite(ax)||!Number.isFinite(ay)||!Number.isFinite(az))continue;
    const actorHeight=r.crouched?CROUCH_HEIGHT:PLAYER_HEIGHT;
    if(y+playerHeight-.08<=ay||y>=ay+actorHeight-.08)continue;
    const minDist=PLAYER_RADIUS*2+.02,newDist=Math.hypot(x-ax,z-az),oldDist=Math.hypot(fromX-ax,fromZ-az);
    if(newDist<minDist&&(oldDist>=minDist||newDist<oldDist-.002))return true;
  }
  return false;
}

function moveHorizontal(dx,dz){
  const next=sweepHorizontalMovement({
    x:position.x,y:position.y,z:position.z,dx,dz,grounded:onGround,arenaLimit:ARENA_LIMIT,followDrop:GROUND_FOLLOW_DROP,
    supportHeight:(x,z,y)=>worldSupportHeight(x,z,y,crouched),
    stepUpHeight:(x,z,y,maxStep)=>worldStepUpHeight(x,z,y,maxStep,PLAYER_RADIUS),maxStepHeight:MAX_STEP_HEIGHT,
    blockedAt:(x,z,y,fromX,fromZ,fromY)=>worldMoveBlockedAt(x,z,y,fromX,fromZ,currentPlayerHeight(),PLAYER_RADIUS,fromY)||remoteActorBlocked(x,z,y,fromX,fromZ),
  });
  position.set(next.x,next.y,next.z);onGround=next.grounded;return next;
}
function blocked(x,z,y=position?.y??terrainHeight(x,z),playerHeight=currentPlayerHeight()){return worldBlockedAt(x,z,y,playerHeight,PLAYER_RADIUS);}
function round3(n){return Math.round(n*1000)/1000;}
function round4(n){return Math.round(n*10000)/10000;}

function updateRemoteVisuals(dt){
  const now=performance.now(),srv=serverNow(),remoteDelay=currentRemoteViewDelayMs(),remoteRenderAt=srv-remoteDelay,remoteTraversalNow=now-remoteDelay;
  for(const [id] of remotes){if(samePlayerId(id,clientId))removeRemote(id);}
  for(const r of remotes.values()){
    syncRemoteBodyVisual(r,now);
    const traversalPoseNow=r.traversal?traversalPose(r.traversal,remoteTraversalNow):null;if(r.traversal&&traversalPoseNow?.done)r.traversal=null;const traversing=!!traversalPoseNow&&!traversalPoseNow.done,laddering=!!r.ladder,rendered=traversing?traversalPoseNow:remoteSnapshotAt(r,remoteRenderAt);
    if(rendered){r.group.position.set(rendered.x,rendered.y,rendered.z);if(Number.isFinite(Number(rendered.yaw)))r.group.rotation.y=Number(rendered.yaw);if(Number.isFinite(Number(rendered.pitch)))r.renderPitch=Number(rendered.pitch);if(typeof rendered.ads==='boolean')r.ads=rendered.ads;if(typeof rendered.crouched==='boolean')r.crouched=rendered.crouched;if(typeof rendered.sprinting==='boolean')r.sprinting=rendered.sprinting;if(typeof rendered.sliding==='boolean')r.sliding=rendered.sliding;r.airborne=traversing||laddering||rendered.y>worldSupportHeight(rendered.x,rendered.z,rendered.y)+.08;}
    const dead=r.hp<=0;r.deathPose=THREE.MathUtils.lerp(r.deathPose,dead?1:0,Math.min(1,dt*(dead?5.5:12)));const dp=r.deathPose*r.deathPose*(3-2*r.deathPose);r.model.rotation.z=1.34*dp;r.model.rotation.x=.10*dp;r.model.position.y=-.18*dp;updateRemoteNameTagPresentation(r);
    if(!dead){
      r.crouchBlend=THREE.MathUtils.lerp(r.crouchBlend,r.crouched?1:0,Math.min(1,dt*12));r.sprintBlend=THREE.MathUtils.lerp(r.sprintBlend||0,r.sprinting?1:0,Math.min(1,dt*14));r.slideBlend=THREE.MathUtils.lerp(r.slideBlend||0,r.sliding?1:0,Math.min(1,dt*16));r.model.scale.y=THREE.MathUtils.lerp(1,CROUCH_HEIGHT/PLAYER_HEIGHT,r.crouchBlend);r.model.rotation.x=.10*dp+r.slideBlend*.17;if(r.tag)r.tag.position.y=THREE.MathUtils.lerp(2.18,1.48,r.crouchBlend);
      const move=THREE.MathUtils.clamp(r.moveSpeed/(movementSettings.runSpeed*.75),0,1),running=move>.08&&!r.airborne&&!traversing&&!laddering;r.animPhase+=dt*(running?5.5+move*6+(r.sprintBlend||0)*2.2:1.8);const swing=running?Math.sin(r.animPhase)*.68*move*(1+(r.sprintBlend||0)*.18):Math.sin(r.animPhase)*.035;
      if(running&&now>=r.nextFootstepAt){playSpatialCue(r.footstepSide?'footstepRight':'footstepLeft',r.group.position.x,r.group.position.y,r.group.position.z,30,.48);r.footstepSide^=1;r.nextFootstepAt=now+THREE.MathUtils.lerp(540,315,move);}else if(!running)r.nextFootstepAt=Math.max(r.nextFootstepAt,now+120);
      r.legL.rotation.x=r.airborne?-.34:swing;r.legR.rotation.x=r.airborne?.34:-swing;r.armL.rotation.x=r.airborne?.28:-swing*.72;r.armR.rotation.x=r.airborne?-.20:swing*.52;r.armL.rotation.z=-.12;r.armR.rotation.z=.12;if(r.weapon==='akimbo1887'){r.armL.rotation.x=-1.05;r.armR.rotation.x=-1.05;r.armL.rotation.z=-.20;r.armR.rotation.z=.20;}
      if(traversing){const p=traversalPoseNow.progress,wave=Math.sin(Math.PI*p);r.armL.rotation.x=-1.55-wave*.35;r.armR.rotation.x=-1.55-wave*.35;r.armL.rotation.z=-.24;r.armR.rotation.z=.24;r.legL.rotation.x=.48*wave;r.legR.rotation.x=-.30*wave;r.body.rotation.x=-.18*wave;r.head.rotation.x=.08*wave;}if(laddering){const phase=(now*.010)% (Math.PI*2),wave=Math.sin(phase);r.armL.rotation.x=-1.35+wave*.34;r.armR.rotation.x=-1.35-wave*.34;r.armL.rotation.z=-.20;r.armR.rotation.z=.20;r.legL.rotation.x=-wave*.42;r.legR.rotation.x=wave*.42;r.body.rotation.x=-.08;r.head.rotation.x=.03;}
      const reloadActive=r.reloadUntil>srv;if(!reloadActive){r.reloadUntil=0;r.reloadStartedAt=0;}const total=weaponRules(r.reloadWeapon||r.weapon)?.reloadMs||650,reloadP=reloadActive?THREE.MathUtils.clamp((srv-(r.reloadStartedAt||srv))/Math.max(1,total),0,1):0,reloadCurve=Math.sin(Math.PI*reloadP);const swapP=r.swapStartedAt?THREE.MathUtils.clamp((now-r.swapStartedAt)/Math.max(1,WEAPON_SWITCH_MS),0,1):1,swapCurve=swapP<1?Math.sin(Math.PI*swapP):0;if(swapP>=1)r.swapStartedAt=0;const kick=now<r.fireKickUntil?Math.sin(Math.PI*THREE.MathUtils.clamp((r.fireKickUntil-now)/170,0,1))*.31:0;
      r.armR.rotation.x+=reloadCurve*.95+kick*1.18;r.armR.rotation.z=.12-reloadCurve*.28+kick*.10;const lower=reloadCurve*.24+swapCurve*.34+(r.sprintBlend||0)*.18+(r.slideBlend||0)*.12+(traversing?Math.sin(Math.PI*traversalPoseNow.progress)*.34:0)+(laddering ? .32 : 0);
      r.pistol.position.set(.45,1.08-lower+kick*.06,-.25+kick*.31);if(r.akimbo1887){r.akimbo1887.position.y=-lower+kick*.04;r.akimbo1887.position.z=kick*.22;if(r.akimboLeft&&r.akimboRight&&r.akimboCycleStartedAt){const lc=akimbo1887CycleState(r.akimboCycleStartedAt.left,now,'left'),rc=akimbo1887CycleState(r.akimboCycleStartedAt.right,now,'right');r.akimboLeft.rotation.set(-.08+lc.spin,.14,-.03);r.akimboRight.rotation.set(-.08+rc.spin,-.14,.03);}}r.assault.position.set(.45,1.09-lower+kick*.07,-.38+kick*.38);r.ump.position.set(.45,1.08-lower+kick*.06,-.34+kick*.34);r.machineGun.position.set(.45,1.08-lower+kick*.08,-.42+kick*.42);r.shotgun.position.set(.45,1.10-lower+kick*.09,-.41+kick*.42);r.semiShotgun.position.set(.45,1.10-lower+kick*.08,-.40+kick*.39);r.sniper.position.set(.45,1.10-lower+kick*.10,-.45+kick*.45);r.grenadeLauncher.position.set(.45,1.08-lower+kick*.09,-.40+kick*.46);r.rpg.position.set(.38,1.42-lower*.82+kick*.10,-.43+kick*.48);for(const gun of [r.pistol,r.akimbo1887,r.assault,r.ump,r.machineGun,r.shotgun,r.semiShotgun,r.sniper,r.grenadeLauncher,r.rpg])gun.rotation.z=-reloadCurve*.35-swapCurve*.35+kick*.08;
      if(r.zombie&&!traversing&&!laddering){const strike=Math.max(0,1-(srv-r.attackAt)/420);r.armL.rotation.x=-1.1-strike*.7;r.armR.rotation.x=-1.25-strike*.6;r.armL.rotation.z=-.16;r.armR.rotation.z=.16;}
      if(!traversing&&!laddering){r.body.rotation.x=r.airborne?-.08:running?Math.sin(r.animPhase*2)*.025:Math.sin(r.animPhase)*.012;r.head.rotation.x=r.ads?-.045:0;}
    }
    if(r.godRing?.visible){r.godRing.rotation.z+=dt*1.8;r.godRing.material.opacity=.66+.24*Math.sin(now*.004+r.group.position.x);}
  }
  updateTeammateDeathMarkers(now);updateAimNameplates(now);
}
function updateAimNameplates(now=performance.now()){
  if(!THREE||!camera||!worldRoot||!matchAllowsMovement(matchState)||hp<=0){aimedRemoteId='';for(const r of remotes.values())updateRemoteNameTagPresentation(r);return;}
  if(now<nextAimTagCheckAt)return;nextAimTagCheckAt=now+70;if(!aimTagRaycaster)aimTagRaycaster=new THREE.Raycaster();
  const targets=[worldRoot];for(const r of remotes.values())if(r.hp>0)targets.push(r.model);aimTagRaycaster.setFromCamera({x:0,y:0},camera);aimTagRaycaster.near=.05;aimTagRaycaster.far=180;
  let hitId='';for(const hit of aimTagRaycaster.intersectObjects(targets,true)){let o=hit.object,remoteId='';while(o){if(o.userData?.remoteId){remoteId=String(o.userData.remoteId);break;}if(o===worldRoot)break;o=o.parent;}if(remoteId){const r=Array.from(remotes.values()).find(item=>samePlayerId(item.id,remoteId));if(r&&r.hp>0&&!modeFriendly(r.team))hitId=String(r.id);break;}break;}
  aimedRemoteId=hitId;for(const r of remotes.values())updateRemoteNameTagPresentation(r);
}

function updateAim(dt){
  const target=adsWanted&&hp>0&&shell.canPlay?1:0,spec=effectiveWeaponSpec(currentWeapon),transitionMs=Math.max(60,Number(target?spec.adsInMs:spec.adsOutMs)||180),seconds=Math.max(.060,transitionMs/1000),frameDt=Math.max(0,Number(dt)||0);
  if(currentWeapon==='sniper')adsBlend=THREE.MathUtils.clamp(adsBlend+(target?1:-1)*(frameDt/seconds),0,1);
  else{const rate=4.605170186/seconds,follow=1-Math.exp(-rate*frameDt);adsBlend+=(target-adsBlend)*follow;if(Math.abs(target-adsBlend)<.002)adsBlend=target;}
  if(currentWeapon==='sniper'){
    const desiredFov=THREE.MathUtils.lerp(baseFov,sniperTargetFov(),sniperZoomAmount()),fovFollow=1-Math.exp(-18*Math.max(0,Number(dt)||0)),fov=camera.fov+(desiredFov-camera.fov)*fovFollow;
    if(Math.abs(camera.fov-fov)>.03){camera.fov=fov;camera.updateProjectionMatrix();}
  }else{
    const eased=adsBlend*adsBlend*(3-2*adsBlend),fov=THREE.MathUtils.lerp(baseFov,spec.adsFov,eased);
    if(Math.abs(camera.fov-fov)>.03){camera.fov=fov;camera.updateProjectionMatrix();}
  }
}
function akimbo1887CycleState(startedAt,now,side){
  if(!startedAt||now<startedAt)return{active:false,p:1,kick:0,spin:0,lever:0,lift:0};
  const p=THREE.MathUtils.clamp((now-startedAt)/AKIMBO_1887_CYCLE_MS,0,1);
  if(p>=1)return{active:false,p:1,kick:0,spin:0,lever:0,lift:0};
  const kickP=THREE.MathUtils.clamp(p/.17,0,1),spinP=smoothstep01((p-.09)/.73),actionP=THREE.MathUtils.clamp((p-.06)/.55,0,1);
  return{active:true,p,kick:Math.sin(Math.PI*kickP),spin:Math.PI*2*spinP,lever:Math.sin(Math.PI*actionP)*1.02,lift:Math.sin(Math.PI*spinP)*.065};
}
function updateWeaponView(dt){
  const now=performance.now();
  sprintViewBlend=expFollow(sprintViewBlend,sprinting?1:0,13,Math.max(.001,dt));slideViewBlend=expFollow(slideViewBlend,sliding?1:0,16,Math.max(.001,dt));
  const kickAds=smoothstep01(adsBlend),sightLock=weaponUsesIronSights(currentWeapon)?kickAds:0;updateWeaponKick(dt);
  // Keep the fore/aft recoil the user can feel, but do not throw the iron sight
  // sideways or rotate it away from the authoritative camera/bullet ray.
  const kickProfile=weaponVisualKickProfile(currentWeapon),kickZ=weaponKickZ*kickProfile.rear*THREE.MathUtils.lerp(1,kickProfile.adsRear,kickAds),kickLift=weaponKickZ*kickProfile.lift*THREE.MathUtils.lerp(1,0,sightLock),kickStep=Math.max(0,localRecoilStep[currentWeapon]??0),kickSeq=Math.max(0,localWeaponShotSequence[currentWeapon]||0),kickSide=Math.sin((kickStep+kickSeq*.73+1)*1.91+WEAPON_ORDER.indexOf(currentWeapon)*.73),kickPitch=weaponKickZ*kickProfile.pitch*THREE.MathUtils.lerp(1,0,sightLock),kickYaw=weaponKickZ*kickSide*kickProfile.yaw*THREE.MathUtils.lerp(1,0,sightLock),kickRoll=weaponKickZ*kickSide*kickProfile.roll*THREE.MathUtils.lerp(1,0,sightLock),actionPulse=weaponActionPulse(currentWeapon,now);
  const moving=hp>0&&onGround?THREE.MathUtils.clamp(localMoveAmount,0,1):0;if(moving>.03)moveBobPhase+=dt*THREE.MathUtils.lerp(11.5,7.5,kickAds)*(0.55+moving*.65);else moveBobPhase+=dt*1.8;
  landingKick=Math.max(0,landingKick-dt*4.2);const bobScale=moving*THREE.MathUtils.lerp(1,.015,sightLock),bobX=Math.sin(moveBobPhase)*.018*bobScale,bobY=Math.abs(Math.cos(moveBobPhase))*-.016*bobScale;
  const jumpSpeed=Math.sqrt(2*movementSettings.gravity*movementSettings.jumpHeight),jumpNorm=onGround?0:THREE.MathUtils.clamp(verticalVelocity/Math.max(.1,jumpSpeed),-1,1),sightMotion=1-sightLock*.94,jumpY=(onGround?0:(jumpNorm>0?-.035:.025))*sightMotion,landY=-Math.sin(landingKick*Math.PI)*.055*sightMotion;
  const reloadW=reloadWeapon||currentWeapon,reloading=!!reloadUntil&&reloadW===currentWeapon;let reloadP=0,reloadCurve=0;
  if(reloading){const total=weaponRules(reloadW).reloadMs;const start=reloadStartedAt||reloadUntil-total;reloadP=THREE.MathUtils.clamp((serverNow()-start)/Math.max(1,total),0,1);reloadCurve=Math.sin(Math.PI*reloadP);}
  const swapP=weaponSwapStartedAt?THREE.MathUtils.clamp((now-weaponSwapStartedAt)/Math.max(1,WEAPON_SWITCH_MS),0,1):1,swapCurve=swapP<1?Math.sin(Math.PI*swapP):0;if(swapP>=1)weaponSwapStartedAt=0;
  const deathP=!replayPlayback&&hp<=0?THREE.MathUtils.clamp((now-(deathAnimStartedAt||now))/650,0,1):0,deathEase=deathP*deathP*(3-2*deathP);
  const traversePoseNow=traversal?traversalPose(traversal,now):null,traverseP=traversePoseNow?traversePoseNow.progress:0,traverseCurve=traversePoseNow?Math.sin(Math.PI*traverseP):0;
  const equipmentLower=equipmentWeaponLower(now),mobilityLower=sprintViewBlend*(1-kickAds),slideLower=slideViewBlend*(1-kickAds*.35),idle=Math.sin(now*.0018)*.0035*THREE.MathUtils.lerp(1,.25,kickAds)*(1-sightLock*.94),commonX=bobX+mobilityLower*.10+slideLower*.035+equipmentLower*.035,commonY=bobY+jumpY+landY+idle+kickLift-reloadCurve*.19-swapCurve*.36-deathEase*.55-traverseCurve*.42-mobilityLower*.19-slideLower*.08-equipmentLower*.30,commonZ=reloadCurve*.08+swapCurve*.10+deathEase*.18+traverseCurve*.16+mobilityLower*.13+slideLower*.055+equipmentLower*.07;
  const reloadRoll=reloadCurve*(currentWeapon==='sniper'?.22:.48),swapRoll=swapCurve*.42,deathRoll=deathEase*.58,mobilityRoll=mobilityLower*.46+slideLower*.16+equipmentLower*.10;
  const a=kickAds,ironCommonX=commonX*(1-sightLock),ironCommonY=commonY*(1-sightLock);
  const sightPose=(group,weapon,fallback)=>{const mods=attachmentsForWeapon(weapon),opticId=String(mods?.optic||''),opticPose=opticId?group?.userData?.attachmentVisuals?.[opticId]?.userData?.adsPose:null;return opticPose?opticPose:(group.userData.adsPose||fallback);},pistolPose=sightPose(pistolGroup,'pistol',{x:0,y:-.14,z:-.54,rx:0,ry:0,rz:0}),assaultPose=sightPose(assaultGroup,'assault',{x:0,y:-.165,z:-.45,rx:0,ry:0,rz:0}),umpPose=sightPose(umpGroup,'ump',{x:0,y:-.155,z:-.46,rx:0,ry:0,rz:0}),machineGunPose=sightPose(machineGunGroup,'machineGun',{x:0,y:-.178,z:-.46,rx:0,ry:0,rz:0}),shotgunPose=sightPose(shotgunGroup,'shotgun',{x:0,y:-.116,z:-.44,rx:0,ry:0,rz:0}),semiShotgunPose=sightPose(semiShotgunGroup,'semiShotgun',{x:0,y:-.118,z:-.44,rx:0,ry:0,rz:0}),rpgPose=sightPose(rpgGroup,'rpg',{x:0,y:-.145,z:-.49,rx:0,ry:0,rz:0});
  pistolGroup.position.set(THREE.MathUtils.lerp(.33,pistolPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.25,pistolPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.67,pistolPose.z,a)+kickZ+commonZ);pistolGroup.rotation.set(THREE.MathUtils.lerp(-.08,pistolPose.rx,a)+reloadCurve*.18+kickPitch,THREE.MathUtils.lerp(-.08,pistolPose.ry,a)-reloadCurve*.18+kickYaw,THREE.MathUtils.lerp(0,pistolPose.rz,a)-reloadRoll-swapRoll-deathRoll-mobilityRoll+kickRoll);
  if(akimboLeftGroup&&akimboRightGroup){
    const left=akimbo1887CycleState(akimboLeftCycleStartedAt,now,'left'),right=akimbo1887CycleState(akimboRightCycleStartedAt,now,'right'),akReload=reloading&&currentWeapon==='akimbo1887'?reloadCurve:0;
    if(left.active&&left.p>=.28&&!akimboCycleSoundPlayed.left){akimboCycleSoundPlayed.left=true;playSoundCue('action1887',.90,{playbackRate:.99+Math.random()*.02,pan:-.42});}
    if(right.active&&right.p>=.28&&!akimboCycleSoundPlayed.right){akimboCycleSoundPlayed.right=true;playSoundCue('action1887',.90,{playbackRate:.99+Math.random()*.02,pan:.42});}
    akimboLeftGroup.position.set(-.40+commonX*.42,-.32+commonY*.50-akReload*.18+left.lift,-.72+commonZ+left.kick*.18);
    akimboRightGroup.position.set(.40+commonX*.42,-.32+commonY*.50-akReload*.18+right.lift,-.72+commonZ+right.kick*.18);
    akimboLeftGroup.rotation.set(-.08+left.spin+akReload*.18,.18,-.035-akReload*.24);
    akimboRightGroup.rotation.set(-.08+right.spin+akReload*.18,-.18,.035+akReload*.24);
    if(akimboLeftLever)akimboLeftLever.rotation.x=Math.PI/2+left.lever;
    if(akimboRightLever)akimboRightLever.rotation.x=Math.PI/2+right.lever;
  }
  assaultGroup.position.set(THREE.MathUtils.lerp(.30,assaultPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.27,assaultPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.52,assaultPose.z,a)+kickZ+commonZ);assaultGroup.rotation.set(THREE.MathUtils.lerp(-.06,assaultPose.rx,a)+reloadCurve*.16+kickPitch,THREE.MathUtils.lerp(-.055,assaultPose.ry,a)-reloadCurve*.14+kickYaw,THREE.MathUtils.lerp(0,assaultPose.rz,a)-reloadRoll-swapRoll-deathRoll-mobilityRoll+kickRoll);
  umpGroup.position.set(THREE.MathUtils.lerp(.30,umpPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.27,umpPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.54,umpPose.z,a)+kickZ+commonZ);umpGroup.rotation.set(THREE.MathUtils.lerp(-.06,umpPose.rx,a)+reloadCurve*.16+kickPitch,THREE.MathUtils.lerp(-.05,umpPose.ry,a)-reloadCurve*.14+kickYaw,THREE.MathUtils.lerp(0,umpPose.rz,a)-reloadRoll-swapRoll-deathRoll-mobilityRoll+kickRoll);
  machineGunGroup.position.set(THREE.MathUtils.lerp(.30,machineGunPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.29,machineGunPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.55,machineGunPose.z,a)+kickZ+commonZ);machineGunGroup.rotation.set(THREE.MathUtils.lerp(-.06,machineGunPose.rx,a)+reloadCurve*.18+kickPitch,THREE.MathUtils.lerp(-.05,machineGunPose.ry,a)-reloadCurve*.15+kickYaw,THREE.MathUtils.lerp(0,machineGunPose.rz,a)-reloadRoll-swapRoll-deathRoll-mobilityRoll+kickRoll);
  shotgunGroup.position.set(THREE.MathUtils.lerp(.30,shotgunPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.28,shotgunPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.50,shotgunPose.z,a)+kickZ+commonZ);shotgunGroup.rotation.set(THREE.MathUtils.lerp(-.06,shotgunPose.rx,a)+reloadCurve*.14+kickPitch,THREE.MathUtils.lerp(-.05,shotgunPose.ry,a)-reloadCurve*.12+kickYaw,THREE.MathUtils.lerp(0,shotgunPose.rz,a)-reloadRoll*.8-swapRoll-deathRoll-mobilityRoll+kickRoll);
  semiShotgunGroup.position.set(THREE.MathUtils.lerp(.30,semiShotgunPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.28,semiShotgunPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.50,semiShotgunPose.z,a)+kickZ+commonZ);semiShotgunGroup.rotation.set(THREE.MathUtils.lerp(-.06,semiShotgunPose.rx,a)+reloadCurve*.14+kickPitch,THREE.MathUtils.lerp(-.05,semiShotgunPose.ry,a)-reloadCurve*.12+kickYaw,THREE.MathUtils.lerp(0,semiShotgunPose.rz,a)-reloadRoll*.8-swapRoll-deathRoll-mobilityRoll+kickRoll);
  const sniperPose=sniperAdsPose(),sniperCenter=sniperCenterAmount(),sniperEye=sniperEyeAmount();sniperGroup.position.set(THREE.MathUtils.lerp(.28,sniperPose.x,sniperCenter)+commonX*(1-sniperCenter),THREE.MathUtils.lerp(-.28,sniperPose.y,sniperCenter)+commonY*(1-sniperCenter),THREE.MathUtils.lerp(-.48,sniperPose.z,sniperEye)+kickZ+commonZ*(1-sniperCenter));sniperGroup.rotation.set(THREE.MathUtils.lerp(-.055,sniperPose.rx,sniperCenter)+reloadCurve*.10*(1-sniperCenter)+kickPitch,THREE.MathUtils.lerp(-.05,sniperPose.ry,sniperCenter)-reloadCurve*.12*(1-sniperCenter)+kickYaw,THREE.MathUtils.lerp(0,sniperPose.rz,sniperCenter)-reloadRoll*.65*(1-sniperCenter)-swapRoll*(1-sniperCenter)-deathRoll*(1-sniperCenter)-mobilityRoll*(1-sniperCenter)+kickRoll);
  grenadeLauncherGroup.position.set(THREE.MathUtils.lerp(.30,0,a)+commonX,THREE.MathUtils.lerp(-.28,-.20,a)+commonY,THREE.MathUtils.lerp(-.48,-.42,a)+kickZ+commonZ);grenadeLauncherGroup.rotation.set(THREE.MathUtils.lerp(-.06,0,a)+GRENADE_LAUNCH_PITCH+reloadCurve*.13+kickPitch,THREE.MathUtils.lerp(-.05,0,a)-reloadCurve*.12+kickYaw,-reloadRoll*.75-swapRoll-deathRoll-mobilityRoll+kickRoll);
  rpgGroup.position.set(THREE.MathUtils.lerp(.34,rpgPose.x,a)+ironCommonX,THREE.MathUtils.lerp(-.16,rpgPose.y,a)+ironCommonY,THREE.MathUtils.lerp(-.46,rpgPose.z,a)+kickZ+commonZ);rpgGroup.rotation.set(THREE.MathUtils.lerp(-.025,rpgPose.rx,a)+reloadCurve*.11+kickPitch,THREE.MathUtils.lerp(-.07,rpgPose.ry,a)-reloadCurve*.10+kickYaw,THREE.MathUtils.lerp(.015,rpgPose.rz,a)-reloadRoll*.6-swapRoll-deathRoll-mobilityRoll+kickRoll);
  // Mechanical cycling is separate from recoil: slide/bolt motion gives the shot
  // visible life without changing the sight/bullet ray.
  if(pistolGroup.userData.cyclePart)pistolGroup.userData.cyclePart.position.z=pistolGroup.userData.cycleBaseZ+pistolGroup.userData.cycleTravel*(currentWeapon==='pistol'?actionPulse:0);
  if(assaultGroup.userData.cyclePart)assaultGroup.userData.cyclePart.position.z=assaultGroup.userData.cycleBaseZ+assaultGroup.userData.cycleTravel*(currentWeapon==='assault'?actionPulse:0);
  if(umpGroup.userData.cyclePart)umpGroup.userData.cyclePart.position.z=umpGroup.userData.cycleBaseZ+umpGroup.userData.cycleTravel*(currentWeapon==='ump'?actionPulse:0);
  if(machineGunGroup.userData.cyclePart)machineGunGroup.userData.cyclePart.position.z=machineGunGroup.userData.cycleBaseZ+machineGunGroup.userData.cycleTravel*(currentWeapon==='machineGun'?actionPulse:0);
  if(semiShotgunGroup.userData.cyclePart)semiShotgunGroup.userData.cyclePart.position.z=semiShotgunGroup.userData.cycleBaseZ+semiShotgunGroup.userData.cycleTravel*(currentWeapon==='semiShotgun'?actionPulse:0);
  if(sniperGroup.userData.cyclePart)sniperGroup.userData.cyclePart.position.z=sniperGroup.userData.cycleBaseZ+sniperGroup.userData.cycleTravel*(currentWeapon==='sniper'?actionPulse:0);
  if(pistolMag)pistolMag.position.y=-.245-(reloading&&currentWeapon==='pistol'?Math.sin(Math.PI*THREE.MathUtils.clamp((reloadP-.18)/.62,0,1))*.20:0);
  if(assaultMag)assaultMag.position.y=-.19-(reloading&&currentWeapon==='assault'?Math.sin(Math.PI*THREE.MathUtils.clamp((reloadP-.15)/.68,0,1))*.28:0);
  if(umpMag)umpMag.position.y=-.20-(reloading&&currentWeapon==='ump'?Math.sin(Math.PI*THREE.MathUtils.clamp((reloadP-.15)/.68,0,1))*.26:0);
  if(machineGunBox){const mgReload=reloading&&currentWeapon==='machineGun'?Math.sin(Math.PI*THREE.MathUtils.clamp((reloadP-.12)/.74,0,1)):0;machineGunBox.position.y=-.19-mgReload*.30;machineGunBox.position.x=-.045-mgReload*.08;}
  if(semiShotgunMag)semiShotgunMag.position.y=-.14-(reloading&&currentWeapon==='semiShotgun'?Math.sin(Math.PI*THREE.MathUtils.clamp((reloadP-.15)/.68,0,1))*.22:0);
  if(sniperBolt)sniperBolt.position.z=-.06+(currentWeapon==='sniper'?actionPulse*.085:0)+(reloading&&currentWeapon==='sniper'?Math.sin(Math.PI*THREE.MathUtils.clamp((reloadP-.20)/.55,0,1))*.18:0);
  const traversalViewActive=!!traversePoseNow;sniperGroup.visible=!traversalViewActive&&currentWeapon==='sniper'&&!sniperWeaponHiddenForScope();shotgunGroup.visible=!traversalViewActive&&currentWeapon==='shotgun'&&!weaponHiddenForScope('shotgun');semiShotgunGroup.visible=!traversalViewActive&&currentWeapon==='semiShotgun';assaultGroup.visible=!traversalViewActive&&currentWeapon==='assault'&&!weaponHiddenForScope('assault');umpGroup.visible=!traversalViewActive&&currentWeapon==='ump'&&!weaponHiddenForScope('ump');machineGunGroup.visible=!traversalViewActive&&currentWeapon==='machineGun'&&!weaponHiddenForScope('machineGun');grenadeLauncherGroup.visible=!traversalViewActive&&currentWeapon==='grenadeLauncher';rpgGroup.visible=!traversalViewActive&&currentWeapon==='rpg'&&!weaponHiddenForScope('rpg');pistolGroup.visible=!traversalViewActive&&currentWeapon==='pistol';if(akimboLeftGroup)akimboLeftGroup.visible=!traversalViewActive&&currentWeapon==='akimbo1887';if(akimboRightGroup)akimboRightGroup.visible=!traversalViewActive&&currentWeapon==='akimbo1887';
  if(shotgunPump){
    let pumpOffset=reloading&&currentWeapon==='shotgun'?Math.sin(Math.PI*reloadP)*.10:0;
    if(shotgunPumpStartedAt){
      const elapsed=now-shotgunPumpStartedAt,p=Math.max(0,Math.min(1,(elapsed-150)/470));
      if(elapsed>=150){const travel=p<.44?THREE.MathUtils.smoothstep(p,0,.44):1-THREE.MathUtils.smoothstep(p,.44,1);pumpOffset=Math.max(pumpOffset,travel*.135);if(!shotgunPumpSoundPlayed&&p>=.42){shotgunPumpSoundPlayed=true;soundShotgunPump();}}
      if(p>=1){shotgunPumpStartedAt=0;shotgunPumpSoundPlayed=false;}
    }
    shotgunPump.position.z=-.48-pumpOffset;
  }
  updateFirstPersonHandRig(now,reloading,reloadP,traversalViewActive);
  if(mantleHands){
    mantleHands.visible=!!traversePoseNow;
    if(traversePoseNow){
      const reach=smoothstep01(Math.min(1,traverseP/.42)),pull=smoothstep01(Math.max(0,(traverseP-.42)/.58)),vault=traversal?.mode==='vault';
      // Hands rise from the lower corners and reach forward. No traversal
      // geometry is allowed closer than ~0.55 m to the eye, so camera pitch or
      // mantle motion cannot expose the inside of a forearm mesh.
      mantleHands.position.set(0,-.015+pull*.035,-.03-reach*.07+pull*.025);mantleHands.rotation.x=-.045-reach*.055+pull*.07;
      mantleHands.children.forEach((limb,i)=>{const side=limb.userData.side|| (i?1:-1),stagger=vault?(i?-.055:.035):0,wave=Math.sin(Math.PI*THREE.MathUtils.clamp(traverseP+stagger,0,1));limb.position.x=side*(.27-.025*reach);limb.position.y=-.34+.085*reach-.035*pull+(vault?side*.012*wave:0);limb.position.z=-.82-.10*reach+.055*pull;limb.rotation.x=(vault?side*.07:0)*wave;limb.rotation.z=side*(.06-.08*reach);});
    }
  }
  for(const flash of [pistolFlash,akimboLeftFlash,akimboRightFlash,assaultFlash,umpFlash,machineGunFlash,shotgunFlash,semiShotgunFlash,sniperFlash,grenadeLauncherFlash,rpgFlash])if(flash)flash.material.opacity=Math.max(0,flash.material.opacity-dt*20);
}
function normalizeAngle(a){while(a>Math.PI)a-=Math.PI*2;while(a<-Math.PI)a+=Math.PI*2;return a;}

function applyViewportSize(metrics=shell.viewport){
  const nextW=Math.max(1,Math.round(metrics?.w||1)),nextH=Math.max(1,Math.round(metrics?.h||1)),nextDpr=Math.max(.5,Math.min(4,Number(metrics?.dpr)||Number(devicePixelRatio)||1));
  const sizeChanged=nextW!==viewW||nextH!==viewH,dprChanged=Math.abs(nextDpr-viewDpr)>.001;
  viewW=nextW;viewH=nextH;viewDpr=nextDpr;
  if(!camera||!renderer)return;
  const aspect=viewW/viewH;
  camera.aspect=aspect;
  const maxHorizontalFov=104*Math.PI/180;
  const landscapeVFov=2*Math.atan(Math.tan(maxHorizontalFov/2)/Math.max(1,aspect))*180/Math.PI;
  baseFov=THREE.MathUtils.clamp(landscapeVFov,58,72);
  if(adsBlend<.01)camera.fov=baseFov;
  camera.updateProjectionMatrix();
  if(sizeChanged||dprChanged){
    const ratio=targetPixelRatio();if(Math.abs(renderer.getPixelRatio()-ratio)>.001)renderer.setPixelRatio(ratio);
    renderer.setSize(viewW,viewH,false);resizeHudOverlay();minimapStaticCache=null;scoreboardPanel=null;scoreboardDrag=null;hudLastDraw=0;
    if(isTouch)resetTouchInput();
  }
  hudLayout=computeHudLayout();
}

function onResize(metrics=shell.viewport){applyViewportSize(metrics);}

function initHudOverlay(){
  hudCanvas=typeof OffscreenCanvas==='function'?new OffscreenCanvas(2,2):document.createElement('canvas');
  hudScene=new THREE.Scene();hudCamera=new THREE.OrthographicCamera(-1,1,1,-1,0,2);
  hudMaterial=new THREE.MeshBasicMaterial({transparent:true,depthTest:false,depthWrite:false,toneMapped:false});
  const quad=new THREE.Mesh(new THREE.PlaneGeometry(2,2),hudMaterial);quad.position.z=-1;hudScene.add(quad);
  resizeHudOverlay();
}

function resizeHudOverlay(){
  if(!hudCanvas)return;
  const quality=playerSettings.graphics,hudMax=quality==='low'?1:(quality==='medium'?1.25:(isTouch?1.4:1.75));hudScale=Math.min(devicePixelRatio || 1,hudMax);
  const width=Math.max(2,Math.round(viewW*hudScale)),height=Math.max(2,Math.round(viewH*hudScale));
  // Uploaded texture dimensions are immutable. Replace the GPU resource when
  // viewport/DPR/quality changes, then bind it to the existing overlay material.
  if(!hudTexture||hudCanvas.width!==width||hudCanvas.height!==height){
    hudTexture?.dispose();hudCanvas.width=width;hudCanvas.height=height;
    hudTexture=new THREE.CanvasTexture(hudCanvas);hudTexture.colorSpace=THREE.SRGBColorSpace;hudTexture.minFilter=THREE.LinearFilter;hudTexture.magFilter=THREE.LinearFilter;hudTexture.generateMipmaps=false;
    hudMaterial.map=hudTexture;hudMaterial.needsUpdate=true;
  }
  // Rasterize the dynamic HUD on the CPU before its per-frame texture upload.
  // This avoids stale clears when Canvas2D and WebGL share an accelerated backing.
  hudCtx=hudCanvas.getContext('2d',{willReadFrequently:true});hudTexture.needsUpdate=true;hudLastDraw=0;
}

function safeInsets(){
  const cs=getComputedStyle(document.documentElement);const n=k=>parseFloat(cs.getPropertyValue(k))||0;
  return{top:n('--safe-top'),right:n('--safe-right'),bottom:n('--safe-bottom'),left:n('--safe-left')};
}

function computeHudLayout(){
  const safe=safeInsets(),landscape=viewW>viewH,compact=isTouch&&landscape&&viewH<=520,margin=compact?8:12;
  const contentLeft=safe.left+margin,contentRight=viewW-safe.right-margin,contentW=Math.max(180,contentRight-contentLeft);
  const desiredMap=compact?96:(isTouch?112:140),mapSize=Math.max(72,Math.min(desiredMap,contentW*.23));
  const menuW=isTouch?44:40,menuH=isTouch?44:34,chatW=menuW;
  const maxTeamSpace=Math.max(130,contentW-mapSize-20),desiredTeamW=compact?208:(isTouch?248:292),teamW=Math.min(desiredTeamW,maxTeamSpace),teamH=compact?32:36;
  const joyR=compact?54:(isTouch?62:0),fireR=compact?37:43,leftFireR=compact?32:37,aimR=compact?27:31,jumpR=compact?29:33,reloadR=compact?21:24,swapR=compact?23:26,modeR=swapR,equipR=compact?23:27,crouchR=compact?22:26;
  const bottom=safe.bottom+margin,ammoW=64,ammoH=16,baseKillW=compact?220:(isTouch?252:300),killH=compact?58:(isTouch?88:112);
  const mapX=contentRight-mapSize,mapY=safe.top+margin,teamY=mapY;
  const desiredTeamX=(viewW-teamW)/2,maxTeamX=mapX-teamW-8,minTeamX=contentLeft;
  const teamX=Math.max(minTeamX,Math.min(desiredTeamX,maxTeamX));
  const topKillSpace=teamX-contentLeft-8,killBelow=topKillSpace<118;
  const killX=contentLeft,killY=killBelow?teamY+teamH+7:mapY,killW=Math.max(96,Math.min(baseKillW,killBelow?mapX-contentLeft-8:topKillSpace));
  const controlsY=mapY+mapSize+6,menuX=mapX,chatX=mapX+mapSize-chatW;
  const moveBoundary=viewW*MOBILE_MOVE_ZONE_RATIO,defaultJoyX=safe.left+joyR+margin,defaultJoyY=viewH-bottom-joyR;
  // Restore the compact lower-left combat cluster: Fire on the upper row,
  // Tactical/Lethal directly beneath it at the bottom edge. The movement stick
  // remains dynamic and cannot spawn over these controls.
  const equipGap=compact?8:10,flashX=safe.left+margin+equipR,stickyX=flashX+equipR*2+equipGap;
  const equipRowY=viewH-bottom-equipR-(compact?4:6),flashY=equipRowY,stickyY=equipRowY;
  const leftFireX=(flashX+stickyX)/2,leftFireY=Math.max(safe.top+leftFireR+52,equipRowY-equipR-leftFireR-(compact?8:10));
  const fireX=viewW-safe.right-margin-fireR,fireY=viewH-bottom-fireR,reloadX=fireX-fireR-reloadR-9,reloadY=fireY,crouchX=reloadX-reloadR-crouchR-9,crouchY=fireY;
  const topRowY=fireY-fireR-Math.max(jumpR,swapR,aimR)-11,jumpX=crouchX,jumpY=topRowY,swapX=reloadX,swapY=topRowY,aimX=fireX,aimY=topRowY;
  const modeX=contentLeft+modeR,modeY=leftFireY-leftFireR-modeR-8,steadyX=leftFireX+leftFireR+modeR+(compact?8:10),steadyY=leftFireY;
  const touchControls=touchGameplayControlsVisible(),ammoX=touchControls?fireX-fireR-8-ammoW:contentRight-ammoW,ammoY=viewH-bottom-ammoH;
  // Reserve full-size touch slots while drawing only a small label at the bottom.
  // On narrow screens the row stays inside the corridor between combat controls.
  const streakW=KILLSTREAK_SELECTION_COUNT*44,streakH=44;
  const streakLeft=touchControls?stickyX+equipR+8:contentLeft,streakRight=touchControls?crouchX-crouchR-8:contentRight;
  const streakX=Math.max(streakLeft,Math.min((contentLeft+contentRight-streakW)/2,streakRight-streakW)),streakY=viewH-bottom-streakH;
  const streakSlots=Array.from({length:KILLSTREAK_SELECTION_COUNT},(_,index)=>({x:streakX+index*44,y:streakY,w:44,h:streakH}));
  const teamIndicatorY=teamY+teamH+8,announcerY=teamIndicatorY+(compact?24:28),noticeW=Math.max(118,Math.min(compact?190:240,contentW*.34)),noticeH=28;
  const noticeX=Math.max(contentLeft,Math.min((viewW-noticeW)/2,contentRight-noticeW)),noticeY=announcerY+(compact?30:36);
  const gapLeft=teamX+teamW+8,gapRight=mapX-8,gapW=gapRight-gapLeft,chatFallbackX=Math.max(contentLeft,Math.min(mapX-150,contentRight-150));
  const chatFeedX=gapW>=92?gapLeft:chatFallbackX,chatFeedRight=gapW>=92?gapRight:mapX-8,chatFeedW=Math.max(72,chatFeedRight-chatFeedX),chatFeedY=mapY+2,composerTop=chatOpen&&!chatComposer.classList.contains('hide')?chatComposer.getBoundingClientRect().top:Infinity;
  const chatOverlapsAmmo=chatFeedRight>ammoX&&chatFeedX<ammoX+ammoW,chatClosedBottom=mapY+mapSize,chatOpenBottom=Math.min(viewH-bottom-8,composerTop-6,chatOverlapsAmmo?ammoY-8:Infinity),chatFeedBottom=chatOpen?chatOpenBottom:chatClosedBottom,chatFeedH=Math.max(0,chatFeedBottom-chatFeedY);
  return{compact,safe,moveBoundary,
    map:{x:mapX,y:mapY,w:mapSize,h:mapSize},kill:{x:killX,y:killY,w:killW,h:killH},
    team:{x:teamX,y:teamY,w:teamW,h:teamH},teamIndicator:{x:teamX+teamW/2,y:teamIndicatorY},notice:{x:noticeX,y:noticeY,w:noticeW,h:noticeH},chatFeed:{x:chatFeedX,y:chatFeedY,w:chatFeedW,h:chatFeedH},announcer:{x:viewW/2,y:announcerY},
    chat:{x:chatX,y:controlsY,w:chatW,h:menuH},menu:{x:menuX,y:controlsY,w:menuW,h:menuH},streak:{x:streakX,y:streakY,w:streakW,h:streakH,slots:streakSlots},
    ammo:{x:ammoX,y:ammoY,w:ammoW,h:ammoH},joy:{x:defaultJoyX,y:defaultJoyY,r:joyR},
    leftFire:{x:leftFireX,y:leftFireY,r:leftFireR},crouch:{x:crouchX,y:crouchY,r:crouchR},flash:{x:flashX,y:flashY,r:equipR},sticky:{x:stickyX,y:stickyY,r:equipR},
    fire:{x:fireX,y:fireY,r:fireR},aim:{x:aimX,y:aimY,r:aimR},jump:{x:jumpX,y:jumpY,r:jumpR},reload:{x:reloadX,y:reloadY,r:reloadR},swap:{x:swapX,y:swapY,r:swapR},mode:{x:modeX,y:modeY,r:modeR},steady:{x:steadyX,y:steadyY,r:modeR},
    deathLoadout:{x:viewW/2-92,y:Math.min(viewH-safe.bottom-margin-34,viewH/2+(compact?60:70)),w:184,h:34}
  };
}
function drawNetworkDiagnostics(c,w,h){
  if(!diagnosticsRecordingEnabled())return;
  const lines=[
    `DIAG REC  ${Math.round((performance.now()-diagnosticsRecorder.startedAt)/1000)}s  INCIDENTS ${diagnosticsRecorder.incidents.length}`,
    `NET ${socket?.readyState===WebSocket.OPEN?'OPEN':'OFF'}  RTT ${Math.round(netDiag.rttMs)}  JIT ${Math.round(netDiag.rttJitterMs)}`,
    `STATE ${Math.round(netDiag.lastStateGapMs)}/${Math.round(netDiag.maxStateGapMs)}ms  SRV ${Math.round(netDiag.serverLastStateGapMs)}/${Math.round(netDiag.serverMaxStateGapMs)}ms`,
    `CORR ${netDiag.corrections}  MAX ${netDiag.maxCorrectionM.toFixed(2)}m  ${netDiag.lastCorrectionReason||'-'}`,
    `REJ ${netDiag.rejects}  ${netDiag.lastReject||'-'}`,
    `STALL ${netDiag.frameStalls}  MAX ${Math.round(netDiag.maxFrameMs)}ms  REC ${netDiag.reconnects}`
  ];
  c.save();c.font='700 9px ui-monospace,monospace';const pad=6,lineH=12,panelW=Math.min(360,Math.max(...lines.map(line=>c.measureText(line).width))+pad*2),panelH=lines.length*lineH+pad*2;c.fillStyle='rgba(0,0,0,.72)';c.fillRect(7,7,panelW,panelH);c.strokeStyle='rgba(215,255,88,.45)';c.strokeRect(7.5,7.5,panelW-1,panelH-1);c.fillStyle='#e8f0f4';c.textAlign='left';c.textBaseline='top';lines.forEach((line,i)=>c.fillText(line,7+pad,7+pad+i*lineH));c.restore();
}
function combatOverviewVisible(scopeAmount=activeScopeMaskAmount()){return scopeAmount<.82;}
function drawKillstreakPanel(c,r){
  if(!r)return;
  const equipped=normalizeKillstreakSelection(killstreakSelection);
  c.save();c.textAlign='center';c.textBaseline='middle';c.font='800 11px system-ui';c.shadowColor='rgba(0,0,0,.85)';c.shadowBlur=3;
  equipped.forEach((kind,index)=>{
    const slot=r.slots[index],ready=killstreakStatus.available.includes(kind),selected=ready&&killstreakSelected===kind;
    const label=kind==='lightning'?'LGT':kind==='asteroids'?'AST':kind==='earthquake'?'EQ':kind==='solarnuke'?'NUKE':KILLSTREAK_SPECS[kind].short;
    const x=slot.x+slot.w/2,bottom=slot.y+slot.h;
    c.fillStyle=ready?HUD_ACCENT:'#8c99a3';c.fillText(label,x,bottom-10);
    if(selected){c.fillStyle=HUD_ACCENT;c.fillRect(x-10,bottom-3,20,2);}
  });
  c.restore();
}
function drawKillstreakTargetingPlayers(c,r){
  const limit=minimapWorldLimit(),toX=x=>r.x+(x/limit+1)*.5*r.w,toY=z=>r.y+(z/limit+1)*.5*r.h,teamBased=currentModeSpec().teamBased,now=performance.now(),pulse=.5+.5*Math.sin(now*.008),targetRadius=Math.max(4,Number(KILLSTREAK_SPECS[killstreakTargeting?.kind]?.targetRadius)||11),inside=[];
  for(const rmt of remotes.values()){
    if((Number(rmt.hp)||0)<=0)continue;const friendly=teamBased&&modeFriendly(rmt.team),enemy=!friendly,x=toX(rmt.group.position.x),y=toY(rmt.group.position.z),distance=Math.hypot(rmt.group.position.x-killstreakTargeting.x,rmt.group.position.z-killstreakTargeting.z);if(enemy&&distance<=targetRadius)inside.push(rmt);
    c.save();c.translate(x,y);if(enemy){c.rotate(Math.PI/4);c.fillStyle='#ff493f';c.fillRect(-4.8,-4.8,9.6,9.6);c.strokeStyle=`rgba(255,230,220,${.72+.28*pulse})`;c.lineWidth=1.4;c.strokeRect(-6.2,-6.2,12.4,12.4);}else{c.beginPath();c.moveTo(0,-5.8);c.lineTo(4.6,4.6);c.lineTo(0,2.7);c.lineTo(-4.6,4.6);c.closePath();c.fillStyle='#58b8ff';c.fill();c.strokeStyle='#dff4ff';c.lineWidth=1;c.stroke();}c.restore();
  }
  if(position){const x=toX(position.x),y=toY(position.z);c.save();c.translate(x,y);c.rotate(-yaw);c.beginPath();c.moveTo(0,-6.6);c.lineTo(5,5.2);c.lineTo(0,3);c.lineTo(-5,5.2);c.closePath();c.fillStyle='#ffffff';c.fill();c.strokeStyle='#77d7ff';c.lineWidth=1.3;c.stroke();c.restore();}
  return inside.length;
}
function drawKillstreakTargeting(c,w,h){
  if(!killstreakTargeting)return;const spec=KILLSTREAK_SPECS.asteroids,pad=Math.max(14,Math.min(46,w*.045)),header=72,footer=78,size=Math.max(180,Math.min(w-pad*2,h-header-footer-18,660)),x=(w-size)/2,y=Math.max(header,(h-size)/2-12),staticMap=getMinimapStatic(768,768,currentMapId),accent='#ff6f45',accentSoft='rgba(255,210,180,.88)';killstreakTargetRect={x,y,w:size,h:size};
  c.save();c.fillStyle='rgba(0,0,0,.88)';c.fillRect(0,0,w,h);roundRect(c,x-9,y-9,size+18,size+18,10,'rgba(8,12,15,.97)',accentSoft);c.drawImage(staticMap,x,y,size,size);c.fillStyle='rgba(255,64,30,.055)';c.fillRect(x,y,size,size);c.strokeStyle=accentSoft;c.lineWidth=2;c.strokeRect(x,y,size,size);
  const scanY=y+(performance.now()*.065%(size+36))-18,scan=c.createLinearGradient(0,scanY-10,0,scanY+10);scan.addColorStop(0,'rgba(255,255,255,0)');scan.addColorStop(.5,'rgba(255,140,80,.14)');scan.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=scan;c.fillRect(x,scanY-10,size,20);
  const enemiesInZone=drawKillstreakTargetingPlayers(c,killstreakTargetRect),limit=minimapWorldLimit(),tx=x+(killstreakTargeting.x/limit+1)*.5*size,ty=y+(killstreakTargeting.z/limit+1)*.5*size,targetRadius=Math.max(4,Number(spec.targetRadius)||11),scatter=targetRadius/(limit*2)*size;c.strokeStyle=accent;c.lineWidth=2.4;c.beginPath();c.arc(tx,ty,Math.max(12,scatter),0,Math.PI*2);c.stroke();c.strokeStyle=accentSoft;c.lineWidth=1.2;c.beginPath();c.arc(tx,ty,Math.max(17,scatter+6),0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(tx-12,ty);c.lineTo(tx+12,ty);c.moveTo(tx,ty-12);c.lineTo(tx,ty+12);c.stroke();
  c.textAlign='center';c.fillStyle='#fff';c.font='1000 20px system-ui';c.fillText(spec.name,w/2,29);c.fillStyle=enemiesInZone?'#ff7d59':'#aeb8bf';c.font='1000 11px system-ui';c.fillText(`${enemiesInZone} ${enemiesInZone===1?'ENEMY':'ENEMIES'} IN STRIKE ZONE`,w/2,49);
  c.textAlign='left';c.font='900 9px system-ui';c.fillStyle='#ff6b58';c.fillText('◆ ENEMY',x,y+size+18);c.fillStyle='#68c3ff';c.fillText('▲ FRIENDLY',x+72,y+size+18);c.fillStyle='#fff';c.fillText('▲ YOU',x+162,y+size+18);
  const buttonY=h-48,buttonH=30,buttonW=Math.min(126,Math.max(96,w*.14)),gap=10;killstreakTargetCancelRect={x:w/2-buttonW-gap/2,y:buttonY,w:buttonW,h:buttonH};killstreakTargetConfirmRect={x:w/2+gap/2,y:buttonY,w:buttonW,h:buttonH};roundRect(c,killstreakTargetCancelRect.x,buttonY,buttonW,buttonH,7,'rgba(18,24,29,.96)','rgba(180,191,199,.55)');c.textAlign='center';c.fillStyle='#d7dde1';c.font='1000 10px system-ui';c.fillText(controllerInputActive()?(killstreakTargeting.chosen?'B  EDIT':'B  CANCEL'):'CANCEL',killstreakTargetCancelRect.x+buttonW/2,buttonY+buttonH/2);roundRect(c,killstreakTargetConfirmRect.x,buttonY,buttonW,buttonH,7,killstreakTargeting.chosen?'rgba(215,255,88,.96)':'rgba(70,78,82,.78)',killstreakTargeting.chosen?'rgba(232,255,160,.9)':'rgba(130,140,145,.5)');c.fillStyle=killstreakTargeting.chosen?'#081005':'#a3adb2';c.fillText(controllerInputActive()?(killstreakTargeting.chosen?'A  DEPLOY':'A  SELECT'):'DEPLOY',killstreakTargetConfirmRect.x+buttonW/2,buttonY+buttonH/2);
  c.fillStyle='#b9c2c7';c.font='850 9px system-ui';const hint=controllerInputActive()?(killstreakTargeting.chosen?'TARGET LOCKED · A DEPLOY · B EDIT':'LS MOVE TARGET · A SELECT · B CANCEL'):isTouch?'TAP MAP TO CHOOSE · THEN TAP DEPLOY':'CLICK MAP TO CHOOSE · ENTER OR DEPLOY TO CONFIRM';c.fillText(hint,w/2,buttonY-9);c.restore();
}

function drawHud(now){
  const scopeAmount=activeScopeMaskAmount(),scoped=scopeAmount>.002,scopeAnimating=scoped&&scopeAmount<.998,hudInterval=scopeAnimating?16:(touchGameplayControlsVisible()?33:16),scopeStateChanged=scoped!==hudLastScopeActive;
  if(!scopeStateChanged&&!scopeAnimating&&now-hudLastDraw<hudInterval)return;hudLastDraw=now;hudLastScopeActive=scoped;if(!hudLayout)hudLayout=computeHudLayout();
  const c=hudCtx,s=hudScale,w=viewW,h=viewH,L=hudLayout,toast=activeToast(now);
  c.setTransform(s,0,0,s,0,0);c.clearRect(0,0,w,h);c.textBaseline='middle';if(replayPlayback){drawReplayHud(c,w,h);hudTexture.needsUpdate=true;return;}if(replayPending?.kind==='final'){drawReplayPendingHud(c,w,h);hudTexture.needsUpdate=true;return;}drawKillstreakEnvironmentOverlay(c,w,h,now);
  if(now<flashUntil){const a=now<flashPeakUntil?1:Math.max(0,(flashUntil-now)/Math.max(1,flashUntil-flashPeakUntil));c.fillStyle=`rgba(255,255,255,${Math.min(.96,a*.92)})`;c.fillRect(0,0,w,h);}c.lineCap='round';c.lineJoin='round';
  const missingHealth=Math.max(0,Math.min(1,(100-hp)/100)),hurtPulse=now<hurtUntil?Math.max(0,(hurtUntil-now)/700):0,damageAlpha=Math.min(.82,missingHealth*.58+hurtPulse*.38);
  if(damageAlpha>.01){const g=c.createRadialGradient(w/2,h/2,Math.min(w,h)*.10,w/2,h/2,Math.max(w,h)*.72);g.addColorStop(0,'rgba(255,18,40,0)');g.addColorStop(.58,`rgba(255,18,40,${damageAlpha*.12})`);g.addColorStop(.82,`rgba(185,0,22,${damageAlpha*.42})`);g.addColorStop(1,`rgba(125,0,16,${damageAlpha})`);c.fillStyle=g;c.fillRect(0,0,w,h);}
  drawBloodSplatter(c,w,h,now,missingHealth);
  if(scoreboardOpen){drawScoreboard(c,L);drawNetworkDiagnostics(c,w,h);hudTexture.needsUpdate=true;return;}
  if(!matchAllowsMovement(matchState)){drawMatchStatus(c,w,h);drawScoreboardButton(c,L.team);if(matchState.status!==MATCH_STATUS.ENDED)drawMenuButton(c,L.menu);drawNetworkDiagnostics(c,w,h);hudTexture.needsUpdate=true;return;}
  if(hp<=0){drawDeathScreen(c,L,w,h,now);drawNetworkDiagnostics(c,w,h);hudTexture.needsUpdate=true;return;}
  if(combatOverviewVisible(scopeAmount)){drawKillFeed(c,L.kill,now);drawMiniMap(c,L.map);drawTeamBar(c,L.team);drawTeamIndicator(c,L.teamIndicator);drawKillstreakPanel(c,L.streak);}if(scoped){drawScopeMask(c,w,h,scopeAmount);drawThermalOptic(c,w,h,thermalOpticAmount());}
  drawMenuButton(c,L.menu);drawAmmo(c,L.ammo);
  drawDamageIndicators(c,w,h,now);drawChatFeed(c,L,w,h,now);if(isTouch)drawChatButton(c,L.chat);if(chatOpen)activeAnnouncer(now);else drawAnnouncer(c,L,now);
  if(touchGameplayControlsVisible())drawTouchControls(c,L,now);if(killConfirmUntil>now)drawKillConfirm(c,w,h,now);
  if(toast){c.font='800 11px system-ui';const toastLabel=clipHudText(c,toast.text,Math.max(70,L.notice.w-20)),tw=Math.min(L.notice.w,c.measureText(toastLabel).width+24),tx=L.notice.x+(L.notice.w-tw)/2,ty=L.notice.y;roundRect(c,tx,ty,tw,L.notice.h,8,HUD_SURFACE,HUD_LINE);c.fillStyle='#fff';c.textAlign='center';c.fillText(toastLabel,tx+tw/2,ty+L.notice.h/2);}
  const hitActive=now<hitUntil,headshotHit=now<headshotUntil,scopeReticle=activeScopeReticleAmount();if(scopeReticle>.002){drawScopeReticle(c,w,h,hitActive,headshotHit,scopeReticle);drawSniperBreathMeter(c,w,h);}else drawWeaponCrosshair(c,w/2,h/2,currentWeapon,hitActive,adsBlend,headshotHit);if(hitActive)drawHitConfirm(c,w/2,h/2,headshotHit);
  if(killstreakTargeting)drawKillstreakTargeting(c,w,h);drawNetworkDiagnostics(c,w,h);hudTexture.needsUpdate=true;
}
function drawDeathScreen(c,L,w,h,now){
  c.fillStyle='rgba(24,3,8,.60)';c.fillRect(0,0,w,h);drawTeamBar(c,L.team);drawMiniMap(c,L.map);drawMenuButton(c,L.menu);
  const coop=!!currentModeSpec().cooperative,total=Math.max(500,Number(worldSettings.combat.respawnMs)||3000),remain=Math.max(0,wastedUntil-serverNow()),progress=Math.max(0,Math.min(1,1-remain/total));
  const panelW=Math.min(430,w-32),panelH=L.compact?138:154,x=(w-panelW)/2,y=Math.max(L.safe.top+8,(h-panelH)/2-20),cx=w/2;
  roundRect(c,x,y,panelW,panelH,12,'rgba(11,10,13,.94)','rgba(255,91,112,.26)');c.fillStyle='#ff5367';c.fillRect(x,y,3,panelH);
  c.textAlign='center';c.fillStyle='#ff6676';c.font=`1000 ${L.compact?27:34}px system-ui`;c.fillText('ELIMINATED',cx,y+(L.compact?25:29));
  if(lastWastedBy){c.fillStyle='#fff';c.font='1000 13px system-ui';c.fillText(clipHudText(c,lastWastedBy,Math.max(120,panelW-42)),cx,y+(L.compact?49:55));}
  const details=[];if(lastWastedWeapon)details.push(weaponLabel(lastWastedWeapon));if(lastWastedHeadshot)details.push('HEADSHOT');if(lastWastedDistance>=1)details.push(`${lastWastedDistance.toFixed(1)} m`);c.fillStyle=lastWastedHeadshot?'#ffd36d':'#b9c4cb';c.font='850 10px system-ui';c.fillText(clipHudText(c,details.join(' · '),Math.max(120,panelW-38)),cx,y+(L.compact?67:74));
  const classId=pendingClassId||activeClassId,classInfo=loadoutClassById(loadoutClasses,classId,selectedLoadout()),showNextClass=!!pendingLoadout||!!pendingClassId&&pendingClassId!==activeClassId;if(showNextClass){c.fillStyle='#8e9aa3';c.font='850 10px system-ui';c.fillText(`NEXT SPAWN · ${String(classInfo?.name||'CLASS').toUpperCase()}`,cx,y+(L.compact?86:94));}
  const barX=x+24,barW=panelW-48,barY=y+(L.compact?101:110);roundRect(c,barX,barY,barW,4,2,'rgba(255,255,255,.10)');if(!coop&&progress>0)roundRect(c,barX,barY,barW*progress,4,2,'#ff5367');
  c.fillStyle='#dce3e7';c.font='900 10px system-ui';c.fillText(coop?'RETURNING NEXT WAVE':remain>120?`RESPAWN ${Math.max(1,Math.ceil(remain/1000))}`:'RESPAWNING',cx,barY+16);
  const b=L.deathLoadout;roundRect(c,b.x,b.y,b.w,b.h,8,'rgba(13,18,22,.94)','rgba(255,255,255,.18)');c.fillStyle='#fff';c.font='900 11px system-ui';c.fillText(`${isTouch?'TAP':controllerInputActive()?'Y':'L'} · CHANGE LOADOUT`,cx,b.y+b.h/2);
}

function drawFinalStandings(c,w,h,returnIn,title,accent){
  const L=hudLayout||computeHudLayout(),rows=allCombatStats(),panelW=Math.min(570,w-L.safe.left-L.safe.right-26),rowH=L.compact?22:25,headH=L.compact?67:76,maxRows=Math.max(3,Math.min(7,Math.floor((h-L.safe.top-L.safe.bottom-headH-40)/rowH))),visible=rows.slice(0,maxRows),panelH=headH+visible.length*rowH+32,x=(w-panelW)/2,y=Math.max(L.safe.top+8,(h-panelH)/2);
  c.save();c.fillStyle='rgba(2,4,6,.70)';c.fillRect(0,0,w,h);roundRect(c,x,y,panelW,panelH,13,'rgba(8,12,15,.97)','rgba(255,255,255,.17)');c.fillStyle=accent;c.fillRect(x,y,3,panelH);
  c.textAlign='left';c.fillStyle=accent;c.font=`1000 ${L.compact?18:22}px system-ui`;c.fillText(title,x+16,y+22);c.fillStyle='#fff';c.font='1000 12px system-ui';c.fillText('FINAL STANDINGS',x+16,y+(L.compact?45:50));
  const spec=currentModeSpec();if(spec.cooperative){c.textAlign='right';c.font='900 11px system-ui';c.fillStyle='#aab6be';c.fillText(`${matchState.wavesCleared} WAVES CLEARED`,x+panelW-16,y+23);}else if(spec.teamBased){const t=teamScores();c.textAlign='right';c.font='1000 13px system-ui';c.fillStyle=factionColor('blue');c.fillText(`ALPHA ${t.blue}`,x+panelW-78,y+23);c.fillStyle=factionColor('red');c.fillText(`${t.red} BRAVO`,x+panelW-16,y+23);}else{c.textAlign='right';c.fillStyle='#aab6be';c.font='850 10px system-ui';c.fillText(spec.short||'MATCH',x+panelW-16,y+23);}
  const nameX=x+16,kX=x+panelW-108,dX=x+panelW-65,kdX=x+panelW-16,headerY=y+headH-11;c.fillStyle='#75818a';c.font='900 9px system-ui';c.textAlign='right';c.fillText('K',kX,headerY);c.fillText('D',dX,headerY);c.fillText('K/D',kdX,headerY);
  let ry=y+headH;for(const p of visible){const self=p.id===clientId;if(self)roundRect(c,x+8,ry,panelW-16,rowH-1,5,'rgba(215,255,88,.08)');c.fillStyle=self?HUD_ACCENT:(spec.teamBased?factionColor(p.team):'#ff6973');c.fillRect(x+9,ry+5,3,rowH-10);c.textAlign='left';c.fillStyle=self?'#fff':'#d8e1e7';c.font=`${self?'1000':'850'} 11px system-ui`;c.fillText(clipHudText(c,`${p.bot?'[BOT] ':''}${p.name}`,Math.max(60,kX-nameX-14)),nameX,ry+rowH/2);c.textAlign='right';c.fillStyle='#fff';c.fillText(String(p.kills),kX,ry+rowH/2);c.fillStyle='#b8c3ca';c.fillText(String(p.deaths),dX,ry+rowH/2);c.fillText(p.deaths?(p.kills/p.deaths).toFixed(2):p.kills?String(p.kills):'0.00',kdX,ry+rowH/2);ry+=rowH;}
  c.textAlign='center';c.fillStyle='#7f8b94';c.font='850 10px system-ui';const hidden=Math.max(0,rows.length-visible.length),footer=`${hidden?`+${hidden} MORE · `:''}${returnIn>0?`LOBBY IN ${returnIn}s`:'RETURNING TO LOBBY'}`;c.fillText(footer,w/2,y+panelH-15);c.restore();
}

function drawMatchStatus(c,w,h){
  if(matchAllowsMovement(matchState))return;
  if(matchState.status==='ended'){
    const spec=currentModeSpec(),teamMode=spec.teamBased,winner=String(matchState.winner||''),isDraw=winner==='draw'||(!winner&&!matchState.winnerId),won=teamMode?winner===myTeam:samePlayerId(matchState.winnerId,clientId),title=spec.cooperative?'OVERRUN':isDraw?'DRAW':won?'VICTORY':'DEFEAT',accent=isDraw?HUD_ACCENT:won?'#8ff0a9':'#ff6973',endedAt=Number(matchState.endedAt)||serverNow(),elapsed=Math.max(0,serverNow()-endedAt),returnIn=Math.max(0,Math.ceil(((Number(matchState.restartAt)||serverNow())-serverNow())/1000));
    if(elapsed>=1900){drawFinalStandings(c,w,h,returnIn,title,accent);return;}
    const panelW=Math.min(470,w-30),panelH=Math.min(185,h-30),x=(w-panelW)/2,y=Math.max(15,(h-panelH)/2-6),reason=spec.cooperative?`${matchState.wavesCleared} WAVES CLEARED`:matchState.reason==='score'?'SCORE LIMIT':matchState.reason==='time'?'TIME LIMIT':'MATCH COMPLETE';
    c.save();c.fillStyle='rgba(2,4,6,.66)';c.fillRect(0,0,w,h);roundRect(c,x,y,panelW,panelH,14,'rgba(8,12,15,.96)','rgba(255,255,255,.18)');c.fillStyle=accent;c.fillRect(x,y,3,panelH);c.textAlign='center';c.fillStyle=accent;c.font=`1000 ${Math.max(30,Math.min(44,h*.095))}px system-ui`;c.fillText(title,w/2,y+49);
    c.fillStyle='#fff';c.font='900 14px system-ui';if(spec.cooperative){c.fillText(`WAVE ${matchState.wave} · ${matchState.blueScore} ZOMBIES ELIMINATED`,w/2,y+88);}else if(teamMode){const t=teamScores();c.fillText(`${t.blue}  ALPHA   ·   BRAVO  ${t.red}`,w/2,y+88);}else c.fillText(matchState.winnerName?`${String(matchState.winnerName).toUpperCase()} WINS`:'MATCH COMPLETE',w/2,y+88);
    c.fillStyle='#c4ced5';c.font='800 12px system-ui';c.fillText(`YOU  ${myStats.kills||0} K  ·  ${myStats.deaths||0} D  ·  ${(myStats.deaths?(myStats.kills/myStats.deaths):myStats.kills||0).toFixed(2)} K/D`,w/2,y+121);c.fillStyle=HUD_MUTED;c.font='800 10px system-ui';c.fillText(reason,w/2,y+147);c.restore();return;
  }
  const warm=matchState.status==='warmup',remain=warm?Math.max(0,matchState.warmupEndsAt-serverNow()):0,count=warm?Math.max(1,Math.ceil(remain/1000)):0,text=warm?String(count):'WAITING FOR MATCH';
  const pw=Math.min(320,w-30),ph=warm?72:58,x=(w-pw)/2,y=h*.29;c.save();roundRect(c,x,y,pw,ph,12,'rgba(6,9,12,.84)','rgba(255,255,255,.16)');c.textAlign='center';c.fillStyle=warm?HUD_ACCENT:'#fff';c.font=`1000 ${warm?42:22}px system-ui`;c.fillText(text,w/2,y+(warm?34:35));if(warm){c.fillStyle='#fff';c.font='900 11px system-ui';c.fillText('GET READY',w/2,y+58);}c.restore();
}
function allCombatStats(){
  const rows=[{id:clientId,name:myName||safeName(),team:myTeam,bot:false,godMode,kills:myStats.kills||0,deaths:myStats.deaths||0}];
  for(const r of remotes.values()){if(currentModeSpec().cooperative&&r.bot)continue;rows.push({id:r.id,name:r.name,team:r.team,bot:r.bot,godMode:!!r.godMode,kills:r.kills||0,deaths:r.deaths||0});}
  return rows.sort((a,b)=>currentModeSpec().teamBased?(a.team.localeCompare(b.team)||(b.kills-a.kills)||(a.deaths-b.deaths)||a.name.localeCompare(b.name)):((b.kills-a.kills)||(a.deaths-b.deaths)||a.name.localeCompare(b.name)));
}
function teamScores(){return{blue:Math.max(0,Number(matchState.blueScore)||0),red:Math.max(0,Number(matchState.redScore)||0)};}
function drawTeamBar(c,r){
  const spec=currentModeSpec(),mid=r.x+r.w/2,clock=matchClockText();roundRect(c,r.x,r.y,r.w,r.h,8,HUD_SURFACE,HUD_LINE);c.textBaseline='middle';
  if(spec.cooperative){
    c.textAlign='left';c.font='900 11px system-ui';c.fillStyle='#99d5a4';c.fillText(`WAVE ${matchState.wave||1}`,r.x+10,r.y+r.h/2);
    c.textAlign='center';c.fillStyle='#fff';c.fillText(matchState.nextWaveAt?clock:matchState.status==='warmup'?clock:'SURVIVE',mid,r.y+r.h/2);
    c.textAlign='right';c.fillStyle='#ff9ca4';c.fillText(`${matchState.waveRemaining} LEFT`,r.x+r.w-10,r.y+r.h/2);return;
  }
  if(spec.scoreType==='player'){
    const rows=allCombatStats(),leader=rows[0];c.fillStyle=HUD_ACCENT;c.fillRect(r.x,r.y,3,r.h);c.fillStyle=relationshipColor(RELATIONSHIP.ENEMY);c.fillRect(r.x+r.w-3,r.y,3,r.h);
    c.textAlign='left';c.font=`900 ${r.h<=32?10:11}px system-ui`;c.fillStyle='#dfe8ee';c.fillText('YOU',r.x+10,r.y+r.h/2);c.font=`1000 ${r.h<=32?14:16}px system-ui`;c.fillStyle='#fff';c.fillText(String(myStats.kills||0),r.x+37,r.y+r.h/2);
    c.textAlign='center';c.font='1000 11px system-ui';c.fillStyle=matchState.status==='ended'?HUD_ACCENT:'#dbe4ea';c.fillText(clock,mid,r.y+r.h/2);
    c.textAlign='right';c.font=`1000 ${r.h<=32?14:16}px system-ui`;c.fillStyle='#fff';c.fillText(String(leader?.kills||0),r.x+r.w-37,r.y+r.h/2);c.font=`900 ${r.h<=32?10:11}px system-ui`;c.fillStyle='#ff9ca4';c.fillText('LEAD',r.x+r.w-10,r.y+r.h/2);return;
  }
  const rows=allCombatStats(),bluePlayers=rows.filter(p=>p.team==='blue').length,redPlayers=rows.filter(p=>p.team==='red').length,t=teamScores();c.fillStyle=factionColor('blue');c.fillRect(r.x,r.y,3,r.h);c.fillStyle=factionColor('red');c.fillRect(r.x+r.w-3,r.y,3,r.h);
  c.textAlign='left';c.font=`900 ${r.h<=32?10:11}px system-ui`;c.fillStyle=factionColor('blue');c.fillText('ALPHA',r.x+10,r.y+r.h/2);c.textAlign='right';c.font=`1000 ${r.h<=32?14:16}px system-ui`;c.fillStyle='#fff';c.fillText(String(spec.scoreType==='none'?bluePlayers:t.blue),mid-40,r.y+r.h/2);
  c.textAlign='center';c.font='1000 11px system-ui';c.fillStyle=matchState.status==='ended'?HUD_ACCENT:'#dbe4ea';c.fillText(clock,mid,r.y+r.h/2);
  c.textAlign='left';c.font=`1000 ${r.h<=32?14:16}px system-ui`;c.fillStyle='#fff';c.fillText(String(spec.scoreType==='none'?redPlayers:t.red),mid+40,r.y+r.h/2);c.textAlign='right';c.font=`900 ${r.h<=32?10:11}px system-ui`;c.fillStyle=factionColor('red');c.fillText('BRAVO',r.x+r.w-10,r.y+r.h/2);
}
function drawTeamIndicator(c,p){if(!p||!currentModeSpec().teamBased)return;const team=normalizeTeam(myTeam),color=factionColor(team),label=currentModeSpec().cooperative?'SURVIVOR':teamLabel(team);c.save();c.textAlign='center';c.textBaseline='middle';c.font='900 9px system-ui';c.shadowColor='rgba(0,0,0,.86)';c.shadowBlur=3;c.fillStyle=color;c.globalAlpha=.88;c.fillText(`◆ ${label}`,p.x,p.y);c.restore();}
function drawScoreboardButton(c,r){roundRect(c,r.x,r.y,r.w,r.h,8,HUD_SURFACE,HUD_LINE);c.textAlign='center';c.fillStyle='#e7eef2';c.font=`1000 ${r.h<=32?10:11}px system-ui`;c.fillText('SCOREBOARD',r.x+r.w/2,r.y+r.h/2);}
function toggleScoreboard(){if(!shell.canPlay)return;scoreboardOpen=!scoreboardOpen;scoreboardDrag=null;if(scoreboardOpen){scoreboardScroll=0;keys.clear();resetTouchInput();clearFireInput();cancelEquipmentAction();joy.x=joy.y=0;}}
function drawScoreboard(c,L){
  const rows=allCombatStats(),w=Math.min(viewW-L.safe.left-L.safe.right-28,L.compact?500:620),rowH=L.compact?24:27,headH=43,maxH=viewH-L.safe.top-L.safe.bottom-34;
  const visibleH=Math.min(maxH,Math.max(150,headH+Math.min(rows.length,7)*rowH+14)),x=(viewW-w)/2,y=Math.max(L.safe.top+L.team.h+15,(viewH-visibleH)/2);
  const bodyTop=y+headH,bodyH=visibleH-headH-9,contentH=rows.length*rowH,maxScroll=Math.max(0,contentH-bodyH);
  scoreboardScroll=Math.max(0,Math.min(maxScroll,scoreboardScroll));scoreboardPanel={x,y,w,h:visibleH,maxScroll,close:{x:x+w-78,y:y+5,w:68,h:28}};
  c.fillStyle='rgba(0,0,0,.44)';c.fillRect(0,0,viewW,viewH);roundRect(c,x,y,w,visibleH,12,'rgba(9,11,13,.97)','rgba(255,255,255,.18)');
  c.textAlign='left';c.fillStyle='#fff';c.font='1000 13px system-ui';c.fillText('SCOREBOARD',x+14,y+17);c.fillStyle='#737e87';c.font='900 10px system-ui';if(maxScroll)c.fillText(`${controllerInputActive()?'RIGHT STICK':touchGameplayControlsVisible()?'DRAG':'WHEEL'} TO SCROLL`,x+108,y+17);
  roundRect(c,x+w-76,y+6,64,25,7,'rgba(255,255,255,.08)','rgba(255,255,255,.14)');c.fillStyle='#fff';c.font='1000 10px system-ui';c.textAlign='center';c.fillText('CANCEL',x+w-44,y+18.5);
  const nameX=x+14,kX=x+w-112,dX=x+w-67,kdX=x+w-18;c.fillStyle='#737e87';c.font='900 10px system-ui';c.textAlign='right';c.fillText('K',kX,y+35);c.fillText('D',dX,y+35);c.fillText('K/D',kdX,y+35);
  c.save();c.beginPath();c.rect(x+7,bodyTop,w-14,bodyH);c.clip();let ry=bodyTop-scoreboardScroll;
  for(const p of rows){if(ry+rowH>=bodyTop&&ry<=bodyTop+bodyH){const self=p.id===clientId;if(self){c.fillStyle='rgba(255,255,255,.06)';c.fillRect(x+7,ry,w-14,rowH-1);}c.fillStyle=p.id===clientId?HUD_ACCENT:(currentModeSpec().teamBased?factionColor(p.team):relationshipColor(RELATIONSHIP.ENEMY));c.fillRect(x+8,ry+5,3,rowH-10);c.textAlign='left';c.font=`${self?'1000':'850'} 11px system-ui`;c.fillStyle=self?'#fff':'#d6e0e8';const playerLabel=`${p.godMode?'◆ ':''}${p.bot?'[BOT] ':''}${p.name}`,playerNameBudget=Math.max(60,kX-nameX-14);c.fillText(clipHudText(c,playerLabel,playerNameBudget),nameX,ry+rowH/2);c.textAlign='right';c.fillStyle='#fff';c.fillText(String(p.kills),kX,ry+rowH/2);c.fillStyle='#b9c5cf';c.fillText(String(p.deaths),dX,ry+rowH/2);c.fillText(p.deaths?(p.kills/p.deaths).toFixed(2):p.kills?String(p.kills):'0.00',kdX,ry+rowH/2);}ry+=rowH;}c.restore();
  if(maxScroll>0){const trackY=bodyTop+3,trackH=bodyH-6,thumbH=Math.max(24,trackH*(bodyH/contentH)),thumbY=trackY+(trackH-thumbH)*(scoreboardScroll/maxScroll);roundRect(c,x+w-6,trackY,2,trackH,1,'rgba(255,255,255,.08)');roundRect(c,x+w-7,thumbY,4,thumbH,2,'rgba(255,255,255,.35)');}
}

function drawKillConfirm(c,w,h,now){const remain=Math.max(0,Math.min(1,(killConfirmUntil-now)/1000)),a=Math.min(1,remain*2.8);c.save();c.globalAlpha=a;c.textAlign='center';c.shadowColor='rgba(0,0,0,.84)';c.shadowBlur=4;c.fillStyle=killConfirmHeadshot?'#ffd36d':'rgba(255,255,255,.94)';c.font='1000 11px system-ui';c.fillText(killConfirmHeadshot?'HEADSHOT':'ELIMINATION',w/2,h/2+36);c.restore();}
function queueAnnouncer(title,subtitle='',duration=1500,priority=1){const item={title:String(title||''),subtitle:String(subtitle||''),duration,priority};if(!item.title)return;if(announcerCurrent&&priority>announcerCurrent.priority){announcerQueue.unshift(announcerCurrent);announcerCurrent=null;}announcerQueue.push(item);announcerQueue.sort((a,b)=>b.priority-a.priority);}
function activeAnnouncer(now){if(announcerCurrent&&now>=announcerCurrent.until)announcerCurrent=null;if(!announcerCurrent&&announcerQueue.length){const next=announcerQueue.shift();announcerCurrent={...next,start:now,until:now+next.duration};soundAnnouncer(next.priority);}return announcerCurrent;}
function drawAnnouncer(c,L,now){const a=activeAnnouncer(now);if(!a)return;const life=(now-a.start)/a.duration,fade=Math.min(1,life*6,(1-life)*5),scale=1+Math.max(0,.08-life*.34);c.save();c.translate(L.announcer.x,L.announcer.y);c.scale(scale,scale);c.globalAlpha=Math.max(0,fade);c.textAlign='center';c.shadowColor='rgba(0,0,0,.78)';c.shadowBlur=8;c.fillStyle='#fff';c.font=`1000 ${Math.max(18,Math.min(28,viewH*.052))}px system-ui`;c.fillText(a.title,0,0);if(a.subtitle){c.fillStyle=HUD_ACCENT;c.font=`900 ${Math.max(9,Math.min(12,viewH*.026))}px system-ui`;c.fillText(a.subtitle,0,20);}c.restore();}
function weaponLabel(w){if(w==='zombie')return 'ZOMBIE ATTACK';return WEAPON_SPECS[w]?.name||EQUIPMENT_SPECS[w]?.name||KILLSTREAK_SPECS[w]?.name||'PISTOL';}
function drawAmmo(c,r){
  const count=Math.max(0,Math.floor(ammo[currentWeapon]||0)),unlimited=!!godMode;
  const current=unlimited?'∞':String(count),capacity=unlimited?'':` / ${effectiveWeaponSpec(currentWeapon).mag}`;
  c.save();c.textAlign='left';c.textBaseline='middle';c.shadowColor='rgba(0,0,0,.85)';c.shadowBlur=4;
  c.font='900 16px system-ui';const currentW=c.measureText(current).width;
  c.font='700 11px system-ui';const capacityW=c.measureText(capacity).width;
  const x=r.x+r.w-currentW-capacityW,y=r.y+r.h/2;
  c.fillStyle=unlimited?HUD_ACCENT:count<=3?'#ff747d':'#fff';c.font='900 16px system-ui';c.fillText(current,x,y);
  c.fillStyle='#aab5bd';c.font='700 11px system-ui';c.fillText(capacity,x+currentW,y+2);
  c.restore();
}
function minimapDotColor(rmt){return relationshipColor(gameplayRelation(rmt.team,rmt.bot));}
const MINIMAP_ZOOM=1.45;
function minimapWorldLimit(geometry=worldGeometry){const value=Number(geometry?.MINIMAP_LIMIT);return Number.isFinite(value)&&value>8?value:Number(geometry?.ARENA_LIMIT)||ARENA_LIMIT;}
function minimapObstacles(geometry=worldGeometry){
  const out=[];for(const o of geometry.STATIC_BOXES||[])out.push({type:'box',x:o.x,z:o.z,w:o.w,d:o.d,rot:o.rot||0,kind:o.kind||'cover'});for(const b of geometry.BUILDINGS||[])out.push({type:'building',x:b.x,z:b.z,w:b.w,d:b.d,rot:b.rot||0});for(const e of geometry.ELEVATION_OBJECTS||[])out.push({type:'box',x:e.x,z:e.z,w:e.w,d:e.d,rot:e.rot||0,kind:e.kind||'platform'});for(const p of geometry.PYRAMIDS||[])out.push({type:'pyramid',x:p.x,z:p.z,base:p.base});for(const o of geometry.NATURAL_OBSTACLES||[])out.push({type:o.type,x:o.x,z:o.z,r:o.r,h:o.h});return out;
}
function getMinimapStatic(w=512,h=512,mapId=currentMapId){
  const id=normalizeMapId(mapId),geometry=CLIENT_WORLD_BUNDLES[id]?.geometry||worldGeometry,mapLimit=minimapWorldLimit(geometry),mapRevision=id==='custom-map'?customMapFingerprintValue:'builtin',key=`${id}:${mapRevision}:${mapLimit}:${Math.round(w)}x${Math.round(h)}`;if(minimapStaticCache?.key===key)return minimapStaticCache.canvas;
  const q=document.createElement('canvas');q.width=Math.max(1,Math.round(w));q.height=Math.max(1,Math.round(h));const c=q.getContext('2d'),iw=q.width,ih=q.height,terrainCells=32,cellW=iw/terrainCells,cellH=ih/terrainCells,terrainFn=geometry.terrainHeight||terrainHeight;
  c.fillStyle='rgba(19,27,26,.94)';c.fillRect(0,0,iw,ih);for(let gy=0;gy<terrainCells;gy++)for(let gx=0;gx<terrainCells;gx++){const wx=-mapLimit+(gx+.5)/terrainCells*mapLimit*2,wz=-mapLimit+(gy+.5)/terrainCells*mapLimit*2,hv=terrainFn(wx,wz),t=Math.max(0,Math.min(1,(hv+2.4)/16.2));c.fillStyle=`rgba(${Math.round(58+72*t)},${Math.round(78+46*t)},${Math.round(57+31*t)},${.34+.34*t})`;c.fillRect(gx*cellW,gy*cellH,cellW+.7,cellH+.7);}
  const toX=x=>(x+mapLimit)/(mapLimit*2)*iw,toY=z=>(z+mapLimit)/(mapLimit*2)*ih;const drawRotRect=(x,z,w,d,rot,fill,stroke='')=>{const cx=toX(x),cy=toY(z),sx=w/(mapLimit*2)*iw,sy=d/(mapLimit*2)*ih,a=(Number(rot)||0)*Math.PI/180;c.save();c.translate(cx,cy);c.rotate(a);c.fillStyle=fill;c.fillRect(-sx/2,-sy/2,sx,sy);if(stroke){c.strokeStyle=stroke;c.lineWidth=Math.max(1,iw/512);c.strokeRect(-sx/2+.5,-sy/2+.5,Math.max(0,sx-1),Math.max(0,sy-1));}c.restore();};for(const road of geometry.ROADS||[]){const kind=road.kind||'street',fill=kind==='dirt'?'rgba(123,101,72,.72)':kind==='sidewalk'?'rgba(125,132,135,.68)':'rgba(48,54,57,.86)',cx=toX(road.x),cy=toY(road.z),sx=road.w/(mapLimit*2)*iw,a=(Number(road.rot)||0)*Math.PI/180;drawRotRect(road.x,road.z,road.w,road.d,road.rot,fill);if(kind==='street'||kind==='service'){c.save();c.translate(cx,cy);c.rotate(a);c.strokeStyle=kind==='street'?'rgba(211,174,72,.72)':'rgba(228,230,226,.54)';c.lineWidth=Math.max(1,iw/512);c.setLineDash([5,5]);c.beginPath();c.moveTo(-sx/2,0);c.lineTo(sx/2,0);c.stroke();c.restore();c.setLineDash([]);}}for(const b of minimapObstacles(geometry)){if(b.type==='box'||b.type==='building'){drawRotRect(b.x,b.z,b.w,b.d,b.rot||0,b.type==='building'?'rgba(226,231,234,.64)':'rgba(190,199,204,.43)',b.type==='building'?'rgba(255,255,255,.30)':'');}else if(b.type==='pyramid'){const px=toX(b.x),py=toY(b.z),rr=b.base/(mapLimit*2)*iw*.55;c.beginPath();c.moveTo(px,py-rr);c.lineTo(px+rr,py+rr);c.lineTo(px-rr,py+rr);c.closePath();c.fillStyle='rgba(207,199,170,.62)';c.fill();}else{const px=toX(b.x),py=toY(b.z),rr=Math.max(1.6,(b.r||1)/(mapLimit*2)*iw*1.6);c.beginPath();c.arc(px,py,rr,0,Math.PI*2);c.fillStyle=b.type==='tree'?'rgba(41,101,52,.84)':b.type==='bush'?'rgba(65,116,59,.76)':'rgba(148,154,153,.72)';c.fill();}}
  minimapStaticCache={key,canvas:q};return q;
}
function renderLobbyMapPreview(mapId=lobbyMapDraft||currentMapId){
  if(!lobbyMapPreview||!shell.inLobby)return;const rect=lobbyMapPreview.getBoundingClientRect(),cssW=Math.max(240,Math.round(rect.width||640)),cssH=Math.max(170,Math.round(rect.height||360)),dpr=Math.min(2,devicePixelRatio||1),pw=Math.round(cssW*dpr),ph=Math.round(cssH*dpr);if(lobbyMapPreview.width!==pw)lobbyMapPreview.width=pw;if(lobbyMapPreview.height!==ph)lobbyMapPreview.height=ph;const c=lobbyMapPreview.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);c.clearRect(0,0,cssW,cssH);c.fillStyle='#080d10';c.fillRect(0,0,cssW,cssH);const pad=12,size=Math.max(1,Math.min(cssW-pad*2,cssH-pad*2)),x=(cssW-size)/2,y=(cssH-size)/2,staticMap=getMinimapStatic(768,768,mapId);c.drawImage(staticMap,x,y,size,size);c.strokeStyle='rgba(255,255,255,.22)';c.lineWidth=1;c.strokeRect(x+.5,y+.5,size-1,size-1);c.fillStyle='rgba(5,8,10,.72)';c.fillRect(x,y,34,20);c.fillStyle='#fff';c.textAlign='center';c.textBaseline='middle';c.font='1000 11px system-ui';c.fillText('N',x+17,y+10);
}

function drawMinimapDeathSkull(c,x,y,color,alpha=1,scale=1){c.save();c.translate(x,y);c.scale(scale,scale);c.globalAlpha=.92*alpha;c.fillStyle=color;c.strokeStyle='rgba(8,12,14,.92)';c.lineWidth=1.1;c.beginPath();c.arc(0,-1.5,4,0,Math.PI*2);c.fill();c.stroke();c.fillRect(-2.8,1.8,5.6,3.4);c.fillStyle='rgba(8,12,14,.95)';c.beginPath();c.arc(-1.5,-2,1.05,0,Math.PI*2);c.arc(1.5,-2,1.05,0,Math.PI*2);c.fill();c.fillRect(-1.9,2.5,.8,2.3);c.fillRect(-.4,2.5,.8,2.3);c.fillRect(1.1,2.5,.8,2.3);c.restore();}
function drawMiniMap(c,r){
  const mapLimit=minimapWorldLimit(),ix=r.x,iy=r.y,iw=r.w,ih=r.h,cx=ix+iw/2,cy=iy+ih/2,visibleWorld=(mapLimit*2)/MINIMAP_ZOOM,ppm=iw/visibleWorld,now=performance.now(),staticMap=getMinimapStatic(),staticScale=(mapLimit*2)/staticMap.width,headingUp=true,rotation=yaw,sinR=Math.sin(rotation),cosR=Math.cos(rotation);
  c.save();c.beginPath();if(typeof c.roundRect==='function')c.roundRect(ix,iy,iw,ih,7);else c.rect(ix,iy,iw,ih);c.clip();
  c.fillStyle='rgba(8,13,17,.58)';c.fillRect(ix,iy,iw,ih);
  const playerMapX=(position.x+mapLimit)/staticScale,playerMapY=(position.z+mapLimit)/staticScale,drawScale=ppm*staticScale;
  c.save();c.translate(cx,cy);if(headingUp)c.rotate(yaw);c.globalAlpha=.96;c.drawImage(staticMap,-playerMapX*drawScale,-playerMapY*drawScale,staticMap.width*drawScale,staticMap.height*drawScale);c.globalAlpha=1;c.restore();
  const toMap=(x,z)=>{const dx=(x-position.x)*ppm,dz=(z-position.z)*ppm;return{x:cx+dx*cosR-dz*sinR,y:cy+dx*sinR+dz*cosR};};
  const edgePad=8,edgeHalfW=Math.max(1,iw/2-edgePad),edgeHalfH=Math.max(1,ih/2-edgePad);
  const clampMinimapMarker=p=>{const dx=p.x-cx,dy=p.y-cy,inside=Math.abs(dx)<=edgeHalfW&&Math.abs(dy)<=edgeHalfH;if(inside)return{x:p.x,y:p.y,edge:false,angle:0};const sx=Math.abs(dx)>1e-6?edgeHalfW/Math.abs(dx):Infinity,sy=Math.abs(dy)>1e-6?edgeHalfH/Math.abs(dy):Infinity,k=Math.min(sx,sy);return{x:cx+dx*k,y:cy+dy*k,edge:true,angle:Math.atan2(dy,dx)};};
  for(const rmt of remotes.values()){if(rmt.hp<=0)continue;if(!matchState.minimapRevealAll&&!modeFriendly(rmt.team)&&now>=rmt.revealedUntil)continue;const p=clampMinimapMarker(toMap(rmt.group.position.x,rmt.group.position.z)),humanTeammate=!rmt.bot&&modeFriendly(rmt.team),color=minimapDotColor(rmt);if(p.edge){c.save();c.translate(p.x,p.y);c.rotate(p.angle+Math.PI/2);c.beginPath();c.moveTo(0,-4.8);c.lineTo(3.8,3.4);c.lineTo(0,2);c.lineTo(-3.8,3.4);c.closePath();c.fillStyle=color;c.fill();c.strokeStyle=modeFriendly(rmt.team)?(humanTeammate?'#d8ffe3':'#fff'):'rgba(255,255,255,.72)';c.lineWidth=1;c.stroke();c.restore();}else if(matchState.minimapDirectional){const markerYaw=Number.isFinite(rmt.targetYaw)?rmt.targetYaw:rmt.group.rotation.y,markerRotation=headingUp?yaw-markerYaw:-markerYaw;c.save();c.translate(p.x,p.y);c.rotate(markerRotation);c.beginPath();c.moveTo(0,-5.2);c.lineTo(3.8,4);c.lineTo(0,2.7);c.lineTo(-3.8,4);c.closePath();c.fillStyle=color;c.fill();c.strokeStyle=modeFriendly(rmt.team)?(humanTeammate?'#d8ffe3':'#fff'):'rgba(255,255,255,.72)';c.lineWidth=1;c.stroke();c.restore();}else{c.beginPath();c.arc(p.x,p.y,3.3,0,Math.PI*2);c.fillStyle=color;c.fill();if(modeFriendly(rmt.team)){c.strokeStyle=humanTeammate?'#d8ffe3':'#fff';c.lineWidth=1;c.stroke();}}}
  for(const marker of teammateDeathMarkers){const alpha=teammateDeathMarkerAlpha(marker,now);if(alpha<=0)continue;const role=relationshipFor({viewerTeam:myTeam,actorTeam:marker.team,teamBased:currentModeSpec().teamBased,self:false,bot:marker.bot});if(role===RELATIONSHIP.ENEMY)continue;const p=clampMinimapMarker(toMap(marker.x,marker.z));drawMinimapDeathSkull(c,p.x,p.y,relationshipColor(role),alpha,p.edge?.82:1);}
  c.save();c.translate(cx,cy);if(!headingUp)c.rotate(-yaw);c.beginPath();c.moveTo(0,-6.5);c.lineTo(4.8,5.2);c.lineTo(0,3.2);c.lineTo(-4.8,5.2);c.closePath();c.fillStyle=selfColor;c.fill();c.strokeStyle='#fff';c.lineWidth=1.2;c.stroke();c.restore();
  const vignette=c.createRadialGradient(cx,cy,Math.min(iw,ih)*.28,cx,cy,Math.min(iw,ih)*.72);vignette.addColorStop(0,'rgba(5,9,12,0)');vignette.addColorStop(.68,'rgba(5,9,12,0)');vignette.addColorStop(.88,'rgba(5,9,12,.18)');vignette.addColorStop(1,'rgba(5,9,12,.72)');c.fillStyle=vignette;c.fillRect(ix,iy,iw,ih);
  const topFade=c.createLinearGradient(0,iy,0,iy+22);topFade.addColorStop(0,'rgba(5,9,12,.58)');topFade.addColorStop(1,'rgba(5,9,12,0)');c.fillStyle=topFade;c.fillRect(ix,iy,iw,22);
  const cardinalRadius=Math.max(10,Math.min(iw,ih)*.5-10),cards=[['N',0,-1],['E',1,0],['S',0,1],['W',-1,0]];c.textAlign='center';c.textBaseline='middle';c.font='1000 9px system-ui';c.fillStyle='rgba(255,255,255,.82)';for(const [label,dx,dz] of cards){const sx=headingUp?(dx*cosR-dz*sinR):dx,sy=headingUp?(dx*sinR+dz*cosR):dz;c.fillText(label,cx+sx*cardinalRadius,cy+sy*cardinalRadius);}
  const bottomFade=c.createLinearGradient(0,iy+ih-25,0,iy+ih);bottomFade.addColorStop(0,'rgba(5,9,12,0)');bottomFade.addColorStop(1,'rgba(5,9,12,.76)');c.fillStyle=bottomFade;c.fillRect(ix,iy+ih-25,iw,25);
  c.restore();
  c.textBaseline='middle';c.font=`900 ${r.w<110?9.5:10.5}px system-ui`;c.textAlign='left';c.fillStyle='rgba(255,255,255,.88)';c.fillText(currentRoom||'----',r.x+6,r.y+r.h-7);c.textAlign='right';c.fillStyle='rgba(211,222,230,.82)';const humanCount=[...remotes.values()].filter(v=>!v.bot).length+1,botTotal=[...remotes.values()].filter(v=>v.bot).length;c.fillText(`${humanCount}P · ${botTotal}B`,r.x+r.w-6,r.y+r.h-7);
}

function handleKill(m){
  if(!m?.attacker||!m?.victim)return;const update=p=>{if(!p)return;if(p.id===clientId){myStats.kills=Number(p.kills)||0;myStats.deaths=Number(p.deaths)||0;}else{const r=remotes.get(p.id);if(r){r.kills=Number(p.kills)||0;r.deaths=Number(p.deaths)||0;}}};update(m.attacker);update(m.victim);const victimRemote=remotes.get(m.victim.id);if(victimRemote&&modeFriendly(victimRemote.team))createTeammateDeathMarker(victimRemote);
  if(m.victim.id===clientId){lastWastedBy=m.attacker.name||'Player';lastWastedWeapon=m.weapon||'';lastWastedHeadshot=!!m.headshot;lastWastedDistance=Math.max(0,Number(m.distance)||0);const killer=remotes.get(m.attacker.id);if(killer){const dx=killer.group.position.x-position.x,dz=killer.group.position.z-position.z;if(Math.hypot(dx,dz)>.05)deathViewTargetYaw=Math.atan2(-dx,-dz);}}
  const mine=m.attacker.id===clientId&&m.victim.id!==clientId,multi=Math.max(0,Number(m.multiKill)||0),distance=Math.max(0,Number(m.distance)||0);
  if(mine){
    killConfirmName=m.victim.name||'Player';killConfirmWeapon=m.weapon||'pistol';killConfirmHeadshot=!!m.headshot;killConfirmDistance=distance;killConfirmUntil=performance.now()+1050;soundKill();
    if(multi===2)queueAnnouncer('DOUBLE KILL','',1500,3);
    else if(multi===3)queueAnnouncer('TRIPLE KILL','',1650,5);
    else if(multi>=4)queueAnnouncer('MULTI-KILL',`×${multi}`,1750,6);
    if(distance>=LONG_SHOT_DISTANCE)queueAnnouncer('LONG SHOT',`${distance.toFixed(1)} m`,1650,4);
  }else if(multi===3)queueAnnouncer('TRIPLE KILL',m.attacker.name||'Player',1550,2);
  else if(multi>=4)queueAnnouncer('MULTI-KILL',`${m.attacker.name||'Player'} · ×${multi}`,1650,2);
  addKillFeed(m);
  const localDeath=samePlayerId(m.victim.id,clientId)&&!samePlayerId(m.attacker.id,clientId);if(m.finalKill)scheduleReplayFromKill(m,'final');else if(localDeath)scheduleReplayFromKill(m,'killcam');
}
function addKillFeed(m){if(!m?.attacker||!m?.victim)return;killFeed.unshift({attacker:m.attacker,victim:m.victim,weapon:m.weapon||'pistol',headshot:!!m.headshot,distance:Math.max(0,Number(m.distance)||0),until:performance.now()+6500});if(killFeed.length>6)killFeed.length=6;}
function drawKillFeed(c,r,now){
  while(killFeed.length&&killFeed[killFeed.length-1].until<now)killFeed.pop();
  c.save();c.beginPath();c.rect(r.x,r.y,r.w,r.h);c.clip();let y=r.y;
  for(const item of killFeed){const h=23,localKill=item.attacker.id===clientId&&item.victim.id!==clientId,localDeath=item.victim.id===clientId,weapon=`${WEAPON_SPECS[item.weapon]?.short||EQUIPMENT_SPECS[item.weapon]?.short||KILLSTREAK_SPECS[item.weapon]?.short||'PST'}${item.headshot?' ◆':''}`;if(y+h>r.y+r.h)break;
    const fill=localKill?'rgba(30,42,20,.91)':localDeath?'rgba(53,12,18,.91)':'rgba(9,11,13,.76)',line=localKill?'rgba(215,255,88,.34)':localDeath?'rgba(255,82,101,.34)':'rgba(255,255,255,.09)';roundRect(c,r.x,y,r.w,h,6,fill,line);
    const teamBased=currentModeSpec().teamBased,attackerColor=teamBased?factionColor(item.attacker.team):(localKill?HUD_ACCENT:relationshipColor(RELATIONSHIP.ENEMY)),victimColor=teamBased?factionColor(item.victim.team):(localDeath?'#ff7b8a':relationshipColor(RELATIONSHIP.ENEMY));c.fillStyle=localKill?HUD_ACCENT:localDeath?'#ff5367':attackerColor;c.fillRect(r.x,y,3,h);
    const innerW=Math.max(40,r.w-17),weaponBudget=Math.min(66,innerW*.30),nameBudget=Math.max(28,(innerW-weaponBudget-8)/2);c.font=`${localKill||localDeath?'1000':'900'} 11px system-ui`;c.textAlign='left';c.fillStyle=localKill?HUD_ACCENT:'#fff';const attacker=clipHudText(c,item.attacker.name||'Player',nameBudget);c.fillText(attacker,r.x+9,y+h/2);
    const aw=c.measureText(attacker).width;c.fillStyle=item.headshot?'#ffd36d':'#89959e';c.font='900 9px system-ui';const weaponText=clipHudText(c,weapon,weaponBudget);c.fillText(` ${weaponText} `,r.x+11+aw,y+h/2);
    const ww=c.measureText(` ${weaponText} `).width;c.fillStyle=localDeath?'#ff9ba5':victimColor;c.font=`${localDeath?'1000':'900'} 11px system-ui`;const victimX=r.x+13+aw+ww,victim=clipHudText(c,item.victim.name||'Player',Math.max(24,r.x+r.w-7-victimX));c.fillText(victim,victimX,y+h/2);y+=h+4;
  }
  c.restore();
}

function drawMenuButton(c,r){roundRect(c,r.x,r.y,r.w,r.h,8,HUD_SURFACE,HUD_LINE);const cx=r.x+r.w/2,cy=r.y+r.h/2;c.save();c.strokeStyle='rgba(245,249,252,.92)';c.lineWidth=1.8;c.lineCap='round';for(const off of [-5,0,5]){c.beginPath();c.moveTo(cx-7,cy+off);c.lineTo(cx+7,cy+off);c.stroke();}c.restore();}
function drawWeaponCrosshair(c,x,y,weapon,hit,ads=0,headshot=false){if(combatActionActive())return;const adsAmount=Math.max(0,Math.min(1,ads)),hideInAds=weaponUsesIronSights(weapon)||weapon==='grenadeLauncher',adsFade=weapon==='sniper'?1-smoothstep01((adsAmount-.16)/.20):hideInAds?1-smoothstep01((adsAmount-.52)/.42):1;if(adsFade<=.01)return;const color=headshot?'#ffd36d':hit?'#fff':'rgba(255,255,255,.94)',gap=accuracyCrosshairRadius();c.save();c.globalAlpha=adsFade;c.strokeStyle=color;c.fillStyle=color;c.shadowColor='rgba(0,0,0,.88)';c.shadowBlur=3;c.lineWidth=hit?2.35:1.65;c.lineCap='round';
  if(weapon==='grenadeLauncher'){
    // Launcher-specific range ladder: center aiming ring plus descending holdover
    // marks communicates the grenade's arcing trajectory instead of reusing a
    // rifle crosshair that implies a flat shot.
    const spread=Math.max(7,gap*.72),ring=4.3+spread*.08;c.lineWidth=hit?2.2:1.45;c.beginPath();c.arc(x,y,ring,0,Math.PI*2);c.stroke();c.beginPath();c.arc(x,y,1.15,0,Math.PI*2);c.fill();
    const ladder=[{dy:14,w:13},{dy:25,w:18},{dy:38,w:24},{dy:53,w:30}];c.beginPath();c.moveTo(x,y+ring+3);c.lineTo(x,y+57);for(const mark of ladder){c.moveTo(x-mark.w/2,y+mark.dy);c.lineTo(x+mark.w/2,y+mark.dy);}c.stroke();
    c.globalAlpha=.72;c.lineWidth=1.1;c.beginPath();c.moveTo(x-18-spread*.25,y-5);c.quadraticCurveTo(x-23-spread*.3,y,x-18-spread*.25,y+5);c.moveTo(x+18+spread*.25,y-5);c.quadraticCurveTo(x+23+spread*.3,y,x+18+spread*.25,y+5);c.stroke();
  }else if(weapon==='akimbo1887'){const r=Math.max(38,Math.min(64,gap*1.12+10)),arc=.82;c.lineWidth=hit?2.65:2.05;c.beginPath();for(let i=0;i<4;i++){const a=i*Math.PI/2-arc/2;c.arc(x,y,r,a,a+arc);}c.stroke();c.globalAlpha*=.72;c.lineWidth=1.2;c.beginPath();c.arc(x,y,Math.max(9,r*.24),0,Math.PI*2);c.stroke();c.globalAlpha=adsFade;c.beginPath();c.arc(x,y,1.8,0,Math.PI*2);c.fill();
  }else if(weapon==='shotgun'||weapon==='semiShotgun'){const r=Math.max(8,gap),arc=.50;c.beginPath();for(let i=0;i<4;i++){const a=i*Math.PI/2-arc/2;c.arc(x,y,r,a,a+arc);}c.stroke();c.beginPath();c.arc(x,y,1.5,0,Math.PI*2);c.fill();}
  else{const len=weapon==='machineGun'?9:weapon==='assault'?8:weapon==='sniper'?6:5.5,inner=Math.max(3.5,gap);if(weapon==='sniper')c.lineWidth=1.2;c.beginPath();c.moveTo(x-inner-len,y);c.lineTo(x-inner,y);c.moveTo(x+inner,y);c.lineTo(x+inner+len,y);c.moveTo(x,y-inner-len);c.lineTo(x,y-inner);c.moveTo(x,y+inner);c.lineTo(x,y+inner+len);c.stroke();c.beginPath();c.arc(x,y,weapon==='assault'?1.35:weapon==='sniper'?1.1:1.6,0,Math.PI*2);c.fill();}
  c.restore();}

function drawHitConfirm(c,x,y,headshot=false){const size=headshot?8.5:7,gap=4.5;c.save();c.strokeStyle=headshot?'#ffd36d':'rgba(255,255,255,.98)';c.lineWidth=headshot?2.5:2.15;c.lineCap='round';c.shadowColor='rgba(0,0,0,.92)';c.shadowBlur=3;c.beginPath();c.moveTo(x-gap-size,y-gap-size);c.lineTo(x-gap,y-gap);c.moveTo(x+gap,y+gap);c.lineTo(x+gap+size,y+gap+size);c.moveTo(x+gap+size,y-gap-size);c.lineTo(x+gap,y-gap);c.moveTo(x-gap,y+gap);c.lineTo(x-gap-size,y+gap+size);c.stroke();c.restore();}

function drawScopeMask(c,w,h,amount=1){
  const a=THREE.MathUtils.clamp(amount,0,1),r=Math.min(w,h)*MAGNIFIED_SCOPE_SCREEN_RADIUS,cx=w/2,cy=h/2;if(a<=.001)return;
  c.save();c.beginPath();c.rect(0,0,w,h);c.arc(cx,cy,r,0,Math.PI*2,true);c.fillStyle=`rgba(0,0,0,${.985*a})`;c.fill('evenodd');
  c.beginPath();c.arc(cx,cy,r,0,Math.PI*2);c.clip();const vignette=c.createRadialGradient(cx,cy,r*.62,cx,cy,r);vignette.addColorStop(0,'rgba(0,0,0,0)');vignette.addColorStop(.82,`rgba(0,0,0,${.035*a})`);vignette.addColorStop(1,`rgba(0,0,0,${.46*a})`);c.fillStyle=vignette;c.fillRect(cx-r,cy-r,r*2,r*2);c.restore();
  c.save();c.globalAlpha=a;c.strokeStyle='rgba(7,9,11,.98)';c.lineWidth=5;c.beginPath();c.arc(cx,cy,r-1.5,0,Math.PI*2);c.stroke();c.strokeStyle='rgba(255,255,255,.10)';c.lineWidth=1;c.beginPath();c.arc(cx,cy,r-4,0,Math.PI*2);c.stroke();c.restore();
}
function ensureRemoteThermalMaterials(r){
  if(!r||r.thermalMaterials)return;
  r.thermalBaseMaterials={body:r.body?.material,head:r.head?.material,armL:r.armL?.material,armR:r.armR?.material,legL:r.legL?.material,legR:r.legR?.material};
  r.thermalMaterials={
    warm:new THREE.MeshBasicMaterial({color:0xff7a1a,toneMapped:false}),
    hot:new THREE.MeshBasicMaterial({color:0xffb044,toneMapped:false})
  };
  r.thermalMaterials.warm.userData.thermalOpticSignature=true;r.thermalMaterials.hot.userData.thermalOpticSignature=true;
}
function setRemoteThermalSignature(r,mode){
  if(!r)return;ensureRemoteThermalMaterials(r);
  if(r.thermalMode!==mode){const gray=mode==='white';r.thermalMaterials.warm.color.set(gray?0xd8dde0:0xff7a1a);r.thermalMaterials.hot.color.set(gray?0xffffff:0xffb044);r.thermalMode=mode;}
  r.body.material=r.thermalMaterials.warm;r.legL.material=r.thermalMaterials.warm;r.legR.material=r.thermalMaterials.warm;r.head.material=r.thermalMaterials.hot;r.armL.material=r.thermalMaterials.hot;r.armR.material=r.thermalMaterials.hot;r.thermalActive=true;
}
function restoreRemoteThermalSignature(r,dispose=false){
  if(!r)return;const base=r.thermalBaseMaterials;if(base){if(r.body)r.body.material=base.body;if(r.head)r.head.material=base.head;if(r.armL)r.armL.material=base.armL;if(r.armR)r.armR.material=base.armR;if(r.legL)r.legL.material=base.legL;if(r.legR)r.legR.material=base.legR;}r.thermalActive=false;r.thermalMode='';
  if(dispose&&r.thermalMaterials){r.thermalMaterials.warm?.dispose?.();r.thermalMaterials.hot?.dispose?.();r.thermalMaterials=null;r.thermalBaseMaterials=null;}
}
function syncThermalOpticSignatures(){
  const mode=thermalOpticMode(),active=!!mode&&thermalOpticScopeAmount()>.90&&hp>0;
  for(const r of remotes.values()){const visibleHeat=active&&r.hp>0&&!modeFriendly(r.team);if(visibleHeat)setRemoteThermalSignature(r,mode);else if(r.thermalActive)restoreRemoteThermalSignature(r);}
}
function drawThermalOptic(c,w,h,amount=1){
  const mode=thermalOpticMode(),a=THREE.MathUtils.clamp(amount,0,1);if(!mode||a<=.001)return;const r=Math.min(w,h)*MAGNIFIED_SCOPE_SCREEN_RADIUS,cx=w/2,cy=h/2;c.save();c.beginPath();c.arc(cx,cy,r-5,0,Math.PI*2);c.clip();c.globalAlpha=a;c.fillStyle=mode==='orange'?'rgba(16,19,20,.10)':'rgba(10,12,13,.14)';c.fillRect(cx-r,cy-r,r*2,r*2);const vignette=c.createRadialGradient(cx,cy,r*.46,cx,cy,r);vignette.addColorStop(0,'rgba(255,255,255,.015)');vignette.addColorStop(.72,'rgba(0,0,0,0)');vignette.addColorStop(1,mode==='orange'?'rgba(5,7,8,.30)':'rgba(3,4,5,.36)');c.fillStyle=vignette;c.fillRect(cx-r,cy-r,r*2,r*2);c.globalAlpha=a*.10;c.fillStyle='rgba(255,255,255,.28)';for(let y=cy-r;y<cy+r;y+=4)c.fillRect(cx-r,y,r*2,1);c.restore();
}
function drawScopeReticle(c,w,h,hit,headshot=false,amount=1){
  const a=THREE.MathUtils.clamp(amount,0,1),r=Math.min(w,h)*MAGNIFIED_SCOPE_SCREEN_RADIUS,cx=w/2,cy=h/2,gap=Math.max(7,r*.032),post=Math.max(30,r*.17);if(a<=.001)return;
  c.save();c.globalAlpha=a;c.strokeStyle='rgba(8,11,13,.94)';c.fillStyle='rgba(8,11,13,.94)';c.lineCap='butt';
  c.lineWidth=3.4;c.beginPath();c.moveTo(cx-r+8,cy);c.lineTo(cx-post,cy);c.moveTo(cx+post,cy);c.lineTo(cx+r-8,cy);c.moveTo(cx,cy-r+8);c.lineTo(cx,cy-post);c.moveTo(cx,cy+post);c.lineTo(cx,cy+r-8);c.stroke();
  c.lineWidth=1.35;c.beginPath();c.moveTo(cx-post,cy);c.lineTo(cx-gap,cy);c.moveTo(cx+gap,cy);c.lineTo(cx+post,cy);c.moveTo(cx,cy-post);c.lineTo(cx,cy-gap);c.moveTo(cx,cy+gap);c.lineTo(cx,cy+post);c.stroke();
  c.beginPath();c.arc(cx,cy,1.65,0,Math.PI*2);c.fill();
  c.font='900 9px system-ui';c.textAlign='center';c.fillStyle='rgba(255,255,255,.72)';c.shadowColor='rgba(0,0,0,.8)';c.shadowBlur=2;c.fillText(activeScopeZoomLabel(),cx,cy-r+20);c.restore();
}
function drawSniperBreathMeter(c,w,h){
  if(currentWeapon!=='sniper'||adsBlend<SNIPER_BREATH_READY_BLEND)return;
  const used=sniperBreathReserve<.995||sniperBreathActive||sniperBreathExhausted;if(!used)return;
  const r=Math.min(w,h)*MAGNIFIED_SCOPE_SCREEN_RADIUS,cx=w/2,y=h/2+r-22,bw=Math.max(44,Math.min(66,r*.28)),bh=3,x=cx-bw/2;
  c.save();c.globalAlpha=.78;c.fillStyle='rgba(255,255,255,.16)';c.fillRect(x,y,bw,bh);c.fillStyle=sniperBreathExhausted?'#ff6973':sniperBreathActive?HUD_ACCENT:'rgba(235,244,248,.74)';c.fillRect(x,y,bw*THREE.MathUtils.clamp(sniperBreathReserve,0,1),bh);c.restore();
}
function drawTouchControls(c,L,now,movementOnly=false){
  c.save();if(touchRoleActive('joy')){const j={x:joy.centerX,y:joy.centerY,r:L.joy.r};c.beginPath();c.arc(j.x,j.y,j.r,0,Math.PI*2);c.fillStyle='rgba(9,11,13,.42)';c.fill();c.strokeStyle='rgba(255,255,255,.24)';c.lineWidth=1.5;c.stroke();c.beginPath();c.arc(j.x,j.y,j.r*.72,0,Math.PI*2);c.strokeStyle='rgba(255,255,255,.08)';c.stroke();const max=j.r*.45,sx=j.x+joy.x*max,sy=j.y+joy.y*max;c.beginPath();c.arc(sx,sy,j.r*.40,0,Math.PI*2);c.fillStyle='rgba(215,255,88,.16)';c.fill();c.strokeStyle='rgba(215,255,88,.42)';c.stroke();c.fillStyle='rgba(255,255,255,.58)';c.font='900 10px system-ui';c.textAlign='center';c.fillText(sprinting?'SPRINT':'MOVE',j.x,j.y+j.r*.70);}c.restore();
  if(movementOnly==='fly')return;
  if(movementOnly){drawRoundControl(c,L.crouch,crouched,'crouch');drawRoundControl(c,L.jump,now<touchVisual.jumpUntil,'jump');return;}
  const weaponLocked=!combatWeaponAvailable(now);
  drawRoundControl(c,L.leftFire,now<touchVisual.fireUntil,'fire',weaponLocked);drawRoundControl(c,L.crouch,crouched,'crouch');drawRoundControl(c,L.flash,equipmentAimKind()===tacticalEquipment||now<touchVisual.flashUntil,'flash');drawRoundControl(c,L.sticky,equipmentAimKind()===lethalEquipment||now<touchVisual.stickyUntil,'sticky');
  drawRoundControl(c,L.fire,now<touchVisual.fireUntil,'fire',weaponLocked);if(currentWeapon!=='akimbo1887')drawRoundControl(c,L.aim,adsWanted,'aim',weaponLocked);drawRoundControl(c,L.jump,now<touchVisual.jumpUntil,'jump');
  drawRoundControl(c,L.reload,now<touchVisual.reloadUntil||!!reloadUntil,'reload',weaponLocked);drawRoundControl(c,L.swap,now<touchVisual.swapUntil,'swap',weaponLocked);
  if(currentWeapon==='assault')drawRoundControl(c,L.mode,now<touchVisual.modeUntil||assaultFireMode==='auto','mode',weaponLocked);else if(currentWeapon==='sniper'&&adsWanted&&adsBlend>=SNIPER_BREATH_READY_BLEND)drawRoundControl(c,L.steady,sniperBreathActive,'steady',weaponLocked||sniperBreathExhausted);
}
function drawRoundControl(c,b,active,type,disabled=false){
  c.save();if(disabled)c.globalAlpha=.34;c.beginPath();c.arc(b.x,b.y,b.r,0,Math.PI*2);const hot=type==='fire',aim=type==='aim';c.fillStyle=active?(aim?'rgba(215,255,88,.30)':hot?'rgba(255,95,103,.48)':'rgba(215,255,88,.22)'):(hot?'rgba(60,22,25,.56)':'rgba(9,11,13,.62)');c.fill();c.strokeStyle=active?(aim?HUD_ACCENT:hot?'rgba(255,132,139,.86)':HUD_ACCENT):(hot?'rgba(255,115,123,.52)':'rgba(255,255,255,.22)');c.lineWidth=active?2:1.4;c.stroke();drawControlIcon(c,b.x,b.y-b.r*.08,b.r,type,active);
  const label=type==='fire'?'FIRE':type==='aim'?((currentWeapon==='sniper'||thermalOpticMode())?(adsWanted?'EXIT':activeScopeZoomLabel()):'ADS'):type==='steady'?'HOLD':type==='jump'?(ladderState?'JUMP OFF':traversal?'CLIMB':'JUMP'):type==='crouch'?(sliding?'SLIDE':crouched?'STAND':'CROUCH'):type==='reload'?'RELOAD':type==='swap'?'SWAP':type==='mode'?assaultFireMode.toUpperCase():type==='flash'?(equipmentAimKind()===tacticalEquipment?'THROW':`${tacticalEquipment==='flash'?'FLASH':'SMOKE'} ${godMode?'∞':equipment[tacticalEquipment]||0}`):type==='sticky'?(equipmentAimKind()===lethalEquipment?'THROW':`${lethalEquipment==='sticky'?'SEMTEX':'FRAG'} ${godMode?'∞':equipment[lethalEquipment]||0}`):'';c.textAlign='center';c.fillStyle=active?'#fff':'rgba(230,243,249,.68)';c.font=`900 ${Math.max(8,Math.min(10,b.r*.26))}px system-ui`;c.fillText(label,b.x,b.y+b.r*.56,Math.max(26,b.r*1.55));c.restore();
}
function drawControlIcon(c,x,y,r,type,active){
  const q=Math.max(8,r*.44),ink=active?'#fff':'rgba(241,250,255,.92)';
  c.save();c.strokeStyle=ink;c.fillStyle=ink;c.lineWidth=Math.max(1.35,r*.055);c.lineCap='round';c.lineJoin='round';
  if(type==='fire'){
    const a=q*.63,g=q*.24;c.beginPath();c.moveTo(x-a,y-g);c.lineTo(x-a,y-a);c.lineTo(x-g,y-a);c.moveTo(x+g,y-a);c.lineTo(x+a,y-a);c.lineTo(x+a,y-g);c.moveTo(x+a,y+g);c.lineTo(x+a,y+a);c.lineTo(x+g,y+a);c.moveTo(x-g,y+a);c.lineTo(x-a,y+a);c.lineTo(x-a,y+g);c.stroke();c.beginPath();c.arc(x,y,q*.105,0,Math.PI*2);c.fill();
  }else if(type==='aim'){
    const a=q*.68,g=q*.22;c.beginPath();c.moveTo(x-a,y-g);c.lineTo(x-a,y-a);c.lineTo(x-g,y-a);c.moveTo(x+g,y-a);c.lineTo(x+a,y-a);c.lineTo(x+a,y-g);c.moveTo(x+a,y+g);c.lineTo(x+a,y+a);c.lineTo(x+g,y+a);c.moveTo(x-g,y+a);c.lineTo(x-a,y+a);c.lineTo(x-a,y+g);c.stroke();c.beginPath();c.arc(x,y,q*.18,0,Math.PI*2);c.stroke();
  }else if(type==='jump'){
    c.beginPath();c.moveTo(x-q*.55,y+q*.25);c.lineTo(x,y-q*.48);c.lineTo(x+q*.55,y+q*.25);c.stroke();c.beginPath();c.moveTo(x-q*.52,y+q*.56);c.lineTo(x+q*.52,y+q*.56);c.stroke();
  }else if(type==='reload'){
    c.beginPath();c.arc(x,y,q*.56,-.7,Math.PI*1.45);c.stroke();c.beginPath();c.moveTo(x+q*.42,y-q*.46);c.lineTo(x+q*.72,y-q*.42);c.lineTo(x+q*.58,y-q*.14);c.stroke();
  }else if(type==='swap'){
    c.beginPath();c.moveTo(x-q*.66,y-q*.26);c.lineTo(x+q*.43,y-q*.26);c.lineTo(x+q*.20,y-q*.49);c.moveTo(x+q*.66,y+q*.26);c.lineTo(x-q*.43,y+q*.26);c.lineTo(x-q*.20,y+q*.49);c.stroke();
  }else if(type==='flash'){
    c.beginPath();c.roundRect(x-q*.38,y-q*.45,q*.76,q*.78,q*.18);c.stroke();c.beginPath();c.moveTo(x-q*.10,y-q*.55);c.lineTo(x+q*.18,y-q*.72);c.lineTo(x+q*.34,y-q*.60);c.stroke();for(const a of [-.9,0,.9]){const sx=x+Math.sin(a)*q*.66,sy=y+Math.cos(a)*q*.66;c.beginPath();c.moveTo(sx,sy);c.lineTo(x+Math.sin(a)*q*.84,y+Math.cos(a)*q*.84);c.stroke();}
  }else if(type==='sticky'){
    c.beginPath();c.arc(x,y,q*.50,0,Math.PI*2);c.stroke();c.beginPath();c.arc(x,y,q*.15,0,Math.PI*2);c.fill();c.beginPath();c.moveTo(x-q*.12,y-q*.55);c.lineTo(x+q*.18,y-q*.76);c.lineTo(x+q*.34,y-q*.62);c.stroke();
  }else if(type==='crouch'){
    c.beginPath();c.arc(x-q*.28,y-q*.32,q*.18,0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(x-q*.13,y-q*.18);c.lineTo(x+q*.12,y+q*.04);c.lineTo(x+q*.48,y+q*.04);c.moveTo(x+q*.12,y+q*.04);c.lineTo(x-q*.10,y+q*.36);c.moveTo(x+q*.10,y+q*.05);c.lineTo(x+q*.34,y+q*.35);c.stroke();
  }else if(type==='steady'){
    c.beginPath();c.moveTo(x-q*.70,y);c.lineTo(x-q*.40,y);c.bezierCurveTo(x-q*.30,y-q*.20,x-q*.18,y+q*.20,x-q*.08,y);c.bezierCurveTo(x+q*.02,y-q*.20,x+q*.14,y+q*.20,x+q*.24,y);c.lineTo(x+q*.70,y);c.stroke();
  }else if(type==='mode'){
    const n=assaultFireMode==='auto'?3:1;for(let i=0;i<n;i++){const yy=y+(i-(n-1)/2)*q*.33;c.beginPath();c.roundRect(x-q*.50,yy-q*.085,q*.82,q*.17,q*.085);c.fill();c.beginPath();c.moveTo(x+q*.35,yy);c.lineTo(x+q*.58,yy);c.stroke();}
  }
  c.restore();
}


function roundRect(c,x,y,w,h,r,fill,stroke){if(w<=0||h<=0)return;c.beginPath();c.roundRect(x,y,w,h,r);if(fill){c.fillStyle=fill;c.fill();}if(stroke){c.strokeStyle=stroke;c.lineWidth=1;c.stroke();}}

function startIntroMusic(){
  if(masterMuted||shell.inMatch||introMusicHandle)return;
  introMusicHandle=playSoundCue('introMusic',1,{loop:true,onended:()=>{introMusicHandle=null;}});
}
function stopIntroMusic(){if(introMusicHandle){introMusicHandle.stop();introMusicHandle=null;}}



function weaponShotSoundId(weapon='pistol',suppressed=false){
  if(suppressed){if(weapon==='pistol')return'shotPistolSuppressed';if(weapon==='akimbo1887')return'shot1887Suppressed';if(weapon==='assault')return'shotAssaultSuppressed';if(weapon==='ump')return'shotUmpSuppressed';if(weapon==='machineGun')return'shotMachineGunSuppressed';if(weapon==='shotgun')return'shotShotgunSuppressed';if(weapon==='sniper')return'shotSniperSuppressed';}
  return weapon==='assault'?'shotAssault':weapon==='ump'?'shotUmp':weapon==='machineGun'?'shotMachineGun':weapon==='akimbo1887'?'shot1887':weapon==='shotgun'?'shotShotgun':weapon==='semiShotgun'?'shotSemiShotgun':weapon==='sniper'?'shotSniper':weapon==='grenadeLauncher'?'shotGl':weapon==='rpg'?'shotRpg':'shotPistol';
}
function weaponAudibleDistance(weapon='pistol',suppressed=false){
  if(suppressed)return weapon==='sniper'?70:weapon==='machineGun'?64:weapon==='assault'?62:weapon==='shotgun'||weapon==='akimbo1887'?58:54;
  return weapon==='sniper'?135:weapon==='rpg'?130:weapon==='machineGun'?115:weapon==='shotgun'||weapon==='akimbo1887'?108:weapon==='assault'?105:weapon==='grenadeLauncher'?100:weapon==='ump'?92:78;
}
function weaponShotVariation(weapon='pistol'){
  const spread=weapon==='machineGun'?.020:(weapon==='assault'||weapon==='ump') ? .016 : (weapon==='shotgun'||weapon==='semiShotgun'||weapon==='akimbo1887') ? .010 : .006;
  return{playbackRate:1+(Math.random()*2-1)*spread,volume:.97+Math.random()*.06};
}
function attachmentShotTone(weapon,mods){let volume=1,rate=1;if(weaponHasAttachment(weapon,mods,'shortBarrel')){volume*=1.08;rate*=1.035;}if(weaponHasAttachment(weapon,mods,'heavyBarrel')){volume*=.98;rate*=.985;}if(weaponHasAttachment(weapon,mods,'shotgunLongBarrel')){volume*=.98;rate*=.982;}return{volume,rate};}
function soundShot(weapon='pistol',hand='right'){const v=weaponShotVariation(weapon),mods=attachmentsForWeapon(weapon),soundScale=attachmentSoundScale(weapon,mods),tone=attachmentShotTone(weapon,mods),suppressed=weaponHasAttachment(weapon,mods,'suppressor'),pan=weapon==='akimbo1887'?(hand==='left'?-0.42:.42):0;playSoundCue(weaponShotSoundId(weapon,suppressed),v.volume*soundScale*tone.volume,{playbackRate:v.playbackRate*(weapon==='akimbo1887'?1.04:1)*(suppressed?.99:1)*tone.rate,pan,priority:4});}
function reloadSoundId(weapon=currentWeapon){
  return weapon==='assault'?'reloadAssault':weapon==='ump'?'reloadUmp':weapon==='machineGun'?'reloadMachineGun':weapon==='akimbo1887'?'reload1887':weapon==='shotgun'?'reloadShotgun':weapon==='semiShotgun'?'reloadSemiShotgun':weapon==='sniper'?'reloadSniper':weapon==='grenadeLauncher'?'reloadGl':weapon==='rpg'?'reloadRpg':'reloadPistol';
}
function soundReload(weapon=currentWeapon){playSoundCue(reloadSoundId(weapon),1,{playbackRate:.99+Math.random()*.02,priority:3});}
function soundHitmarker(){playSoundCue('hitmarker',1,{priority:5});}
function soundHeadshot(){playSoundCue('hitmarker',1.10,{playbackRate:.88,priority:6});}
function soundKill(){playSoundCue('kill',1,{priority:6});}
function soundAnnouncer(priority=1){playSoundCue('announcer',1,{playbackRate:priority>=5?1.08:1,priority:Math.max(3,Math.min(6,priority))});}
function soundHurt(){playSoundCue('hurt',1,{priority:5});}
function soundJump(){playSoundCue('jump');}
function soundFootstep(side=0,volume=1){playSoundCue(side?'footstepRight':'footstepLeft',volume*(.96+Math.random()*.08),{playbackRate:.96+Math.random()*.08});}
function soundLanding(volume=1){playSoundCue('land',volume,{playbackRate:.97+Math.random()*.05});}
function soundSlide(){playSoundCue('slide',.92,{playbackRate:.97+Math.random()*.06});}
function soundShotgunPump(){playSoundCue('shotgunPump',1,{playbackRate:.985+Math.random()*.03});}
function soundThrowableThrow(kind='flash'){playSoundCue(kind==='sticky'||kind==='frag'?'stickyThrow':'flashThrow');}
function soundThrowableImpact(kind='flash',m){if(!m)return;playSpatialCue(kind==='sticky'||kind==='frag'?'stickyImpact':'flashImpact',Number(m.x)||0,Number(m.y)||0,Number(m.z)||0,32,.85);}

function semtexBeepInterval(remainingMs){const p=1-THREE.MathUtils.clamp(Number(remainingMs||0)/1850,0,1);return Math.round(THREE.MathUtils.lerp(360,85,Math.pow(p,1.22)));}
function soundSemtexBeep(g,remainingMs){if(!g?.root)return;const p=1-THREE.MathUtils.clamp(Number(remainingMs||0)/1850,0,1),rate=1+p*.10,interval=semtexBeepInterval(remainingMs)/1000,pos=g.root.position;playSpatialCue('semtexBeep',pos.x,pos.y,pos.z,44,1,{playbackRate:rate,maxDuration:Math.max(.055,Math.min(.18,interval*.72))});}

function soundTacticalDetonation(kind,m,{playbackRate=1}={}){if(!m)return;const cue=kind==='flash'||kind==='smoke'?'flashDetonate':kind==='grenadeLauncher'?'glExplosion':kind==='rpg'?'rpgExplosion':'grenadeExplosion',distance=kind==='rpg'?104:kind==='grenadeLauncher'?88:kind==='sticky'||kind==='frag'?82:62,rate=Math.max(.60,Number(playbackRate)||1);playSpatialCue(cue,Number(m.x)||0,Number(m.y)||0,Number(m.z)||0,distance,1,{playbackRate:(.985+Math.random()*.03)*rate,priority:3});}
const unlockAudioFromGesture=e=>{if(!e.isTrusted||e.type==='keydown'&&e.repeat)return;void ensureAudio();if(!shell.inMatch&&!masterMuted)startIntroMusic();};
for(const type of ['pointerdown','pointerup','keydown'])document.addEventListener(type,unlockAudioFromGesture,{capture:true});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)void gameAudio.resume();});

let collisionOverlay=null,collisionOverlayMode='off';
window.breachCollisionDebug=(mode='player')=>{
 collisionOverlayMode=mode||'off';
 if(collisionOverlay){collisionOverlay.removeFromParent();collisionOverlay.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});collisionOverlay=null;}
 if(!mode||mode==='off')return;
 const root=new THREE.Group();collisionOverlay=root;
 for(const p of collisionDebugShapes(worldGeometry,mode)){
  let mesh;const material=new THREE.MeshBasicMaterial({color:(p.channel||mode)==='player'?0x00ffff:0xff44cc,wireframe:true,depthTest:false,transparent:true,opacity:.65});
  if(p.type==='box'){mesh=new THREE.Mesh(new THREE.BoxGeometry(p.w,p.maxY-p.minY,p.d),material);mesh.position.set(p.x,(p.minY+p.maxY)/2,p.z);mesh.rotation.y=authoredYaw(p.rot);}
  else if(p.type==='round'){mesh=new THREE.Mesh(new THREE.CylinderGeometry(p.r,p.r,p.maxY-p.minY,16),material);mesh.position.set(p.x,(p.minY+p.maxY)/2,p.z);}
  else if(p.type==='pyramid'){mesh=new THREE.Mesh(new THREE.ConeGeometry(p.base/Math.sqrt(2),p.h,4),material);mesh.position.set(p.x,p.minY+p.h/2,p.z);mesh.rotation.y=Math.PI/4;}
  else if(p.type==='ramp'){
   const dx=p.x2-p.x1,dz=(p.z2??p.z)-(p.z1??p.z),len=Math.hypot(dx,dz),nx=-dz/len*p.w/2,nz=dx/len*p.w/2,base=p.bottomY??Math.min(p.y0,p.y1),a=p.z1??p.z,b=p.z2??p.z;
   const v=[[p.x1+nx,base,a+nz],[p.x1-nx,base,a-nz],[p.x2-nx,base,b-nz],[p.x2+nx,base,b+nz],[p.x1+nx,p.y0,a+nz],[p.x1-nx,p.y0,a-nz],[p.x2-nx,p.y1,b-nz],[p.x2+nx,p.y1,b+nz]];
   const geom=new THREE.BufferGeometry();geom.setAttribute('position',new THREE.Float32BufferAttribute(v.flat(),3));geom.setIndex([0,1,2,0,2,3,4,6,5,4,7,6,0,4,5,0,5,1,1,5,6,1,6,2,2,6,7,2,7,3,3,7,4,3,4,0]);mesh=new THREE.Mesh(geom,material);
  }
  if(mesh){mesh.renderOrder=10000;root.add(mesh);}else material.dispose();
 }
 worldRoot.add(root);return {mode,shapes:root.children.length};
};


// Map editing is another local world session in the game engine. No second
// first-person renderer, controller, movement simulation or network player.
function builderControlsAvailable(){const e=builderSession?.editor;return !!(e?.play.active&&e.state.phase==='test'&&!e.panel&&!e.hud?.focusActive&&!e.dragging&&e.state.camera==='perspective');}
function playerMovementActive(){return builderSession?builderControlsAvailable():shell.canPlay&&matchAllowsMovement(matchState);}
function playerPointerLocked(){return (canvas.getRootNode().pointerLockElement||document.pointerLockElement||document.webkitPointerLockElement)===canvas;}
function resetBuilderMotion(){keys.clear();resetTouchInput();stopSlide();cancelSprint();traversal=null;ladderState=null;moveVelocityX=moveVelocityZ=verticalVelocity=knockX=knockZ=0;onGround=false;crouched=crouchWanted=false;crouchBlend=0;jumpBufferedUntil=traversalIntentUntil=0;correctionViewX=correctionViewY=correctionViewZ=0;adsWanted=false;adsBlend=0;sniperSwayYaw=sniperSwayPitch=0;}
function addBuilderSelectionOutline(group,parts){
 const bounds=new THREE.Box3();
 for(const p of parts){
  const lo=p.minY??p.bottomY,hi=p.maxY??p.topY,w=p.w||p.r*2,d=p.d||p.r*2,a=(p.rot||0)*Math.PI/180;
  if(!Number.isFinite(lo+hi+w+d))continue;
  for(const u of [-1,1])for(const v of [-1,1])for(const y of [lo,hi])bounds.expandByPoint(new THREE.Vector3(p.x+u*w/2*Math.cos(a)-v*d/2*Math.sin(a),y,p.z+u*w/2*Math.sin(a)+v*d/2*Math.cos(a)));
 }
 if(bounds.isEmpty())return;
 const size=bounds.getSize(new THREE.Vector3()),center=bounds.getCenter(new THREE.Vector3()),box=new THREE.BoxGeometry(size.x+.06,size.y+.06,size.z+.06),edges=new THREE.EdgesGeometry(box);box.dispose();
 const outline=new THREE.LineSegments(edges,new THREE.LineBasicMaterial({color:0x65c6ff,depthTest:false,transparent:true,opacity:.85}));outline.position.copy(center);outline.renderOrder=100;group.add(outline);
}
function clearBuilderGhost(){const b=builderSession;if(!b?.ghost)return;scene.remove(b.ghost);b.ghost.traverse(o=>{o.geometry?.dispose();o.material?.dispose();});b.ghost=null;b.ghostSource=null;}

const editorThumbnailCache=new Map();
function editorThumbnail(item){
 if(['spawn','ladder','road','roadcurve','prefab'].includes(item.type))return null;const key=JSON.stringify(item);if(editorThumbnailCache.has(key))return editorThumbnailCache.get(key);const e=builderSession?.editor;if(!e)return null;
 const object={...item,id:'asset-preview',x:0,z:0,rot:0,yOffset:0},candidate=e.previewObject(object),parts=candidate.parts,previewScene=new THREE.Scene(),group=new THREE.Group();previewScene.background=new THREE.Color(0x253137);previewScene.add(group);previewScene.add(new THREE.AmbientLight(0xffffff,3));previewScene.add(new THREE.HemisphereLight(0xffffff,0x555566,2));const light=new THREE.DirectionalLight(0xffffff,3);light.position.set(-20,40,30);previewScene.add(light);
 const styles=BUILDING_MATERIALS[item.style]||BUILDING_MATERIALS.industrial,materials=item.type==='building'?{wall:worldMat(styles[0],buildingWallTexture(item.style),.92),trim:worldMat(styles[1],'paintedMetal',.78,.1),floor:worldMat(styles[2],'concrete',.97)}:authoredPropMaterials();
 if(Object.values(materials).some(m=>m.map&&!m.map.image)){for(const m of Object.values(materials))m.dispose();editorThumbnailCache.set(key,null);return null;}
 for(const p of parts){const lo=p.minY??p.bottomY,hi=p.maxY??p.topY;if(!(hi>lo))continue;const role=item.type==='building'?(p.role==='wall'?'wall':['trim','rail','roof','stairSide'].includes(p.role)?'trim':'floor'):authoredPropRole(p.role),mesh=new THREE.Mesh(p.type==='round'?new THREE.CylinderGeometry(p.r,p.r,hi-lo,14):new THREE.BoxGeometry(p.w,hi-lo,p.d),materials[role]||materials.default);mesh.position.set(p.x,(lo+hi)/2,p.z);mesh.rotation.y=authoredYaw(p.rot);group.add(mesh);}
 if(item.type==='natural'){for(const mesh of [...group.children]){group.remove(mesh);mesh.geometry.dispose();}const batches=naturalVisualBatches([{...object,type:item.kind}],()=>candidate.geometry.terrainHeight(0,0)),geos=naturalVisualGeometries(),colors=[0x594333,0x41582e,0x465b2c,0x77776d];for(let i=0;i<4;i++){const material=new THREE.MeshStandardMaterial({color:colors[i],roughness:1});materials['nature'+i]=material;for(const t of batches[i]){const mesh=new THREE.Mesh(geos[i],material);mesh.position.set(t.x,t.y,t.z);mesh.scale.set(t.sx,t.sy,t.sz);mesh.rotation.y=t.ry||0;group.add(mesh);}}}
 const bounds=new THREE.Box3().setFromObject(group),center=bounds.getCenter(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3()),span=Math.max(2,size.x,size.y,size.z)*.85,cam=new THREE.OrthographicCamera(-span*1.3,span*1.3,span,-span,.1,1000);cam.position.copy(center).add(new THREE.Vector3(60,48,70));cam.lookAt(center);const target=new THREE.WebGLRenderTarget(192,144),prior=renderer.getRenderTarget(),oldAlpha=renderer.getClearAlpha(),oldColor=renderer.getClearColor(new THREE.Color());target.texture.colorSpace=THREE.SRGBColorSpace;renderer.setRenderTarget(target);renderer.setClearColor(0x253137,1);renderer.clear();renderer.render(previewScene,cam);const bytes=new Uint8Array(192*144*4);renderer.readRenderTargetPixels(target,0,0,192,144,bytes);renderer.setRenderTarget(prior);renderer.setClearColor(oldColor,oldAlpha);const c=document.createElement('canvas');c.width=192;c.height=144;const context=c.getContext('2d'),image=context.createImageData(192,144);for(let y=0;y<144;y++)image.data.set(bytes.subarray((143-y)*192*4,(144-y)*192*4),y*192*4);context.putImageData(image,0,0);const url=c.toDataURL();target.dispose();group.traverse(o=>o.geometry?.dispose());for(const material of Object.values(materials))material.dispose();editorThumbnailCache.set(key,url);return url;
}
function builderTestShot(){
 const b=builderSession;if(!b||b.editor.state.phase!=='test')return null;const ray=b.adapter.ray(),end={x:ray.origin.x+ray.dir.x*250,y:ray.origin.y+ray.dir.y*250,z:ray.origin.z+ray.dir.z*250};let hit=null,previous={...ray.origin};for(let distance=1;distance<=250&&!hit;distance++){const next={x:ray.origin.x+ray.dir.x*distance,y:ray.origin.y+ray.dir.y*distance,z:ray.origin.z+ray.dir.z*distance};hit=trajectorySegmentHit(previous.x,previous.y,previous.z,next.x,next.y,next.z,previous.y-terrainHeight(previous.x,previous.z)-.08,next.y-terrainHeight(next.x,next.z)-.08,0);previous=next;}const point=hit||end;
 if(b.shot){scene.remove(b.shot);b.shot.geometry.dispose();b.shot.material.dispose();}const geometry=new THREE.BufferGeometry().setFromPoints([ray.origin.clone(),new THREE.Vector3(point.x,point.y,point.z)]);b.shot=new THREE.Line(geometry,tracerMaterial(hit?0xffaa55:0x66eebb));b.shotUntil=performance.now()+600;scene.add(b.shot);b.editor.toast(hit?'Projectile hit · '+Math.hypot(point.x-ray.origin.x,point.y-ray.origin.y,point.z-ray.origin.z).toFixed(1)+' m':'Projectile path clear');return {hit:!!hit,point};
}
const builderGameRuntime={
 attach(editor){
   if(!engineReady)throw new Error('Game engine is not ready');
   if(!builderSession){builderSession={editor,revision:-1,parent:canvas.parentNode,next:canvas.nextSibling,style:canvas.getAttribute('style'),map:currentMapId,pose:position.clone(),yaw,pitch,hp,hidden:[]};
     for(const o of [pistolGroup,akimboLeftGroup,akimboRightGroup,assaultGroup,umpGroup,machineGunGroup,shotgunGroup,semiShotgunGroup,sniperGroup,grenadeLauncherGroup,rpgGroup,mantleHands,firstPersonHands])if(o){builderSession.hidden.push([o,o.visible]);o.visible=false;}
   }
   builderSession.editor=editor;builderSession.revision=-1;builderSession.adapter?.dispose();builderSession.adapter=new EditorScene(editor,scene,camera,canvas);canvas.classList.add('builder-game-canvas');editor.stage.prepend(canvas);canvas.style.cssText='position:absolute;inset:0;width:100%;height:100%;display:block;z-index:2;touch-action:none';editor.stage.classList.add('uses-game-runtime');resetBuilderMotion();hp=100;this.teleport(editor.play);onResize();
 },
 teleport(p){if(!builderSession)return;position.set(p.x,p.y-PLAYER_HEIGHT,p.z);yaw=-p.yaw;pitch=p.pitch;resetViewVertical(position.y);resetBuilderMotion();},
 suspend(){if(!builderSession)return;resetBuilderMotion();canvas.style.display='none';clearBuilderGhost();if(playerPointerLocked())document.exitPointerLock?.();},
 close(){const b=builderSession;if(!b)return;this.suspend();if(b.shot){scene.remove(b.shot);b.shot.geometry.dispose();b.shot.material.dispose();}b.adapter?.dispose();canvas.classList.remove('builder-game-canvas');b.editor.stage.classList.remove('uses-game-runtime');b.parent.insertBefore(canvas,b.next?.parentNode===b.parent?b.next:null);if(b.style===null)canvas.removeAttribute('style');else canvas.setAttribute('style',b.style);builderSession=null;setActiveMap(b.map,{rebuild:false});rebuildWorldVisuals();position.copy(b.pose);yaw=b.yaw;pitch=b.pitch;hp=b.hp;resetViewVertical(position.y);for(const [o,visible]of b.hidden)o.visible=visible;onResize();},
 jump:()=>tryJump(),crouch:()=>toggleCrouch(),
 testShot:builderTestShot,
 thumbnail:editorThumbnail,
 debugCollision:mode=>window.breachCollisionDebug(mode),
 ray(point){return builderSession?.adapter.ray(point);},
 transformPointer(kind,event){return builderSession?.adapter.pointer(kind,event)||false;},
 cancelTransform(){builderSession?.adapter.cancel();},
 project(point){return builderSession?.adapter.project(point);},
 pauseInput(){keys.clear();resetTouchInput();cancelSprint();if(playerPointerLocked())document.exitPointerLock?.();}
};
function frameBuilderRuntime(dt){
 const b=builderSession,e=b.editor;if(!e.play.active)return;e.flushBrush?.();if(b.shot&&performance.now()>b.shotUntil){scene.remove(b.shot);b.shot.geometry.dispose();b.shot.material.dispose();b.shot=null;}
 if(b.revision!==e.sceneRev){const runtime=e.runtimePhysical();clearBuilderGhost();currentMapId='custom-map';applyWorldGeometry(runtime.geometry,runtime.collision);rebuildWorldVisuals();b.revision=e.sceneRev;
   if(e.state.phase==='test'&&activeWorldCollision.worldBlockedAt(position.x,position.z,position.y,currentPlayerHeight(),PLAYER_RADIUS)){const sp=e.doc.spawns.find(s=>!activeWorldCollision.worldBlockedAt(s.x,s.z,terrainHeight(s.x,s.z),PLAYER_HEIGHT,PLAYER_RADIUS));position.set(sp?.x||0,terrainHeight(sp?.x||0,sp?.z||0)+(sp?.yOffset||0),sp?.z||0);resetViewVertical(position.y);resetBuilderMotion();}
 }
 if(builderControlsAvailable()){const steps=Math.max(1,Math.min(CLIENT_MAX_SIM_STEPS,Math.ceil(dt/(CLIENT_FIXED_STEP_SEC*1.35))));for(let i=0;i<steps;i++){updateCrouchState(dt/steps);updateMovement(Math.min(MAX_PLAYER_PHYSICS_STEP_SEC,dt/steps));}}else{keys.clear();resetTouchInput();moveVelocityX=moveVelocityZ=0;}
 updateGameFrame(Math.min(dt,MAX_PLAYER_PHYSICS_STEP_SEC));Object.assign(e.play,{x:camera.position.x,y:camera.position.y,z:camera.position.z,yaw:-camera.rotation.y,pitch:camera.rotation.x,feetY:position.y,bodyHeight:currentPlayerHeight()});e.update();b.adapter.update();
 const src=e.state.phase==='edit'&&!e.panel?e.ghost:null;
 if(src!==b.ghostSource){clearBuilderGhost();b.ghostSource=src;if(src){b.ghost=new THREE.Group();for(const p of src.protected||[]){const a=(p.rot||0)*Math.PI/180,points=[[-1,-1],[1,-1],[1,1],[-1,1],[-1,-1]].map(([u,v])=>{const lx=u*(p.w/2+p.pad),lz=v*(p.d/2+p.pad),x=p.x+lx*Math.cos(a)-lz*Math.sin(a),z=p.z+lx*Math.sin(a)+lz*Math.cos(a);return new THREE.Vector3(x,terrainHeight(x,z)+.12,z);});const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:0xffad55,depthTest:false}));line.renderOrder=101;b.ghost.add(line);}const selecting=!!src.selection,color=selecting?0x65c6ff:src.valid!==false?0xd7ff58:0xff5f67;if(selecting)for(const group of src.outlineGroups||[src.parts])addBuilderSelectionOutline(b.ghost,group);for(const p of selecting?[]:src.parts){if(src.brush){const points=[];for(let i=0;i<=64;i++){const a=i/64*Math.PI*2,x=p.x+Math.cos(a)*p.w/2,z=p.z+Math.sin(a)*p.d/2;points.push(new THREE.Vector3(x,terrainHeight(x,z)+.09,z));}const ring=new THREE.Line(new THREE.BufferGeometry().setFromPoints(points),new THREE.LineBasicMaterial({color:0xd7ff58,depthTest:false}));ring.renderOrder=100;b.ghost.add(ring);continue;}const lo=p.minY??p.bottomY,hi=p.maxY??p.topY,w=p.w||p.r*2,d=p.d||p.r*2;if(!Number.isFinite(lo+hi+w+d)||hi<=lo)continue;const mesh=new THREE.Mesh((p.type==='round'?new THREE.CylinderGeometry(p.r,p.r,hi-lo,12):new THREE.BoxGeometry(w,hi-lo,d)),new THREE.MeshBasicMaterial({color,wireframe:false,transparent:true,opacity:.28,depthWrite:false}));mesh.position.set(p.x,(lo+hi)/2,p.z);mesh.rotation.y=-(p.rot||0)*Math.PI/180;b.ghost.add(mesh);}scene.add(b.ghost);}}
 const c=hudCtx;c.setTransform(hudScale,0,0,hudScale,0,0);c.clearRect(0,0,viewW,viewH);c.textBaseline='middle';if(touchGameplayControlsVisible())drawTouchControls(c,hudLayout||computeHudLayout(),performance.now(),(e.state.phase==='edit')?'fly':true);hudTexture.needsUpdate=true;
 renderer.autoClear=true;const savedFog=scene.fog;if(e.state.camera==='top')scene.fog=null;renderer.render(scene,b.adapter.activeCamera());scene.fog=savedFog;renderer.autoClear=false;renderer.clearDepth();renderer.render(hudScene,hudCamera);renderer.autoClear=true;
}
