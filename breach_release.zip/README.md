## Breach Rebuild Phase 4.1

Version **1.45.0-alpha.4.3**, protocol **101**.

This is the hardware-validation gate for the Phase 4 movement/lifecycle foundation. Production combat, bots, full maps, audio and killstreaks are still intentionally excluded.

- Deploy 1_SERVER_REPO_UPLOAD to the existing Cloudflare Worker endpoint breach-online; the client performs /health version/protocol preflight before opening WebSocket.
- Deploy 2_CLIENT_REPO_UPLOAD to a static host.
- Join the alpha room and open Hardware Validation.
- Run the appropriate profile on desktop keyboard/mouse, desktop controller, iPhone Safari touch, and iPhone + Bluetooth controller.
- Close the validation panel while exercising controls; the run continues. Reopen it to see the next unmet check.
- Stop & Evaluate only when the checklist is complete, then export the JSON report.
- A clean gate requires PASS with zero runtime errors and zero invariant violations.
