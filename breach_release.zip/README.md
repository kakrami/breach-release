# BREACH PROJECT HANDOFF / OPERATIONS README

This file exists so a new ChatGPT conversation can continue the Breach project without the user having to re-explain the deployment and packaging workflow.

## CURRENT BASELINE

Current release: Breach v1.28.0
Protocol: 47

### v1.28.0 shooting model and ballistic presentation
- Center-screen reticle is the authoritative ballistic aim.
- Recoil changes the reticle/camera aim, so later rounds actually climb unless the player compensates.
- Stationary ADS first shots are highly accurate; sustained fire builds recoverable firing heat/spread.
- Movement, airborne state, crouch, and partial ADS transition feed the same shared accuracy model on client and server.
- First-person tracers originate at the visible weapon muzzle and converge onto the authoritative center-screen trajectory.
- Large local world-space bullet spheres were replaced with brief tracers so strafing no longer makes shots appear to launch from the side of the screen.
- Near-wall muzzle obstruction is checked server-side so center-screen aiming cannot shoot through cover when the weapon is physically blocked.
- Shotgun audio/flash triggers once per shell instead of once per pellet event.

### v1.27.2 desktop fullscreen correction
- Reverted the broader v1.27.1 fullscreen/menu changes back to the v1.27.0 behavior baseline.
- Mobile/touch fullscreen entry, menu gating, rotation handling, and fullscreen exit behavior remain unchanged from v1.27.0.
- The only behavioral change is that desktop Start Match no longer requests fullscreen automatically; desktop captures pointer lock (or uses the active controller) while fullscreen remains an explicit user action.

This ZIP is the canonical source package for the next change. Treat it as the current baseline unless the user supplies a newer breach_release.zip.

Do not assume older architecture is correct just because it existed previously. Fix root causes cleanly and remove conflicting or obsolete logic instead of layering patches.


### v1.27.0 native controller support
- Added first-class browser Gamepad API support for Bluetooth/USB Xbox-style controllers on desktop and mobile.
- Standard mapping: left stick move, right stick look, LT ADS, RT fire, A jump/mantle, B crouch, X reload, Y weapon swap, LB flash, RB sticky, View scoreboard, Menu pause/resume.
- D-pad provides direct primary/pistol, fire-mode, and weapon-swap shortcuts; right-stick click cycles sniper zoom or assault fire mode.
- Uses radial stick deadzones and curved right-stick response while preserving analog movement magnitude.
- Input ownership switches cleanly among touch, mouse/keyboard, and controller. Touch combat controls are hidden while controller input owns the game and return when the screen is touched.
- Desktop pointer lock is no longer required while controller input is active, and loss of pointer lock does not pause an active controller session.
- Controller scoreboard supports right-stick scrolling.

### v1.26.4 traversal camera fix
- Rebuilt the first-person mantle/vault arm view model so geometry stays safely in front of the camera near plane and cannot engulf the view.
- Mantle view-model materials render camera-space without world-depth clipping.
- Hardened self-player ID filtering and removes any accidental local third-person remote model before rendering.

## REPOSITORIES

There are three GitHub repositories involved:

1. kakrami/breach-release
   - Release/orchestration repository.
   - The user uploads ONE file here: breach_release.zip.
   - It also contains .github/workflows/deploy.yml.
   - GitHub Actions extracts the ZIP and pushes each half to its target repository.

2. kakrami/breach-online
   - Server repository.
   - Receives the contents of:
     1_SERVER_REPO_UPLOAD/
   - Cloudflare automatically deploys when this repository changes.

3. kakrami/breach
   - Client repository.
   - Receives the contents of:
     2_CLIENT_REPO_UPLOAD/
   - GitHub Pages automatically deploys when this repository changes.

The user works primarily from a phone and should NOT have to manually split the release between repositories.

## NORMAL RELEASE FLOW

The intended recurring workflow is:

1. ChatGPT edits/tests the game.
2. ChatGPT returns a ZIP named EXACTLY:
   breach_release.zip
3. The user replaces breach_release.zip in the root of kakrami/breach-release.
4. The user commits the change.
5. The Deploy Breach GitHub Action runs.
6. The action validates the ZIP.
7. The action pushes server files to kakrami/breach-online.
8. The action pushes client files to kakrami/breach.
9. Existing Cloudflare and GitHub Pages integrations deploy automatically.
10. The user reloads the game after both deployments finish.

Do not ask the user to rename the ZIP. Generate it with the correct name.

## REQUIRED ZIP STRUCTURE

breach_release.zip must have these items at the ZIP ROOT:

README.md
1_SERVER_REPO_UPLOAD/
2_CLIENT_REPO_UPLOAD/

There must NOT be an extra outer folder around those directories.

CORRECT:
breach_release.zip
  README.md
  1_SERVER_REPO_UPLOAD/worker.js
  2_CLIENT_REPO_UPLOAD/index.html

WRONG:
breach_release/
  1_SERVER_REPO_UPLOAD/
  2_CLIENT_REPO_UPLOAD/

Never put the deployment workflow/setup ZIP in place of the game ZIP.

README.md is documentation only. The deployment workflow should sync only the two deployment directories, so this README is not pushed into either runtime repository unless explicitly desired.

## DEPLOYMENT SAFETY RULES

Never use a destructive repository sync such as:

rsync -a --delete

That previously risked deleting persistent assets from the target repositories.

Release deployment must be non-destructive:
- overwrite files present in the release,
- add new files present in the release,
- do NOT automatically delete unrelated files already in the repo.

The safe pattern is equivalent to:

rsync -a --checksum SOURCE/ DESTINATION/

while excluding .git/ and .github/.

If an obsolete runtime file truly needs to be deleted, handle that intentionally and explicitly after determining that removal is safe.

## AUDIO ASSETS

The client has an existing persistent audio/ asset directory containing the game's WAV files.

Recent release ZIPs intentionally did not duplicate the WAV library. Therefore:
- NEVER wipe audio/ during deployment.
- Existing/custom audio files in kakrami/breach must survive game-code releases.
- audio-engine.js and client.js may reference files under audio/.
- If the user asks for a completely self-contained release, first obtain/include the actual audio assets rather than fabricating or silently omitting them.

Do not infer that a no-audio source package gives permission to remove audio from the live client repository.

## GITHUB DEPLOY TOKEN

The release workflow uses the repository secret:

DEPLOY_TOKEN

It must be a GitHub fine-grained personal access token with access to:
- kakrami/breach-online
- kakrami/breach

Repository permission required:
- Contents: Read and write

The release repository itself does not need to be selected merely so the workflow can push to the other two repositories.

A 403 while pushing means token/repository access should be checked before changing game code.

## PACKAGE CONTENT RULES

For normal Breach releases:
- Include the runtime files required by the server and client.
- Do not include release notes, helper tools, tests, generators, or extra deployment documentation unless explicitly requested.
- This README.md is now the intentional exception because the user requested a persistent project handoff file.
- Keep the server/client package clean and production-oriented.
- Preserve repository-owned persistent assets that are outside the release package.

## RELEASE VERSIONING

The visible game version must be updated for real releases.

Server and client game-config.js must agree on:
- APP_VERSION
- PROTOCOL_VERSION

Shared runtime files that exist in both halves must remain byte-identical where designed to be shared, especially movement/collision/world definitions.

Do not bump protocol merely for ordinary client/server code changes unless the wire contract actually changes.

## TESTING EXPECTATIONS

Do not hand the user a release after only editing syntax.

At minimum, before packaging:
- run node --check on every JavaScript file,
- verify all local relative imports resolve,
- verify server/client APP_VERSION matches,
- verify server/client PROTOCOL_VERSION matches,
- verify intentionally shared modules are synchronized,
- validate ZIP structure and ZIP integrity,
- run targeted regression tests for the system changed,
- run broader game/server smoke tests when practical,
- browser-boot the client when practical,
- treat startup failure as a release blocker.

The user expects root-cause fixes and regression testing, not repeated patches.

## CURRENT MOVEMENT / COLLISION BASELINE (v1.27.0)

Do not casually undo this architecture.

The movement/collision work leading to v1.26.4 included:
- wall contact no longer damps the player's complete planar velocity; collision resolves the blocked displacement while preserving tangential wall-slide speed,
- entering a vault/mantle clears stale visual server-correction offsets so the camera cannot be shifted into a wall or window frame during the forced traversal,
- window traversal carries an explicit first-person ceiling clearance and ducks the eye through the opening,
- shared client/server movement and collision definitions,
- production step-up handling for stairs and walkable ledges,
- separation of standing headroom checks from ordinary body collision,
- mantle/climb resolution based on reachable landing surfaces,
- explicit window traversal portal behavior,
- traversal through windows in both directions,
- upper-floor window exits that allow natural falling instead of requiring a same-height exterior landing,
- off-center window approaches guided through the opening rather than snagging the frame,
- ordinary walls/floors/ceilings remaining solid,
- server authoritative validation using the same movement rules.

The v1.26.3 movement regression was continuous wall contact damping the entire planar velocity and traversal carrying stale visual correction offsets into forced movement. The earlier upper-story window regression also remains covered: window behavior must always be tested from BOTH SIDES and across ALL floors.

For future movement work, test real paths rather than just proving that a geometric opening exists.

## USER'S DEVELOPMENT PREFERENCES

For Breach changes:
- Fix the root cause.
- Do not layer fixes on top of old fixes.
- Rebuild/consolidate a subsystem when the existing architecture is the problem.
- Integrate features natively into gameplay/UI instead of attaching them as isolated patches.
- Test the actual packaged artifact before delivery.
- Keep instructions concise.
- Give the user a ready-to-upload package rather than delegating avoidable file work.
- The release artifact should normally be named breach_release.zip.

## IMPORTANT NEW-CHAT INSTRUCTION

If this README is being read in a new chat:

1. Use the breach_release.zip containing this README as the starting source.
2. Inspect the actual current code before proposing a fix.
3. Preserve the three-repository deployment architecture described above.
4. Preserve persistent audio and unrelated repository files.
5. Make and test the requested change.
6. Return a new file named breach_release.zip with this README updated when the operational baseline materially changes.
